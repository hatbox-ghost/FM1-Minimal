# Pacific Field — source and license inventory

Pacific Field is a GPL-3.0-only workstation derived from FartyPants/fm1-nachtfahrt, with inherited DUB-1, AMB-1, X0X, FoMni and Felucca platform code. [LICENSE](LICENSE) is the project license. All original source notices and additional upstream permissions remain in place. Distributions of the combined binary need the complete corresponding source, including adapters, build scripts and the upstream files used to build it.

| Component in this tree | Origin / notice | License |
| --- | --- | --- |
| `fm1/pacific/` workstation, routing, UI and adapters | Pacific Field; inherited source notices retained | GPL-3.0-only |
| `fm1/firmware/`, `fm1/tools/`, `fm1/web/` platform and legacy application | NACHTFAHRT → DUB-1 / AMB-1 → Felucca lineage; Leo Kuroshita / Hügelton Instruments and other authors named in files | GPL-3.0-only; additional legacy DSP notices in `fm1/LEGACY-LICENSING.md` |
| BRANCH exciter `fm1/pacific/upstream/elements/` | Mutable Instruments Elements and stmlib, Emilie Gillet; original MIT text in selected files | MIT |
| Shared Clouds `fm1/pacific/upstream/clouds/` | Mutable Instruments Clouds and stmlib, Emilie Gillet; pinned in upstream manifest | MIT |
| Shared Oliverb `fm1/pacific/upstream/oliverb/` | Clouds Parasites / stmlib, Emilie Gillet and Matthias Puech; pinned in upstream manifest | MIT |
| TORT `fm1/pacific/upstream/obervave/`, `obervave-*.inc` | zvenson/OberVave; commit and detailed inherited credits in `PIN.json` / `LICENSING.md` | GPL-3.0-only |
| Optional bench HALL `fm1/pacific/hall-lite.h` | Felucca HALL, Leo Kuroshita / Hügelton Instruments, revision `a4f007c` | GPL-3.0-only |
| LEAD `fm1/pacific/upstream/fmini/`, `fmini-core.inc`, `lead*.c` | FMini-1 / Felucca, Leo Kuroshita / Hügelton Instruments | GPL-3.0-only combined source; selected engine material also has upstream MIT grant in `LICENSE-Engines` |
| TEMPLE FM routing `fm1/pacific/upstream/fm-lab/algorithms.h` and adapted TEMPLE headers | FM LAB / dxsloop; Dexed/MSFA routing by Google, Pascal Gauthier and C port by Sven Trogus; `LICENSING.md` and `Apache-2.0.txt` retained | Apache-2.0 AND GPL-3.0-only (see file header) |
| Sequencer/editor adaptations in `fm1/pacific/app.c`, `block_seq.h` | Melodee, Kerem Kilic / Ellic Studio; original attribution retained in `app.c` | GPL-3.0-only |
| Sequencer `fm1/pacific/upstream/sloop/` and adapted sequencer headers | isod89/sloop-fm1; pinned manifest | GPL-3.0-only |
| `fm1/assets/fonts/` Barlow / Terminus | The Barlow Project Authors / Dimitar Toshkov Zhekov; bundled OFL notices | SIL OFL 1.1 |
| `references/` source archives and derived WASM test oracles | Pinned Pacific Field commits, same complete corresponding source supplied next to binaries | Same GPL-3.0-only combined work and retained upstream notices |

The Clouds/Oliverb adaptation details are in `fm1/pacific/ORIGINAL-FX.md`. Elements and synth reuse details remain in the historical implementation reports under `docs/`. Unused legacy application source is retained for provenance; source presence does not mean it is linked into Pacific Field.

The JieLi SDK and Linux PI32v2 compiler are external build prerequisites. They are not bundled in the source export. Native packaging reads `uboot.boot`, `cfg_tool.bin` and `cfg/eq_cfg_hw.bin` from the SDK; the inherited build identifies the AC79 SDK as Apache-2.0. Preserve and inspect the SDK's own license when redistributing its packaging artifacts. No Beads DSP is included in the current production effects build.

M-VAVE, FM-1, Mutable Instruments, Prophet and other product names identify hardware, provenance or design references; they do not imply endorsement. No third-party ownership notices have been replaced with a Pacific Field ownership claim.
