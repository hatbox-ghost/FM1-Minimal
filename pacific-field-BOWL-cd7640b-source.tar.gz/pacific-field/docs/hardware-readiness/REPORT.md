# FM-1 hardware readiness

**Hold installation.** The current browser source now produces a real PI32v2 firmware package. It passes the package and memory checks and boots in strict chip emulation. Its audio still misses the deadline under representative layered or wet playing. No physical FM-1 was connected or flashed.

## Source and target changes

- Baseline is the current four-instrument browser workstation, including the LCD project menu, sequencer snap and undo, shared tuning, and circular Clouds delay artwork. The separate engine-bank experiment is outside this candidate.
- The JieLi toolchain has C headers and target libraries but lacks C++ standard headers. The native build now supplies the small subset used by the pinned DSP, uses the target math/compiler runtime and resolves the missing freestanding C calls. It does not replace Clouds, Oliverb or Elements.
- Compiling individual data tables into separate sections lets the existing linker discard tables with no live references. The first linked attempt exceeded the 581,564-byte XIP slot by 148,076 bytes. Per-table collection put it inside the slot.
- Native code keeps three accidental double-precision call sites in single precision. Browser audio identity still matches its reference. The native voice iterator skips inactive routing slots, and LEAD collects input arrays at its existing 32-sample render boundary. The effects adapter skips untouched buses and uses the same SRC taps without a 64-bit index per tap. Starting an untouched effects bus on first send changes its initial timing and modulation phase relative to the continuously running browser effects. This difference has no physical listening verification yet.
- App storage and the updater’s loader accept the two known 1 MiB SPI NOR IDs. Other IDs remain excluded from project writes or app replacement. Only the original ID was exercised in chip emulation. The rescue script still has its original narrower allowlist.

## Linker and storage

| Resource | Measured | Limit or reserve |
|---|---:|---:|
| App image | 407,244 B | 581,564 B slot, 174,320 B free |
| Ordinary RAM, data and BSS | 87,608 B | 98,304 B, 10,696 B free |
| Audio and display pool | 331,408 B | 344,064 B, 12,656 B free, including 8,192 B protected reserve |
| Project payload | 15,772 B | 16,128 B, 356 B free |
| User stack allocation | 24,320 B | 256 B guard |
| Supervisor stack allocation | 7,936 B | 256 B guard |

The linker check reports 909 RAMTEXT instructions with no calls, no soft-double routines, and no out-of-HAL register access. Stack figures are reserved sizes from the linker, not runtime high-water measurements. The loader only replaces the app region at `0x04000–0x92fff`. Project copies start at `0xD0000` and `0xD4000`, and panel calibration starts at `0xDC000`.

## Runtime evidence

Native binaries were run in strict mode in the FM-1 chip emulator at 240 MHz. The measured values below are the firmware's own ISR timer counters read from emulated RAM. They are diagnostic estimates, not measured physical CPU load. At 44.1 kHz a 256-frame half-buffer has a 5.805 ms deadline.

| Native scenario | Peak render | Result |
|---|---:|---|
| Before sparse voices and first-send FX gating, silent boot | 33.80 ms | Missed deadline |
| Sparse candidate, one dry BOWL note | 5.61 ms | Audible PCM, very little margin |
| Sparse candidate, layered playing with a six-note TEMPLE chord | 11.66 ms | Missed deadline |
| Sparse candidate, both sends up | 14.39 ms | Missed deadline |
| Latest SRC candidate, both sends up | 13.36 ms | Missed deadline |

A 100 ms time-weighted diagnostic trace with both sends up attributed about 22% of sampled core-0 time to the shared FX frame adapter. Oliverb processing and the two Elements resonator paths were also among the larger named hotspots. These are emulator samples and do not establish hardware utilization.

LCD SAVE produced 67 flash erase/program operations in emulation and wrote a valid 15,772-byte project to the expected first extent. LCD RECALL restarted from that flash image, with the boot counter advancing to two and no flash writes during recall. This does not validate physical flash timing or a stock-to-Pacific OTA transfer.

The browser CI gate passed all 51 independent suites after the native dependency fixes, including the PCM identity, storage, and six-note TEMPLE tests. The later native-only scheduling changes were also checked against the browser PCM and panel suites. A complete build produced the first sparse candidate. For the final SRC candidate, the vendor compiler intermittently crashed on unchanged translation units under the Linux VM. The changed effects object and missing object were recompiled, then the standard linker, guards and packager ran against the retained objects. A second clean rebuild has not been demonstrated for that candidate.

Bench-only package SHA-256 is `2a0f54f43b5b4e4e56f3c8a11c26b4b3416b2042cbab88aea0fe880950584a46`.

## Upstream references

- [Felucca](https://github.com/hugelton/Felucca) at `a4f007c` provides the platform, linker, updater and target-budget comparison.
- [SLOOP](https://github.com/isod89/sloop-fm1) at `bac9c05` provides the newer UC25HQ80 identification and a reference for measured second-core work with fallback.
- [Karma](https://github.com/eatyourgreensstudio-dotcom/karma-fm1) at `739b6c9` documents separate storage ownership and target budget tests. Its project storage is firmware-specific.
- [FM-1 chip emulator](https://github.com/joakimeriksson/fm1-emu) at `9de1ef0` ran the packaged native binary. It did not execute the browser WASM.

## Release criteria

Keep the first physical unit on its existing firmware until the native candidate has margin under layered dry playback and simultaneous wet sends. Profile the native render hotspots, then verify a bounded division of work, with SLOOP's second-core fallback as a reference. Repeat native package, cold boot, SAVE/RECALL, update recovery, sustained layered audio, and stack checks on the actual unit. No voice count or pool guard was reduced to produce this bench candidate.

## Audio deadline follow-up

**The updated package is bench-only.** The render loop now avoids per-sample timing math for idle sequencers, computes each running arp's interval once per render block, uses a fast wrap for common oscillator phases, reuses the TEMPLE timbre envelope gain across operators, and configures BOWL's shared Elements field and exciters once per block. All four engines, both effects, and TEMPLE's six voices remain available.

The table compares the previously packaged candidate and the updated one using identical scripted panel inputs. The earlier 11.66 ms layered result above came from a separate run and is excluded from this comparison. PCM was present in all three scenarios. When audio or UI service falls behind, the timestamped panel script can be serviced at different points in the render stream, so these captures are timing evidence and should not be used as PCM identity fixtures.

| Strict chip scenario | Previous peak | Updated peak | Updated late halves |
|---|---:|---:|---:|
| Dry BOWL | 5.622 ms | 5.310 ms | 1 |
| BOWL with both sends raised | 13.357 ms | 13.068 ms | 2 |
| Layered performance with six TEMPLE notes | 15.957 ms | 16.263 ms | 26 |

The changes save about 0.3 ms in each single-instrument scenario. Layered playback remains over budget and the measured peak increased. The dry scenario still misses a DMA handoff during the run despite staying under the 5.805 ms render limit.

The updated app occupies 408,252 B of the 581,564 B slot. Ordinary RAM is 87,628 B of 98,304 B. Audio and display pool use remains at 331,408 B, with 12,656 B free including the 8,192 B protected reserve. Project layout and stack allocation are unchanged. The vendor compiler rebuilt the changed objects, then the standard linker, guards, and packager ran with retained objects from the previous build.

The 51-suite CI validation passed during this pass. The final BOWL change was separately checked with the Elements behavior, isolation, and DSP/UI PCM identity suites. The PCM fixture stayed intact.

To repeat the chip test from the repository root, use the emulator revision above and the map produced with the package. The test retains PCM, RAM dumps, and logs and returns a failing status for missed deadlines, late DMA handoffs, missing audio, a crash, or a timeout.

```sh
python3 fm1/tools/check_native_deadline.py /path/to/fm1-live \
  fm1/build/hardware-timing/pacific-field-TIMING-BENCH-ONLY.fwsc \
  fm1/build/hardware-timing/target.map fm1/build/hardware-timing/deadline
```

Updated bench-only package SHA-256 is `99df3579858fb07204e6787eb0f4a7f353bcd29d648620f343b171b30d2de45f`.

### First physical unit

Keep the unit on its factory firmware for initial checks. Record the factory version and unit revision, check that the panel and headphone output work, and identify the SPI flash through a verified read-only probe before attempting an update. Use the matching stock recovery image for that revision. The installation candidate still needs a clean deadline check, an update and recovery test, then sustained dry and wet playing, a six-note TEMPLE chord with the other engines active, and SAVE/RECALL across a power cycle on the device.

## Fixed-workload native performance audit

**The FM-1 candidate remains bench-only.** The release target is below 4 ms per 256-frame render half. The deadline at 44.1 kHz is 5.805 ms. The timings here are firmware timer measurements in strict chip emulation. Physical FM-1 timing and installation remain unverified.

### Workload and instrumentation

The opt-in benchmark runs factory patches with fixed gain and exact note-on commands. It resets engine and effects state between cases, warms each case for 16 halves, then records 80 consecutive halves. For the combined test it holds one BOWL note, three POLY notes, six TEMPLE notes, and one LEAD note, with both sends at 70. Clouds is in its factory delay mode. The readout checks all four held-note masks before reporting timing. It also reports the final DMA half's native 24-bit output fingerprint, calculated from all 512 interleaved words after the timing and handoff counters are sampled.

The effects adapter column is the measured wet frame path minus the original Clouds and Oliverb processing calls. It includes the SRC, block staging, meters, and return mix. Per-frame timer instrumentation itself adds overhead. The native panel check below uses the ordinary package with the profiling code compiled out.

A deadline miss counts a measured render longer than the 5.805 ms budget. The existing late DMA counter checks whether DMA changed halves while the ISR was rendering. At severe overload, DMA can advance an even number of halves and return to the same index. A zero late count can therefore coexist with a deadline miss on every render.

### Matched results

All times below are milliseconds per 256-frame half. Each count is out of 80 measured halves.

| Fixed workload | Average before → after | Peak before → after | Deadline misses before → after | Late DMA before → after |
|---|---:|---:|---:|---:|
| idle | 3.752 → 3.743 | 3.867 → 3.853 | 0 → 0 | 0 → 0 |
| bowl-1 | 5.193 → 5.065 | 5.309 → 5.166 | 0 → 0 | 0 → 0 |
| poly-1 | 4.544 → 4.529 | 4.627 → 4.609 | 0 → 0 | 0 → 0 |
| lead-1 | 4.214 → 4.171 | 4.312 → 4.271 | 0 → 0 | 0 → 0 |
| temple-1 | 5.567 → 5.000 | 5.665 → 5.137 | 0 → 0 | 0 → 0 |
| temple-3 | 8.679 → 6.951 | 8.821 → 7.111 | 80 → 80 | 80 → 80 |
| temple-6 | 13.276 → 9.809 | 13.411 → 9.923 | 80 → 80 | 0 → 80 |
| clouds | 9.549 → 8.943 | 9.630 → 9.062 | 80 → 80 | 80 → 80 |
| oliverb | 9.667 → 9.147 | 9.793 → 9.293 | 80 → 80 | 80 → 80 |
| both-fx | 12.959 → 12.129 | 13.098 → 12.303 | 80 → 80 | 0 → 0 |
| layered-wet | 25.156 → 20.950 | 25.316 → 21.123 | 80 → 80 | 0 → 80 |

The TEMPLE renderer's average for one, three, and six notes fell from 2.055 / 5.143 / 9.733 ms to 1.556 / 3.491 / 6.354 ms. Those times isolate the instrument render path from the rest of the workstation. Idle BOWL alone costs 1.589 ms after optimization, including its shared Elements atmosphere. One dry BOWL note brings that renderer to 2.896 ms. The isolated dry POLY and LEAD renderers average 1.097 and 0.918 ms with one note.

| Wet workload | Clouds DSP before → after | Oliverb DSP before → after | Shared adapter before → after |
|---|---:|---:|---:|
| clouds | 1.309 → 1.343 | 0.000 → 0.000 | 2.568 → 2.065 |
| oliverb | 0.000 → 0.000 | 1.531 → 1.587 | 2.486 → 2.019 |
| both-fx | 1.475 → 1.513 | 1.706 → 1.771 | 4.064 → 3.236 |
| layered-wet | 1.487 → 1.530 | 1.720 → 1.787 | 4.125 → 3.336 |

The layered average improved 16.7%. TEMPLE and the effects remain the dominant costs. In the layered run the two original effect calls together cost 3.317 ms and the adapter adds 3.336 ms. BOWL costs 3.185 ms and POLY costs 2.510 ms with three notes. The apparent increase in late handoffs in the layered case follows the DMA index check wrapping as described above. Both builds miss all 80 deadlines.

The final native render-half fingerprints matched before and after in all 11 workloads, including six-note TEMPLE and the layered wet case. A separate comparison of the target code paths built to WASM matched bit for bit over 256,000 four-engine frames. This covers the exercised workloads. Hardware underruns and the resulting output stream can still differ as scheduling changes. No audio fixture was updated.

### Changes

- TEMPLE's neutral sine-pair patch uses a direct form of the existing six-operator expression with the same sine table, modulation and accumulation order. The general renderer still handles all waveforms, feedback, ratios, routing, and edited envelopes. Note slots and polyphony are unchanged.
- Oscillator wrap uses the target's existing float bit representation for common phases, with the original floor path for larger excursions. An initial use of ordinary `memcpy` emitted calls in the inner loop and made TEMPLE slower. The measured build uses the existing bit union instead.
- BOWL avoids recomputing filter coefficients at a scheduled refresh if all coefficient inputs are identical. It omits the Elements side result that the adapter already discarded. Exciters, modal partials, bowed atmosphere, and the refresh cadence are preserved. The coefficient cache adds 976 B to the pool.
- The FX adapter processes a stereo pair together to share the ring traversal and tap loads. Each channel retains the original coefficients, phase, tap count, and accumulation order. Original Oliverb and Clouds DSP are unchanged.

### Second-core scheduling

SLOOP 2.8.5 uses separately owned accumulators, disjoint render jobs, a guarded core-1 stack, and a cache-synchronized job mailbox. It performs a boot self-test and holds the second core when a job fails validation or times out. Its idle loop lives in RAM so flash erase can take place with the audio IRQ stopped and core 1 quiescent. In strict emulation the distributed SLOOP package ran 5.16 million core-1 instructions in a 3.2 s fault-free test. Injecting RAM misreads at rate 0.001 with seed 7 produced 212 misreads and 0.67 million core-1 instructions, consistent with the worker being stopped early. This exercises the reference and the emulator's fault path. [SLOOP core-1 HAL and mailbox](https://github.com/isod89/sloop-fm1/blob/bac9c05/firmware/hal/fm1_cpu1.h)

For Pacific Field, command drain, timing advancement, note ownership, and the mixer must remain ordered on the audio core. Rendering arbitrary layers concurrently would race the shared `current` pointer, routing scratch, and clock state. A worker would need an explicit context and immutable job descriptor, separate voice state and output, and a bounded join against the remaining DMA budget. An FX worker would need exclusive DSP state ownership and a drain barrier for save, recall, reset, and updater operations. SLOOP's 8 ms wait and replay of a partially executed job are unsuitable for Pacific Field's deadline and stateful FX. A timeout must hold the worker and resume from known state rather than advance partially mutated voices or delay lines twice.

No second-core worker was enabled. The optimized single-core combined average is roughly 21 ms. Even an ideal, contention-free split of that work would take roughly 10.5 ms per half, and moving the intact six-note TEMPLE renderer alone would exceed 5.805 ms. These are sizing estimates from the measured workload, with real core scaling and contention still unknown. A first worker prototype can use isolated stateless SRC tiles to validate publication, cancellation, and injected faults before any stateful handoff. The measurements call for substantially less serial work before a second core can close the gap.

### Reproducing the audit

Build with `PACIFIC_FIELD=1 PF_NATIVE_BENCH=1` using the normal SDK and toolchain procedure. Save the generated bench-only package and matching linker map before building another variant. Run these commands from the repository root with the pinned emulator revision listed above.

```sh
FM1_STRICT=1 FM1_BENCH_KEYS='' FM1_DUMPRAM=fm1/build/profile.ram \
  /path/to/fm1-live --fwsc fm1/build/pacific-NATIVE-BENCH-ONLY.fwsc --bench 13500
python3 fm1/tools/read_native_bench.py fm1/build/pacific-NATIVE-BENCH-ONLY.map fm1/build/profile.ram
```

The ordinary optimized candidate uses 410,476 B of app flash, 87,628 B of ordinary RAM, and 332,384 B of the audio/display pool. That leaves 11,680 B of pool space, including the 8,192 B protected reserve. Project storage and stack reservations are unchanged. The changed files were rebuilt and linked against retained unchanged objects, and the standard package, linker, register access and RAMTEXT checks passed. The ordinary panel gate still fails at 5.202 ms dry peak with one late handoff, 12.348 ms wet peak with two, and 12.552 ms layered peak with 90. Panel events can land on different render blocks under overload. Use the fixed workload for the matched comparison.

The full validation profile passed all 51 independent suites, including the 1,800-second LFO soak, 600-second sequencer soak, browser PCM identity, TEMPLE polyphony and preservation, and native storage. The ordinary bench-only package tested above has SHA-256 `9905b82a1aaeb175f45d632aeb0140e5299f5ac80d67a42347b1fd70e98b3e02`. No hardware was flashed.
