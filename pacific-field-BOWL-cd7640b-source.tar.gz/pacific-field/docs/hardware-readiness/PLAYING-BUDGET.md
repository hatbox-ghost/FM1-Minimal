# FM-1 playing budget and optional native bench profile

The reference firmware remains the default build. The optional `PF_PLAYABLE_BENCH=1` build keeps all four instruments and the project format, and selects HALL, a native stereo delay, Q24 Clock for compatible TEMPLE patches, and a dormant BOWL policy. It has a separate bench-only filename and the release packager rejects the flag. No hardware was flashed. Timings come from strict chip emulation, with a 5.805 ms hard deadline and 4 ms margin target.

## Workload

The playing matrix covers 72 cases per variant. It exercises each instrument by itself, including one, three, and six TEMPLE notes, all six pairs and all four triples, and two four-instrument loads. Each case is tested dry and with delay, reverb, and both. Pairs and triples use the matching subset of a moderate workload with one BOWL, three POLY, three TEMPLE, and one LEAD note. The heavy case uses six BOWL, six POLY, six TEMPLE, and one monophonic LEAD note. This is a heavy keyboard workload. Additional generator voices, dense arps, sequencer overlap, and arbitrary patch extrema can cost more.

The benchmark verifies the held-note masks, warms 64 render halves, and measures 40. Average, peak, deadline miss counts, DMA half changes, per-engine costs, and final-half fingerprints are in the raw TSVs. Late DMA detects a changed half index. An even number of handoffs can return DMA to the same index and produce zero late counts despite overruns. Count a case as passing only if both the deadline miss and late counters are zero.

## Results

| Build | Zero-miss and zero-late cases | Of those, peak ≤ 4 ms | Instrumented ordinary RAM | Pool |
|---|---:|---:|---:|---:|
| Original DSP | 5 / 72 | 0 | 92,552 B | 332,384 B |
| HALL + original Clouds SRC, Q24 prototype | 15 / 72 | 6 | 96,280 B | 311,904 B |
| HALL + short native delay, Q24 prototype | 30 / 72 | 12 | 96,312 B | 250,504 B |
| Implemented bench profile | 30 / 72 | 11 | 96,680 B | 316,040 B |

| Implemented workload | FX | Average | Peak | Deadline misses / 40 | Late DMA / 40 |
|---|---|---:|---:|---:|---:|
| BOWL-1 | both | 5.585 ms | 5.656 ms | 0 | 0 |
| POLY-1 | both | 3.656 ms | 3.819 ms | 0 | 0 |
| LEAD-1 | both | 3.334 ms | 3.507 ms | 0 | 0 |
| TEMPLE-1 | both | 3.899 ms | 4.012 ms | 0 | 0 |
| TEMPLE-3 | both | 5.094 ms | 5.153 ms | 0 | 0 |
| TEMPLE-6 | dry | 6.562 ms | 6.710 ms | 40 | 40 |
| TEMPLE-6 | both | 7.061 ms | 7.216 ms | 40 | 40 |
| POLY+LEAD | both | 5.369 ms | 5.475 ms | 0 | 0 |
| TEMPLE+LEAD | both | 5.643 ms | 5.740 ms | 0 | 0 |
| four-moderate | dry | 10.066 ms | 10.160 ms | 40 | 40 |
| four-moderate | both | 10.604 ms | 10.707 ms | 40 | 40 |
| four-heavy | dry | 20.208 ms | 20.329 ms | 40 | 40 |
| four-heavy | both | 20.751 ms | 20.870 ms | 40 | 40 |

The fastest measured trio was POLY+TEMPLE+LEAD (dry) at 7.413 ms peak. HALL plus original Clouds returned 0 clean results among the delay-active cases. For the implemented profile, the perfect two-core split of the measured four-instrument wet peak is 5.354 ms at moderate load and 10.435 ms at heavy load. These are optimistic lower bounds for that measured work, with no mailbox, synchronization, or shared-cache cost. A second core could be useful for moderate patches after isolating jobs. It offers no sufficient path for the tested heavy patch.

The interactive profile without timing instrumentation uses 316,972 B of app flash, 91,756 B of ordinary RAM, and 316,040 B of pool. It leaves 28,024 B of pool including the 8,192 B protected reserve. The rebuilt reference uses 410,492 B of app flash, 87,628 B of ordinary RAM and 332,384 B of pool. The earlier reference package is preserved separately. The builds pass package, linker, RAMTEXT and register access checks.

The panel-driven gate for the implemented profile still fails. It measured 5.295 ms dry with one late buffer, 5.874 ms with both sends and two late buffers, and 10.813 ms layered with 188 late buffers. The matrix uses sustained scripted notes after warm-up. The panel gate also observes boot, note entry, control changes, and handoffs, so a steady-state pass alone is insufficient.

## Practical configuration

The most promising listening candidate is the optional HALL and native-delay profile, with solo instruments or a tested duo. Use the reference for the Oliverb and Clouds sound, and for comparisons with the full original Clock path. The lean profile trades Clouds' texture and long delay behavior for substantially lower work, and HALL has a different tail and stereo response. A profile save keeps the original FX settings for later recall. Keep the engine capable of six notes and use conservative workload selection until there is measured headroom for six sustained notes under the hard deadline.

The reference gate passed 51 independent suites after the change, with the CI 120-second soaks. The same reference passed its full-duration 1,800-second LFO and 600-second sequencer soaks before the isolated bench option was added. Optional-profile tests passed the six-note contribution, held-note renderer switch, BOWL lifecycle, one-second delay timing, HALL wet signal, and project round-trip checks. No physical validation was performed.

## Implementation

- **HALL** is the Felucca fixed-point eight-line network, running internally at half rate with a native 44.1 kHz interface. The profile exposes size, damping, send, return and FX master. Its mono-summed input and stereo return have a different response from Oliverb, as measured in the preceding impulse audit. Oliverb remains in the reference. [Felucca HALL source](https://github.com/hugelton/Felucca/blob/a4f007c9211ea5b37298c01ff6d73430fe2cb96a/firmware/src/fx.c)
- **Native delay** has 49,152 stereo int16 frames, about 1.11 seconds. It retains free/synced timing, feedback, send and return, with a short two-tap crossfade when the delay time changes. Longer synced selections show a limit indicator. This is a clean stereo feedback delay. The reference build is the place to use Clouds pitch, granular, stretch, freeze, and longer timing. Their saved values are retained across profile saves.
- **TEMPLE** retains six voices, all three sine pairs, the Clock movement controller, amp ADSR and signed FM envelope. The phase and step are quantized on the Q24 path. A patch using expanded routing, non-sine waves, custom operator ratios, envelope, level, or feedback automatically uses the existing renderer. Phase is transferred between representations when editing while a voice is sounding. The matrix measures the Q24-compatible factory patch. The expanded renderer can cost more.
- **BOWL** suspends the shared Elements field only with its generator inactive and its active/releasing voice mask empty. Keyboard and sequenced triggers wake it before rendering. While a voice releases, the field continues. On wake the dormant field resumes its stored state, so the first note's evolving texture can differ from the reference. Tests exercise silence, wake, release, and generator restart.

## Clouds at 44.1 kHz

A direct-clock experiment in the prior audit established the available SRC saving, with a changed impulse response and shortened time constants. A rate-correct port would have to recalibrate the looping and freeze crossfades, delay slewing and sync conversion, grain duration and trigger density, WSOLA timing and search size, normalized filters, feedback/freeze smoothing, and internal diffusion, pitch and reverb delay lines. Pitch ratios expressed in semitones remain dimensionless. The grain and freeze durations and their modulation rates must still be rescaled. The low-fidelity long-delay path has its own 2× converter and would move from 16 to 22.05 kHz. [Clouds processor source](https://github.com/pichenettes/eurorack/blob/master/clouds/dsp/granular_processor.cc)

The two current 65,408-byte histories need about 49.5 KB of additional storage in total to preserve duration and resolution. The previously measured HALL + direct Clouds pool was 308,212 B, leaving 27,660 B after the 8,192 B reserve. That is a shortfall of about 21.8 KB before retuning the internal lines. The scratch effects cannot simply overlap. In particular, diffusion and the feedback-dependent reverb can both be active during freeze. A smaller history or lower precision would be a measurable tradeoff. This pass did not produce a rate-correct Clouds implementation.

## Scheduling and admission

The best split would hand a complete, explicitly owned DSP job to core 1 while core 0 owns note/timing events and the ordered mix. SLOOP uses a guarded stack, checked mailbox, cache synchronization, quiescence for flash access, and disables the worker after faults. Pacific Field's `current` context and shared render scratch rule out concurrently calling the existing layer renderer as-is. BOWL or TEMPLE could be a job after isolating its context. Wet sends depend on the dry mix, and HALL plus the native delay is too small a job to justify a worker. An FX pipeline would need explicit state ownership, extra buffers, and a defined recovery boundary for a partially advanced delay line. [SLOOP core-1 HAL](https://github.com/isod89/sloop-fm1/blob/bac9c05ea7627449405aa10e48da21d75b6c8c56/firmware/hal/fm1_cpu1.h)

Dynamic admission can cap new notes by patch and active workload, with cost reserved for release tails and wet returns. The matrix already shows that limiting simultaneous instrument count buys more than simply reducing TEMPLE voices in a fully layered patch. A policy that protects six TEMPLE slots would have to reduce other concurrent work. No automatic note stealing or worker was added. The engine's six-note capability remains available in every build, while some configurations still miss the timing deadline.

## Building and checking the profile

Use the existing native toolchain with `PACIFIC_FIELD=1 PF_PLAYABLE_BENCH=1`. Leave `PF_NATIVE_BENCH` unset for the normal interactive panel. Build without the profile flag to get the reference effects and synth behavior.

For the host transition checks, set `PF_PLAYABLE_BENCH=1` and a separate `PF_WASM_OUTPUT` when running `fm1/pacific/build-fx.py`. Pass the resulting WASM and ordinary browser WASM to `fm1/pacific/bench/test-playable-bench.mjs`. The tests verify BOWL wake and tails, the generator, six-note TEMPLE, envelope edits, live renderer fallback, and reference → profile → reference project recall. The separate TEMPLE polyphony test confirms all six notes contribute to PCM.
