# Pacific Field native architecture experiments

**Keep the current instruments and effects as the reference.** The fastest prototype averaged 11.871 ms and peaked at 11.981 ms per 256-frame half, against a 5.805 ms deadline. This is a strict FM-1 chip emulator result, using firmware timer counters. No hardware was flashed or timed.

## Matched native workload

The benchmark uses the same fixed workload as the previous audit. One BOWL note, three POLY notes, six TEMPLE notes, one LEAD note, factory voices, fixed output gain, and both sends at 70. Each variant measures 80 halves after 16 warm-up halves. Note masks confirmed the held keys. All six prototypes link and pass the native memory, RAMTEXT, and register-access checks. The experimental source was compiled through a separate overlay in the build directory.

| Architecture | Average | Peak | Deadline misses / 80 | Late DMA / 80 | Pool |
|---|---:|---:|---:|---:|---:|
| Reference Oliverb + original Clouds SRC | 20.950 ms | 21.123 ms | 80 | 80 | 332,384 B |
| HALL + original Clouds SRC | 18.172 ms | 18.255 ms | 80 | 80 | 311,904 B |
| HALL + Clouds clocked directly at 44.1 kHz | 16.013 ms | 16.076 ms | 80 | 0 | 308,212 B |
| HALL + 44.1 kHz stereo feedback delay | 14.288 ms | 15.210 ms | 80 | 0 | 250,504 B |
| Same FX + dormant BOWL | 14.537 ms | 15.338 ms | 80 | 0 | 250,504 B |
| Same + two-pair clock TEMPLE | 11.871 ms | 11.981 ms | 80 | 0 | 250,504 B |
| Same + three-pair Q24 clock TEMPLE | 11.943 ms | 12.061 ms | 80 | 0 | 250,504 B |

Late DMA observes the half index before and after rendering. If DMA advances an even number of halves the index can match despite an overrun. The independent deadline count records the overload.

## Effects

| Layered FX cost | Reverb DSP | Clouds DSP | Adapter and native delay |
|---|---:|---:|---:|
| Reference | 1.787 ms | 1.530 ms | 3.336 ms |
| HALL + original Clouds SRC | 0.369 ms | 1.409 ms | 2.314 ms |
| HALL + direct Clouds | 0.345 ms | 1.634 ms | 0.214 ms |
| HALL + native delay | 0.341 ms | — | 0.220 ms |

- **Felucca HALL** accepts 44.1 kHz blocks and uses its original eight-line fixed-point network internally at 22.05 kHz. The bench wrapper uses a mono sum of the stereo send, HALL's stereo return, a local Q15 sine table, and size/damping mapping. With original Clouds still active it saved **2.778 ms overall** and about **1.022 ms** in the shared adapter. The isolated BOWL + reverb scenario went from 9.147 ms to 5.487 ms average. Original Clouds had the same native delay-only PCM fingerprint in this variant. The HALL wrapper has size and damping. It does not implement the current Oliverb freeze, diffusion, modulation, or low-cut controls. It is an alternate reverb with a different response. [Felucca HALL source](https://github.com/hugelton/Felucca/blob/a4f007c9211ea5b37298c01ff6d73430fe2cb96a/firmware/src/fx.c)
- **Direct Clouds** is an upper-bound cost probe. It removes the adapter around Clouds while keeping its 32-sample algorithm and passing in 44.1 kHz data. It saved **4.937 ms overall with HALL**, of which about **3.122 ms** came from the adapter. The processor still assumes 32 kHz, so frame-count durations shrink to about 72.6% and time-derived features move. A genuine retarget would need new sample-rate constants, grain/window timing, sync math, filter calibration, and history sizing. Preserving a given history duration at the higher rate needs about 38% more samples. This test does not establish a rate-correct Clouds port. [Original Clouds processor](https://github.com/pichenettes/eurorack/blob/master/clouds/dsp/granular_processor.cc)
- **Native stereo delay** uses a 32,768-frame int16 stereo ring, feedback, and tempo or free timing. This and HALL saved **6.662 ms overall**, with the former 3.336 ms adapter reduced to 0.220 ms including the delay work. The prototype gives clean repeats and has a 743 ms ceiling. It lacks Clouds granular/stretch, pitch, freeze, interpolation character, and long divisions. Keeping both algorithms selectable would require exclusive, reset-on-switch reuse of their workspace or a larger pool. The 81,880 B pool saving shown above comes from linking out the reference FX workspace in that bench build.

A separate impulse render used identical inputs and settings in target-configured WASM to check the wet signal. Oliverb first crossed the threshold at 2.43 ms and peaked at 31.18 ms. HALL first crossed at 21.90 ms and peaked at 53.49 ms, with less side energy at the measured gain. The native delay produced its first repeat at the specified 280 ms. The direct Clouds probe changed the impulse shape. These are unmatched-level signal measurements, with no listening or physical playback evaluation.

## BOWL and TEMPLE

The dormant BOWL variant keeps timing and note ownership alive. It skips the shared Elements field only when the generator is off and the active/releasing render mask is empty. The BOWL idle bucket fell from **1.578 to 0.347 ms** in the paired native-delay builds. The BOWL voice still needs its full DSP while playing. Pausing the field changed the first-note PCM fingerprint, since the random exciter and resonator history stopped advancing during silence. Treat **about 1.2 ms** as a dormant-only saving. A production version would need an explicit wake policy and checks for attack, release, and generator transitions.

The Braun Study creates three FM pairs per voice with sine carriers, upper harmonics, per-pair modulation, and clock-derived movement. The current TEMPLE already has a fast path for a neutral three-pair patch. Removing extra parameter pages alone would save little render time. The prototypes kept the current clock controller, quartz/mechanical drift and orbit, six-note polyphony, amp envelope and signed FM envelope amount. They removed the expanded operator-level path from these bench renders.

| Clock variant | One note DSP | Three notes DSP | Six notes DSP | Total with only six TEMPLE notes |
|---|---:|---:|---:|---:|
| Existing TEMPLE, same FX and dormant BOWL | 1.497 ms | 3.374 ms | 6.210 ms | 8.379 ms |
| Two sine pairs with amp and FM envelope | 1.024 ms | 2.147 ms | 3.822 ms | 6.007 ms |
| Three sine pairs with Q24 phase and cached increments | 1.045 ms | 2.214 ms | 3.965 ms | 6.150 ms |

The two-pair version saved **2.388 ms** in the isolated six-note renderer, with a changed spectrum from removing one pair. The three-pair version saved **2.245 ms** and kept the extra pair, with changed PCM from fixed-point phase and the reduced operator-control path. The Q24 prototype costs an additional **3,600 B of ordinary RAM** versus the two-pair build. Neither reduced TEMPLE's allocated voice pool in the experiment. Keeping the full editor and engine as an available reference requires its state or a shared representation. This shows meaningful CPU savings from a smaller clock path, with no demonstrated RAM savings or reason to replace TEMPLE in the workstation.

## Deadline decision

The best layered peak is **11.981 ms**. Perfectly even two-core execution of that amount of work would still peak at **5.991 ms**, before coordination, shared memory contention, or UI costs outside the timed render. The three-pair architecture has a similar ideal bound of 6.031 ms. The existing four-engine architecture therefore has no demonstrated route to 5.805 ms with margin from these changes alone. Real hardware timing and second-core scaling remain open.

The cheapest benchmark paths were intentionally separate from the normal firmware. The source overlay and raw timing tables are available in the benchmark source archive. The restored reference package matches the previously tested bench-only package byte for byte.
