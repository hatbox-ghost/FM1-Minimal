#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Read fixed-workload timing counters from a strict fm1-live RAM dump."""
import argparse
from pathlib import Path
import re
import struct

CASES = (
    ("idle", (0, 0, 0, 0)), ("bowl-1", (1, 0, 0, 0)),
    ("poly-1", (0, 1, 0, 0)), ("lead-1", (0, 0, 0, 1)),
    ("temple-1", (0, 0, 1, 0)), ("temple-3", (0, 0, 3, 0)),
    ("temple-6", (0, 0, 6, 0)), ("clouds", (1, 0, 0, 0)),
    ("oliverb", (1, 0, 0, 0)), ("both-fx", (1, 0, 0, 0)),
    ("layered-wet", (1, 3, 6, 1)),
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("map", type=Path)
    parser.add_argument("ram", type=Path)
    args = parser.parse_args()
    match = re.search(r"^\s+(0x[0-9a-fA-F]+)\s+pf_bench_results\s*$",
                      args.map.read_text(), re.MULTILINE)
    if not match:
        parser.error("map lacks pf_bench_results")
    offset = int(match[1], 16) - 0x01C00000
    raw = args.ram.read_bytes()
    row = struct.Struct("<17I")
    print("case avg_us peak_us deadline_misses late_dma bowl_us poly_us temple_us "
          "lead_us clouds_us oliverb_us fx_adapter_us pcm_hash")
    for name, voices in CASES:
        count, total, peak, missed, late, *data = row.unpack_from(raw, offset)
        offset += row.size
        if count != 80 or tuple(mask.bit_count() for mask in data[:4]) != voices:
            parser.error(f"{name}: incomplete run or unexpected note mask {data[:4]}")
        bowl, poly, temple, lead, fx, clouds, oliverb, pcm_hash = data[4:]
        costs = (bowl, poly, temple, lead, clouds, oliverb, fx - clouds - oliverb)
        print(name, round(total / count), peak, missed, late,
              *(round(cost / (24 * count)) for cost in costs), f"{pcm_hash:08x}")


if __name__ == "__main__":
    main()
