#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Exercise a packaged Pacific Field build in the strict FM-1 chip emulator."""

import argparse
import os
from pathlib import Path
import re
import struct
import subprocess

RAM_BASE = 0x01C00000
DEBUG_MAGIC = 0x44424731
HALF_FRAMES = 256
SAMPLE_RATE = 44100
SCENARIOS = (
    ("dry", 3200, "2000:pot:710,2100:n7,2600:n7^"),
    ("wet", 3400, "1900:pot:710,1980:FX,2020:FX^,2080:e2:70,2150:e3:70,2250:n7,2850:n7^"),
    ("layers", 4500,
     "1500:pot:710,1750:SCL,1810:SCL^,1870:n7,1960:n7^,2050:e6:1,"
     "2200:SCL,2260:SCL^,2320:n7,2390:n7^,2410:n9,2490:n9^,2510:n11,"
     "2590:n11^,2610:n12,2690:n12^,2710:n14,2790:n14^,2810:n16,2890:n16^,"
     "2990:e6:1,3140:SCL,3200:SCL^,3280:n7,3390:n7^,3500:e6:1,"
     "3650:SCL,3720:SCL^,3800:n7,3900:n7^"),
)


def run_scenario(args, offset, name, duration, keys):
    ram = args.output / (name + ".ram")
    pcm = args.output / (name + ".pcm")
    log = args.output / (name + ".log")
    ram.unlink(missing_ok=True)
    pcm.unlink(missing_ok=True)
    # Ignore any bench overrides inherited from a developer's shell.
    env = {key: value for key, value in os.environ.items() if not key.startswith("FM1_")}
    env.update(FM1_STRICT="1", FM1_BENCH_KEYS=keys,
               FM1_BENCH_WAV=str(pcm), FM1_DUMPRAM=str(ram))
    with log.open("wb") as output:
        subprocess.run(
            [str(args.emulator.resolve()), "--fwsc", str(args.package),
             "--bench", str(duration)], env=env, stdout=output,
            stderr=subprocess.STDOUT, timeout=120, check=True,
        )
    # Read en_dbg as laid out in main_fm1.c. A dump may end during an ISR.
    magic, halves, peak, _, _, late, _, ui_frames, _, _, boots, stage, crashes = (
        struct.unpack_from("<13I", ram.read_bytes(), offset)
    )
    if magic != DEBUG_MAGIC or not halves or not ui_frames or boots != 1 or stage or crashes:
        raise ValueError("missing runtime counters, incomplete boot or firmware crash")
    peak_pcm = max((abs(sample) for (sample,) in struct.iter_unpack("<h", pcm.read_bytes())),
                   default=0)
    passed = peak_pcm > 0 and 0 < peak and peak * SAMPLE_RATE <= HALF_FRAMES * 1_000_000 and late == 0
    print(f"{'PASS' if passed else 'FAIL'} {name}: {peak} us peak, {late} late halves, "
          f"{halves} rendered halves, PCM peak {peak_pcm}")
    return passed


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("emulator", type=Path, help="path to fm1-live")
    parser.add_argument("package", type=Path, help="native .fwsc to test")
    parser.add_argument("linker_map", type=Path, help="map from the same build")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    match = re.search(r"^\s+(0x[0-9a-fA-F]+)\s+en_dbg\s*$",
                      args.linker_map.read_text(), re.MULTILINE)
    if not match or int(match[1], 16) < RAM_BASE:
        parser.error("missing en_dbg RAM address in linker map")
    offset = int(match[1], 16) - RAM_BASE
    args.output.mkdir(parents=True, exist_ok=True)
    print(f"Strict emulation deadline {HALF_FRAMES * 1_000_000 / SAMPLE_RATE:.1f} us")
    passed = []
    for name, duration, keys in SCENARIOS:
        try:
            passed.append(run_scenario(args, offset, name, duration, keys))
        except (OSError, ValueError, struct.error, subprocess.SubprocessError) as error:
            print(f"FAIL {name}: {error}")
            passed.append(False)
    return 0 if all(passed) else 1


if __name__ == "__main__":
    raise SystemExit(main())
