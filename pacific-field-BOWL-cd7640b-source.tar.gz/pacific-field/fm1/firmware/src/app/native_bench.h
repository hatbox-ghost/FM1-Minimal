/* SPDX-License-Identifier: GPL-3.0-only
 * Fixed performance workloads for a bench build. No panel inputs are required.
 * Never distribute this build for installation. */
#include "../../../pacific/native-bench.h"

enum { BENCH_WARM = 16, BENCH_MEASURE = 80 };
static const struct {
    uint8_t voices[4], sends;
} bench_cases[] = {
    {{0,0,0,0},0}, {{1,0,0,0},0}, {{0,1,0,0},0}, {{0,0,0,1},0},
    {{0,0,1,0},0}, {{0,0,3,0},0}, {{0,0,6,0},0},
    {{1,0,0,0},1}, {{1,0,0,0},2}, {{1,0,0,0},3}, {{1,3,6,1},3},
};

struct bench_result {
    uint32_t count, total_us, peak_us, missed, late, active[4], ticks[BENCH_BUCKETS], pcm_hash;
} pf_bench_results[sizeof bench_cases / sizeof *bench_cases];
uint32_t pf_bench_ticks[BENCH_BUCKETS];
static unsigned bench_case, bench_block;

static void bench_prepare(void)
{
    static const int notes[] = {7,9,11,12,14,16};
    if (bench_case >= sizeof bench_cases / sizeof *bench_cases || bench_block)
        return;
    pf_init();
    pf_apply();
    for (int m = 0; m < 4; m++) {
        pf_post(PF_MODE, m, 0);
        pf_post(PF_PARAM, 24, bench_cases[bench_case].sends & 1 ? 70 : 0);
        pf_post(PF_PARAM, 27, bench_cases[bench_case].sends & 2 ? 70 : 0);
        for (unsigned i = 0; i < bench_cases[bench_case].voices[m]; i++)
            pf_post(PF_RECALL_KEY, notes[i], 0);
    }
}

static void bench_capture(uint32_t us, uint32_t late, const int32_t *pcm)
{
    if (bench_case >= sizeof bench_cases / sizeof *bench_cases)
        return;
    if (bench_block >= BENCH_WARM) {
        struct bench_result *r = &pf_bench_results[bench_case];
        r->count++;
        r->total_us += us;
        if (us > r->peak_us)
            r->peak_us = us;
        r->missed += us > HALF_FRAMES * 1000000u / FS;
        r->late += late;
        for (int m = 0; m < 4; m++)
            r->active[m] = pf_layer_active(m);
        for (int i = 0; i < BENCH_BUCKETS; i++)
            r->ticks[i] += pf_bench_ticks[i];
    }
    if (++bench_block == BENCH_WARM + BENCH_MEASURE) {
        /* Sample the last complete DMA half before moving to a new workload.
         * Hash after the timer and handoff check, outside the measured render. */
        uint32_t hash = 2166136261u;
        for (unsigned i = 0; i < HALF_WORDS; i++)
            hash = (hash ^ (uint32_t)pcm[i]) * 16777619u;
        pf_bench_results[bench_case].pcm_hash = hash;
        bench_block = 0;
        bench_case++;
    }
}
