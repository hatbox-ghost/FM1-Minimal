// Exercises the optional profile through the shared panel and render interfaces.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {modeDelta} from '../test-panel-order.mjs';
import {setTemple} from '../test-temple-controls.mjs';

const {instance:{exports:e}} = await WebAssembly.instantiate(fs.readFileSync(process.argv[2]), {
  wasi_snapshot_preview1: new Proxy({}, {get: () => () => 0}),
  env: new Proxy({}, {get: () => () => 0}),
});
e._initialize();
e.web_audio_boot();

function peak(blocks) {
  let max = 0;
  for (let i = 0; i < blocks; i++) {
    e.web_audio_render(128);
    for (const sample of new Float32Array(e.memory.buffer, e.web_out_l(), 128)) {
      assert(Number.isFinite(sample));
      max = Math.max(max, Math.abs(sample));
    }
  }
  return max;
}

assert.equal(peak(100), 0, 'dormant BOWL is silent');
e.web_keys(1 << 7);
assert(peak(36) > 1e-5, 'keyboard attack wakes the BOWL field');
e.web_keys(0);
peak(32);
assert(peak(32) > 1e-5, 'release continues beyond the note minimum gate');
peak(5500);
assert.equal(e.web_layer_active(0), 0);
e.web_buttons(1 << 10);
e.web_buttons((1 << 10) | (1 << 6));
e.web_buttons(0);
assert(peak(100) > 1e-5, 'generator wakes an idle field without a key');

e.web_audio_boot();
e.web_enc(2, modeDelta(e, 2));
peak(1);
const chord = [0, 4, 7, 11, 14, 18].reduce((mask, note) => mask | 1 << note, 0);
e.web_keys(chord);
assert(peak(80) > 1e-5);
assert.equal(e.web_layer_active(2), chord);
setTemple(e, 34, 20);
setTemple(e, 38, 150);
assert(peak(80) > 1e-5, 'Q24 Clock with FM envelope is audible');
setTemple(e, 22, 3);
assert(peak(80) > 1e-5, 'expanded wave edit falls back with held voices');
assert.equal(e.web_temple_runtime(22), 3);
setTemple(e, 22, 0);
assert(peak(80) > 1e-5, 'returning to sine pairs keeps the chord sounding');
assert.equal(e.web_layer_active(2), chord);
assert.equal(e.web_dropped(), 0);
console.log('PASS playable bench wake, release, generator, six-note clock and live renderer fallback');

if (process.argv[3]) {
  async function boot(path, saved) {
    const {instance:{exports:w}} = await WebAssembly.instantiate(fs.readFileSync(path), {
      wasi_snapshot_preview1: new Proxy({}, {get: () => () => 0}),
      env: new Proxy({}, {get: () => () => 0}),
    });
    w._initialize();
    if (saved) {
      new Uint8Array(w.memory.buffer, w.web_store(0), saved.length).set(saved);
      w.web_store_set_len(0, saved.length);
    }
    w.web_audio_boot();
    return w;
  }
  function save(w) {
    assert.equal(w.web_save_project(), 0);
    return new Uint8Array(w.memory.buffer, w.web_store(0), w.web_store_len(0)).slice();
  }
  const original = await boot(process.argv[3]);
  original.web_open_page(37);
  original.web_enc(3, 1);
  original.web_audio_render(128);
  assert.equal(original.web_fx_setting(9), 1);
  const originalProject = save(original);
  const profile = await boot(process.argv[2], originalProject);
  assert.equal(profile.web_fx_setting(9), 1, 'inactive Clouds setting is preserved');
  const profileProject = save(profile);
  assert.equal(profileProject.length, originalProject.length);
  const restored = await boot(process.argv[3], profileProject);
  assert.equal(restored.web_fx_setting(9), 1, 'original Clouds mode survives a profile save and reload');
  console.log('PASS reference → profile → reference project compatibility');
}

e.web_open_page(37);
e.web_enc(3, (1000 - e.web_fx_setting(8)) / 5);
peak(1);
assert.equal(e.web_fx_setting(8), 1000);
e.web_fx_reset();
let firstRepeat = -1;
for (let at = 0; at < 45056 && firstRepeat < 0; at += 1024) {
  e.web_fx_probe(0, 1024, Number(at === 0));
  const samples = new Float32Array(e.memory.buffer, e.web_out_l(), 1024);
  const index = samples.findIndex(sample => Math.abs(sample) > 1e-5);
  if (index >= 0) firstRepeat = at + index;
}
assert.equal(firstRepeat, 44100, 'native ring supports a one-second repeat at 44.1 kHz');
e.web_fx_reset();
e.web_fx_probe(1, 1024, 1);
assert(new Float32Array(e.memory.buffer, e.web_out_l(), 1024).some(sample => Math.abs(sample) > 1e-5));
console.log('PASS native one-second delay timing and HALL wet signal');
