/* SPDX-License-Identifier: GPL-3.0-only
 * Shared stereo buses; rational 44100/32000 adapter around original DSP. */
#include "fx.h"
#include "native-bench.h"
#include "../firmware/src/app/plat.h"
#include <string.h>
#include "fx-src.h"
int16_t pf_fx_settings[20];
int16_t pf_fx_delay_sync,pf_fx_delay_division,pf_fx_bpm=96;
typedef struct {float input[4][32],output[4][128],inBlock[2][64],outBlock[2][64],cfg[20];uint32_t head,phase,native,fill,faults;int ready;
#ifdef PACIFIC_FIELD
 uint8_t live;
 uint16_t history;
#endif
} FxState;
static FxState state EN_POOL;
static volatile float activity[4];
float pf_fx_meter(int i){return i>=0&&i<4?activity[i]:0;}
void pf_fx_init(void){memset(&state,0,sizeof state);for(int i=0;i<4;i++)activity[i]=0;pf_clouds_init();pf_oliverb_init();}
#ifdef PACIFIC_FIELD
/* Convolve a stereo pair in one pass, preserving the tap order in each channel. */
static inline void src_pair(const float *left,const float *right,const float *coeff,
                            unsigned size,unsigned head,unsigned taps,float *l,float *r){
 float a=0,b=0;
 unsigned first=head+1<taps?head+1:taps;
 for(unsigned t=0;t<first;t++){
  float w=coeff[t];
  a+=left[head-t]*w;
  b+=right[head-t]*w;
 }
 for(unsigned t=first;t<taps;t++){
  float w=coeff[t];
  a+=left[size+head-t]*w;
  b+=right[size+head-t]*w;
 }
 *l=a;*r=b;
}
#endif
void pf_fx_frame(float dl,float dr,float rl,float rr,float *L,float *R){FxState *s=&state;
#ifdef PACIFIC_FIELD
 if(!s->live){
  /* Before the first send, no delay or reverb history exists. */
  if(dl==0&&dr==0&&rl==0&&rr==0){*L=*R=0;return;}
 }
 if(dl!=0||dr!=0)s->live|=1;
 if(rl!=0||rr!=0)s->live|=2;

#endif
 float values[4]={dl,dr,rl,rr};for(int c=0;c<4;c++)s->input[c][s->head&31]=values[c];s->phase+=32000;
 if(s->phase>=44100){
 s->phase-=44100;int phase=(int)(s->phase*63u/32000u);
#ifdef PACIFIC_FIELD
 for(int bus=0;bus<2;bus++){
  float *dest=&s->inBlock[bus][s->fill*2];
  if(s->live&(1u<<bus))
   src_pair(s->input[2*bus],s->input[2*bus+1],fxDown[phase],32,s->head&31,32,dest,dest+1);
  else dest[0]=dest[1]=0;
 }
#else
 for(int c=0;c<4;c++){
  float v=0;
  for(int t=0;t<32;t++)v+=s->input[c][(s->head-t)&31]*fxDown[phase][t];
  s->inBlock[c/2][s->fill*2+c%2]=v;
 }
#endif
 s->fill++;s->native++;
#ifdef PACIFIC_FIELD
 if(s->history<128)s->history++;
#endif
 if(s->fill==32){for(int i=0;i<20;i++){float target=pf_fx_settings[i];if(!s->ready||i==9||i==14)s->cfg[i]=target;else s->cfg[i]+=.04f*(target-s->cfg[i]);}s->ready=1;
#ifdef PACIFIC_FIELD
 if(s->live&1){PF_BENCH_BEGIN(effectTick);pf_clouds_block(s->inBlock[0],s->outBlock[0],s->cfg);PF_BENCH_END(effectTick,BENCH_CLOUDS);}
 if(s->live&2){PF_BENCH_BEGIN(effectTick);pf_oliverb_block(s->inBlock[1],s->outBlock[1],s->cfg);PF_BENCH_END(effectTick,BENCH_OLIVERB);}
#else
 pf_clouds_block(s->inBlock[0],s->outBlock[0],s->cfg);
 pf_oliverb_block(s->inBlock[1],s->outBlock[1],s->cfg);
#endif
 float peaks[4]={0};for(int j=0;j<32;j++)for(int c=0;c<4;c++){float input=s->inBlock[c/2][j*2+c%2];if(input<0)input=-input;if(input>peaks[c/2])peaks[c/2]=input;float v=s->outBlock[c/2][j*2+c%2];if(!__builtin_isfinite(v)){s->faults++;v=0;}s->output[c][(s->native-32+j)&127]=v;float peak=v<0?-v:v;if(peak>peaks[2+c/2])peaks[2+c/2]=peak;}for(int i=0;i<4;i++)activity[i]=peaks[i]>activity[i]*.995f?peaks[i]:activity[i]*.995f;s->fill=0;}}
 s->head++;float out[4]={0};int ph=63-(int)(s->phase*63u/44100u);
#ifdef PACIFIC_FIELD
 unsigned taps=s->history>=94?32:s->history<63?0:s->history-62;
 unsigned head=(s->native-63u)&127u;
 for(int bus=0;bus<2;bus++)if(s->live&(1u<<bus))
  src_pair(s->output[2*bus],s->output[2*bus+1],fxUp[ph],128,head,taps,&out[2*bus],&out[2*bus+1]);
#else
 for(int c=0;c<4;c++)for(int t=0;t<32;t++){int64_t at=(int64_t)s->native-63-t;if(at>=0)out[c]+=s->output[c][at&127]*fxUp[ph][t];}
#endif
 /* Raise both current wet returns by another 30% (1.3 * 1.3 = 1.69).
 * Sends, feedback, dry signal and the original algorithms remain unchanged. */float master=s->cfg[19]*.0169f;*L=(out[0]*s->cfg[15]*.01f+out[2]*s->cfg[7]*.01f)*master;*R=(out[1]*s->cfg[15]*.01f+out[3]*s->cfg[7]*.01f)*master;}
uint32_t pf_fx_bytes(void){return sizeof state+pf_clouds_bytes()+pf_oliverb_bytes();}

uint32_t pf_fx_faults(void){return state.faults;}
