/* SPDX-License-Identifier: GPL-3.0-only */
#pragma once
#ifdef PF_NATIVE_BENCH
#include "../firmware/hal/fm1_time.h"

enum { BENCH_FX = 4, BENCH_CLOUDS, BENCH_OLIVERB, BENCH_BUCKETS };
extern uint32_t pf_bench_ticks[BENCH_BUCKETS];
#define PF_BENCH_BEGIN(name) uint32_t name = fm1_ticks()
#define PF_BENCH_END(name, bucket) (pf_bench_ticks[bucket] += fm1_ticks() - (name))
#else
#define PF_BENCH_BEGIN(name) ((void)0)
#define PF_BENCH_END(name, bucket) ((void)0)
#endif
