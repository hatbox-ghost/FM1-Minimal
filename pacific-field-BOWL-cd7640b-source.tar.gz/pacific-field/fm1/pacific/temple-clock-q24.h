/* SPDX-License-Identifier: GPL-3.0-only
 * Optional native bench renderer for compatible three-pair Clock patches. */
#define CLOCK_PHASE 16777216u
typedef struct {
 uint32_t c[3], m[3], ci[3], mi[3], stamp;
 float last_inc;
 const float (*config)[5];
 uint8_t active;
} TempleClockPhase;
static TempleClockPhase temple_clock_phase[PF_NV];
static uint32_t temple_clock_stamp;

static inline float temple_clock_sine(uint32_t phase){
 phase &= CLOCK_PHASE-1;
 unsigned i=phase>>13;
 return sine[i]+(sine[i+1]-sine[i])*(float)(phase&8191u)*(1.f/8192.f);
}

static void temple_clock_envelopes(int slot,Voice *voice,int gate,float attack,float release){
 if(!temple_block.clockPairs){
  temple_envelopes(slot,voice,gate,attack,release);
  return;
 }
 TempleEG *e=&temple_eg[slot];
 if(temple_params[39]&1)
  voice->env=temple_adsr(voice->env,&e->amp,gate,temple_block.ampA,temple_block.ampD,temple_block.ampS,temple_block.ampR);
 else{
  voice->env+=(gate-voice->env)*(gate?attack:release);
  e->amp=gate?TE_SUSTAIN:TE_RELEASE;
 }
 e->tone=temple_adsr(e->tone,&e->stage,gate,temple_block.toneA,temple_block.toneD,temple_block.toneS,temple_block.toneR);
}

static float temple_clock_sample(int slot,Voice *voice,const float cfg[3][5]){
 VoiceDSP *s=voice->dsp;
 TempleClockPhase *ph=&temple_clock_phase[slot];
 if(!temple_block.clockPairs){
  if(ph->active){
   for(int j=0;j<3;j++){
    s->c[j]=(ph->c[j]&(CLOCK_PHASE-1))*(1.f/CLOCK_PHASE);
    s->m[j]=(ph->m[j]&(CLOCK_PHASE-1))*(1.f/CLOCK_PHASE);
   }
   ph->active=0;
  }
  return temple_sample(slot,voice,cfg);
 }
 if(!ph->active){
  for(int j=0;j<3;j++){
   ph->c[j]=(uint32_t)(cycle(s->c[j])*CLOCK_PHASE);
   ph->m[j]=(uint32_t)(cycle(s->m[j])*CLOCK_PHASE);
  }
 }
 if(!ph->active||ph->stamp!=temple_clock_stamp||ph->last_inc!=s->inc[0]||ph->config!=cfg){
  ph->active=1;
  ph->stamp=temple_clock_stamp;
  ph->last_inc=s->inc[0];
  ph->config=cfg;
  for(int j=0;j<3;j++){
   ph->ci[j]=(uint32_t)(cycle(s->inc[j]*cfg[j][0]*current->clockDetune[j])*CLOCK_PHASE+.5f);
   ph->mi[j]=(uint32_t)(cycle(s->inc[j]*cfg[j][1])*CLOCK_PHASE+.5f);
  }
 }
 float mix=smooth[1]*.01f,amount=temple_block.amount,tone=temple_eg[slot].tone;
 float depth=amount>=0?1-amount+amount*tone:1+amount*tone,out=0;
 for(int j=0;j<3;j++){
  float offset=temple_clock_sine(ph->m[j])*(current->clockIndex[j]*depth);
  int32_t mod=(int32_t)(offset*CLOCK_PHASE);
  uint32_t p=ph->c[j]+(uint32_t)mod;
  out+=(temple_clock_sine(p)*(1-mix)+temple_clock_sine(p*2u)*mix)*cfg[j][3];
  ph->c[j]+=ph->ci[j];
  ph->m[j]+=ph->mi[j];
 }
 out*=1.6f;
 s->low+=(out-s->low)*current->clockBrightness;
 return s->low;
}
