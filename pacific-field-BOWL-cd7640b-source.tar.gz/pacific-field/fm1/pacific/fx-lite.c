/* SPDX-License-Identifier: GPL-3.0-only
 * Alternate native bench profile. The regular firmware links fx.c. */
#include "fx.h"
#include "native-bench.h"
#include "../firmware/src/app/plat.h"
#include <string.h>

int16_t pf_fx_settings[20];
int16_t pf_fx_delay_sync, pf_fx_delay_division, pf_fx_bpm = 96;
#include "hall-lite.h"

static int16_t delay_line[PF_LITE_DELAY_FRAMES][2] EN_POOL;
static unsigned delay_head, delay_length, delay_previous, delay_fade, delay_live;
static float delay_gain;
static int32_t delay_feedback;

void pf_fx_init(void)
{
    hall_init();
    memset(delay_line, 0, sizeof delay_line);
    delay_head = delay_length = delay_fade = delay_live = 0;
}

static void delay_frame(float left, float right, float *wet_left, float *wet_right)
{
    if (!delay_live && left == 0 && right == 0) {
        *wet_left = *wet_right = 0;
        return;
    }
    delay_live = 1;
    if (!(delay_head & 31u)) {
        float ms = pf_fx_delay_sync
            ? pf_delay_sync_ms(pf_fx_bpm, pf_fx_delay_division) : pf_fx_settings[8];
        unsigned target = clamp((int32_t)(ms * 44.1f), 1, PF_LITE_DELAY_FRAMES - 1);
        if (target != delay_length) {
            delay_previous = delay_length;
            delay_fade = delay_length ? 32 : 0;
            delay_length = target;
        }
        delay_gain = pf_fx_settings[15] * pf_fx_settings[19] * (.000169f / 32768.f);
        delay_feedback = pf_fx_settings[12] * 327;
    }
    unsigned read = delay_head + PF_LITE_DELAY_FRAMES - delay_length;
    if (read >= PF_LITE_DELAY_FRAMES)
        read -= PF_LITE_DELAY_FRAMES;
    int32_t a = delay_line[read][0], b = delay_line[read][1];
    if (delay_fade) {
        unsigned old = delay_head + PF_LITE_DELAY_FRAMES - delay_previous;
        if (old >= PF_LITE_DELAY_FRAMES)
            old -= PF_LITE_DELAY_FRAMES;
        int32_t fade = --delay_fade;
        a = (a * (32 - fade) + delay_line[old][0] * fade) / 32;
        b = (b * (32 - fade) + delay_line[old][1] * fade) / 32;
    }
    *wet_left = a * delay_gain;
    *wet_right = b * delay_gain;
    delay_line[delay_head][0] = clamp((int32_t)(left * 32768.f) + mulq15(a, delay_feedback), -32768, 32767);
    delay_line[delay_head][1] = clamp((int32_t)(right * 32768.f) + mulq15(b, delay_feedback), -32768, 32767);
    if (++delay_head == PF_LITE_DELAY_FRAMES)
        delay_head = 0;
}

void pf_fx_frame(float dl, float dr, float rl, float rr, float *left, float *right)
{
    float hl, hr;
    delay_frame(dl, dr, left, right);
    hall_frame(rl, rr, &hl, &hr);
    *left += hl;
    *right += hr;
}

float pf_fx_meter(int field) { (void)field; return 0; }
uint32_t pf_fx_faults(void) { return 0; }
uint32_t pf_fx_bytes(void)
{
    return sizeof delay_line + sizeof rev_comb + sizeof rev_u + sizeof hl +
        sizeof hall_in + sizeof hall_mid + sizeof song + sizeof hall_at +
        sizeof hall_live + sizeof delay_head + sizeof delay_length +
        sizeof delay_previous + sizeof delay_fade + sizeof delay_live + sizeof delay_gain + sizeof delay_feedback;
}
