/* SPDX-License-Identifier: GPL-3.0-only
 * Original FMini-1 oscillator, mixer, ladder and filter contour, pinned in upstream/fmini.
 * Pacific owns tuning, routing and mono last-note priority. The loudness envelope
 * adapts FMini's capacitor attack law to an independently adjustable ADSR release.
 * No imported effects, polyphony, unison or additional long buffers. */
#include <stdint.h>
#include <string.h>
#include "../firmware/src/dsp/fastmath.h"
#include "lead.h"
#include "../firmware/src/app/plat.h"
#define NVOICE 1
#define NPART 1
#define NTRK 1
#include "upstream/fmini/felucca_engine.h"
#include "upstream/fmini/felucca_tables.h"
enum {P_E0,P_E1,P_E2,P_E3,P_E4,P_E5,P_E6,P_E7};
typedef struct track {int16_t p[8];voice_t v[1];int32_t lfo_val,lfo_fade;uint8_t mw;} track_t;
static track_t trk[1];
#include "upstream/fmini/dsp.c"
#include "upstream/fmini/eng_fmini_filter.h"
static float oscillatorRatio[3];
#include "fmini-core.inc"
static struct {uint32_t ages[60],serial,lastAge;int32_t audio[32];unsigned read;int selected,bend;float hz,level,ratio;} mono EN_POOL;
#ifdef EN_HOST
static uint32_t sampleCalls;
uint32_t pf_lead_sample_calls(void){return sampleCalls;}
#endif
static int index127(float x){int n=(int)(x*1.27f+.5f);return n<0?0:n>127?127:n;}
void pf_lead_init(void){
#ifdef EN_HOST
 sampleCalls=0;
#endif
memset(trk,0,sizeof trk);memset(&mono,0,sizeof mono);memset(fmini_patch,0,sizeof fmini_patch);memset(fmini_eff,0,sizeof fmini_eff);memset(fmini_sm,0,sizeof fmini_sm);memset(fmini_pk,0,sizeof fmini_pk);mono.selected=-1;mono.read=32;fmini_sm_ok=0;fmini_nst[0]=0x2f6e2b1;fmini_pgen[0]=0;}
void pf_lead_patch(int i,int value){if(i>=0&&i<32){fmini_patch[0][i]=clamp(value,0,127);fmini_pgen[0]++;}}
void pf_lead_wheel(int value){trk[0].mw=clamp(value,0,127);}
void pf_lead_bend(int bend){mono.bend=clamp(bend,-8192,8191);}
void pf_lead_event(int slot){if(slot>=0&&slot<60)mono.ages[slot]=++mono.serial;}
static void amp_tick(voice_t *v,const float *p){int32_t sus=(int32_t)(p[6]*(1<<24)/100.f);if(!v->gate&&v->stage&&v->stage!=3)v->stage=3;
 if(v->stage==1){int32_t step=ENV_LIN[index127(p[4])]>>1;int32_t d=(int32_t)(((int64_t)((5<<22)-v->env)*step*824)>>32);v->env+=d<1?1:d;if(v->env>=(1<<24)){v->env=1<<24;v->stage=2;}}
 else if(v->stage==2)v->env+=mulq16(sus-v->env,ENV_EXP[index127(p[11])]);
 else if(v->stage==3){v->env-=mulq16(v->env,ENV_EXP[index127(p[5])]);if(v->env<(1<<12)){v->env=0;v->stage=0;v->active=0;}}
}
float pf_lead_sample(const float *hz,const float *level,const uint8_t *gates,const float *p,float pitchMod,float amplitudeMod,float modulation,float transpose,const float *oscFine){

#ifdef EN_HOST
 sampleCalls++;
#endif
 if(mono.read==32){/* Apply the current resonance before upstream note-on tests self-oscillation. */
 for(int j=0;j<6;j++)trk[0].p[j]=index127(p[(int[]){0,1,2,8,9,10}[j]]);
 int next=-1;uint32_t age=0;for(int j=0;j<60;j++)if(gates[j]&&(next<0||mono.ages[j]>=age)){next=j;age=mono.ages[j];}voice_t *v=trk[0].v;int was=v->gate;v->gate=next>=0;
 if(next>=0){float want=hz[next]*pitchMod*fm_exp2f(mono.bend/8192.f*p[14]/12.f);if(mono.hz<1||p[3]<=0)mono.hz=want;else{float seconds=.003f+5.f*(p[3]*.01f)*(p[3]*.01f);mono.hz+=(want-mono.hz)*fm_minf(1.f,32.f/(44100.f*seconds));}mono.level=level[next];
 if(next!=mono.selected||age!=mono.lastAge||!was){if(!was||p[12]<.5f){fmini_note_on(trk,v);v->stage=1;}v->active=1;}}
 mono.selected=next;mono.lastAge=age;
 trk[0].p[6]=index127(p[15]);trk[0].lfo_fade=32767;trk[0].lfo_val=(int32_t)(modulation*32767.f);
 fmini_patch[0][FG_KBD]=index127(p[13]);fmini_pgen[0]++;fmini_block(trk);for(int j=0;j<3;j++){float cents=((fmini_patch[0][28+j]>=64)?fmini_patch[0][28+j]-128:fmini_patch[0][28+j])+fm_clampf(oscFine[j],-200,200);oscillatorRatio[j]=cents?fm_exp2f(cents/1200.f):1;}memset(mono.audio,0,sizeof mono.audio);
 if(v->active||v->stage){mono.ratio=transpose;float played=(mono.hz>1?mono.hz:440)*transpose;float note=(69+12*fm_log2f(played/440.f))*16;int coarse=(int)note;v->pitch_cur=coarse;float quantized=440*fm_exp2f((coarse/16.f-69)/12.f);vmod_t mod={0};mod.pitch16=coarse;mod.fine=(int)((played/quantized-1)*4096);mod.amp0=(int)(v->env_out*mono.level*amplitudeMod*.65f);amp_tick(v,p);int amp=v->env>>9;mod.amp1=(int)(amp*mono.level*amplitudeMod*.65f);v->env_out=amp;fmini_render(trk,v,mono.audio,32,&mod);}
 mono.read=0;}
 return mono.audio[mono.read++]/32768.f;
}
uint32_t pf_lead_bytes(void){return sizeof oscillatorRatio+sizeof trk+sizeof mono+sizeof fmini_patch+sizeof fmini_pgen+sizeof fmini_eff+sizeof fmini_nst+sizeof fmini_pk+sizeof fmini_nbuf+sizeof fmini_sm+sizeof fmini_sm_ok+sizeof fmini_mn;}
/* trk is ordinary RAM, not .pool. Keep both accounting views explicit. */
uint32_t pf_lead_pool_bytes(void){return pf_lead_bytes()-sizeof trk-sizeof oscillatorRatio;}
float pf_lead_frequency(void){return mono.hz*(mono.ratio>0?mono.ratio:1);}
int pf_lead_slot(void){return mono.selected;}
uint32_t pf_lead_key_age(int key){return mono.ages[key];}

int pf_lead_needs_block(void){return mono.read==32;}
