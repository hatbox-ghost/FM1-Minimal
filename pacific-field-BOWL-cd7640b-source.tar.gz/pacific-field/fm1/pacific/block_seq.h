/* SPDX-License-Identifier: GPL-3.0-only
 * Pacific adapter for the original SLOOP synth sequencer. See SLOOP-PORT.md. */
#include "sloop-core.h"
static void seq_tick(track_t *t,uint32_t adv,int primary);
#include "clip-events.h"
static void seq_release_all(void){seq_release(&current->seq);}
static void seq_command(int a,int b){track_t *t=&current->seq;
 if(a>=30000&&a<30096){t->editRevision++;int index=a-30000;uint32_t word=(uint32_t)b;memcpy(&t->data->pattern[index/24].locks[index%24],&word,4);return;}
 if(a>=20000&&a<20768){t->editRevision++;int index=a-20000,word=index%3,step=(index/3)%64,bank=index/(3*64);uint32_t value=(uint32_t)b;memcpy((uint8_t*)&t->data->pattern[bank].steps[step]+word*4,&value,4);return;}
 if(a>=0&&a<(int)sizeof(PFSeqLane)){uint64_t oldLoop=clip_units(t),oldUnits=t->units;((uint8_t*)t->data)[a]=(uint8_t)b;t->editRevision++;if(a==offsetof(PFSeqLane,swing))clip_cache_dirty(t);uint64_t newLoop=clip_units(t);if(newLoop!=oldLoop){t->units=oldUnits/oldLoop*newLoop+(oldUnits%oldLoop)*newLoop/oldLoop;PFEventRuntime*r=clip_rt(t);for(int h=0;h<8;h++){if(r->owner[h])r->off[h]=t->units+(r->off[h]>oldUnits?(r->off[h]-oldUnits)*newLoop/oldLoop:0);uint8_t *held=clip_hold(mode,h);if(held[9]){uint64_t start;memcpy(&start,held,8);start=t->units-(oldUnits-start)*newLoop/oldLoop;memcpy(held,&start,8);}}if(t->queued>=0)r->launch=(t->units/newLoop+1)*newLoop;r->cycle=t->units/newLoop;r->wrap=(r->cycle+1ull)*newLoop;t->seq_abs=SEQ_NONE;clip_cache_dirty(t);}return;}
 if(a==10000){b=clamp(b,0,3);if(t->run){t->queued=b==t->active?-1:b;if(t->queued>=0){uint64_t loop=clip_units(t);clip_rt(t)->launch=(t->units/loop+1)*loop;}}else{t->active=b;t->data->active=b;t->step=-1;t->seq_abs=SEQ_NONE;t->editRevision++;}}
 if(a==10001){if(!b){clip_record_finish(t);t->run=0;t->queued=-1;clip_voices_clear(t);locks_restore(t);}else{if(!t->run){clip_start_local(t);phaseFraction[2*mode+1]=0;}if(t->arm&&!t->countUnits)clip_record_begin(t);}}
 if(a>=10016&&a<10020){/* Old duplicate-head commands are intentionally inert. */return;}
 if(a==10002)seqProjectBpm=clamp(b,30,240);
 if(a==10003){clip_rec_toggle(t);}
 if(a==10004){unsigned note=b&127,vel=(b&128)?((b>>8)?(b>>8)&127:100):0;if(t->countUnits){clip_count_input(t,note,vel);return;}if(vel){if(t->arm){clip_start_local(t);if(!clip_record_begin(t))return;}if(t->record)clip_record_on(t,note,vel);}else if(t->record)clip_record_off(t,note,0);}
 if(a==10020){recQuant=clamp(b,0,5);rec_quant_off=!recQuant;}
 if(a==10041)clip_snap(t,b);
 if(a==10042)clip_undo(t);
 if(a==10040&&b==t->active){clip_record_finish(t);clip_voices_clear(t);locks_restore(t);t->seq_abs=SEQ_NONE;t->editRevision++;}

 if(a==10030||a==10031||a==10032){int bank=(b>>8)&3,step=b&63,note=(b>>6)&3,active=t->active;if(pf_clip_events(&t->data->pattern[bank]))return;t->active=bank;t->editResult=step;if(a==10030)note_del(t,step,note);if(a==10031)t->editResult=note_shift(t,step,(b&(1<<10))?-1:1,!!(b&(1<<11)));if(a==10032){step_t *st=&t->data->pattern[bank].steps[step];if(note<st->n)note_force_set(st,note,clamp((int)note_force(st,note)+((b&(1<<10))?-1:1),0,4));}t->active=active;t->editRevision++;}
 if(a==10013){t->fillHeld=!!b;}if(a==10014)t->fillArm=1;if(a==10015){int idx=b&63;step_fill_set(t,idx,(b>>8)&3);}
 if(a==10010)seqRecTempo=1;if(a==10011)seqRecCount=!!b;if(a==10012)rec_quant_off=!!b;
 if(a>=11000&&a<12024){t->editRevision++;int index=(a-11000)/4,bank=index/64,step=index%64,note=(a-11000)%4,active=t->active;if(pf_clip_events(&t->data->pattern[bank]))return;t->active=bank;step_t *st=&t->data->pattern[bank].steps[step];if(note<st->n){uint8_t key=st->note[note];span_set(t,step,&key,1,clamp(b,1,64));}t->active=active;}
}
/* SLOOP seq_tick: shared musical units, ordered microtiming and ratchets.
 * Synth-only branch; Pacific pattern banks replace song/drum/lock hooks. */
static void seq_tick(track_t *t,uint32_t adv,int primary){
 if(!pf_clip_events(&t->data->pattern[t->active])&&t->seq_n&&!t->seq_hold){if(t->seq_off<=adv)seq_release(t);else t->seq_off-=adv;}
 if(primary&&ft_on&&ft_trk==seq_track_index(t)){ft_frames++;ft_t=ft_frames/CTL;if(ft_t>=FT_BLOCKS)ft_close();}if(primary&&t->countUnits){uint8_t oldBeat=t->countBeat;t->countUnits+=adv;uint32_t beat=t->countUnits/BEAT_U;t->countBeat=beat>=4?0:4-beat;if(t->countBeat&&t->countBeat!=oldBeat)click_on(0);if(beat>=4){t->countUnits=0;clip_count_complete(t);}}if(!t->run)return;
 if(t->queued>=0&&t->units>=clip_rt(t)->launch){
  uint64_t over=t->units-clip_rt(t)->launch;
  clip_record_finish(t);locks_restore(t);clip_voices_clear(t);
  t->data->active=t->active=t->queued;t->queued=-1;t->units=over;
  t->seq_abs=SEQ_NONE;t->fillLastBar=0;t->editRevision++;
  clip_rt(t)->cycle=0;clip_rt(t)->wrap=clip_units(t);clip_clear_fresh(t);
 }
 uint32_t bar=t->units/(BEAT_U*4ull);if(primary&&bar!=t->fillLastBar){t->fillLastBar=bar;t->fillBar=t->fillArm;t->fillArm=0;}
 if(pf_clip_events(&t->data->pattern[t->active])){
  uint32_t into,slen,abs=trk_grid(t,&into,&slen),len=trk_len(t);if(t->seq_abs==SEQ_NONE||abs!=t->seq_abs){unsigned idx=abs%len;
   t->seq_abs=abs;t->step=t->seq_idx=idx;t->events++;t->last=t->frames;if(!idx)t->pass++;lock_step(t,idx);
  }clip_event_tick(t,adv);return;
 }
 uint32_t len=trk_len(t),into,slen,abs=trk_grid(t,&into,&slen),nabs,fire=0,div=trk_div(t);
 if(t->seq_abs!=SEQ_NONE&&div!=t->seq_den)t->seq_abs=abs;t->seq_den=div;
 if(t->seq_abs==SEQ_NONE){nabs=abs;fire=(int32_t)(slen/64u)*t->data->pattern[t->active].steps[nabs%len].micro<=(int32_t)into;}
 else{int32_t mu;nabs=t->seq_abs+1;mu=(int32_t)(slen/64u)*t->data->pattern[t->active].steps[nabs%len].micro;if(abs==nabs)fire=mu<=(int32_t)into;else if(abs+1==nabs)fire=mu<0&&(int32_t)slen+mu<=(int32_t)into;else if((int32_t)(abs-nabs)>0)fire=1;}
 if(fire){uint32_t idx=nabs%len;
 t->seq_abs=nabs;t->seq_idx=idx;t->step=idx;t->events++;t->last=t->frames;memset(t->rat_done,0,4);if(!idx)t->pass++;
 t->seq_skip=!step_plays(t,idx);if(primary){lock_step(t,t->seq_skip?64:idx);rec_hold(t,idx,len,nabs);}step_t *st=&t->data->pattern[t->active].steps[idx];uint32_t skip=0;for(uint32_t i=0;i<st->n;i++)if(live_has(t,st->note[i]))skip|=1u<<i;t->rskip_n=0;if(t->seq_skip)seq_release(t);else seq_step(t,st,slen,skip);
 }
 int32_t mu=(int32_t)(slen/64u)*t->data->pattern[t->active].steps[t->seq_idx%len].micro;
 int32_t rel=t->seq_abs==abs?(int32_t)into-mu:t->seq_abs==abs+1?(int32_t)into-((int32_t)slen+mu):(int32_t)into;
 if(t->seq_abs!=SEQ_NONE)seq_ratchets(t,rel<0?0:rel,slen);t->units+=adv;
}

static void seq_sample(uint32_t frame){track_t *t=&current->seq;t->frames++;
 if(!t->run&&!t->countUnits&&!(ft_on&&ft_trk==mode)&&!t->seq_n)return;
 seq_tick(t,phase_advance(2*mode+1,seq_bpm(t)),1);}
