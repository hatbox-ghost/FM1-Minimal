/* SPDX-License-Identifier: GPL-3.0-only.
 * Expanded Pacific TEMPLE operators; original quartz/mechanical controller stays upstream in engine.c.
 * Routing is the original licensed Dexed/msfa table carried by FM Lab. This is NOT its DX7 core. */
#include "upstream/fm-lab/algorithms.h"
static uint8_t temple_params[PF_TEMPLE_BYTES];
enum {TE_IDLE,TE_ATTACK,TE_DECAY,TE_SUSTAIN,TE_RELEASE};
typedef struct {float tone;uint8_t amp,stage,op[6];} TempleEG;
static TempleEG temple_eg[PF_NV]; /* ordinary RAM, not the realtime pool */
static struct {float decay[6],level[6],ratio[6],op[6][4],feedback,ampA,ampD,ampS,ampR,toneA,toneD,toneS,toneR,amount;uint8_t wave[6],routing,plainPairs;
#ifdef PF_PLAYABLE_BENCH
 uint8_t clockPairs;
#endif
} temple_block;
static float *temple_env(VoiceDSP *s,int op){static const uint8_t offset[6]={offsetof(VoiceDSP,band),offsetof(VoiceDSP,mal),offsetof(VoiceDSP,excite),offsetof(VoiceDSP,x),offsetof(VoiceDSP,velocity),offsetof(VoiceDSP,mi)};return (float*)((char*)s+offset[op]);}
static void temple_note(int slot,VoiceDSP *s){temple_eg[slot]=(TempleEG){.tone=temple_params[34]?0:1,.amp=TE_ATTACK,.stage=temple_params[34]?TE_ATTACK:TE_DECAY,};for(int i=0;i<6;i++){int attack=temple_params[40+i*4];temple_eg[slot].op[i]=attack?TE_ATTACK:TE_DECAY;*temple_env(s,i)=(temple_params[3]&(1u<<i))?(attack?0:1):1;}s->mi[1]=s->mi[2]=0;}
static void temple_prepare(void){
 float a=par[4]*.01f,r=par[5]*.01f,d=temple_params[32]*.01f;
 temple_block.ampA=1.f/(PF_SR*(.002f+7*a*a*a));temple_block.ampD=1-fm_expf(-6.907755f/(PF_SR*(.005f+8*d*d*d)));temple_block.ampS=temple_params[33]*.01f;temple_block.ampR=1-fm_expf(-9.21034f/(PF_SR*(.005f+9*r*r*r)));
 a=temple_params[34]*.01f;d=temple_params[35]*.01f;r=temple_params[37]*.01f;
 temple_block.toneA=1.f/(PF_SR*(.002f+7*a*a*a));temple_block.toneD=1-fm_expf(-6.907755f/(PF_SR*(.005f+8*d*d*d)));temple_block.toneS=temple_params[36]*.01f;temple_block.toneR=1-fm_expf(-9.21034f/(PF_SR*(.005f+9*r*r*r)));temple_block.amount=((int)temple_params[38]-100)*.01f;
 temple_block.routing=temple_params[28];temple_block.feedback=temple_params[2]*.0045f;
 for(int op=0;op<6;op++){int carrier=(DX_ALG[temple_block.routing][5-op]&3)==0;int decay=temple_params[16+op]?temple_params[16+op]:temple_params[carrier?0:1];float seconds=decay?.02f*fm_exp2f((decay-1)*.125f):0;
 temple_block.decay[op]=seconds?fm_expf(-1.f/(PF_SR*seconds)):1;temple_block.level[op]=temple_params[10+op]*.01f;temple_block.ratio[op]=temple_params[4+op]*.25f;temple_block.wave[op]=temple_params[22+op];int at=40+op*4;a=temple_params[at]*.01f;d=temple_params[at+1]*.01f;r=temple_params[at+3]*.01f;temple_block.op[op][0]=1.f/(PF_SR*(.002f+7*a*a*a));temple_block.op[op][1]=1-fm_expf(-6.907755f/(PF_SR*(.005f+8*d*d*d)));temple_block.op[op][2]=temple_params[at+2]*.01f;temple_block.op[op][3]=1-fm_expf(-9.21034f/(PF_SR*(.005f+9*r*r*r)));}
 temple_block.plainPairs=temple_block.routing==4&&temple_block.feedback==0&&
                        temple_block.amount==0&&temple_params[3]==0;
 for(int op=0;op<6;op++)
  if(temple_block.wave[op]||temple_block.decay[op]!=1||temple_block.level[op]!=1)
   temple_block.plainPairs=0;
#ifdef PF_PLAYABLE_BENCH
 temple_block.clockPairs=temple_block.routing==4&&temple_block.feedback==0&&temple_params[3]==0;
 for(int op=0;op<6;op++)
  if(temple_block.wave[op]||temple_block.decay[op]!=1||temple_block.level[op]!=1||temple_block.ratio[op])
   temple_block.clockPairs=0;
#endif
}
/* Per-note ADSRs. Linear attack, exponential decay/release, exact sustain and idle endpoints. */
static float temple_adsr(float value,uint8_t *stage,int gate,float attack,float decay,float sustain,float release){
 if(!gate&&*stage>TE_IDLE&&*stage<TE_RELEASE)*stage=TE_RELEASE;
 switch(*stage){case TE_ATTACK:value+=attack;if(value>=1){value=1;*stage=TE_DECAY;}break;
 case TE_DECAY:{float before=value;value+=(sustain-value)*decay;if(value==before||fm_fabsf(value-sustain)<.00001f){value=sustain;*stage=TE_SUSTAIN;}break;}
 case TE_SUSTAIN:{float before=value;value+=(sustain-value)*.002f;if(value==before||fm_fabsf(value-sustain)<.00001f)value=sustain;break;}case TE_RELEASE:value*=1-release;if(value<.00001f){value=0;*stage=TE_IDLE;}break;default:value=0;}
 return CL(value,0,1);
}
static void temple_envelopes(int slot,Voice *voice,int gate,float attack,float release){TempleEG *e=&temple_eg[slot];
 if(!gate&&voice->env==0&&e->tone==0&&e->amp==TE_IDLE&&e->stage==TE_IDLE)return;
 if(temple_params[39]&1)voice->env=temple_adsr(voice->env,&e->amp,gate,temple_block.ampA,temple_block.ampD,temple_block.ampS,temple_block.ampR);
 else{ /* Unedited older patches keep their exact original AR trajectory. Editing AMP opts into ADSR. */
 voice->env+=(gate-voice->env)*(gate?attack:release);e->amp=gate?TE_SUSTAIN:TE_RELEASE;}
 e->tone=temple_adsr(e->tone,&e->stage,gate,temple_block.toneA,temple_block.toneD,temple_block.toneS,temple_block.toneR);
 unsigned custom=temple_params[3];
 for(int op=0;op<6;op++){
  float *level=temple_env(voice->dsp,op);
  if(custom&(1u<<op))*level=temple_adsr(*level,&e->op[op],gate,temple_block.op[op][0],temple_block.op[op][1],temple_block.op[op][2],temple_block.op[op][3]);
  else if(temple_block.decay[op]!=1)*level*=temple_block.decay[op];
  else if(*level!=1)*level=1;
 }
 if(!gate&&voice->env==0&&e->tone==0){e->amp=e->stage=TE_IDLE;for(int op=0;op<6;op++){e->op[op]=TE_IDLE;*temple_env(voice->dsp,op)=0;}}
}
/* Shapes follow FM Lab's operator palette; sine uses TEMPLE's existing lookup unchanged. */
static float temple_wave(float phase,int wave){if(!wave)return sn(phase);float p=cycle(phase);switch(wave){case 1:return p<.5f?sn(p):0;case 2:return sn(p<.5f?p:p-.5f);case 3:return ((int)(p*4)&1)?0:sn(p-(int)(p*4)*.25f);case 4:return p<.5f?sn(p*2):0;case 5:return p<.5f?sn(p<.25f?p*2:p*2-.5f):0;case 6:return p<.5f?1:-1;default:return p*2-1;}}
/* Factory sine pairs use unity operator levels. Keep the same FM expression
 * and addition order, and retain the general renderer for every edited patch. */
static inline float temple_sine_pair(VoiceDSP *s,int j,float mix,const float cfg[3][5]){
 float p=s->c[j]+sn(s->m[j])*current->clockIndex[j];
 return (sn(p)*(1-mix)+sn(p*2)*mix)*cfg[j][3];
}
static float temple_sample(int slot,Voice *a,const float cfg[3][5]){
 VoiceDSP *s=a->dsp;
 float out=0,mix=smooth[1]*.01f;
 if(temple_block.plainPairs){
  out+=temple_sine_pair(s,0,mix,cfg);
  out+=temple_sine_pair(s,1,mix,cfg);
  out+=temple_sine_pair(s,2,mix,cfg);
 }else{
 float env[6],amount=temple_block.amount,tone=temple_eg[slot].tone;
 float toneGain=amount>=0?1-amount+amount*tone:1+amount*tone;
 const uint8_t *routing=DX_ALG[temple_block.routing];
 for(int op=0;op<6;op++){
  env[op]=*temple_env(s,op)*temple_block.level[op];
  if(amount!=0&&(routing[5-op]&3))env[op]*=toneGain;
 }
 if(temple_block.routing==4){ /* Exact original three-pair topology; neutral controls preserve its PCM. */
  for(int j=0;j<3;j++){int c=2*j,m=c+1;float mod;
   if(j==2&&temple_block.feedback){mod=temple_wave(s->m[j]+(s->mi[1]+s->mi[2])*.5f*temple_block.feedback,temple_block.wave[m]);s->mi[2]=s->mi[1];s->mi[1]=mod*env[m];}else mod=temple_wave(s->m[j],temple_block.wave[m]);
   float index=current->clockIndex[j]*env[m],p=s->c[j]+mod*index;
   out+=(temple_wave(p,temple_block.wave[c])*(1-mix)+temple_wave(p*2,temple_block.wave[c])*mix)*cfg[j][3]*env[c];
  }
 }else{
  float bus[3]={0,0,0};uint8_t has[3]={1,0,0};
  for(int order=0;order<6;order++){int op=5-order,j=op/2,m=op&1;uint8_t flags=DX_ALG[temple_block.routing][order];int in=(flags>>4)&3,dest=flags&3;float phase=m?s->m[j]:s->c[j],input=in&&has[in]?bus[in]:0;
   if(flags&0x40)input+=(s->mi[1]+s->mi[2])*.5f*temple_block.feedback;
   float sample=temple_wave(phase+input,temple_block.wave[op]);if(!dest)sample=sample*(1-mix)+temple_wave((phase+input)*2,temple_block.wave[op])*mix;
   float value=sample*env[op]*(dest?current->clockIndex[j]:cfg[j][3]);
   if(flags&0x80){s->mi[2]=s->mi[1];s->mi[1]=sample*env[op];}
   if((flags&4)&&has[dest])bus[dest]+=value;else bus[dest]=value;has[dest]=1;
  }out=bus[0];
 }
 }
 for(int j=0;j<3;j++){float cr=temple_block.ratio[2*j]?temple_block.ratio[2*j]:cfg[j][0],mr=temple_block.ratio[2*j+1]?temple_block.ratio[2*j+1]:cfg[j][1];s->c[j]=cycle(s->c[j]+s->inc[j]*cr*current->clockDetune[j]);s->m[j]=cycle(s->m[j]+s->inc[j]*mr);}
 out*=1.6f;s->low+=(out-s->low)*current->clockBrightness;return s->low;
}
