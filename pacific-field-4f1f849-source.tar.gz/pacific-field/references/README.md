# Immutable audio references

`manifest.json` pins two WASM binaries and their complete corresponding firmware source archives by SHA-256. Neither binary is produced from the implementation under test. These are required test fixtures, not the shipped workstation runtime.

- `historical-ui`: commit 3b12349, the original four-engine UI fixture after the authorized 1.69 wet-return gain. Its unchanged PCM fixture reproduces `4cf759…`.
- `current-ui`: commit 999f62e, the authorized four-engine/EFX build immediately before audit remediation. Current identity tests compare against this frozen sound baseline (`071540…`).

The old fixture is preserved and still checked against its own historical build. The root-cause report lists the intervening authorized engine and phasing epochs. No fixture is recaptured from the current implementation to make a mismatch pass.

The firmware source archives include the corresponding engine/platform sources and their original license texts/notices. This combined code is GPL-3.0-only with embedded permissive components; see the project licensing inventory. SDK/toolchain binaries are not included.

To independently rebuild and compare PCM, with Python 3.12+, Emscripten 6.0.13 and Node 24.19.0 available:

```sh
EMCC=emcc NODE=node python3 tools/rebuild-reference.py historical-ui
EMCC=emcc NODE=node python3 tools/rebuild-reference.py current-ui
```

The source archive does not need a `.git` directory or network access for normal validation or these reference builds. Tool versions are recorded because a different compiler may change floating-point code generation. A rebuild is checked for audio identity rather than file-byte identity where source path diagnostics/toolchain metadata differ.
