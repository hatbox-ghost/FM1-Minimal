#!/usr/bin/env python3
"""Stage matching browser sources, source download and previews without publishing."""
import argparse,os,pathlib,shutil,subprocess,sys
root=pathlib.Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('output',type=pathlib.Path);p.add_argument('--source-archive',type=pathlib.Path);p.add_argument('--working-tree',action='store_true');a=p.parse_args();a.output=a.output.resolve();a.output.mkdir(parents=True,exist_ok=True)
for name in ['index.html','worklet.js','display-worker.js','preview.html']:
 shutil.copyfile(root/'fm1/web/emu'/name,a.output/name)
shutil.copyfile(root/'fm1/build/emu/amb.wasm',a.output/'amb.wasm')
shutil.copyfile(root/'LICENSE',a.output/'LICENSE.txt')
if a.source_archive:shutil.copyfile(a.source_archive,a.output/'source.tar.gz')
else:subprocess.run([sys.executable,root/'tools/make-source-archive.py',a.output/'source.tar.gz',*(['--working-tree']if a.working_tree else [])],check=True,timeout=120)
node=os.environ.get('NODE')or shutil.which('node');assert node,'Set NODE or put node on PATH'
subprocess.run([node,root/'fm1/pacific/preview-ui-v2.mjs',a.output/'amb.wasm',a.output/'ui-v2'],check=True,timeout=120)
print(a.output)
