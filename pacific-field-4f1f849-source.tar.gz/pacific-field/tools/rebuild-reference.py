#!/usr/bin/env python3
"""Rebuild pinned reference source and compare its PCM to the bundled oracle.
No git history or network is required once this source archive is unpacked.
"""
import argparse,hashlib,json,os,pathlib,shutil,subprocess,sys,tarfile,tempfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('name',choices=['current-ui','historical-ui']);a=p.parse_args();r=json.loads((ROOT/'references/manifest.json').read_text())['references'][a.name];archive=ROOT/'references'/r['source'];assert hashlib.sha256(archive.read_bytes()).hexdigest()==r['sourceSha256']
node=os.environ.get('NODE') or shutil.which('node');assert node
with tempfile.TemporaryDirectory(prefix='pf-reference-') as directory:
 root=pathlib.Path(directory)
 with tarfile.open(archive) as t:t.extractall(root,filter='data')
 (root/'fm1/build/emu').mkdir(parents=True,exist_ok=True)
 env=os.environ.copy();env.pop('PF_WASM_OUTPUT',None);env.pop('PF_CLOUDS_FULL_BUFFER',None)
 subprocess.run([sys.executable,root/'fm1/pacific/build-fx.py'],env=env,check=True,timeout=240)
 subprocess.run([node,ROOT/'fm1/pacific/test-dsp-ui-identity.mjs',root/'fm1/build/emu/amb.wasm',ROOT/'references'/r['wasm']],check=True,timeout=180)
 print('PASS pinned source rebuild and PCM identity:',a.name,r['commit'])
