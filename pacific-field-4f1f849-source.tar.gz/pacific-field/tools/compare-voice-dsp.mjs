// Compare exact PCM/patch bytes against a separately preserved pre-optimization build.
// Probe binaries are production objects relinked with --export=pf_post solely to
// exercise normally unmapped actions/panic; no test hook is added to source/UI.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {modeDelta} from '../fm1/pacific/test-panel-order.mjs';
import {setFx} from '../fm1/pacific/test-fx-controls.mjs';
import {setTemple,setClockParam} from '../fm1/pacific/test-temple-controls.mjs';
const [after,before,output]=process.argv.slice(2);
assert(after&&before,'usage: node compare-voice-dsp.mjs AFTER_PROBE BEFORE_PROBE [REPORT.json]');
const branchControls={11:[0,3],6:[0,4],13:[0,5],0:[3,3],2:[2,3],3:[2,4],1:[2,5],10:[2,6],8:[0,6],14:[3,4],15:[3,5],12:[3,6],4:[1,3],5:[1,4]};
const results=[];
async function boot(path,fixture) {
  const {instance:{exports:e}}=await WebAssembly.instantiate(fs.readFileSync(path),{
    wasi_snapshot_preview1:new Proxy({},{get:()=>()=>0}),env:new Proxy({},{get:()=>()=>0})
  });
  e._initialize();assert(e.pf_post,'relink the preserved production objects with --export=pf_post');
  if(fixture){const b=fs.readFileSync(fixture);new Uint8Array(e.memory.buffer,e.web_store(0),b.length).set(b);e.web_store_set_len(0,b.length);}
  e.web_audio_boot();return e;
}
async function pair(name,fixture) {
  const engines=[await boot(before,fixture),await boot(after,fixture)],hash=crypto.createHash('sha256');
  let frames=0,peak=0;
  const both=fn=>engines.forEach(fn);
  const run=(n=128)=>{
    for(let start=0;start<n;start+=128){const count=Math.min(128,n-start);both(e=>e.web_audio_render(count));
      for(const channel of ['web_out_l','web_out_r']){
        const buffers=engines.map(e=>Buffer.from(new Uint8Array(e.memory.buffer,e[channel](),count*4)));
        assert(buffers[0].equals(buffers[1]),`${name}: PCM mismatch, channel ${channel}, block starting at frame ${frames}`);
        hash.update(buffers[0]);
        for(const x of new Float32Array(engines[0].memory.buffer,engines[0][channel](),count)){assert(Number.isFinite(x));peak=Math.max(peak,Math.abs(x));}
      }
      for(const e of engines){assert.equal(e.web_dropped(),0);assert.equal(e.web_fx_faults(),0);}
      frames+=count;
    }
  };
  const tap=b=>{both(e=>e.web_buttons(1<<b));both(e=>e.web_buttons(0));run();};
  const turn=(r,d)=>{both(e=>e.web_enc(r,d));run();};
  const select=m=>{both(e=>e.web_enc(2,modeDelta(e,m)));run();};
  const page=p=>both(e=>e.web_open_page(p));
  const keys=mask=>{both(e=>e.web_keys(mask));run();};
  const command=(op,a=0,b=0)=>{both(e=>assert.equal(e.pf_post(op,a,b),1));run();};
  const branch=(id,value)=>{const[p,r]=branchControls[id];page(p);both(e=>e.web_enc(r,(value-e.web_param(id))/(id===12?5:1)));run();};
  const clock=(id,value)=>{both(e=>setClockParam(e,id,value));run();};
  const temple=(id,value)=>{both(e=>setTemple(e,id,value));run();};
  const fx=(id,value)=>{both(e=>setFx(e,id,value,()=>{}));run();};
  const midi=(note,velocity)=>{both(e=>e.web_midi(9|(0x90<<8)|(note<<16)|(velocity<<24)));run();};
  const patch=()=>{tap(7);const blobs=engines.map(e=>Buffer.from(new Uint8Array(e.memory.buffer,e.web_store(0),e.web_store_len(0))));assert.equal(blobs[0].length,15664);assert(blobs[0].equals(blobs[1]),name+': exact same persisted patch required');return crypto.createHash('sha256').update(blobs[0]).digest('hex');};
  const finish=patchHash=>{
    assert(peak>0,name+': capture must contain audible output');
    results.push({name,frames,seconds:frames/44100,patchSha256:patchHash,pcmSha256:hash.digest('hex'),maxAbsoluteDifference:0,peak});
    console.log('PASS',name,frames,'frames, exact PCM and patch bytes');
  };
  run();return {engines,both,run,tap,turn,select,page,keys,command,branch,clock,temple,fx,midi,patch,finish};
}

// Four-field Branch persistence: coupled wind/rain, blow, bow, strike, hard/soft
// silence, reseeding, repeated triggers and upper MIDI routing slots.
for(const style of ['mechanics','bow','blow','strike']){
  const a=await pair('branch-'+style);a.select(0);
  for(const [id,value] of [[10,100],[2,80],[3,37],[1,87],[11,style==='blow'?95:20],[6,style==='bow'?90:15],[13,style==='strike'?100:35]])a.branch(id,value);
  a.page(0);const p=a.patch();a.command(3,1);a.keys((1<<27)-1);
  for(const n of [48,60,72,96])a.midi(n,100);
  for(let j=0;j<1500;j++){
    if(j===100||j===700)a.command(5,0); // manual mechanical/exciter impulse
    if(j===200)a.command(4,1); if(j===240)a.command(4,0);
    if(j===330)a.keys(0); if(j===430)a.keys((1<<7)|(1<<14));
    if(j===600)a.command(3,0); if(j===650)a.command(3,1);
    if(j===800)a.command(5,1); // reseed, preserving original RNG call order
    if(j===900)a.command(8,0); if(j===950)a.command(3,1);
    if(j===1050)a.keys(1<<7); if(j===1150)a.keys(0);
    a.run();
  }
  for(const n of [48,60,72,96])a.midi(n,0);
  a.both(e=>e.web_audio_boot());a.run();a.keys((1<<7)|(1<<11));a.run(44100);a.keys(0);a.run(44100);a.finish(p);
}

// Full TEMPLE per-note state must remain independent: all original ratio sets,
// every FM routing, operator ADSRs, feedback, phase accumulators and all waves.
for(let routing=0;routing<32;routing++){
  const a=await pair('temple-routing-'+routing);a.select(2);
  a.clock(6,routing%7);a.clock(2,80);a.clock(13,80);a.temple(28,routing);a.temple(2,75);
  for(const [id,value]of[[32,25],[33,65],[34,15],[35,45],[36,30],[37,35],[38,175]])a.temple(id,value);
  for(let op=0;op<6;op++)for(const [id,value]of[[22+op,(routing+op)%8],[40+4*op,op*4],[41+4*op,25+op*5],[42+4*op,30+op*8],[43+4*op,20+op*5]])a.temple(id,value);
  a.page(0);const p=a.patch();const chord=[0,4,7,11,14,18].reduce((m,k)=>m|(1<<k),0);a.keys(chord);
  for(let j=0;j<700;j++){
    if(j===100)a.keys(chord&~(1<<4));if(j===160)a.keys(chord);
    if(j===220)a.midi(84,95);if(j===290)a.midi(84,0);
    if(j===360)a.command(4,1);if(j===390)a.command(4,0);
    if(j===450)a.keys(0);if(j===550){a.command(8);a.keys(chord);}
    a.run();
  }
  a.keys(0);a.run(22050);a.finish(p);
}

// Four engines at once, all generic paths and both arp/sequence heads.
for(const arps of [false,true]){
  const a=await pair(arps?'four-engine-arps':'four-engine-sequences');
  for(let m=0;m<4;m++){
    a.select(m);a.page(31);
    for(const mask of [(1<<7)|(1<<11)|(1<<14)|(1<<18),(1<<9)|(1<<12)|(1<<16)|(1<<19)]){a.keys(mask);a.keys(0);}
    a.page(32);a.turn(3,-14);a.page(41);a.turn(3,100);a.page(6);a.turn(3,45);a.turn(4,45);
    if(arps){a.page(0);a.tap(1);a.keys((1<<27)-1);a.keys(0);a.page(8);a.turn(3,1);}
    for(const n of [48,60,72,96])a.midi(n,95);
    a.page(10);a.turn(3,75);a.turn(4,40);a.turn(5,1);
  }
  a.fx(9,1);a.fx(16,85);const p=a.patch();if(!arps)a.tap(10);
  for(let j=0;j<3500;j++){
    if(j%300===0){a.select((j/300)%4);a.page(0);a.keys(1<<(7+(j/300)%12));}
    if(j%300===100)a.keys(0);
    if(j===800){a.both(e=>e.web_seq_post(0,10000,1));a.run();}
    if(j===1400){a.select(0);a.command(3,1);a.command(5,0);}
    if(j===2000){a.select(0);a.command(5,1);}
    if(j===2400){a.select(2);a.temple(28,31);a.temple(2,95);}
    a.run();
  }
  for(let m=0;m<4;m++){a.select(m);a.command(8);}
  a.run(44100);a.finish(p);
}

// Exercise the unchanged migration path on the exact same legacy patch bytes.
{
  const a=await pair('legacy-v15-mixed',new URL('../fm1/pacific/fixtures/v15-four-engine.bin',import.meta.url));
  for(let m=0;m<4;m++){a.select(m);a.page(0);a.tap(1);a.keys((1<<7)|(1<<11)|(1<<14));a.keys(0);}
  const p=a.patch();a.run(44100*4);for(let m=0;m<4;m++){a.select(m);a.command(8);}
  a.run(44100);a.finish(p);
}
const report={pass:true,beforeSha256:crypto.createHash('sha256').update(fs.readFileSync(before)).digest('hex'),afterSha256:crypto.createHash('sha256').update(fs.readFileSync(after)).digest('hex'),cases:results.length,frames:results.reduce((n,r)=>n+r.frames,0),maxAbsoluteDifference:0,results};
if(output)fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({pass:true,cases:report.cases,frames:report.frames,maxAbsoluteDifference:0}));
