#!/usr/bin/env python3
"""Deterministic complete-source export, including immutable test references."""
import argparse,gzip,hashlib,io,json,os,pathlib,subprocess,tarfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser();p.add_argument('output',type=pathlib.Path);p.add_argument('--working-tree',action='store_true',help='explicitly include reviewed uncommitted files during development');a=p.parse_args()
 if (ROOT/'.git').exists():
  dirty=subprocess.check_output(['git','status','--porcelain','--untracked-files=normal'],cwd=ROOT,text=True)
  if dirty and not a.working_tree:raise SystemExit('Commit changes first, or explicitly use --working-tree.')
  files=set(subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0'))
  if a.working_tree:files.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=ROOT).decode().split('\0'))
 else:
  entries=json.loads((ROOT/'SOURCE-MANIFEST.json').read_text())['files'];files=set(entries)
  if not a.working_tree:
   for name,sha in entries.items():
    if not (ROOT/name).is_file() or hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=sha:raise SystemExit('Source manifest mismatch: '+name)
 output=a.output.resolve();files=sorted(f for f in files if f and (ROOT/f).is_file() and (ROOT/f).resolve()!=output and '.git/' not in f and not f.endswith('.DS_Store'))
 manifest={f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in files};raw=io.BytesIO()
 with tarfile.open(fileobj=raw,mode='w',format=tarfile.PAX_FORMAT) as tar:
  for file in files:
   source=ROOT/file;data=source.read_bytes();info=tarfile.TarInfo('pacific-field/'+file);info.size=len(data);info.mtime=0;info.mode=0o755 if os.access(source,os.X_OK) else 0o644;tar.addfile(info,io.BytesIO(data))
  data=(json.dumps({'schema':1,'files':manifest},indent=2,sort_keys=True)+'\n').encode();info=tarfile.TarInfo('pacific-field/SOURCE-MANIFEST.json');info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data))
 output.parent.mkdir(parents=True,exist_ok=True);output.write_bytes(gzip.compress(raw.getvalue(),mtime=0));print(json.dumps({'archive':str(output),'files':len(files),'sha256':hashlib.sha256(output.read_bytes()).hexdigest()}))
if __name__=='__main__':main()
