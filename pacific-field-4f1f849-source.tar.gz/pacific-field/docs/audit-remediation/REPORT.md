# Pacific Field — audit remediation

Baseline: **999f62e821060fde5daff5a862826db90efcec22**. Branch: **codex/audit-remediation**. The current sound, mappings, controls, navigation, effects and graphics are preserved. No deployment, device connection or hardware flash occurred.

**Result:** all 50 independent validation suites pass, including the original full-duration soaks. Both immutable reference source builds reproduce their expected PCM. A source export also passes the gate without Git or external reference folders. **Native firmware linking remains blocked** by the missing target C++ standard-library headers and unresolved freestanding string functions. Complete native RAM/flash totals, stack high-water and device CPU performance are therefore not claimed.

## Findings, causes and remediation

| Original finding | Root cause | Actual remediation | Status / evidence |
| --- | --- | --- | --- |
| `dsp-ui-identity` PCM mismatch | A fixture from the earlier Prophet/BRANCH/Slip engine epoch was compared to the authorized later workstation | Preserve the old fixture and historical binary; also compare current PCM to an independently frozen pre-audit build, with checksums and corresponding source | PASS; detailed epoch analysis below; fixture bytes unchanged |
| `record-onset` failure | Obsolete controls and struct offsets: velocity was read as note count, gate as note type; old REC/length gestures no longer selected those operations | Rewrite the harness against actual current REC/PLAY and 12-byte step schema; add cross-loop held-note/chord coverage | PASS, 24 cases; no recording/DSP source change |
| Incomplete and inflated validation | Omitted suites; aliases/helpers counted as separate coverage; obsolete sequencer harnesses; implicit stale `dist` reference and expected-failure gate wrapper | Exhaustive manifest; strict single gate; current schema/control harnesses; explicit reference build and timeout status | PASS, 49 independent JS suites + one C storage suite = 50; four aliases and five helpers excluded |
| Source export not independently testable | Hidden reference binaries/history and absent output-directory creation | Bundle two immutable oracles and complete corresponding source; deterministic exporter; fresh-build directories; reference rebuild wrapper | Both oracle rebuilds PASS; export extraction gate PASS |
| Native memory/linker evidence missing | Baseline native command fails before target application linking; build selected legacy AMB-1 and omitted Pacific engine; implicit include search missing | Correct native source selection, explicit target C headers, `size_t` declarations; capture real PI32v2 objects and failed-link diagnostics | PARTIAL: C units compile; original C++ units cannot compile; no valid application ELF/map |
| Inaccurate project licensing/docs | Top-level guide still describes NACHTFAHRT/old engine trees and omitted new upstreams | Root GPL text and actual source/license inventory; retain original licenses/notices and detailed legacy attribution; current build guide | Updated; no upstream license notices removed |
| Stale paths/logs/build artifacts | Obsolete checked-in browser runtime/source archive, empty compiler logs, absolute host paths, old controls presented as current | Remove obsolete generated distribution and empty logs; staging/source-export tools; parameterize research probes; supersede old Albion guide; mark historical reports | Cleanup inventory in `cleanup.json`; substantive historical sound examples and evidence retained |

## 1. PCM mismatch explained; no silent fixture reset

The unchanged `fm1/pacific/fixtures/ui-v2-dsp-reference.json` contains:

`4cf7592498c8810c1bd10d5acdaa7cc911668a68ce4127ee088a377cc8983b55`

The historical 3b12349 binary reproduces that exact hash with **both** its original harness and the current harness with startup settings restored. Rebuilding its archived corresponding source also reproduces it. This rules out an unexplained compiler drift, corrupt fixture or startup restoration bug.

The current pre-audit baseline, frozen before any remediation, produces:

`0715404c4328bb3c5b3a323278b28fe5724f14a2d25429ced556faa7c9c0255d`

Protected checkpoints isolate the changes:

| Checkpoint epoch | Same capture scenario hash |
| --- | --- |
| 3b12349; before startup-profile change; before BRANCH Elements | `4cf7592498c8810c1bd10d5acdaa7cc911668a68ce4127ee088a377cc8983b55` |
| After authorized BRANCH Elements / Bow work, before OberVave | `c0377f060a113d1eba36463e0736fc57b1f31fb4fbf2e6f68688c95ac602db0e` |
| After authorized OberVave replacement, before and after TEMPLE expansion | `35bc7c083cd51a75ec4b90c48ee59468e78f752eb84124e766435c2a91bcde40` |
| After retirement of old fixed-offset Slip; later independent phasing and current EFX baseline | `0715404c4328bb3c5b3a323278b28fe5724f14a2d25429ced556faa7c9c0255d` |

These were prior user-authorized changes: BRANCH Elements (d612324 / abdd8b1), OberVave (174762e), and old Slip retirement (bc69a4b), followed by independent panned doubles (08a7de5). The v15 fixture has nonzero old Slip fields: `[-10,100,100,1]`, `[-3,100,100,1]`, `[4,100,100,1]`, `[11,100,100,1]`. Later migration intentionally makes those retired timing controls inert. This is a real historical scheduling difference, not an unexplained audio tolerance adjustment.

TEMPLE expansion itself is **not** blamed for the old PCM mismatch: its before/after checkpoint hash is unchanged, and `temple-preservation` reproduces the exact seven original ratio-set sounds with mechanics active. Existing engine/preservation tests and the new minimum six-note audio check pass.

The fixed identity test checks two explicit epochs: the old fixture against its historical build, and current output against frozen 999f62e. It never captures a replacement expectation from the implementation under test. `references/manifest.json` pins full commits, binary checksums and corresponding-source checksums. No fixture hash was edited.

## 2. Recording regression investigation

Current `PFSeqStep` is 12 bytes: notes 0–3, velocity 4, gate 5, count 6, type 7, flags 8, level 9, ratchet 10, microtiming 11. The old test interpreted velocity 100 as a note count and failed `100 != 1`. It also used obsolete page/knob mappings for REC and length, so it did not exercise the intended recording operation.

The repaired test drives actual controls, checks actual recorded pitches/count/type, and covers four instruments × lengths 1, 2 and 16 × single note/chord = **24 cases**. Notes begin at the last step, remain held for more than three complete wraps, retain their original attack, and extend as ties across step zero where applicable. Partial chord release, complete manual release, recording stop and sequencer-owner STOP are checked. No dropped commands or DSP faults occurred. No demonstrated sequencer regression required a firmware change.

Other omitted sequencer tests had the same obsolete schema problem: the prior v10 patch, two-note step, command packing and recording controls no longer describe SLOOP. The replacements retain meaningful tests for current timing, queued banks/cancel, manual ownership, ties/rests, step entry, four-lane persistence and clean stop. They do not change the current interface to satisfy an old assertion.

## 3. Validation inventory and timeouts

`fm1/pacific/validation-suites.json` exhaustively classifies every `test-*.mjs`. Unclassified or missing scripts fail preflight. Four alias entry points (`edit-pages`, `layered`, `web`, `slip`) and five imported helper modules are listed but not counted again. There are **49 independent JavaScript suites and one independent native-storage C harness**. Loop iterations, presets, browser instances, compiler steps and 24 recording cases do not inflate the independent-suite count.

`fm1/pacific/check-fx.py` and `fm1/tools/suite_gate.sh` now run the same strict gate. The old wrapper's missing script and expected-failure exemptions are removed. The original full-buffer Clouds reference is compiled explicitly from the same upstream source with `PF_CLOUDS_FULL_BUFFER=1`; current PCM comparisons use the pinned pre-audit artifact. No test depends on `dist/amb.wasm` or a personal scratch folder.

| Execution budget | Explicit wall timeout |
| --- | ---: |
| Main and full-buffer reference compilation | 240 s each |
| LFO long render | 1,200 s |
| Clock / sequencer stress / SLOOP stress | 600 s each |
| Other JS suites | 180 s each |
| Host storage compilation / execution | 60 / 120 s |

Full mode renders **1,800 audio seconds** for LFO and **600 audio seconds** for mixed sequencer stress. CI mode explicitly renders **120 seconds each**; reports identify the profile and durations. TIMEOUT is a separate failing status. Filtered `--only` diagnostics explicitly report incomplete inventory. Native target firmware linking is a separate, failing milestone; host storage success is not hardware firmware validation.

Full results: `validation-full.json`. The initial repaired full run passed all 50 suites with **zero failures and zero timeouts**. The extracted source export's CI run also passed all 50 suites; see `validation-source-export.json`.

## 4. Reproducible source archive

`tools/make-source-archive.py` exports sorted source, licenses, test inputs, reference binaries and their complete corresponding source archives. Archive timestamps/ownership are normalized and `SOURCE-MANIFEST.json` records per-file SHA-256. Default export requires a clean checkout; explicit `--working-tree` permits reviewed development snapshots. Outputs and ignored build products are excluded.

Two independent exports of the same tested development snapshot had identical SHA-256:

`5a88a523a1dc3273107158fab6177354c823bdc5b48eeecfc5cc52e8d69b44f8`

That is the verification snapshot, not a promise that later documentation additions retain its hash. It was unpacked into a fresh directory with no `.git`, no generated build directory and no outside reference folders, then compiled and ran the CI gate successfully. Both pinned historical/current sources were also extracted, compiled and compared independently using `tools/rebuild-reference.py`; both pass PCM identity with Emscripten 6.0.13 / Node 24.19.0.

The obsolete `dist/` binaries/archive were removed because they described another engine epoch. `tools/stage-browser.py` stages current source assets plus freshly compiled WASM, a complete source download and regenerated framebuffer previews; the gallery HTML was moved unchanged into the source asset directory. Nothing was published during this audit. Historical reference archives remain immutable, including their original metadata; active guides/scripts no longer depend on those old personal paths.

## 5. Real native evidence and memory limits

Target: **JieLi AC79 / PI32v2 r3**, `-mfprev1 -ffp-contract=off`; not ARM. The retained Linux toolchain and SDK were used through the existing macOS VM. The missing VM guest agent was restored from its already-downloaded installer; compiler mounts were corrected. No new SDK/toolchain was downloaded.

The **unchanged baseline native build fails**: no standard C header search path, and this machine's Pillow lacks libraqm. The inherited `EN_FONT_NORAQM=1` fallback was declared for diagnostic native builds only; it changes legacy proportional-font metrics and is not an approved graphics change or shipping build. The normal browser gate uses the current pixel renderer and needs no generated proportional font.

The build wiring also compiled `firmware/src/dsp/amb.c` unconditionally while omitting `pacific/engine.c`. The Pacific target now excludes AMB-1 from its object list and includes its actual engine. Legacy AMB source and copyright attribution remain available. This verifies the **link input selection**, not an exclusion from a successfully linked firmware ELF: there is no successful final ELF yet.

The explicit toolchain C include path then exposed `unsigned` versus target `size_t` prototype conflicts in freestanding `memcpy`, `memset`, `memcmp`. Correcting their declarations fixes the compiler error without changing the algorithms. Isolated PI32v2 before/after objects have **identical disassembly** (`libc-target-identity.json`).

The resulting original C++ compilation fails on missing `<cmath>` and `<algorithm>` (the toolchain has no C++ standard-library headers). A diagnostic link of the available real target C objects also stops on missing `strlen`; target symbols additionally expose unresolved `strcmp`/`strcpy`. The original C++ objects and their math/runtime dependencies are not available for a complete link. No substitute DSP, fake math functions, permissive undefined-symbol link or storage/size guard bypass was used. Resolving the remaining standard-library/runtime closure needs a compatible native C++ integration and subsequent target checks; it is not completed here.

### Before / after figures, separated by evidence type

| Quantity | Before | After | Evidence / meaning |
| --- | ---: | ---: | --- |
| Complete native linked RAM | unavailable | unavailable | Both application builds fail before a valid final link |
| Complete native application flash image | unavailable | unavailable | No valid application ELF/image; no claimed savings |
| Native stack high-water / remaining runtime headroom | unmeasured | unmeasured | Requires real target execution, including nested interrupts |
| Emulator DSP pool API | 269,724 B | 269,724 B | Actual frozen/current WASM measurements, **not** target linker totals |
| Emulator canvas API | 65,280 B | 65,280 B | Unchanged; not a new target allocation claim |
| Emulator linear memory reservation | 4,194,304 B | 4,194,304 B | Browser runtime, not FM-1 RAM |
| Project payload | 15,664 B | 15,664 B | Compile-time struct guard and storage test; format unchanged |
| Native project bank payload capacity | 16,128 B | 16,128 B | Physical storage backend constant; **464 B** payload spare |
| Native project bank span, two copies | 16,384 B each | 16,384 B each | Total 32,768 B reserved; no storage guard weakened |

`app.ld` sets ordinary RAM **98,304 B**, pool **344,064 B**, RAM-executed code **24,576 B**, application XIP **581,564 B**, and NOINIT **15,696 B**. Its user stack range is **24,320 B**, system/IRQ stack range **7,936 B**, with two **256 B** guard bands. These are configured limits, not measured usage or spare stack. The existing required **8,192 B pool reserve** remains enforced. Emulator pool+canvas arithmetic leaves 868 B beyond that reserve; this tight **emulator/layout check does not establish native link fit**.

Project banks occupy flash offsets `0xD0000` and `0xD4000`, ending at `0xD8000`; calibration begins at `0xDC000`. Header/CRC/dual-bank cut-point regressions pass on the actual C storage backend simulated against a flash array. Legacy FC000/FD000 reads remain. That test is host execution of native backend source, not physical flash testing.

Real **unlinked PI32v2 object sections**, captured after the build fixes:

| C object | `.bss` | `.data` | COMMON symbols | `.pool` |
| --- | ---: | ---: | ---: | ---: |
| main | 45,312 | 44 | 15,664 | 65,280 |
| Pacific engine | 26,520 | 20 | 65 | 31,288 |
| shared FX C routing | 16 | 2 | 44 | 3,688 |
| FMini LEAD | 124 | 0 | 0 | 636 |
| FMini double | 752 | 4 | 0 | 0 |

These are actual target object allocations, **not total linked firmware RAM**: missing C++ effects/Elements state, linker alignment/GC, vectors/startup and final placement preclude totals. Object symbol/section evidence is in `target-partial-objects.json`. `incomplete-target.map` contains only early common-symbol allocation before the first unresolved-symbol abort; it is explicitly not a full linker map. `native-before.log` and `native-after.log` preserve the failing compiler diagnostics. A generated invalid partial ELF was not kept or packaged.

No measured maximum combined hardware CPU load, latency, xruns, or stack high-water is available. Browser render timings are not used to infer any of these.

## 6–7. Licenses, cleanup and preservation

Root `LICENSE` contains GPLv3; `NOTICE.md` inventories the actual platform, Pacific adapters, MIT Elements/Clouds/Oliverb, GPL OberVave/FMini/SLOOP, dual-licensed FM LAB/Dexed/MSFA routing, fonts and external SDK packaging boundary. Original notices, GPL texts, Apache text, MIT grants and OFL texts remain. `fm1/LEGACY-LICENSING.md` retains detailed inherited attribution; the current guide no longer describes NACHTFAHRT as the product. No Beads production integration is claimed.

The stale three-instrument Albion guide is replaced by current links; older implementation reports are explicitly historical. The obsolete distribution, its nested source archive, empty compiler logs and stale absolute-path report generator were removed. Historical probes now take reference/output/tool arguments; machine-specific paths in retained reports were normalized. The Elements provenance metadata uses its repository URL. Unique audio examples, pictures, source references and historical memory evidence are retained. `cleanup.json` lists removals. Host `.DS_Store` files were ignored, not deleted.

`runtime-preservation.json` verifies **136** existing DSP/UI/browser runtime source files are byte-identical to the protected baseline. No engine algorithm, parameter map, graphics source or navigation handler was edited. The only platform runtime file adjustment is the demonstrated native libc declaration fix, whose target instruction identity was verified. The six-note TEMPLE audio check, original seven-tone preservation, OberVave, FMini LEAD, BRANCH, phasing, recording, effects and navigation suites all pass.

**Remaining failures:** native original C++ header/runtime closure and the resulting unavailable full native link/memory map. Physical hardware CPU/audio/stack validation remains unperformed. Those gaps are explicit; the emulator and source-export passes do not close them.
