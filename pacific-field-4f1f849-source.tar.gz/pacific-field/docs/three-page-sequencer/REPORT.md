# Three-page sequencer

Baseline: `835446d`, the isolated VoiceDSP memory optimization. The browser and firmware use the same panel and sequencer source.

| SEQ page | K1 | K2 | K3 | K4 |
|---|---|---|---|---|
| TIMING | Division / free BPM | Length | Swing | Global Slip |
| RECORD | Onset quantize, including OFF | Gate | Four-beat count-in | Global metronome |
| CLIP LAUNCH | A | B | C | D |

Turn a clip's knob to select it. While running, it queues at the selected instrument's next loop boundary. Turn the current clip's knob to cancel the queue. Other lanes continue independently. The keyboard plays normally on every page. SELECT and ALGORITHM no longer edit steps, and EDIT still goes to the instrument.

Tap REC while running to overdub, and tap again to finish without stopping the transport. With count-in enabled, recording starts after four clicks even if the global metronome is off. While stopped with count-in off, REC arms and the first note starts the lane. Hold GLOBALS and tap REC to undo the selected instrument's last take. SAVE remains save. Hold GLOBALS and turn the relevant timing knob for FREE/SYNC: K1 on SEQ TIMING, K2/K3 on ARP, or the visible Delay Time control. Existing SEQ-first performance fill shortcuts remain available.

## Behavior and compatibility

- Held notes have one onset and a separate release deadline, including across repeated loop wraps. Quantization snaps the onset on a beat-based grid and leaves the raw held duration intact. Overdubbing adds events and does not fill rests.
- Global Slip changes the primary clock rates of the four instruments. At 40, BRANCH/TORT/TEMPLE/LEAD rates are 1.00000, 1.00512, 0.99488 and 1.01024 times their own unslipped rate. A four-beat phrase at 96 BPM takes roughly eight minutes to gain or lose a loop against BRANCH at the ±0.512% rates. The fastest lane is twice as far from BRANCH. At zero, the rates return to normal without jumping back into phase. Clip launch retains the local clock's residual and Slip carry. Slip does not add voices or pan the sound.
- Saved legacy patterns still use their original SLOOP step playback, including ties, rests, ratchets, nudge, fills and locks. Starting an overdub on a legacy clip converts that clip's onsets to event form. Complex legacy slide, mixed ratchet, nudge and lock combinations can articulate differently after conversion; undo restores the original step clip. If the conversion will not fit, REC reports CLIP FULL and leaves the clip untouched.
- Capacity is 127 events per clip and eight concurrent sequencer gates per instrument, with the existing mono behavior of LEAD. Finishing a take or changing clips closes notes still held in that take. SAVE stores completed events; finish a take before saving to include all releases. Format 22 reads older saves and retains former per-instrument Slip settings as inactive legacy data. The new global Slip starts at zero for migrated projects. Keep an older project export if you need to reopen it in older firmware.
- Delay uses the existing Clouds buffer and synchronization behavior, including its existing automatic time fit and quality changes for long synced delays. SEQ and ARP preserve playback position on FREE/SYNC changes.

## Build and memory

The hardware mapping was checked in `plat.h`, `panel.c`, and `plat_fm1.c` before editing: GLO, SEQ, REC and K1–K4 still route through the physical matrix and calibration to the same logical controls. Both the engine and the panel translation unit compile as real JieLi ELF32 PI32v2 objects. This is not a complete firmware link or a test on a physical instrument.

| Allocation | Before | After |
|---|---:|---:|
| Compiled engine/FX pool accounting | 266,364 B | 266,364 B |
| Canvas | 65,280 B | 65,280 B |
| Calculated pool headroom (344,064 B budget) | 12,420 B | 12,420 B |
| Headroom after existing 8 KiB reserve | 4,228 B | 4,228 B |
| Project payload (16,128 B limit) | 15,664 B | 15,664 B |
| PI32v2 engine object `.pool` | 27,928 B | 27,928 B |
| PI32v2 engine object `.bss` | 26,520 B | 26,504 B |
| PI32v2 engine object `.data` | 20 B | 24 B |
| PI32v2 engine object unlinked `.text*` | 53,052 B | 57,278 B |

The recorder uses the retired 1,152-byte free-take buffer. The four scheduler states reuse 928 bytes of retired second-playhead storage. Clip events occupy the same 768 bytes that held each clip's legacy steps. No synth slots, display memory, effects buffers or storage reserve were removed. Unlinked code size is not a final flash-usage number. Physical CPU load, stack high-water, dropout margin and a complete native link are unverified.

## Verification

The emulator gate exercises recorded chords, held notes across more than three wraps, a tick-zero quantized onset at a non-integer sample boundary, duration invariance across playback divisions, six simultaneous TEMPLE gates, overdub and undo, local clip queueing, save/reload, audible count-in, all three timing gestures and accumulating Slip on the primary ARP and SEQ clocks. It also checks legacy SLOOP playback, synth/effects regressions, the actual worker-rendered clip view and native storage power cuts. Immutable PCM fixtures were kept: both the zero-Slip arp and legacy sequence references and the broader DSP/UI identity oracle still match.

All 51 independent suites passed in the CI profile (50 browser/host suites and one C storage suite). The mixed-clock and LFO soaks each covered 120 seconds of audio; the SLOOP stress suite also covered 120 seconds. See [validation results](validation.json).
