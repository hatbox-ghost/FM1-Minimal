> Historical implementation record. Dates, memory projections, controls and validation claims apply to that checkpoint. See [the current audit](../audit-remediation/REPORT.md) and root README for current status.

# Effects baseline preservation

Effects branch: `codex/fx-development` in `$ARCHIVED_WORKSPACE/pacific-effects`.
Verified parent: `91cee73d294629443a1ed56073d0f70209ff9db3`.

## Comparison before branch creation

Read-only SHA-256 comparison: `$SCRATCH/pacific-edit-pages` versus `$ARCHIVED_WORKSPACE/pacific-field`. Git refs/history/reflogs and executable modes were inspected separately.

- Baseline: 163 files; saved: 686 files.
- All 162 matching paths are byte-identical, with identical file modes. No current source, DSP, UI, WASM, configuration, test or documentation changes would be lost at matching paths.
- `.gitignore` exists only in the verified baseline and is retained.
- Saved-only: 386 exact copies of current baseline content, 46 older copies whose exact blobs are already in baseline Git history, 90 iCloud placeholders, one older audit report and Finder `.DS_Store` metadata.
- `docs/fx-feasibility 2.md` has no added text: it is the current report minus its later Clock v8 appendix. A verbatim copy is kept here as `saved-fx-feasibility-earlier-copy.md`.
- Saved HEAD `9ce219ec233d5680979aaa7b6e150767ee433168` is an ancestor of the baseline. All two saved commits reachable through refs/reflogs exist in baseline history. No unique saved commits were found.
- `.icloud` files are preserved as placeholders, but their cloud-resident payloads were not downloaded or compared. They remain an explicit unresolved-content caveat. Keep the original folder; these archives alone are not an offline backup of cloud-only payloads.
- Git normally omits three ignored files in `previous-prototype-dist/` (`app.js`, `index.html`, `style.css`). They were also copied verbatim into this new checkout without overwriting anything, and remain ignored. No prototype was activated in the production build.

## Independent verified backups

Preservation directory: `$ARCHIVED_WORKSPACE/Preservation/effects-baseline-20261101T071307Z-d3d2a3`.

Both original folders, including their .git directories, were archived before branching. Every locally available regular-file payload was SHA-256 checked, and symlink targets were checked. Complete inventories and the detailed file comparison are beside the archives.

- Baseline: `$ARCHIVED_WORKSPACE/Preservation/effects-baseline-20261101T071307Z-d3d2a3/verified-baseline.tar.gz`
- Saved folder: `$ARCHIVED_WORKSPACE/Preservation/effects-baseline-20261101T071307Z-d3d2a3/saved-pacific-field.tar.gz`

Neither original was edited, switched, cleaned, reset, stashed, overwritten or discarded. The new checkout has independent Git objects (`--no-hardlinks`), not shared worktree state. Its origin fetch URL records the local baseline, with push disabled (`DISABLED-PRESERVATION-BASELINE`) so effects work cannot accidentally update that folder.

## Functionality and effects gate

Every baseline file is byte-identical in the new checkout before these preservation-only documents are added. Branch, TORT, Clock mechanics without climbing, global tuning, all four-LFO banks, latch, mixer, arps/Slip, patch v8 and existing web artifacts are retained. Production source and assets are unchanged.

The effects integration gate remains in `docs/fx-feasibility.md`: establish the matching native build/link map and physical FM-1 CPU constraints before beginning a DSP port. Upstream repositories stay outside workstation code in the sibling `References` directory. No effects integration, deployment, merge, firmware replacement or hardware flashing was authorized or performed by this preservation step.
