> Historical implementation record. Dates, memory projections, controls and validation claims apply to that checkpoint. See [the current audit](../audit-remediation/REPORT.md) and root README for current status.

# TORT — original OberVave engine integration

Implemented on `codex/tort-obervave`, against the rebuilt and tested `a54a230` baseline. The previous source is preserved at `codex/pre-obervave-a54a230`; its local preview binary and HTML are also retained in `$SCRATCH/pacific-pre-obervave-preview`. The local preview is http://127.0.0.1:8784/. Nothing was flashed or publicly deployed.

TORT now uses adapted **original OberVave DSP**, replacing the active Prophet implementation. Branch, Clock/TEMPLE and LEAD remain present and match the protected baseline PCM in deterministic comparisons. No other instrument's voice count, synthesis, sequencer or effects was reduced.

## Source and dependencies

Upstream: https://github.com/zvenson/obervave, commit `099ccd6f30a83591cea3521efaec6d3546004036`. The complete inspected checkout is separate at `$SCRATCH/pacific-obervave-reference`. Selected licensed sources are under `fm1/pacific/upstream/obervave`; their PIN and original GPL-3.0-only license/notices are retained. Copyright 2026 zvenson. The workstation is already GPL-3.0-only.

| Original file | Reuse |
|---|---|
| `firmware/src/obv_dsp.h` | Original fixed-point polyBLEP oscillator, hard-sync reset handling, state-variable filter, nonlinear ladder, input saturation and soft knee; included directly |
| `firmware/gen/obv_tables.h` | Original 44.1 kHz coefficients, RC envelope/glide and saturation tables; immutable tables shared by all voices |
| `firmware/src/obv_engine.h` | Original `env_tick`, extracted unchanged into `obervave-envelope.inc`; original `voice_render` inner sample loop in `obervave-render.inc`, adapted to return one mono sample to Pacific's routing |
| `firmware/src/obv_params.h` | Original parameter IDs, bounds and defaults; adapted control/initialization mapping in `tort-patch.h` |

`obv_engine.h` is retained for provenance/comparison, not compiled wholesale. Its mixer, sequencer, allocator, UI, MIDI dispatcher, native LFOs and effects are excluded. There are no extra build tools or third-party runtime dependencies: the existing C build includes the selected DSP headers and tables. Pacific still owns MIDI, keyboard/arp/sequence ownership, pan/spread, sends, alternative tunings, master transpose, four LFOs and storage.

The envelope equations and sample oscillator/filter/saturation processing remain upstream algorithms. Platform adaptations include compact mutually exclusive SVF/ladder state, existing 60 note owners, original 16-frame envelope/coefficient updates, direct fractional-frequency phase increments for Pacific's just tunings, and native glide coefficients applied in logarithmic pitch. Upstream velocity, vintage tuning/cutoff drift and envelope variation are connected. The standalone eight-card allocator, Q8 equal-tempered pitch quantization, unison modes, per-card native LFO fade/spread and standalone effect infrastructure are excluded. There is no new generic oscillator/filter substitute.

## Controls

PRESETS retains instrument selection. HOME cycles four-channel volume, pan, Oliverb sends and Clouds sends. GLO retains tempo, global tuning/root/anchor and system pages. MASTER remains the physical master control.

For TORT, EDIT enters Filter and cycles these eight pages; each table row is knobs 1–4 in order:

| EDIT page | Knob 1 | Knob 2 | Knob 3 | Knob 4 |
|---|---|---|---|---|
| Filter | Cutoff, displayed Hz | Resonance | SEM morph | Bipolar filter envelope amount |
| Oscillator 1 | Wave 1 | Pulse width 1 | Oscillator 1 level | Noise level |
| Oscillator 2 | Wave 2 | Pulse width 2 | Relative semitones | Fine detune |
| Oscillator interaction | Hard sync | Cross-modulation | Bipolar filter envelope → oscillator 2 pitch | Oscillator 2 level |
| Voice | Glide | Filter key tracking | Vintage | Velocity → amp |
| Filter model | Filter type | Drive | Velocity → filter | Key tracking |
| Voice spread | Spread | — | — | — |
| Note mix | Selected note level | Keyboard octave | Selected note pan | Selected note fine tuning |

ENV directly alternates filter ADSR and amplifier ADSR, with Attack, Decay, Sustain and Release on knobs 1–4. There is no duplicate native LFO page. ALGORITHM changes TORT cutoff outside page families where that encoder already owns navigation; mixer/global/FX/sequence navigation keeps its established behavior.

Oscillator waves are Off, Saw, Pulse and Saw+Pulse, exactly as supported upstream. Width modulation is meaningful when the pulse component is enabled. Filter types are LP12, HP12, BP12, Notch, LP24 nonlinear ladder and SEM. **Turning MORPH selects SEM.** Its original continuous path is LP → notch → HP; it does not morph between every discrete model. Envelope amount and envelope → oscillator 2 are centered on zero and displayed signed. Drive uses the actual upstream nonlinear input stage.

LFO repeats three pages for each of the four independent slots:

1. Rate / Depth / Destination / Shape.
2. Sync / Key sync / Phase / Slew.
3. Destination A / Signed amount A / Destination B / Signed amount B.

Destinations: Off, Cutoff, Oscillator mix, Width 1, Resonance, Pitch fine, Amplitude, Pan, Width 2, Drive, Cross-modulation, Filter morph and Filter envelope amount, plus Noise. Positive oscillator-mix modulation raises oscillator 1 while lowering oscillator 2. Filter morph applies in SEM. Additional amounts range −100…+100 and are independent of the primary destination depth. Routes sum before clamping the native parameter. LFOs are instrument-wide and evaluated once per audio block, with the existing slew; cutoff/resonance also retain upstream control smoothing. No per-voice LFO copies were added.

## Saved projects

Project version is now **17**, 15,600 bytes. The 15,584-byte v16 prefix, including its alignment padding, is preserved; 16 signed route bytes are appended. A compile-time assertion checks both the route offset and total length. The real native 16,128-byte storage guard remains enabled, leaving 528 bytes spare. The native storage regression passed all 16,166 simulated interrupted-write cut points.

On importing an old Prophet-era project, TORT's 56 sound bytes are explicitly initialized to the OberVave default rather than reinterpreted. Universal LFO shapes/rates/settings, musical notes, four pattern banks, Slip, tuning, mix information and other engines remain in their existing fields. Established startup normalization still opens a silent mixer at equal 72% levels, zero sends, SEL/arp/mute/solo off and unassigned LFOs; LEAD glide stays zero. No boot-time write replaces the saved original. Saving after migration writes v17. Export an old project or retain the protected build if the old Prophet tone needs to be recovered; tone conversion is not claimed.

A captured genuine v16 fixture with intentionally distinct Prophet sound bytes checks exact preservation of the remaining musical prefix, explicit initialization, silent startup and absence of automatic writes. Existing v15 and older migration checks also pass.

## Measured allocations

Evidence: `allocations.json`, `before-wasm.map.gz`, `after-wasm.map.gz`, `artifacts.json`, `host-stress.json`, `regressions.log` and `tort-controls.log`. Maps are **WASM maps**, not PI32v2 maps. The native-layout rows are compiler-emitted 32-bit source projections from the actual firmware entry point, engine/effect/LEAD translation units, Branch adapter and Elements RNG. They establish object sizes, not final target alignment/link placement.

| Allocation | Protected baseline | OberVave TORT | Change |
|---|---:|---:|---:|
| Per-owner TORT DSP | 116 B | 116 B | 0 |
| 60 TORT states | 6,960 B | 6,960 B | 0 |
| TORT shared block | 104 B | 68 B | −36 B |
| Effective TORT parameters | 56 B | 56 B | 0 |
| Velocity bytes | 0 B | 60 B | +60 B |
| Additional runtime routes | 0 B | 16 B | +16 B |
| Native two patch copies | 31,168 B | 31,200 B | +32 B |
| Project payload | 15,584 B | 15,600 B | +16 B |
| Native projected ordinary BSS + data | 86,522 B | 86,594 B | +72 B |
| Native projected pool, including canvas | 334,788 B | 334,788 B | 0 |
| Conservative pool API + canvas | 335,004 B | 335,004 B | 0 |
| Spare after conservative pool + 8,192 B reserve | 868 B | 868 B | 0 |
| WASM file | 501,488 B | 496,978 B | −4,510 B |

The conservative API includes some adapter state that is ordinary RAM, accounting for its 216 B difference from projected pool sections; retain the smaller 868 B planning headroom. Ordinary RAM projection leaves 11,710 B of the 98,304 B region before target padding/uncertainty. Stacks, stack guards, RAMTEXT and NOINIT remain separate and unchanged. Temporary control sums and other existing scratch remain on the existing audio stack; this change does not add per-voice stack buffers or heap allocation.

Native-source readonly objects decreased from 93,876 B to 89,256 B. This is not a native flash executable size: target code generation, library linkage, RAMTEXT and final linker placement remain unmeasured. The WASM artifact decrease similarly must not be used as a native flash claim. The old SDK/toolchain is retained; no extended environment setup was attempted.

## Regression and performance results

`EMCC=… NODE=… python3 fm1/pacific/check-fx.py` automatically compiles and checks original effects, native storage, four engines, controls/navigation/display workers, all global tunings/transpose, MIDI ownership, envelopes, arp octave input, sequencer recording/chords/ties/gates/banks/Slip, mixer/spread, migrations and combined load. Additional native oscillator increment tests confirm all five global tuning profiles, root changes and direct zero-glide octave entry. Parameter tests use timing-matched modulation on/off captures, so unrelated RNG/phase advancement cannot make a disconnected destination pass.

The protected pre-OberVave PCM fixture checks Branch, Clock/TEMPLE and LEAD sample-for-sample. The historical unchanged Clock zero-Slip golden remains checked; obsolete Prophet audio expectations have been replaced by tests of the actual new oscillator/filter controls. No old golden was regenerated from the replacement engine.

Combined host tests exercise all four instruments, 16 LFOs, both original effects, all 27 held keyboard notes per instrument, four real MIDI owners and A/B sequence chords. Peak observed TORT native activity is **39 voices**; its complete 60-owner storage capacity is retained. Six filter runs also use drive 127, resonance 115 and cross-modulation 100. No invalid samples, command drops or effect faults were observed; note release/panic and independent ownership pass. Other engines were not reduced.

Measured on this computer: approximately 29–31% average render time relative to a 128-frame/44.1 kHz block's 2.90 ms duration. One LP24 host block took **7.12 ms**, exceeding that block duration; other recorded per-mode maxima were about 1.04–1.22 ms. These timings include host scheduling/JIT effects and are neither hardware utilization nor a promise of underrun-free playback. They are recorded without hiding the outlier.

## Remaining device qualification / exclusions

No physical FM-1 was measured, flashed or certified. The unchanged native entry point and replacement C DSP pass the 32-bit frontend compilation/projection, but a successful PI32v2 link, actual flash size, target linker map, interrupt-cycle maximum, audio underrun counters, native stack watermark and thermal/long-duration playback still require the hardware/toolchain milestone. Keep the previous build for rollback until those pass. No on-device polyphony maximum is asserted from the browser result.

On-device checks: sweep all six filters at maximum resonance/drive; play dense TORT chords with Branch, Clock, LEAD, both FX and all LFOs; exercise overlapping A/B tails, MIDI steals, repeated bank switches and panic; measure worst interrupt cycles and stack watermark; verify storage/power-cut recovery and the target flash/RAM linker regions. If target CPU fails, present measured tradeoffs before changing polyphony or any other engine.

Excluded upstream standalone features: dual/unison/mono allocator modes, eight-card stealing policy, standalone chorus/delay/reverb, arpeggiator/sequencer/UI, native per-voice LFO fades/spread, factory sound banks and its independent MIDI mapping. Pacific's existing equivalents remain. No arbitrary cross-model morph or continuously interpolated saw/pulse waveform is claimed. Existing LEAD remains the mono lead instrument.

## Browser verification

The final localhost preview was started without resetting or saving over the user’s project. TORT opens Filter at EDIT 1/8; LFO 1 Routes is correctly titled at 3/12, with both signed amounts initially zero.

![Verified TORT filter page](browser.png)
