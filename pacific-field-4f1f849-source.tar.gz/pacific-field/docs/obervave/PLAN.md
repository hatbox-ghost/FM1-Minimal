> Historical implementation record. Dates, memory projections, controls and validation claims apply to that checkpoint. See [the current audit](../audit-remediation/REPORT.md) and root README for current status.

# TORT OberVave transplant — inspected approach

Working baseline:a54a230, preserved at codex/pre-obervave-a54a230. Baseline build and complete workstation checks pass. Reference repository is a separate checkout at $SCRATCH/pacific-obervave-reference; its revision is pinned when vendoring selected files.

Current TORT has60 routing slots and60 Prophet DSP states of116 bytes (6960B), plus its104B control block and56B effective patch. It is connected through tort_note/tort_prepare/tort_sample; Pacific owns note/arp/sequence/MIDI ownership, tuning/transpose, mixer/pan/spread and shared FX. It has four independent universal LFOs plus its obsolete native Prophet modulation pages.

OberVave's native voice is172 bytes; copying60 whole cards would cost10320B, exceeding current pool headroom. Its actual fixed-point oscillators, SEM state-variable filter, nonlinear24dB ladder, RC ADSRs, lookup tables and inner sample loop can be transplanted without its four-track mixer, allocator, arp, sequencer, effects, MIDI implementation or UI. The standalone firmware uses8 shared voice cards; Pacific's routing retains60 owners. A compact per-owner state will share mutually exclusive SVF/ladder state, omit native per-voice LFO/pan/allocator fields, and benchmark all60 owners without reducing other engines.

Filter behavior exists upstream:LP12, HP12, BP12, notch, nonlinear LP24 ladder, and SEM LP→notch→HP morph. Drive is an actual pre-filter soft stage. No new arbitrary filter morph path is needed. Four Pacific LFOs supply modulation; no native LFO is duplicated. Where capacity allows, two extra signed routes per LFO will use16 appended patch bytes and explicit migration.

Patch handling must advance the project version. Preserve existing global/musical/other-engine data; initialize or explicitly translate old Prophet sound data, never reinterpret its56 bytes silently. TORT stays named TORT. All interface families and direct buttons remain. Filter is the first page; ALGO accesses cutoff except where mixer/global navigation owns that knob.

Native target linker regions remain98,304B ordinary RAM and344,064B pool with8,192B protected pool reserve. Current conservative tracked engine/effects pool is269,724B plus65,280B canvas; remaining after reserve868B. Current patch15584B, physical payload16128B. Physical native CPU, linker instruction sizes and stack high-water remain unverified; the retained toolchain runtime is not available, so browser/WASM measurements are not hardware qualification.
