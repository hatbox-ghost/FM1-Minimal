# VoiceDSP access audit — before layout changes

Baseline: `57237c8` (working HOLD/SHIFT build). All 60 slots per instrument remain required. `VoiceDSP` is 18 floats / 72 bytes. Baseline `voiceDsp[2][60]` occupies 8,640 pool bytes, plus an existing 72-byte TORT pool scratch and 72-byte LEAD ordinary-RAM scratch.

## BRANCH: four persistent floats

| Field | Writes / initialization | Observable reads / persistence |
| --- | --- | --- |
| `mal` | global zero-init; retrigger; process action/rain; hard silence | Elements input on every active note sample, then *= .995; must remain independent for all 60 slots |
| `excite` | global zero-init; retrigger; action/rain; soft/hard silence; process decay | Elements excitation and displayed mechanical energy; independently persistent |
| `x` | global zero-init; branch_seed; mechanical integration in slots 30–37 | spring restoring force, previous-slot coupling, Elements physical input; hard silence does NOT reset it |
| `velocity` | global zero-init; branch_seed; retrigger/action/rain increments; mechanical integration | spring integration and energy display; hard silence does NOT reset it |

BRANCH `c`, `m`, `low`, `band`, `inc`, `mi` have no reachable synthesis readers. `low`/`band` are hard-silence zero writes only. `inc`/`mi` are generic frequency writes from keyboard, arpeggiator, control updates and SLOOP `trk_note_on`. No current BRANCH renderer reads them: it calls original Elements through `pf_branch_sample`, whose own note/resonator/exciter state is separate and unchanged. The legacy `morph()` definition reads c[0]/inc[0] but has no callers in the source tree; it is not a BRANCH render path.

Plan: retain four compact floats for every slot; point BRANCH's remaining generic write-only DSP access at the existing TORT routing scratch. Preserve all arithmetic, ordering, zero-init, reseeding, and partial versus hard reset behavior. Use no casts between compact and full structures, and add no per-slot pointer/allocation overhead.

## TEMPLE: NOT write-only — sharing is unsafe

| Full-state fields | Active readers / writers |
| --- | --- |
| `c[3]`, `m[3]` | `temple_sample`: six persistent oscillator phases, advanced separately for every note |
| `inc[3]` | keyboard / arp / SLOOP note setup and controls write; `temple_sample` consumes them for per-note phase increments |
| `low` | `temple_sample` persistent per-note brightness lowpass state; hard silence clears it |
| `band`, `mal`, `excite`, `x`, `velocity`, `mi[0]` | `temple_env` maps these six floats to operator amplitude envelopes; `temple_note` initializes them; `temple_envelopes` evolves/clears them; `temple_sample` and `pf_temple_operator_env` read them |
| `mi[1]`, `mi[2]` | per-note FM feedback history, reset on new note and read/write in original three-pair and expanded routing algorithms |

Every one of TEMPLE's 18 floats is used. Its 60 × 72 = 4,320 bytes must remain independently persistent. The user-authorized condition for scratch substitution is not satisfied. No TEMPLE state will be shared or removed; the existing actual per-note operator-envelope/feedback data is not equivalent to generic write-only scaffolding.

## Other engines and generic paths

- TORT renders via its independent `tort_voices[60]`; generic VoiceDSP writes use its existing scratch. No audible synthesis reads the scratch's phases/filter/feedback values.
- LEAD renders via original FMini state and its own routing scratch. Neither is resized or shared differently.
- `setvoice`: compact BRANCH retrigger values must use the slot-specific compact array; TEMPLE retrigger and `temple_note` remain full-state operations.
- `silence`: BRANCH resets excite/mallet as before, preserving x/velocity. TEMPLE low/band/mallet clear semantics remain unchanged.
- `branch_seed`, process action, rain, mechanical coupling, and BRANCH render: migrate only four-field storage addresses, without changing arithmetic or evaluation order.
- Keyboard, MIDI, arp and sequencer (both heads): keep the existing 60-slot routing, note owners, frequency/envelope/gate paths. Generic inc/mi writes remain legal full-structure writes to the existing scratch for BRANCH; TEMPLE points to its dedicated full-state array.
- `pf_init`: zero both compact BRANCH and full TEMPLE arrays, wire all 60 pointers, preserve seeds, command queues and original engine initialization.
- `pf_pool_bytes`: replace the old two-bank sizeof with actual full TEMPLE + compact BRANCH allocation sizes; verify with compiler/object maps rather than trusting this API alone.

Sources inspected: engine.c, temple-fm.h, sloop-core.h, seq-slip.h, tort.h and its includes, lead.c/lead-double.c, branch-elements.cc, and all source-tree `.dsp`/`->dsp`/VoiceDSP references. No serialized patch includes runtime VoiceDSP bytes.
