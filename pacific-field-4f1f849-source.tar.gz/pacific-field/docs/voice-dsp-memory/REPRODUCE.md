# Reproducing this comparison

Prerequisites are in `fm1/BUILDING.md`. Use Emscripten 6.0.13 and Node 24.19.0 for the recorded audio checks. Run from the repository root. Preserve a baseline source/build outside the working checkout; do not replace its engine after building it.

1. Extract `git archive 57237c8 fm1` into a separate baseline directory. Run its `fm1/pacific/build-fx.py` with the chosen `EMCC`; its normal production WASM must hash to `3e3538ff70ed505c7956dcad847afde8fa90eb6cfddd7367f90e2b28f2580f76` with the recorded toolchain.
2. Build the optimized source with the same compiler and options. For allocation maps, set `PF_MEMORY_AUDIT` to a different directory for each source tree. Do not reuse one tree's `fm1/build/fx/*.o` for the other.
3. Relink each tree's preserved object files separately, using its matching `em++`:

```sh
em++ BASELINE/fm1/build/fx/*.o --no-entry -sSTANDALONE_WASM \
  -sSTACK_SIZE=131072 -sINITIAL_MEMORY=4194304 -sFILESYSTEM=0 \
  -Wl,--export=pf_post -o BEFORE_PROBE.wasm
em++ fm1/build/fx/*.o --no-entry -sSTANDALONE_WASM \
  -sSTACK_SIZE=131072 -sINITIAL_MEMORY=4194304 -sFILESYSTEM=0 \
  -Wl,--export=pf_post -o AFTER_PROBE.wasm
node tools/compare-voice-dsp.mjs AFTER_PROBE.wasm BEFORE_PROBE.wasm comparison.json
```

The additional export exists only in the probes. No adapter, oscillator, envelope, renderer or patch code is replaced. The comparison asserts equal stored patch payloads, exact stereo sample bytes and zero dropped commands/DSP faults.

4. Run the normal unmodified main gate on the production build:

```sh
EMCC=emcc NODE=node python3 fm1/pacific/check-fx.py --profile full
```

5. For native allocation changes, compile each `engine.c` with the actual PI32v2 compiler and the identical flags listed in `allocations.json`, then inspect sections and symbols using the matching `objdump -h -t`. The retained dumps are target objects. A complete firmware link is not substituted by these object measurements.

The normal gate remains self-contained using its existing pinned artifacts. The optional one-off historical-baseline comparator requires a separately preserved baseline build; it is not a new hidden dependency of the main validation gate.
