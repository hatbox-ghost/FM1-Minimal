# VoiceDSP memory-only optimization

Baseline: `57237c8`, the working HOLD/SHIFT build. Isolated branch: `codex/voice-dsp-memory`. Production change: **engine.c only**. The proposed sequencer overhaul remains canceled; none of that work is included.

## Result

**3,360 bytes reclaimed**, verified independently in the WebAssembly linker allocation map and a real JieLi **PI32v2 r3** engine object compiled before and after with identical flags. All 60 slots remain present. BRANCH's controller/excitation state is now four independent floats per slot (16 bytes instead of 72). Its separate original Elements resonators/exciters are untouched.

**TEMPLE was not replaced by shared scratch.** The required safety condition is false in this build: all 18 floats in every TEMPLE `VoiceDSP` are read by active synthesis or envelope code. Sharing them would alter phase, envelopes, feedback and filtering across notes. Its 60 independent full states are preserved (4,320 bytes).

The full access trace, including generic note writes, initialization and reset semantics, is in [ACCESS-AUDIT.md](ACCESS-AUDIT.md).

## Implementation and persistence

- Introduce `BranchDSP {mal, excite, x, velocity}` and `branchDsp[60]` in the same realtime pool.
- Retain `VoiceDSP` unchanged, with `templeDsp[60]`. Add compile-time 16-byte/72-byte size checks.
- Preserve every BRANCH read/write to the four retained fields: per-note retrigger, process seed, impulses, rain, spring integration/coupling, energy display, Elements input and mallet decay. Expressions, arithmetic, RNG calls and their order remain the same.
- Preserve partial/hard reset behavior: `excite` and hard-reset `mal` clear as before; `x` and `velocity` persist across silence as before, and reset/reseed only where they did previously.
- BRANCH's now-inert generic full-structure accesses use the existing full-size TORT routing scratch. Those are write-only frequency/scaffolding values; actual BRANCH state is accessed through its correctly typed compact array. There is no cast of a small structure to a large one, no extra per-note pointer, and no new scratch buffer.
- TEMPLE pointers still target their individual full states. TORT/LEAD retain their existing scratch locations and original engine state.
- `pf_init` explicitly zeros both state arrays and both existing scratch structures. Pointer routing and all 60-slot voice/owner/gate structures retain their size.
- Update `pf_pool_bytes()` to count the actual two arrays. This API is independently checked against compiler allocations, not accepted as the sole proof of savings.

## Measured allocations

| Quantity | Before | After | Change |
| --- | ---: | ---: | ---: |
| BRANCH per-slot state | 72 B | 16 B | −56 B |
| BRANCH × 60 slots | 4,320 B | 960 B | **−3,360 B** |
| TEMPLE × 60 slots | 4,320 B | 4,320 B | 0 |
| Combined BRANCH/TEMPLE arrays | 8,640 B | 5,280 B | **−3,360 B** |
| Actual PI32v2 engine object `.pool` | 31,288 B | 27,928 B | **−3,360 B** |
| Actual PI32v2 engine object `.bss` | 26,520 B | 26,520 B | 0 |
| Actual PI32v2 engine object `.data` | 20 B | 20 B | 0 |
| Actual PI32v2 `routeVoices` symbol | 8,640 B | 8,640 B | 0 |
| Existing TORT / LEAD scratch symbols | 72 B each | 72 B each | 0 |
| Unlinked PI32v2 engine `.text*` sections | 53,056 B | 53,052 B | −4 B |
| Unlinked PI32v2 engine `.rodata*` sections | 15,782 B | 15,782 B | 0 |
| Browser WASM file | 554,211 B | 554,380 B | +169 B |

Native section/symbol dumps: [before](target-before.txt), [after](target-after.txt), [summary](allocations.json). These are **actual target engine objects**, not a full firmware ELF or final linked flash image. The +169-byte WASM file change is code/encoding size, not added persistent RAM.

Linked WebAssembly maps: [before](wasm-before.map.gz), [after](wasm-after.map.gz). The old `voiceDsp` symbol is 0x21c0 (8,640) bytes; its replacements are `branchDsp` 0x3c0 (960) and `templeDsp` 0x10e0 (4,320). Both existing scratch allocations remain 0x48 bytes. Machine-specific source prefixes in the retained maps are normalized.

### Remaining pool headroom

Measured compiled emulator pool accounting, against the configured 344,064-byte native pool budget:

| Quantity | Before | After |
| --- | ---: | ---: |
| DSP pool API (all engines/effects) | 269,724 B | 266,364 B |
| Display canvas | 65,280 B | 65,280 B |
| Accounted pool usage including canvas | 335,004 B | 331,644 B |
| **Accounted free space** | **9,060 B** | **12,420 B** |
| Required reserve | 8,192 B | 8,192 B |
| **Spare beyond that reserve** | **868 B** | **4,228 B** |
| Project payload | 15,664 B | 15,664 B |
| Browser linear-memory reservation | 4,194,304 B | 4,194,304 B |

[Raw measurements](pool-accounting.json). This is the existing compiled pool-accounting check, with the savings additionally verified on the real target object. **12,420 bytes is not a claim of measured free RAM on a physical FM-1 or a complete native linker result.** A full native application link remains subject to the previously documented C++ header/runtime blockers. No guard, reserve, storage limit or linker region was weakened to improve these figures.

## Independent deterministic PCM comparison

The exact pre-change production WASM was copied before any layout edit and a clean baseline rebuild reproduced its SHA-256:

`3e3538ff70ed505c7956dcad847afde8fa90eb6cfddd7367f90e2b28f2580f76`

Production object files were also preserved before editing. Baseline and optimized objects were separately relinked with **only** `--export=pf_post` added, allowing the comparator to exercise otherwise unmapped process impulse/reseed/panic paths. No hook was added to production source or UI. Both probes execute the same patches and events; the comparator checks saved patch bytes and compares the raw stereo PCM bytes after every rendered block, reporting the first differing frame if any.

`tools/compare-voice-dsp.mjs` passed **39 scenarios, 6,182,588 stereo frames (about 140.19 seconds)**, with **maximum absolute difference 0** and byte-identical patch payloads:

- Four BRANCH sound/control configurations: mechanics, bow, blow and strike; wind/rain/coupling; all 27 keyboard keys; four MIDI notes; process start/soft stop, hard panic, repeated retrigger, impulse, freeze, reseed and reboot.
- All 32 TEMPLE FM routings, spanning all seven original ratio sets and all eight waveform IDs, six independently played keys, advanced operator ADSRs, feedback, mixed note releases/retriggers, MIDI and panic.
- Four-engine mixed sequencer and arp runs with independent phased doubles, MIDI, LFOs, original Clouds/Oliverb sends, queued pattern switching and BRANCH reseeding while other engines sound.
- The same legacy v15 patch loaded into both builds, migrated, played and saved identically.

[Per-scenario patch/PCM hashes and frame counts](pcm-comparison.json). This comparison is against the exact current pre-optimization baseline, not a re-blessed committed PCM fixture. Existing historical/current fixtures were not modified. The independent frozen UI/DSP identity and seven-tone TEMPLE preservation checks also pass.

## Compiler and validation results

- Baseline and optimized Emscripten builds: **PASS**, Emscripten 6.0.13, `-O2 -ffp-contract=off`. Existing warning messages are identical before/after: CTL macro redefinition, inherited FMini shift precedence and inherited Elements memset warning. [Warning comparison](compiler-warnings.json).
- Baseline and optimized real PI32v2 engine compilation: **PASS**, same `-O2 -ffunction-sections -fno-builtin -mcpu=r3 -mfprev1 -ffp-contract=off -DPACIFIC_FIELD` flags and target headers. Both emit the same count of six pre-existing warnings; no warning cleanup was mixed into the patch.
- Focused identity, instrument isolation, TEMPLE six-note and original-tone tests: **PASS**.
- Initial full-duration gate: **50 suites passed; one failed an old exact memory-size assertion** (`266364 !== 269724`, “no extra realtime pool state”). Its synthesis checks passed before that assertion. The assertion was corrected from equality to **at most the unchanged 269,724-byte ceiling**, matching its stated no-additional-memory requirement while allowing this independently measured reduction. No audio assertion, tolerance or fixture changed. [Original full run](validation-initial-full.json), [exact failure](initial-memory-assertion.log).
- The original **1,800-second modulation soak and 600-second sequencer stress soak both passed** on this optimized binary. After the test-only ceiling correction, the **entire 51-suite gate passed with zero failures and zero timeouts** in its declared CI profile (120 seconds for each soak). Production WASM SHA-256 is unchanged between those two runs: `beb3aca96d3366a61f6155aa7504d3ae6109969617a056b67ae2357a892d4af2`. [Final complete gate](validation-final-ci.json), [artifact identity](artifacts.json).

## Scope and unresolved limits

Only `fm1/pacific/engine.c` changes production behavior/storage. The only existing test edit replaces the obsolete exact-size assertion with its original no-additional-pool ceiling. New supporting files are the access audit, measurements/report and standalone direct comparator. No UI/controller change, parameter mapping, patch/version/migration change, instrument/voice reduction, canvas change, effect buffer change, synthesis algorithm rewrite or RAMTEXT/linker change is included. TEMPLE, BRANCH, OberVave and FMini LEAD retain their sound engines and slots.

The proposed TEMPLE scratch substitution is intentionally **not performed** because active per-note readers make it unsafe. Its additional hypothetical savings are not counted. Full native linking and physical FM-1 CPU, audio and stack high-water remain unverified; browser renders do not establish those results. No output difference was accepted or masked by a tolerance or fixture update.
