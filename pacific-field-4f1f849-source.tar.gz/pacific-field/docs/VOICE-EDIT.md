> Historical implementation record; not the current build or validation guide. See [the current audit](audit-remediation/REPORT.md) and root README.

# Voice-only EDIT navigation

Requested refinement: EDIT should cycle only parameters that design the selected instrument’s voice.

- Branch: Voice, Envelope, Mechanics, Rain (four pages; rain/excitation settings belong to its physical voice).
- Clock: Voice, Envelope, Mechanics, Quartz (four pages; no removed pitch-shifting controls).
- TORT: Filter, Filter Env, Amp Env, OSC A, OSC B, B Waves, OSC Mixer, Env Mod, Poly-Mod, native LFO, Wheel Source, Mod Routes (twelve pages).

EDIT wraps within those voice pages. From Mixer / Global / Note Mix / FX / universal ARP pages, EDIT returns to the first voice page. Mixer, tuning, per-note mix, effects and arpeggiator settings remain accessible via their existing direct controls.

Universal LFO slots remain on the dedicated LFO button. EDIT within a selected universal LFO toggles only its main/configuration pair, preserving access to sync, key sync, phase and slew without traversing other sections. Repeated LFO presses still select slots 1–4. Page counters describe the current section, avoiding misleading zero/voice-count displays on global/performance pages.

No DSP, patch format, parameter values or transport semantics change. The effects feasibility gate remains closed. The two protected original folders remain unchanged; this refinement is developed on the independent effects checkout and staged for publication separately.
