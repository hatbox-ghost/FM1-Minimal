> Historical implementation record. Dates, memory projections, controls and validation claims apply to that checkpoint. See [the current audit](../audit-remediation/REPORT.md) and root README for current status.

# Clock performance, simple LEAD startup and whole-note delay

Continues the panned-double Slip implementation protected in `08a7de5`. All four synth engines, both Slip playheads, effects, sequencing and tuning remain present. No public deployment or hardware flashing.

## TEMPLE / Clock

First EDIT page: **Clock Set / Mechanics / Drift / Orbit**. ALGORITHM also selects the original seven clock sets. These controls directly address existing saved parameters6,10,13,2: the seven original FM configurations, remontoire blend, quartz wander depth and coupled mechanical modulation depth.

Repeated EDIT visits FM SOUND (FM Depth / Color / Detune / FM Envelope Amount), then FM ROUTING (Routing / Feedback / Spread / Evolution). There is one primary Clock performance page. Hold EDIT retains individual operators and envelopes; ALGORITHM in deeper editing reaches inherited shaping, original mechanical rate controls, quartz details and note mix. No parameter or advanced sound engine was removed.

The `clock_mechanics` function was compared against protected earlier `a54a230` source and is unchanged. Seven original Clock configuration sound goldens, with active mechanics, pass sample-for-sample after applying the same settings through the new layout. No sonic reference fixture was regenerated. This verifies the original neutral-extension Clock sounds; it does not identify or reverse edits in an individual browser project that cannot be inspected while browser access is blocked.

`clock.png` is the actual240×240 C framebuffer rendered offline, not a browser screenshot. The UI lists all four requested controls together without a value overlay obscuring its graphic.

## LEAD startup

Every boot initializes one audible saw oscillator: OSC1 saw, level90; OSC2/OSC3/noise levels0 and source switches off. LEAD stays mono per side. Slip still has its independently sounding original FMini instance. Glide and native/shared LFO routes retain their previously requested zero/off startup behavior.

Raising another oscillator or noise level enables its original source, so the full engine remains playable. Saved tuning, other waveform choices, detune and muted noise color remain available. Startup does not write over the saved project; saving later deliberately stores the current state.

Historical audio tests explicitly restore the historical oscillator levels/source switches through the control path before comparing immutable PCM. The new single-saw boot preference is therefore not confused with a change to the FMini DSP.

## Original Clouds delay: half and whole notes

Turning delay division below1/4 now reaches1/2 and1/1;1/1 is four beats. Half/whole dotted divisions are also available. Existing12 saved division IDs remain unchanged; the four new IDs occupy the remaining values in the existing reserved nibble, without overlapping recording or global Slip bits. Project size/version remain v19/15,664 bytes.

The normal Clouds stereo16-bit/32kHz workspace holds about1.02s. Only newly added long divisions, when they exceed that capacity, select **original Clouds quality2: stereo8-bit/16kHz**, which holds about4.08s in the same buffers. Original upstream DSP sources are unchanged; this is its own low-fidelity path, not a substitute delay algorithm. Existing divisions, free timing, granular and stretch retain their old quality and pass original audio checks. Switching buffer format clears the previous delay tail, as the original Clouds quality-change implementation requires.

At120 BPM a whole note is2s; at96 BPM2.5s; at60 BPM4s. At30 BPM8s cannot fit, so the panel honestly shows1/2 AUTO (4s), while retaining the requested1/1 ID. No extra buffer allocation or storage guard bypass was introduced.

The actual original Clouds impulse arrives at88,447 output samples, about2.0056s at120 BPM, including SRC/filter latency. Tests also verify tempo changes, whole-note persistence, shared reserved bits and slow-tempo AUTO fitting.

## Checks and delivery

`regression.log` records the successful complete build/check run, including panned stereo audio on all four synths for both arp and sequence, cumulative phasing, independent note ownership, ties/bank boundaries, both-head octave entry, all old engine goldens, new startup behavior, whole-note impulse timing and the actual native storage backend with16,166 cut points. Two-minute stress retains all four dual-head sequencers, four dual-head arps, LFOs and original effects. Browser host timing does not establish FM-1 CPU/stack performance.

The protected audio pool stays unchanged at269,724 API bytes plus65,280 canvas, with the8,192 reserve and868 spare bytes. No new audio buffers were added. The prior panned-Slip native-source allocation report remains the baseline for its additional1,732 ordinary-RAM bytes. Native linking, physical interrupt CPU and stack measurements remain unverified.

The local preview is updated at http://127.0.0.1:8784/ and previous binaries/HTML/source archives are preserved separately. Refresh the page to load the new binary. Saved browser storage was not reset or overwritten.

Automatic approval review denied browser inspection because it hit a usage limit. No browser workaround or retry through another surface was attempted. Verification used compilation, the actual C framebuffer, DSP audio output and regression checks; live browser interaction remains unverified for this update.

Verified emulator SHA-256: `c304c10da987451409d7ddb81bdb069031fa06931249688880dfc326b8fd7765`.
