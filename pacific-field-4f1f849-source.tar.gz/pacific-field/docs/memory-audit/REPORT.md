> Historical implementation record. Dates, memory projections, controls and validation claims apply to that checkpoint. See [the current audit](../audit-remediation/REPORT.md) and root README for current status.

# Pacific Field memory audit and safe optimizations

Date: 2026-11-02. Baseline: **ba4595862d82f891f54dab127ecf3b6e31792d46**, freshly rebuilt from the current source, including the startup profile. Optimization branch: **codex/full-memory-audit**. Protected checkpoint: **codex/memory-audit-baseline-ba45958**. No deployment, hardware flash, engine redesign, voice reduction, or patch-format change.

## Results and evidence limits

**20,196 bytes of persistent writable allocations reclaimed in the 32-bit source layout:** 11,480 in the native pool and 8,716 in ordinary RAM. A further **1,024 bytes of explicit audio scratch stack storage** are shared by operations with disjoint lifetimes; this is separate from the persistent savings. Original sound comparisons remain byte-identical. A final pass moved the two arp gain pairs from every generic voice into each instrument context, reclaiming a further 1,072 B beyond the initial pass while preserving both independent heads.

These are compiler-measured WASM allocations and a separate native-source layout projection, **not a successful PI32v2 firmware link**. No physical device was queried or measured. The retained Linux toolchain/SDK are present, but its Docker runtime is unavailable (`Cannot connect to the Docker daemon …/.colima/default/docker.sock`). I did not restart/setup that environment. Consequently there is no current native ELF, native instruction-size measurement, target linker placement, stack watermark, or hardware CPU proof. The report does not claim the firmware is ready to flash.

Evidence: [allocations.json](allocations.json), [before WASM map](before-wasm.map.gz), [after WASM map](after-wasm.map.gz), [individual WASM stack frames](wasm-stack-frames.json), [artifact hashes](artifacts.json), [regressions](regressions.log), and [host stress](host-stress.json). The maps identify their actual build objects and addresses; they must not be presented as native maps. Old allocation reports were not used as the baseline.

## Target memory regions

The source targets the AC79 FM-1 map with a 512 KiB RAM address window, `0x01C00000..0x01C7FFFF`. The actual board's chip identification and memory were not queried. `app.ld` allocates that window as follows:

| Region | Address / capacity | Purpose |
|---|---|---|
| RAMTEXT | 0x01C00000 / 24,576 B | flash driver routines copied from XIP |
| Reserved debug gap | 0x01C06000 / 8,192 B | not application free memory |
| RAM | 0x01C08000 / 98,304 B | initialized data and ordinary BSS |
| POOL | 0x01C20000 / 344,064 B | persistent audio state and display canvas |
| User stack | 0x01C74100..0x01C7A000 / 24,320 B | main loop/UI, storage |
| Supervisor stack | 0x01C7A100..0x01C7C000 / 7,936 B | interrupts/audio |
| Stack guards | two 256 B bands | never allocated to engines |
| NOINIT | 0x01C7C000 / 15,696 B | reset/crash/panel state; not general free memory |
| Boot/mailbox/vectors | 0x01C7FD50..0x01C80000 / 688 B | platform reserved |

Firmware expects JEDEC `0x856014`, a **1 MiB flash part**, before enabling writes (`app/main_fm1.c`). Application XIP starts at `0x02000120`, with an **581,564-byte app slot** (`0x8DFBC`). Data storage, update loader and calibration areas are separate. An address-space capacity is not a measured amount of free RAM or flash.

### Native-layout writable allocations (projection, before linker padding)

| Category | Before | After | Reclaimed |
|---|---:|---:|---:|
| Ordinary `.bss` | 94,443 | 86,239 | 8,204 |
| Ordinary `.data`, including upstream mutable globals | 583 | 71 | 512 |
| Total ordinary RAM | **95,026** | **86,310** | **8,716** |
| Ordinary capacity remaining | 3,278 | 11,994 | +8,716 |
| `.pool`, including canvas | **333,880** | **322,400** | **11,480** |
| Pool capacity remaining | 10,184 | 21,664 | +11,480 |
| Pool after retaining 8,192 B uncommitted reserve | 1,992 | **13,472** | +11,480 |

These are sums of optimized 32-bit source objects. Actual PI32v2 alignment, code in RAMTEXT, section garbage collection, startup padding and compiler-specific layouts require its real linker map. Reserve another 512 B of pool and 1,024 B of ordinary RAM for projection uncertainty when planning a new engine. NOINIT, both stacks, guards and RAMTEXT are excluded from these totals. None has been reassigned.

`pf_pool_bytes()` previously included 104 B of ordinary TORT block state and 112 B of ordinary LEAD track state. It now reports only pool-declared DSP objects. That **216 B accounting correction is not a memory saving** and is excluded from the 20,196 B result. Pool symbol sizes still exclude linker padding. The stress test now reads the actual canvas capacity instead of assuming the old 69,120 B.

## Subsystem audit

RAM figures below are native-layout object bytes. Flash figures marked “shared” cannot honestly be attributed to a single instrument after compiler inlining. Numeric flash figures are **measured WASM code + readonly/initialized data**, not PI32v2 flash sizes. Rows with “included” are explanatory and must not be added again.

| Subsystem | RAM before | RAM after | Flash before | Flash after | Reclaimed |
|---|---:|---:|---:|---:|---|
| BRANCH oscillator/resonator state (arp gains moved to context) | 4,800 | 4,320 | shared engine | shared engine | **480 B RAM** |
| TEMPLE FM state (arp gains moved to context) | 4,800 | 4,320 | shared engine | shared engine | **480 B RAM** |
| TORT synth + generic scaffolding + block/effective patch | 11,920 | 7,192 | shared engine | shared engine | **4,728 B RAM** |
| LEAD/FMIni runtime, including ordinary track | 740 | 740 | 12,397 | 12,397 | 0 |
| LEAD inert routing scratch (ordinary) | 80 | 72 | included engine | included engine | **8 B RAM** |
| Four-engine note routing (240 slots) | 10,560 | 8,640 | shared engine | shared engine | **1,920 B RAM** |
| Four shared instrument contexts (incl. LFO/arp/A playhead) | 4,640 | 4,608 | shared engine | shared engine | **32 B RAM** |
| Sine lookup, now readonly | 8,196 | 0 | included engine | included engine | **8,196 B RAM**, +8,196 B readonly flash |
| Clouds processor and two original workspaces | 188,780 | 188,780 | 89,494¹ | 89,494¹ | buffers unchanged |
| Clouds mu-law lookup | 512 | 0 | included Clouds | included Clouds | **512 B RAM**, flash initializer retained |
| Oliverb processor + delay memory | 33,056 | 33,056 | 25,767 | 9,379 | **16,388 B duplicate readonly table** |
| FX sample-rate conversion/block state | 3,688 | 3,688 | included FX adapter | included FX adapter | 0 |
| FX stereo send buses | 2,048 | 2,048 | included engine | included engine | 0 |
| Display canvas | 69,120 | 65,280 | included UI | included UI | **3,840 B RAM** |
| Sequencer program banks | 14,144 | 14,144 | shared engine | shared engine | 0 |
| Sequencer undo snapshots | 3,528 | 3,528 | included UI | included UI | 0 |
| Sequencer lock runtime | 488 | 488 | shared engine | shared engine | 0 |
| Four independent B/Slip playheads | 992 | 992 | shared engine | shared engine | 0 |
| Free-time recording events | 1,152 | 1,152 | shared engine | shared engine | 0 |
| Four command rings, 256 commands each | 8,192 | 8,192 | shared engine | shared engine | 0 |
| Live patch + storage scratch + legacy migration output | 33,412 | 33,412 | included UI | included UI | 0 |
| Sequencer MIDI owner/kind maps | 4,096 | 4,096 | included UI | included UI | 0 |
| Hardware output DMA | 4,096 | 4,096 | platform, unmeasured target | same | 0 |
| USB audio ring | 8,192 | 8,192 | platform, unmeasured target | same | 0 |
| Storage streaming scratch | 256 | 256 | platform | same | 0 |

¹ Clouds module flash includes the shared original 16,388 B window table. Oliverb uses that table; it was not removed from the system. Its two previous copies were verified byte-for-byte identical in the fresh baseline binary before sharing.

Further audit findings:

- Four universal LFOs per instrument remain: **16 × 36 B = 576 B runtime**, included in contexts, plus 256 B of serialized settings in the patch. They are independent. Their phases/random states cannot be shared between simultaneous instruments.
- Arp timing, gates, owners and dual-head state remain independent; A/B sequencer release tails retain all routing slots. No command capacity, pattern length, chord size, delay duration or voice capacity was reduced.
- Tuning ratios are already readonly: 5 × 12 floats = **240 B**. Root/anchor/transpose and note tuning remain global and saved. TORT and FMini tables are already const.
- The realtime `seqPrograms` copies and UI patch banks are not redundant scratch: audio reads/writes while UI snapshots and recording operate. Overlaying them would introduce a race. Undo snapshots are per instrument and must survive switching instruments.
- `projectScratch` was already shared among non-reentrant main-thread storage operations. `legacyOut` must survive while that scratch is initialized during migration; overlaying the two would corrupt older projects.
- The old generic TORT oscillator/filter DSP bank was unused for sound, **except the two arp pan gains**. TORT retains its actual Prophet voice array, envelopes, filters and modulation; the two arp owners retain distinct per-head gain pairs in their instrument context. Inert generic TORT writes share a single scratch object. LEAD keeps its own existing routing scratch. Neither shares live state with BRANCH/TEMPLE.
- Old `ep`, `rpL`, `rpR`, `controlCount`, `midiMask`, `arpDir` and `selected` context members had no readers/writers beyond obsolete aliases. Removing them saves 96 B after layout; adding the independent per-head pan gains uses 64 B, for a net context saving of 32 B. Moving those gains out of every generic voice saves more than their replacement cost. LEAD's inert routing scratch also shrinks by 8 B of ordinary RAM. The old layer delay-line arrays no longer exist in this current source; there is no additional large old echo allocation to reclaim.
- FMini's unused factory-browser variables (`fmini_slot`, `fmini_want`, `fmini_own`, etc.) already disappear in optimized output. They are not counted as new savings. Its live patch, noise, pink-filter, smoothing and mono priority state remain.
- The native platform still needs LCD transfer buffers (480 B fill + 64 B command), USB MIDI/endpoint/routing buffers, OTA staging (including 1,024/512/512 B working objects), crash/panel records and DMA state. Their individual allocations are in the native-source inventory; they are not safe to repurpose while firmware update/USB functions remain supported.
- Clouds' 114,688 + 65,408 B buffers contain sample history and overlapping upstream scratch allocations. No additional shortening/overlap was introduced. Granular, looping delay, WSOLA, pitch shifting, feedback, freeze and internal diffusion retain their algorithms and precision. Oliverb retains its full 16,384-word delay memory. Spectral/low-fi structures within the original processor were not excised without a separate reachability and mode-transition proof.

### Flash and browser accounting

| Fresh WASM linker measurements | Before | After | Difference |
|---|---:|---:|---:|
| Linked function bodies | 240,368 | 240,275 | −93 |
| Readonly data | 96,903 | 89,223 | −7,680 |
| Initialized writable data | 586 | 74 | −512 |
| Code + initialized data | 337,857 | 329,572 | **−8,285** |
| Complete `.wasm` artifact | 410,120 | 398,003 | **−12,117**, not native flash |

Final values include the stack scratch change; all raw measurements are retained in allocations.json.

The native **readonly/initializer saving is 8,192 B**: eliminate a duplicate 16,388 B original window, add an 8,196 B sine initializer; moving the 512 B mu-law initializer into readonly storage does not duplicate its flash contents. Native instruction savings and total native flash remaining are **unknown until a PI32v2 link**. They must not be reported using the WASM download size.

WASM places readonly tables in linear memory too. Its aggregate mapped static bytes therefore fall by more than the native writable-RAM savings. Each browser instance still reserves **4 MiB linear memory**, and audio and display use two instances. Browser-only objects include a 115,200 B full framebuffer, 17,036 B visual packet, 16,384 B emulated flash store, 8,192 B output arrays, and host MIDI bridge. Those are not present in native firmware and are excluded from native RAM headroom. The native screen uses only the strip canvas, not a 240×240 full framebuffer.

## Stack and scratch lifetimes

`pf_render` previously kept two float layer blocks and two int32 click blocks simultaneously: 2,048 B explicit scratch. Every layer's float output is fully consumed into dry/send buses before click generation begins. A local union now reuses 1,024 B for the later click phase. The next block overwrites the float members before reading them. This is local to the audio call: no engine, delay history, renderer, command ring or interrupt shares that scratch. Golden comparisons with metronome off **and on** verify it.

Compiler-emitted WASM `.su` files record individual linear-stack frames, not transitive call-stack peaks or target register spills. Before sharing, `pf_render` was 2,064 B; after sharing it is **1,040 B**. The largest UI individual frame is `pf_load`, 2,592 B. `single_render` is 544 B, effect adapters are 256 B each, and UI content is 160 B. Zero-byte WASM frames often mean locals are in the VM operand/register stack; they do **not** imply zero native stack use.

Planning estimate only: allow 4–8 KiB main/UI peak and 4–6 KiB audio/interrupt peak pending actual target stack reports and hardware guard/watermark tests. Nominal remaining space under the upper estimate would be 16,128 B main and 1,792 B supervisor. **Verified worst-case stack headroom is unknown**. Retain both guard bands and existing stack regions; do not spend their apparent margin on resonators. The separate 8 KiB pool reserve is not a substitute for supervisor stack capacity.

## Patch storage and compatibility

Current serialized patch remains **15,584 B, version 16**. Physical per-bank payload remains **16,128 B**, leaving **544 B**. Two 16 KiB banks occupy 0xD0000..0xD7FFF, with header/payload metadata separate from RAM. Calibration banks at 0xDC000/0xDD000 and old project fallback at 0xFC000/0xFD000 are unchanged. Native capacity guard is still enabled. Ownership of these flash regions by the actual factory/update environment still requires device verification before flashing.

All serialization members and offsets remain unchanged. Saving, old-version migration and startup behavior pass the existing tests. The actual native storage backend regression covers 16,166 interrupted-write positions, legacy fallback, calibration isolation, payload overflow and invalid object rejection. None of the unused *runtime* fields removed here was serialized.

## Existing BRANCH removal and a future budget

**No BRANCH removal or redesign occurred.** Its 60 × 72 B independent generic DSP bank accounts for **4,320 B** that a replacement could free. Its 60 × 36 B routing bank (2,160 B), shared context, four LFOs, sequencer/arp, note ownership and UI/patch storage should remain for a playable replacement. Removing the entire channel could free those too, but would violate the four-instrument objective and is not proposed. Its code is intertwined/inlined with shared routing; an exact BRANCH-only flash figure cannot be extracted by subtracting the whole engine object.

Conservative planning after replacing only those 4,320 B:

- Pool room: 21,664 current raw headroom + 4,320 replaceable state − 8,192 reserve − 512 alignment uncertainty = **17,280 B total for replacement DSP**.
- Propose **12 KiB maximum persistent new BRANCH DSP** initially, leaving about 4,992 B beyond the explicit reserve. This is a design budget, not an allocation already made.
- Ordinary RAM: 11,994 current raw headroom − 1,024 uncertainty = **10,970 B**. Initially budget at most **4 KiB** of additional control/metadata; keep the remainder uncommitted.
- Patch space remains only 544 B. Reuse BRANCH's existing 28 parameters where sensible; initially budget no more than 256 B of new serialized state, with an explicit new migration if needed.
- A plausible 12 KiB design could cover 60 compact oscillator/LPG/excitation states, a small modal coupled network and pink-noise/generative state, retaining all note owners. Example planning buckets: oscillator/FM/wavefold state 3,840 B; compact resonator state 3,840 B; LPG/envelopes 960 B; noise/impulses 960 B; coupling/autonomy 1,024 B; remainder 1,664 B. These are illustrative byte budgets, not a proven sound architecture. Long per-voice physical delay lines or heavy oversampling would require a different budget.
- Do not infer CPU feasibility from this memory. First prototype against the original character, measure maximum simultaneous TORT/TEMPLE/LEAD/BRANCH + original FX + Slip load on hardware, then choose implementation details. Physical audio deadlines, target stack high-water and final native section fits remain gates before a hardware release.

## Further opportunities, ranked

| Opportunity | Potential savings | Risk / effort | Decision |
|---|---|---|---|
| Replace current BRANCH-specific DSP bank | 4,320 B pool | intended larger redesign / high effort | budgeted separately; untouched |
| Specialize unused per-engine context portions (Temple mechanics in other channels, TORT config copies elsewhere) | hundreds of bytes | medium; command/modulation callers and snapshots need layout migration | investigate next; no unsafe alias introduced |
| Split BRANCH/Temple generic per-voice structures by their actual fields | low KiB | medium/high; generic note/arp/reset writes currently touch both sets | retain independent banks; prove every write before overlaying fields |
| Native per-data-section dead stripping of unused upstream resource tables | potentially substantial flash, unmeasured | medium; needs actual PI32v2 link and retained debug/platform symbols review | do not claim savings before native measurement |
| Overlay OTA/boot-only scratch with inactive main-thread storage scratch | low KiB | high; update entry, interrupted saves, USB callbacks and flash-off routines | not implemented without lifecycle proof |
| Separate audio-only/display-only WASM builds | host memory/code only | medium; deployment/worker ABI change | no FM-1 RAM saving; not this task |
| Pack patches or reduce note ownership maps | potentially KiB | high; migration/race/recording behavior | retain current compatibility and all owners |
| Share live DSP states between instruments, reduce voices, shorten FX lines, lower precision | potentially large | compromises simultaneous playback/quality | explicitly rejected, not implemented |

## Validation and local delivery

The 24-suite build/check pipeline passed after the safe changes, including sound engines, 16 LFOs, global tuning/transpose, ordered mixer, direct keyboard/SEL, release ownership, SLOOP recording, chord/tie/gate/Slip scheduling, boundaries, display snapshots/pixels, original FX, migration and simultaneous load. Audio fixture hashes were **not** rebaselined. Direct comparisons against this task's checkpoint also passed for the four-engine/generator/sequence/effects mix and all three Clouds modes with pitch/freeze. Metronome-on comparison additionally covers the shared stack scratch. A separate checkpoint comparison enables all four dual-head arps together with the metronome, validating the per-head pan-state relocation without changing audio.

Host stress covers 27 manual keys per engine, native generators, four MIDI owners per engine, A/B sequence chords, 16 LFOs and both original effects, with finite/clipped output, no dropped commands or FX faults, and clean note ownership at stop. Host wall-clock measurements vary with OS scheduling: an intermediate candidate had a 12.83 ms outlier; the final suite measured ~33.8% average and 1.28 ms maximum per 2.90 ms host block. **Neither is a hardware CPU guarantee.** See retained logs for the exact final run.

The optimized local binary is `fm1/build/emu/amb.wasm`; rebuild it with:

```sh
EMCC=$SCRATCH/pacific-emsdk/upstream/emscripten/emcc \
NODE=$SCRATCH/pacific-emsdk/node/24.19.0_64bit/bin/node \
PF_MEMORY_AUDIT=$SCRATCH/pacific-memory-final \
python3 fm1/pacific/check-fx.py
```

`PF_MEMORY_AUDIT` adds the linker map and stack-usage emission. `gen-sine-table.py` reproducibly regenerates the readonly table from the original float fastmath initializer; it does not use libm. Shared-window adaptation is enabled for browser and native C++ builds by `PF_SHARED_FX_WINDOW`; upstream table data and licenses remain present. Without the flag Oliverb still defines its original standalone table.

The public site, `dist/amb.wasm`, downloadable public source archive, protected saved folders and checkpoint branch remain unchanged. The optimized source is committed only on the audit branch. BRANCH redesign remains paused.

To reproduce the 32-bit native-source inventory independently, run `project-native-layout.py BASELINE_SOURCE_ROOT OPTIMIZED_SOURCE_ROOT OUTPUT_ROOT` with `EMCC` set, then pass its `before/native-main.ll` and `after/native-main.ll` alongside the two WASM maps to `analyze.py`. The projection emits no target instructions or executable hardware build.
