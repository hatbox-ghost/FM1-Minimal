#!/usr/bin/env python3
"""Reproduce measured wasm allocations and a separate 32-bit native-source projection.
Usage: analyze.py BASELINE_MAP AFTER_MAP BASELINE_MAIN_LL AFTER_MAIN_LL OUTPUT_JSON
No PI32v2 linker map or hardware measurement is inferred from these files.
"""
import sys,re,json,pathlib,collections

def maprows(path):
 rows=[]
 for line in pathlib.Path(path).read_text().splitlines():
  m=re.match(r'\s*([a-f0-9-]+)\s+([a-f0-9]+)\s+([a-f0-9]+)\s+(.+):\((.+)\)$',line)
  if m:rows.append(dict(address=None if m[1]=='-' else int(m[1],16),bytes=int(m[3],16),object=pathlib.Path(m[4]).name,section=m[5]))
 return rows

def irrows(path):
 s=pathlib.Path(path).read_text();types=dict(re.findall(r'^(%[^ ]+) = type (.+)$',s,re.M));cache={}
 def parse(t):
  t=t.lstrip()
  if t.startswith('ptr'):return (4,4),t[3:]
  m=re.match(r'(i\d+|float|double)',t)
  if m:
   k=m[1];n={'float':4,'double':8}.get(k) or (int(k[1:])+7)//8
   return (n,min(n,8)),t[m.end():]
  if t.startswith('%'):
   m=re.match(r'%(?:"[^"]+"|[\w.$]+)',t);k=m[0]
   if k not in cache:cache[k]=parse(types[k])[0]
   return cache[k],t[m.end():]
  if t.startswith('['):
   m=re.match(r'\[(\d+) x ',t);(n,a),tail=parse(t[m.end():]);assert tail.lstrip().startswith(']'),tail
   return (int(m[1])*((n+a-1)//a*a),a),tail.lstrip()[1:]
  packed=t.startswith('<{');assert t.startswith('{') or packed,t[:100]
  tail=t[2:] if packed else t[1:];off=0;alignment=1
  while not tail.lstrip().startswith('}'):
   (n,a),tail=parse(tail);a=1 if packed else a;off=(off+a-1)//a*a+n;alignment=max(alignment,a);tail=tail.lstrip()
   if tail.startswith(','):tail=tail[1:]
  tail=tail.lstrip()[2 if packed else 1:]
  return ((off+alignment-1)//alignment*alignment,alignment),tail
 rows=[]
 for l in s.splitlines():
  m=re.match(r'^@([^ ]+) = .*?\b(global|constant) (.*)',l)
  if not m or 'external ' in l or m[1].startswith('llvm.'):continue
  (n,a),tail=parse(m[3]);align=re.search(r'\balign (\d+)',tail);a=int(align[1]) if align else a
  sec=re.search(r'section "([^"]+)"',tail)
  category=sec[1] if sec else '.rodata' if m[2]=='constant' else '.bss' if re.match(r'\s*(zeroinitializer|null|false|0(?:\.0+e\+00)?)(?:,|$)',tail) else '.data'
  rows.append(dict(symbol=m[1],bytes=n,align=a,section=category))
 return rows

def summarize(rows):
 d=collections.defaultdict(int)
 for r in rows:d[r['section'].split('.')[1] if r['section'].startswith('.') else 'code']+=r['bytes']
 return dict(d)
a,b,c,d,out=sys.argv[1:];data={'limitations':'WASM linker measured; native main LLVM globals are 32-bit source projection, not target placement, instruction sizes or a linked firmware. Explicit per-object alignment and dead-section GC can change native totals.','before':maprows(a),'after':maprows(b),'native_main_before':irrows(c),'native_main_after':irrows(d)}
for label,path in [('before',c),('after',d)]:
 allrows=[]
 for ll in sorted(pathlib.Path(path).parent.glob('native-*.ll')):
  for row in irrows(ll):row['object']=ll.name;allrows.append(row)
 data['native_all_'+label]=allrows
for k in list(data):
 if isinstance(data[k],list):data[k+'_totals']=summarize(data[k])
pathlib.Path(out).write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({k:v for k,v in data.items() if k.endswith('_totals')},indent=2))
