#!/usr/bin/env python3
"""Emit optimized native-source globals through a 32-bit LLVM frontend.
This does NOT compile PI32v2 instructions, link firmware, or execute MMIO.
Arguments: baseline source root, optimized source root, output root.
EMCC must name the retained Emscripten compiler. Generated font header must exist
in optimized_source/fm1/build/gen (the normal workstation build prerequisite).
"""
import os,pathlib,subprocess,sys,json
baseline,current,out=map(lambda s:pathlib.Path(s).resolve(),sys.argv[1:])
em=pathlib.Path(os.environ['EMCC']);commands=[]
def run(args):
 commands.append(list(map(str,args)));subprocess.run(list(map(str,args)),check=True)
for label,source in [('before',baseline),('after',current)]:
 dest=out/label;dest.mkdir(parents=True,exist_ok=True);root=source/'fm1'
 inc=dest/'declarations';inc.mkdir(exist_ok=True)
 # main.c supplies its own freestanding libc with 32-bit unsigned lengths.
 # The host frontend's libc size_t spelling differs; declarations only, no code.
 (inc/'string.h').write_text('#pragma once\nvoid *memcpy(void*,const void*,unsigned);\nvoid *memset(void*,int,unsigned);\nint memcmp(const void*,const void*,unsigned);\nunsigned strlen(const char*);\nint strcmp(const char*,const char*);\nchar *strcpy(char*,const char*);\n')
 run([sys.executable,root/'tools/gen_words.py',root/'firmware/words.tsv',dest/'words',dest/'ann_words.h'])
 run([em,'-Os','-fno-builtin','-DPACIFIC_FIELD','-I'+str(inc),'-I'+str(root/'firmware/hal'),'-I'+str(root/'firmware/src'),'-I'+str(current/'fm1/build/gen'),'-I'+str(dest),'-S','-emit-llvm',root/'firmware/src/main.c','-o',dest/'native-main.ll'])
 for name in ['engine.c','fx.c','lead.c','lead-double.c']:
  if not (root/'pacific'/name).exists():continue
  run([em,'-O2','-DPACIFIC_FIELD','-ffp-contract=off','-S','-emit-llvm',root/'pacific'/name,'-o',dest/('native-'+name+'.ll')])
 for name in ['clouds','oliverb']:
  flags=['-std=c++11','-fno-exceptions','-fno-rtti','-DTEST','-Dclouds=pf_'+name,'-Dstmlib=pf_'+name+'_stmlib','-I'+str(root/'pacific/upstream'/name)]
  if label=='after':flags+=['-DPF_SHARED_FX_WINDOW']
  run([em.with_name('em++'),'-O2','-ffp-contract=off',*flags,'-S','-emit-llvm',root/'pacific'/(name+'-port.cc'),'-o',dest/('native-'+name+'.ll')])
(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
