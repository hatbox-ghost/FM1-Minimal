> Historical implementation record. Dates, memory projections, controls and validation claims apply to that checkpoint. See [the current audit](../audit-remediation/REPORT.md) and root README for current status.

# TEMPLE — continuous FM expansion

TEMPLE is one expanded instrument. There is **no Classic mode, replacement bank or separate legacy engine**. The existing seven ratio sets, sustained sounds, quartz/mechanical motion, evolution, tension, remontoire recovery, drift and freeze remain available in the same controls. With the new controls neutral, automated captures match **all seven previous TEMPLE configurations sample-for-sample with active mechanics**. Branch, OberVave TORT and LEAD also match the protected build.

Baseline: `174762e`, preserved at `codex/pre-temple-expansion-174762e`. Development branch: `codex/temple-fm-expansion`. The previous local preview is retained in `$SCRATCH/pacific-pre-temple-preview`. Current preview: http://127.0.0.1:8784/. No public deployment or hardware flash was performed.

## What changed

The old engine already used six sine oscillators, arranged as three parallel FM pairs, but the seven choices mainly changed their frequency ratios and weights. All pairs shared the amplifier shaping and had no independent strike/body decay. That explains why different settings often stayed in the same sustained, hazy family.

The same oscillators now have:

- **32 six-operator routing patterns**, including long stacks, shorter parallel stacks and additive arrangements.
- Independent ratios and levels for all six operators.
- **Body Decay** for carriers and **Strike Decay** for modulators. A brief modulator envelope gives a bright strike that softens while the carrier rings.
- Per-operator decay overrides. Zero inherits the Body/Strike setting; nonzero supplies that operator's own decay. The routing determines which operators are carriers and modulators.
- Feedback using two-sample history, including feedback paths spanning operators where specified by the routing table.
- Eight operator waveforms: sine, half sine, absolute sine, quarter pulses, alternate, camel, square and saw.
- A diagram derived from the selected routing table, with carrier/modulator colors, output connections, feedback and operator level bars.

The existing quartz/mechanical controller still modulates FM depth, oscillator detuning and brightness across these expanded networks. It does not transpose the note center or reintroduce the removed climbing feature. Keyboard, MIDI, arp, both sequencer playheads, ties/slides, gate/release, global tunings, mixer, spread and shared effects retain their ownership and behavior. The new FM parameters also support sequencer locks and restore their panel values on STOP.

## FM Lab source use

Inspected the actual [FM Lab repository](https://github.com/jsmith13/fm_lab), retained separately at `$SCRATCH/pacific-fm-lab-reference`. The exact revision is recorded in `fm1/pacific/upstream/fm-lab/PIN.json`.

The original `DX_ALG[32][6]` routing table was extracted unchanged from `firmware/src/dx7_core.c`, originally Dexed/msfa and carried through Sven Trogus's C port and FM Lab. Its attribution, GPL-3.0-only / Apache-2.0 notices, full license texts and upstream licensing description are included. The operator waveform palette follows FM Lab's waveform design, adapted to TEMPLE's existing floating-point sine lookup.

**This is not a transplant of FM Lab's complete DX7 core.** TEMPLE keeps its own oscillator sound, timing, shared amplifier and mechanics. Its new operator decays are exponential shaping, not DX7 four-stage rate/level envelopes. FM Lab's independent firmware platform, UI, banks, sequencer, effects, allocator and native LFO infrastructure were not imported. No Yamaha/M-VAVE patch data was copied. This approach expands the existing sound without adding a second instrument mode or reducing its voice allocation.

## Controls

Main EDIT retains Oscillator Mix, FM Depth, **Ratio Set** and Detune. “Ratio Set” is the existing seven-choice control formerly labelled ALGO; saved values and sound stay unchanged. **Routing** is the separate, genuine 32-network selector.

| Repeated EDIT | Knobs 1–4 |
|---|---|
| 1: Main | Oscillator Mix / FM Depth / seven Ratio Sets / Detune |
| 2: FM Character | Body Decay / Strike Decay / 32 Routing algorithms / Feedback |
| 3: Operators 1–2 | OP1 ratio / OP2 ratio / OP1 level / OP2 level |
| 4: Operators 3–4 | OP3 ratio / OP4 ratio / OP3 level / OP4 level |
| 5: Operators 5–6 | OP5 ratio / OP6 ratio / OP5 level / OP6 level |
| 6: Operator shape 1 | OP1 decay / OP2 decay / OP1 wave / OP2 wave |
| 7: Operator shape 2 | OP3 decay / OP4 decay / OP3 wave / OP4 wave |
| 8: Operator shape 3 | OP5 decay / OP6 decay / OP5 wave / OP6 wave |
| 9–13: existing pages | FM Field / Mechanics / Quartz Drift / Voice Spread / Note Mix |

ENV alternates the existing Attack/Release/Level page and FM Character. HOME, GLO, LFO, FX, instrument selection, physical MASTER and the existing algorithm encoder behavior remain. The old clock graphic remains on its original pages; the operator pages show the routing diagram. The temporary bottom value strip remains.

Decay zero is **SUSTAIN** for Body/Strike. Other values span about 20 ms to 106 seconds and display milliseconds. Per-operator zero is **INHERIT**. Ratios display **PROFILE** when using the original ratio set; overrides span 0.25–31.00 in quarter-ratio steps. Levels and feedback display percentages. Sine waves, inherited ratios, full relative operator levels, sustained Body/Strike and routing 5 reproduce the old three-pair sound without a Classic switch. The four existing LFOs remain; this pass does not add a new per-operator LFO matrix.

## Starting sounds

These are settings in the same synth, not additional modes. Keep effects sends at zero to hear the envelope clearly.

**Pluck:** amp Attack 0; Body Decay 34 (about 348 ms), Strike Decay 20 (about 103 ms), Feedback 8, routing 5. The test example uses OP ratios 1/2, 2/3 and 1/1, with relative levels 100/80, 70/65 and 40/50. Try other original Ratio Sets with ratios left at PROFILE too.

**Tubular bell:** amp Attack 0; Body Decay 70, Strike Decay 32, Feedback 12, routing 5. Ratios OP1–6: 1, 3.5, 2.75, 7, 5.5, 10.5. Levels: 100, 80, 45, 55, 25, 35. Use a longer amp Release if you want the bell to keep ringing after lifting the key; a shorter release still intentionally chokes the note. Operator decay overrides can remain INHERIT.

To return to sustained shaping, set Body and Strike to SUSTAIN and operator decays to INHERIT. To recover the exact original ratio set's voicing, also return ratios to PROFILE, waves to sine, relative levels to 100, routing to 5 and feedback to zero. Existing saved projects initialize those neutral extensions automatically.

## Memory, storage and checks

The operator envelope and feedback history use **previously unused fields in TEMPLE's existing per-voice state**. Generic note/arp/sequence setup no longer overwrites those fields. No new per-voice allocation, heap, voice-pool reduction or other-engine state sharing was introduced. Tied/sliding notes retain their operator envelopes; true retriggers restart them.

| Allocation | Before | After |
|---|---:|---:|
| Conservative realtime pool API | 269,724 B | 269,724 B |
| Canvas | 65,280 B | 65,280 B |
| Spare after pool + canvas + 8,192 B reserve | 868 B | 868 B |
| Native-source ordinary BSS + data projection | 86,594 B | 86,774 B |
| Native-source pool projection | 334,788 B | 334,788 B |
| Project payload | 15,600 B, v17 | 15,632 B, v18 |
| Spare in native 16,128 B project object | 528 B | 496 B |
| WASM file | 496,978 B | 506,498 B |

The 180 B projected ordinary-RAM increase comprises two 32 B patch extensions, 32 B runtime parameters and an 84 B shared coefficient/control block. The per-sample temporary envelope/bus arrays total nine floats, separate from persistent voice RAM. Actual native stack watermark and final linker placement remain unverified. New patch bytes are appended after the full v17 prefix, with compile-time offset/size guards. Old projects preserve their complete musical prefix and get neutral new controls. Boot does not overwrite stored data.

The full automatic `check-fx.py` build/regression suite passes. New checks cover all 28 exposed FM controls, all 32 reachable and distinct routing captures, held-pluck decay versus a ringing bell, zero-level silence, persistence, direct navigation and real audio-owned parameter locks/restoration. The protected pre-expansion comparison covers all seven ratio sets with mechanics active plus the other three synths. Existing three-minute clock stability/freeze, sequencing/Slip, MIDI, tuning, original effects, startup and native storage power-interruption checks pass. The real storage backend passes 16,166 simulated interruption points without bypassing its capacity guard.

Combined load was tested with all four engines, all 16 LFOs, keyboard/MIDI/A/B ownership, both original effects, high-drive LP24 TORT, and six representative TEMPLE routings. On this computer, the recorded average is approximately 35–45% of a 128-frame block's duration; the highest observed block is about 1.59 ms versus a 2.90 ms block duration. Host results are evidence for this browser build, **not FM-1 CPU certification**. No voice counts were reduced. Native target link/flash size, interrupt-cycle maximum, stack watermark and sustained device playback still require actual FM-1 testing; no extended toolchain setup or flash was attempted.

Evidence: `regressions.log`, `host-stress.json`, `allocations.json`, both compressed WASM maps, `artifacts.json`, and the preserved v17/PCM fixtures. Maps are WASM linker maps; the separate 32-bit native-source allocation projection is not a successful PI32v2 link.

## Browser preview

The new preview tab has an unsaved short-pluck example (fast amp attack, Body 348 ms, Strike 103 ms and Feedback 8%). No SAVE or factory reset was used, and the user's other tab and saved project were left alone. Repository defaults remain neutral.

![Expanded TEMPLE routing and articulation controls](browser.png)
