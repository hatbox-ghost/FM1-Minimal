> Historical implementation record. Dates, memory projections, controls and validation claims apply to that checkpoint. See [the current audit](../audit-remediation/REPORT.md) and root README for current status.

# Effects redesign and universal FREE/SYNC timing

Baseline: 6438fe0, protected as `$SCRATCH/pacific-before-efx-redesign.wasm`. Development branch: `codex/efx-redesign`. Original Clouds and Parasites Oliverb implementations, their adapters, shared stereo routing and all four synthesizer sound engines are preserved. No additional effects instance or audio buffer.

## Final page map

FX opens MAIN from other screens. Repeated FX presses cycle **MAIN → OLIVERB → OLIVERB 2 → CLOUDS → CLOUDS 2**, then MAIN: five pages instead of six. IDs remain 6, 35, 36, 37, 38. The retired page 39 redirects to Clouds' return row. EDIT immediately returns to the selected instrument's primary voice page. Preset rotation still selects the instrument; MAIN identifies whose sends are being edited. All large value feedback remains in the temporary bottom strip.

| Page / row | Knob 1 | Knob 2 | Knob 3 | Knob 4 |
|---|---|---|---|---|
| EFX MAIN | Selected instrument REVERB SEND (par27) | Selected instrument DELAY SEND (par24) | FEEDBACK (fx12) | DELAY TIME / division (fx8) |
| OLIVERB | SIZE (fx0) | DECAY (fx1) | DAMPING (fx2) | MODULATION amount (fx4) |
| OLIVERB 2 / Motion | DIFFUSION (fx3) | MOD RATE (fx5) | FREEZE (fx6) | REVERB RETURN (fx7) |
| OLIVERB 2 / Return | HIGH PASS (fx18) | FX MASTER (fx19) | — | — |
| CLOUDS | MODE (fx9: Delay / Granular / Stretch) | PITCH (fx11) | GRAIN / LOOP SIZE (fx10) | TEXTURE (fx13) |
| CLOUDS 2 / Record | POSITION / delay time (fx8) | DENSITY (fx16) | SPREAD (fx17) | FREEZE (fx14) |
| CLOUDS 2 / Return | CLOUDS RETURN (fx15) | — | — | — |

All 20 existing shared FX parameters are retained, including return trims, high-pass and global FX gain. No renumbering of saved values. The **ALGORITHM rotary encoder** switches the two clearly labeled rows on each secondary page; no encoder click or held SELECT gesture. The separate SELECT rotary control scrolls FX pages. **SEL button always controls latch**, even with FX held; the former FX+SEL sync shortcut is removed.

## Universal timing gesture

Tap GLOBALS normally to navigate global pages. Holding it does not navigate first. Hold GLOBALS and turn the relevant timing knob to toggle FREE/SYNC; continued movement during that same hold cannot toggle it repeatedly. Release GLOBALS, then turn normally to adjust the selected timing mode. Hold and turn again to return. The same gesture works for:

- Delay Time on MAIN and CLOUDS 2's first row, in original looping-delay mode only. FREE adjusts the retained independent time in 5ms increments; SYNC steps through straight, dotted and triplet divisions, including 1/1. Existing honest buffer-fit/AUTO behavior is retained. Granular/stretch position is not falsely presented as a tempo-synchronized delay.
- Both ARP Rate and Div/Rate knobs: FREE adjusts that instrument's retained local tempo (1 BPM increments); SYNC adjusts its division and follows project BPM. The local free tempo and division remain remembered.
- SEQ Rate on Pattern and Banks pages: FREE adjusts that instrument's existing lane BPM (1 BPM increments), leaving other lanes/project tempo alone; SYNC selects musical divisions against project BPM. The remembered division determines the beat fraction in either clock mode. Project tempo remains on GLOBALS.

This is continuous rate adjustment rather than quantization to musical subdivisions in FREE mode; the digital controls still have the stated finite resolution. Arp/sequence sync is independent per instrument; delay sync belongs to the shared effect. Existing Slip copies inherit their owner's chosen clock. Mode changes do not restart playheads or release held notes.

Existing GLOBALS+ARP mute and GLOBALS+SEQ solo remain. Hold/release bookkeeping prevents those combinations from opening an unrelated page. Freeze, performance transport and latch retain their separate buttons. There are no new timing settings pages.

## Signals and graphics

New metering measures peak magnitudes of the two actual DSP input buses and two original DSP outputs per native 32-frame processing block, with a decaying peak envelope. Outputs are measured before return/master trims; this is DSP activity, not a physical output loudness meter. Four scalar meter values (16 bytes) live outside the audio pool. A four-scalar temporary peak accumulator is not an audio buffer.

The firmware renderer uses those measurements and existing parameters:

- MAIN: unified lavender expanding ellipses plus coral pulses on the same field. Reverb send/size emphasize the field; delay send emphasizes pulses; feedback controls repetition/trails; effective delay time controls their cadence.
- OLIVERB: radial expansion follows active input/tails. Size sets field size, decay sets persistence, damping removes fine rings/detail, and the actual modulation amount/rate deform the field. No constant rotation. Silent fields stop moving; freeze uses continued processed output without presenting live input as new excitation.
- CLOUDS: Delay uses repeating elliptical pulses; Granular uses moving particles on broken elliptical paths; Stretch uses slow elongated threads. Pitch changes motion/geometry; grain size changes grouping; density, spread and feedback remain visible. Freeze suppresses the new-input marker and input-driven activity while existing processed output can continue moving.

Ring ages, individual particle positions and visual trails are lightweight **illustrations**, not the actual Oliverb delay-line positions or Clouds grain/read heads. Color overlap does not imply audio cross-feedback: the effects remain parallel shared buses. Meter values and displayed parameter states are measured/read directly; the geometry communicates them without simulating another DSP engine.

All geometry is implemented in the same C firmware renderer used on FM-1. Audio does not rasterize pixels. The browser display worker receives the two detail-row selectors and four meter values in its existing snapshot pipeline. Instrument voice graphics are unchanged.

## Persistence, memory and native status

Patch remains **15,664 bytes**, below the guarded native payload capacity of 16,128 bytes. Version 21 reuses seqReserved bits 8–11 for the four arp sync flags and activates the existing per-lane sync/BPM fields. Old versions migrate to the actual previous behavior: arps keep local clocks and all sequencers follow project BPM (those old sync fields were previously ignored). Existing FX values and recording/delay flag bits survive. No storage write occurs until SAVE.

Protected pool remains 269,724 bytes; canvas 65,280; reserve 8,192; margin **868 bytes**. No new framebuffer, sample buffer or voice allocation. Browser-only packet growth is 16 bytes; row selectors fill existing padding.

Native storage-backend capacity/cut-point regression passed. A complete new PI32v2 firmware link and on-device CPU/audio measurement were not performed; these remain unverified and are separate from emulator success. The actual native renderer source is shared and changed here, not a browser-only imitation.

## Verification and files

The full `check-fx.py` suite passed: automatic compilation; effects modes, impulses, pitch, freeze and actual synced echo intervals; all engine and timing regressions; immutable audio goldens; navigation; browser AudioWorklet/display-worker separation; two-minute four-engine sequence/arp/Slip stress; migration; and real native storage-backend cut points. Legacy test setup was updated to use the new physical control map and GLOBALS for project BPM; audio golden captures were not regenerated.

A final frozen-input visual gating adjustment was rebuilt and checked with the new EFX test, original-binary wet-tail PCM comparison and browser worker test. The universal timing test measures actual scheduler intervals, not only displayed flags. It covers one toggle per hold, independent FREE clocks, project-following SYNC clocks, both timing access points, latch ownership and save/reload. All original DSP tails remain sample-identical to the protected baseline while changing FX pages.

Main implementation files: `app.c`, `navigation.h`, `ui-v2.h`, new `fx-visual.h`, `fx.c`/`fx.h` (read-only metering), `engine.c`/`sloop-core.h` (clock selection), `pacific.h` (arp flag definition), `web.c`, `web/emu/worklet.js` and `index.html`. New `test-efx-redesign.mjs` and `test-fx-controls.mjs` exercise the actual mappings; existing affected panel/migration tests were updated. No upstream DSP files changed.

Screenshots and contrasting states are in [gallery.html](gallery.html). These are actual firmware framebuffer captures, not mockups. Browser automation was previously blocked by approval-review usage limits; no alternate browser-control route was used. The local HTTP binary is verified independently.
