# HOLD / SHIFT — pre-change assignment audit

Working baseline: `11b776d`, current audit/handoff source. Reference: the retained `Pacific-Field-c53fbd0.zip` snapshot, exact source `c53fbd03771510559f1d18dd5598ad7e5e7cb888`. The separately named `(2)` duplicate was not present; the commit-pinned original snapshot was inspected read-only. It is older than the current source and is not used to roll back later fixes.

## Existing button map, inspected before implementation

| Button / gesture | Baseline behavior | Conflict / planned handling |
| --- | --- | --- |
| SEL | Current source: per-instrument latch toggle + LED; c53fbd0: FX+SEL also toggled delay sync | Preserve current dedicated latch; remove obsolete FX+SEL browser instructions |
| GLO tap / release | Open/cycle Project, Tuning, System | Consumed only for K1–K4 or mute/solo, not all other gestures; add complete consumption and a 400 ms tap/hold distinction |
| GLO + timing knob | Toggle FREE/SYNC once per timing family per held gesture | Already implemented for delay time, ARP rate/division and SEQ rate/division; retain values and mapping |
| GLO + new keyboard key | Absolute transpose; captured key release cannot become a note | Missing consumed-GLO flag; fix accidental GLOBALS navigation on release |
| GLO + ARP / SEQ | Instrument mute / solo | Preserve; consume both button edges so they do not navigate |
| SEQ held first + GLO + ninth/tenth white key | Global fill / alternate-fill performance controls | Preserve grid/performance semantics; consume GLO so release does not open GLOBALS |
| SELECT / ALGORITHM / PRESETS encoders while GLO held | Normal context-specific encoder behavior | Currently do not consume GLO; prevent accidental GLOBALS page opening; preserve encoder actions |
| HOME | Mixer; repeats volume/pan/reverb-send/delay-send | Preserve |
| EDIT | Voice pages; TEMPLE long press opens operators | Preserve |
| ENV / LFO / FX / ARP | Existing page-family entry/cycling | Preserve |
| SEQ tap / hold | Sequencer family / white-key grid | Preserve |
| PLAY; PLAY+HOME | Sequencer transport; generator transport | Preserve |
| REC tap / hold | Arm/finish take; process freeze | Preserve |
| OCT− / OCT+ | Keyboard octave; Notes page tools and existing grid edit gestures | Preserve |
| SAVE | Immediate project save on press in every context | Preserve; do not turn recording-time SAVE into an undo |
| SEQ+EDIT+OCT− or OCT+ | Existing pattern snapshot undo/redo swap on sequencer pages | Separate from SEL and SAVE; preserve |

## SAVE / UNDO decision

A context-sensitive SAVE undo would replace an existing valid save action while recording, or would require deferring all saves to distinguish taps/holds. Neither is necessary for this cleanup. SAVE remains save even on SEQ RECORD and while GLO is held. Existing sequencer undo stays available through its existing gesture; no new menu or button combination is introduced.

## Scope boundary

Only input gesture handling, matching browser help, regression tests and documentation may change. Synthesis, effects DSP, sequencer playback/recording algorithms, patch schema and parameter IDs remain unchanged. Note ownership and existing saved latch/sync settings must survive the revised modifier handling.

## Platform / retained-source boundary

The active native path selects `pacific/hardware-ui.h` → `pacific/app.c` when `PACIFIC_FIELD=1`; browser `web.c` includes the same app controller. Retained `firmware/src/app/ui.c` and upstream SLOOP controller assignments are legacy/reference code, not active Pacific button handlers. The platform's raw `buttons & 3` startup gesture is documented as OCT− + OCT+ calibration, not logical FX+SEL; it is unchanged. Existing boot/recovery, screen-reader and physical MASTER behavior is untouched.
