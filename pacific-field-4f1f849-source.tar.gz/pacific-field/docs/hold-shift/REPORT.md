# Pacific Field — HOLD / SHIFT button cleanup

Baseline: `11b776d` (audit/handoff). Branch: `codex/hold-shift-cleanup`. The pre-implementation assignment/conflict audit is [AUDIT.md](AUDIT.md). The retained c53fbd0 source ZIP was inspected as a reference without overwriting or reverting the working build.

## Final button map

| Gesture | Action |
| --- | --- |
| **SEL press** | Dedicated selected-instrument **HOLD/latch** toggle in every context; existing HOLD and keyboard LEDs preserved |
| **GLO tap** | Open GLOBALS; repeat to cycle Project Clock → Tuning → System |
| **GLO held** | **SHIFT**; a hold lasting 400 ms or more does not open GLOBALS on release |
| **GLO + timing/division knob** | Toggle FREE / project-BPM SYNC once for that timing family during the gesture; release GLO before changing the rate/division |
| **Timing knob, GLO released** | Existing independent free rate/time, or musical divisions when synchronized |
| **GLO + new keyboard key** | Existing absolute project transpose; C2 resets. The shortcut key is consumed and its release cannot become a new note |
| **GLO + ARP** | Existing selected-instrument mute |
| **GLO + SEQ** | Existing selected-instrument solo |
| **SEQ held first, then GLO + ninth/tenth white key** | Existing global fill / alternate-fill performance gestures |
| **SAVE** | Immediate project save on press, including while recording and with GLO held |
| **SEQ + EDIT + OCT−/OCT+ on sequencer pages** | Existing snapshot undo/redo gesture, separate from SEL and SAVE |
| **SELECT / PRESETS / ALGORITHM rotary encoders** | Existing context-specific browsing/editing; turning while GLO is held consumes SHIFT and never opens GLOBALS on release |

HOME mixer cycling; EDIT/ENV/LFO/FX/ARP/SEQ page navigation; octave/tools; PLAY and PLAY+HOME transports; REC tap/hold; and grid edit gestures keep their existing behavior. No extra page or menu was introduced. SELECT the rotary encoder is distinct from the SEL/HOLD button.

## Conflicts resolved

1. **Obsolete FX+SEL delay-sync instructions.** The c53fbd0 snapshot overloaded SEL, but current runtime had already removed that action. Browser tooltip, play guide and accessibility help now consistently describe SEL as HOLD and GLO+timing as the sync modifier.
2. **Transpose / grid shortcut fall-through.** These consumed keyboard notes without marking the GLO gesture used. Releasing GLO could unexpectedly open GLOBALS. Fresh shortcut key downs now consume SHIFT without changing note ownership or transpose calculations.
3. **Navigation-encoder and button fall-through.** GLO consumption now covers SELECT, ALGORITHM and PRESETS as well as the four parameter knobs and other buttons. Their existing actions remain intact; GLO release does not append an unwanted GLOBALS page change.
4. **Plain hold interpreted as tap.** Only an unused release before 400 ms opens GLOBALS; a sustained hold stays on the current page. Any used modifier gesture is consumed immediately, even if shorter than 400 ms.
5. **Final detent and release in one input frame.** Encoder deltas are polled before deciding whether GLO was a tap. Timing sees the released GLO edge for that one frame, so the last shifted turn toggles sync instead of opening GLOBALS and editing the wrong control. Encoder actions still execute in their original order.

The first regression suite failed on the original binary (`long GLO hold: page 48 instead of page 0`). A second focused reproduction failed before the final-detent fix (`release-frame timing gesture: page 48 instead of page 6`). Both now pass; no audio fixture was changed to obtain that result.

## SAVE and UNDO

SAVE was audited on SEQ RECORD, armed/active recording, with GLO held and while a note is physically held. It continues to write once on press and does not undo or disarm recording. A context-specific SAVE undo was deliberately not added: it would replace a valid save operation while recording or defer saves to distinguish a new gesture. Existing undo/redo is already separate from SEL and remains tested. No additional button combination was added.

## Implementation files

- `fm1/pacific/app.c`: GLO tap threshold, consumed input handling and release-frame encoder polling. No latch algorithm, timing arithmetic, save routine, sequencer record/playback algorithm or patch field changed.
- `fm1/web/emu/index.html`: corrected visible/browser help and tooltip text only.
- `fm1/pacific/test-hold-shift.mjs`: gesture, held-note, HOLD LED, timing, SAVE and undo regressions.
- `fm1/pacific/test-transpose.mjs`: replace the old assertion that expected accidental GLOBALS navigation; assert consumed GLO and deliberate tap navigation instead.
- `fm1/pacific/validation-suites.json`: new independent suite in the strict main gate.
- `README.md`, `CHATGPT-HANDOFF.md`, this report and pre-change audit: current instructions and inventory.

## Validation

The focused run passed HOLD/SHIFT, transpose, navigation, SLOOP, effects-page/timing, actual Clouds delay sync and frozen DSP identity checks. The HOLD/SHIFT suite covers **91 gesture cases**, all four instruments, both transpose-key release orders, physically held and latched notes, HOLD-only behavior with FX/GLO/SEQ held, all seven encoders, navigation/button consumption, mute/solo, fill controls, six timing-knob locations per instrument, immediate SAVE while recording, and existing undo.

The current full inventory is **50 independent JavaScript suites + one native-storage C suite = 51 independent suites**. Aliases/helpers and individual gesture cases are not counted again. The complete full-duration gate passed **all 51 independent suites**, with **zero failures and zero timeouts**. It rendered 1,800 audio seconds of modulation and 600 audio seconds of sequencer stress. [Machine-readable results](validation-full.json) include explicit timeout budgets. No native hardware validation is implied.

Frozen current PCM remains `0715404c4328bb3c5b3a323278b28fe5724f14a2d25429ced556faa7c9c0255d`; the historical fixture still reproduces `4cf7592498c8810c1bd10d5acdaa7cc911668a68ce4127ee088a377cc8983b55`. No audio fixture was edited. [Source preservation evidence](preservation.json) records 173 unchanged DSP/platform/sequence/UI source files; only the app input handler changes control behavior, with matching browser help text. The project remains 15,664 bytes and the DSP pool API remains 269,724 bytes. BRANCH, OberVave TORT, FMini LEAD and minimum six-note TEMPLE checks pass. Full native linking and device CPU/stack/audio performance remain outside this browser-input validation.

The compiled browser binary changes because of input handling: baseline SHA-256 `f2ca768e3268d229476ae0a4e5081427cd2a5c55a70c8e6cf663929c0595f01c`, updated `3e3538ff70ed505c7956dcad847afde8fa90eb6cfddd7367f90e2b28f2580f76`. PCM equality is checked independently of binary identity.
