> Historical implementation record. Dates, memory projections, controls and validation claims apply to that checkpoint. See [the current audit](../audit-remediation/REPORT.md) and root README for current status.

# Global Slip — continuous pattern phasing

Protected baseline: `adcbbf7` (`codex/pre-global-slip-adcbbf7`), with the preceding WASM preserved separately. Work branch: `codex/global-slip`. Local preview only; no publishing or flashing.

## Previous behavior and replacement

The actual baseline had two different Slip implementations. Each arp fired a delayed, automatically panned second copy at the same rate. Each sequencer had an independently clocked duplicate with signed ±10% speed and separate level/on controls. That sequencer duplicate did accumulate phase, but it did not change timing relationships between the workstation’s original independent patterns. The arp implementation was a fixed offset.

Both duplicate schedulers are retired. The original four arps and original four SLOOP lanes now advance on their own clocks, with one global 0–100 Slip amount. No notes, tunings, synth envelopes, effects, order settings or pattern data are transformed. Gate fractions advance in their source’s local musical time. Existing randomized arp orders remain user settings; Slip adds no randomness.

The implemented registry is Branch=0, TORT=1, TEMPLE=2 (historical Clock), LEAD=3. SHELL/GROVE/FIELD are not additional engines in this checkout. Each implemented engine has an arp and sequencer. LEAD remains mono, so simultaneous note owners compete through its existing last-note priority rather than gaining polyphony.

## One knob

- ARP first page: knob 4, **SLIP 0–100**.
- Existing SEQ Slip page: knob 1, **the same global SLIP**. The other three knobs are blank/inert.
- No second-head level, on switch, chance, stereo width or new menu.

Both access points edit one value and show it across every instrument. Zero restores normal speeds without snapping pattern positions back together. A single eligible pattern stays at its normal speed regardless of Slip.

## Timing

Sources are ordered by existing engine ID, then ARP followed by sequencer. Eligibility requires a running, unfrozen arp with notes, or a running, unfrozen sequencer whose current bank contains note events. Empty lanes and count-in do not become reference patterns. Mute/solo do not stop a musical clock.

For N eligible sources, rank r=0…N−1:

`rate(r) = 1 + 0.032 × (SLIP/100)² × r/(N−1)`

For N≤1 all rates are one. Thus the reference is exactly normal speed, and distinct additional sources range up to +3.2%. At 10, the largest difference is +0.032%; at 25 +0.2%; at 50 +0.8%; at 75 +1.8%; at 100 +3.2%. At 120 BPM with sixteenth-note steps, the largest gap takes approximately 391 seconds to gain one step at 10, 15.6 seconds at 50, and 3.91 seconds at 100. Full-pattern alignments take proportionately longer.

The existing sequence musical-unit accumulator is retained. Eight fixed-point Q24 rate/residual pairs provide fractional advance, including for slow arps where subtracting tiny floating-point offsets from a large countdown would lose precision. Fractional carries survive loops and Slip=0. Arps keep their original countdown, note order and gate owner; sequences retain their original chords, ties, ratchets, microtiming, locks and boundary switching. The primary clock never receives a duplicate note owner.

Rate changes slew over approximately 50ms without changing phase positions, counters or current note gates. Reference selection follows stable registry order when patterns join/leave; the new first eligible source returns to the exact base rate and other rates slew toward their new spacing. This can change an existing source’s drift speed when the active set changes; it does not restart it. Actual transport start/stop keeps its existing explicit reset semantics. The master metronome, count-in and effects sync retain the unmodified project tempo.

Natural realignment is approximate to the sample, as with any finite-rate digital clock. Different original tempos or lengths need not share a short common repeat; Slip preserves those original settings.

## Project compatibility and resources

The existing v19 project remains 15,664 bytes, with 464 bytes spare in the protected 16,128-byte native payload. No storage guard was bypassed. The unused high byte of `seqReserved` stores a marker (bit15) and the amount (bits8–14); recording and delay sync keep the low byte. Existing projects have no marker, so new global Slip reads zero. Prior per-layer Slip bytes remain in place but are inert. Import performs no storage write; SAVE persists the new field normally. `v19-before-global-slip.bin` was captured from the preceding unchanged binary and checks the entire retained musical prefix.

The four duplicate `PFSeqSlip` runtimes are removed. Eight rates/residuals plus the amount use 68 bytes, replacing 992 bytes: **924 bytes saved** in projected native ordinary RAM. Pool, canvas, routing slots, patch size, scratch and synth engines remain unchanged. Ordinary BSS+data projects from 87,726 to 86,802 bytes. Native pool remains 334,788 bytes. The conservative emulator pool API plus canvas and protected 8,192-byte reserve still leaves 868 bytes.

`allocations.json` distinguishes measured WASM sections and the 32-bit native-source projection. These are not a PI32v2 linker map or physical device measurement. No native flash, interrupt CPU or stack-watermark claim is made.

## Verification

- Production clock functions simulated through six minutes at Slip10 and shorter runs at 0/50/100: drift accumulates at the measured rate across repetitions. Maximum setting passes a full-pattern natural realignment check.
- ARP/ARP, SEQ/SEQ and ARP/SEQ pairs, all eight eligible clocks, exact reference and seven distinct bounded rates.
- Live changes leave positions/counters untouched; after returning to zero, the acquired phase difference persists at normal rates.
- Local gate measurement: sequence 4,393 vs 4,257 frames and arp 3,857 vs 3,738 frames at base vs maximum offset, consistent within sample rounding with the same gate fraction.
- Zero-Slip PCM remains identical to the preceding working binary for each of the four arps, and the independent original TEMPLE sequence golden remains unchanged. Baseline fixture hashes were generated from the old binary, not the modified implementation.
- Actual v19 project import preserves all musical bytes, leaves old Slip inert and writes nothing on boot. Shared amount saves/reboots silently.
- Full regression suite includes four-instrument transport, note ownership, bank boundaries, ties/chords, octave entry, tuning, original effects, envelopes and native storage fault injection. Retired duplicate-head assertions were replaced with global-clock assertions; unrelated engine sound goldens were retained.
- Two-minute audio stress uses all four arps and all four 64-step/four-note sequencers, queued banks, LFOs and original effects. `regression.log` records the measured host time and verifies bounded finite audio, ownership and no dropped commands/FX faults.
- Additional matched all-engine/ADSR/effects host stress: `host-before.json` and `host-stress.json`. The preceding duplicate-head build used 36.77% average host budget; global phasing used 31.07%, a 5.70 percentage-point reduction in this single matched run (not a statistical benchmark). These host timings are not FM-1 CPU guarantees and are subject to host scheduling.

Long-duration tests expose a host-only runner that calls the actual production schedulers without oscillator/effect rendering; audio stress separately exercises the complete render path. The test runner is absent from native firmware.

Build/check: `EMCC=… NODE=… python3 fm1/pacific/check-fx.py`. Browser screenshot and logs accompany this report.

Verified emulator SHA-256: `8f9ac2107899217564701185b15b8dd09a16e5b6abae0f94dc3286143be19f83`.
