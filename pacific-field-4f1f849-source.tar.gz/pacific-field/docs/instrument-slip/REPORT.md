> Historical implementation record. Dates, memory projections, controls and validation claims apply to that checkpoint. See [the current audit](../audit-remediation/REPORT.md) and root README for current status.

# Independent instrument Slip and idle processing

Implements the requested resource-conscious scope change from `ad7e23e` on `codex/per-instrument-slip`. Previous source/binary are preserved separately. Local development only; no public deployment or hardware flash.

## Playing

Each instrument now has its own SLIP0–100. Select Branch, TORT, TEMPLE or LEAD, then use ARP knob4 or the existing SEQ Slip page knob1. Both access points edit the selected instrument’s value. That amount applies to its arp and sequencer; other instruments remain unchanged. Defaults are zero.

The panned double still starts aligned, runs slightly slower, accumulates phase across loops and eventually realigns. Original notes retain their base clocks. A positive amount on one instrument does not activate any other instrument’s double. Zero releases that instrument’s double, with a short fade; it does not stop its original or another instrument’s Slip.

## Resource behavior

- Disabled sequencer doubles use a fast return instead of running the additional scheduler or repeatedly smoothing settled gain values.
- Arps without held notes do not activate their doubles. Empty sequences do not activate doubles either.
- LEAD’s second original FMini instance is rendered only while an arp/sequence double or its short fade is audible. A positive Slip value during ordinary manual mono playing does not invoke the second instance.
- After the fade, inaudible double slots and their envelope state become idle. Long release settings cannot keep muted double DSP running in the background.
- No extra per-pattern allocation, audio buffer or heap allocation. The existing approximately1.7KB double-state reservation remains fixed; disabling Slip saves processing, not that static memory.

The previous global integer is replaced by four one-byte amounts. Four eligibility-cache bytes add **4 ordinary native-source RAM bytes** overall. Project size stays15,664, with464 bytes spare under the unchanged16,128 storage payload guard. Native pool stays334,788; conservative pool API269,724 + canvas65,280 + protected8,192 reserve leaves868 spare bytes. The second synth/dual playhead capacity and all four engines are retained.

`allocations.json` contains measured WASM sections and a separate32-bit native-source projection: ordinary BSS+data88,534 →88,538. WASM BSS grows12 bytes: four runtime cache bytes plus eight host-only diagnostic-counter bytes. Those counters are excluded from native firmware. This is not a PI32v2 linker map; physical FM-1 CPU, flash and stack remain unverified.

## Compatibility

Format v20 reuses the existing per-instrument `seqSlip[0]` fields. Nothing is appended. Their older signed duplicate-head interpretation is not reused accidentally.

For v19 or older: the previous global amount, if present, transfers only to the saved selected instrument; all other amounts become zero. Prior global high-byte bits are cleared while recording and delay-sync bits remain intact. Earlier projects without global Slip initialize all instruments at zero. The actual preceding v19 binary produced `fixtures/v19-global-slip.bin` for migration verification. Loading never writes over saved storage; SAVE persists v20 normally. Boot remains silent with arps/transport off, one-saw LEAD, zero initial sends and the established tuning/mixer defaults.

## Verification

`regression.log` records the complete successful automatic build/check run. This includes independent knob/persistence ownership, native storage fault injection, all original engine sound goldens, whole-note original Clouds delay, Clock performance controls, cumulative Slip timing, both-side real stereo audio, notes/ties/banks/octaves and two minutes with all eight original timing sources plus all eight doubles and effects.

Specific isolation tests run all eight originals, enable only TEMPLE and verify zero double events/gates on the other three instruments. Turning TEMPLE off leaves its original and Branch’s independently enabled Slip running. Four different saved amounts survive reboot. Actual v19 migration transfers61 only onto saved TEMPLE and does not write storage.

Host-only counters verify **zero second-FMini sample calls** with LEAD Slip off, even while another instrument phases; also zero calls when LEAD has Slip enabled but only manual notes or empty sequences. After disabling an active LEAD double and allowing its fade, its extra sample-call count stops increasing. Real audio tests verify all muted double envelope slots become idle.

`host-profile.json` is one sequential host observation with identical four arps, four sequences and effects in each case (about6.97 audio seconds per case):

| Enabled Slip | Average host budget | Second LEAD calls |
|---|---:|---:|
| None | 12.28% | 0 |
| TEMPLE only | 15.64% | 0 |
| All four | 18.93% | 307,200 |

These are illustrative host measurements, not a statistical comparison or hardware CPU guarantee. Reproduce with `node fm1/pacific/benchmark-instrument-slip.mjs fm1/build/emu/amb.wasm`.

The local binary and source download are updated at http://127.0.0.1:8784/ . Reload to use the new code. Prior served files are backed up, and browser project storage was not reset. Live browser interaction was not attempted because automatic approval review previously blocked it due to a usage limit; verification used source, DSP output, framebuffer-path tests and regression checks.

Verified emulator SHA-256: `76b0d0af9fada481aa10973ae5f77d6b27e716b5880d75550341cc0528a1f90e`.
