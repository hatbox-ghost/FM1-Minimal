from pathlib import Path
import shlex,json,hashlib,subprocess
import argparse,shutil
parser=argparse.ArgumentParser(description='Historical upstream research probe; not the workstation validation gate.')
parser.add_argument('--references',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);parser.add_argument('--emxx',default=shutil.which('em++'));args=parser.parse_args()
base=args.references;out=args.output;out.mkdir(parents=True,exist_ok=True);cc=args.emxx;assert cc,'--emxx is required';allresults=json.loads((out/'compile-results.json').read_text())
for name,repo in [('clouds','eurorack'),('beads','eurorack'),('oliverb','parasites')]:
 root=base/repo;files=set()
 for dep in (out/name).glob('*.d'):
  files.update(x for x in shlex.split(dep.read_text().replace('\\\n',' ').split(':',1)[1]) if x.startswith(str(root)))
 for probe in [out/(name+'-size.cc')]+([out/'oliverb-call.cc'] if name=='oliverb' else []):
  p=subprocess.run([cc,'-DTEST','-std=c++11','-Wno-vla-cxx-extension','-I'+str(root),'-MM',str(probe)],capture_output=True,text=True)
  files.update(x for x in shlex.split(p.stdout.replace('\\\n',' ').split(':',1)[1]) if x.startswith(str(root)))
 manifest=[]
 for f in sorted(files):
  path=Path(f);text=path.read_text(errors='replace');notice='MIT notice' if 'Permission is hereby granted, free of charge' in text else 'REVIEW'
  manifest.append({'path':str(path.relative_to(root)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'license_header':notice})
 (out/name/'dependencies.json').write_text(json.dumps(manifest,indent=2)+'\n');allresults[name]['dependency_count']=len(manifest);allresults[name]['license_review']=[x['path'] for x in manifest if x['license_header']=='REVIEW'];print(name,len(manifest),'files; manual review:',allresults[name]['license_review'])
(out/'compile-results.json').write_text(json.dumps(allresults,indent=2)+'\n')
