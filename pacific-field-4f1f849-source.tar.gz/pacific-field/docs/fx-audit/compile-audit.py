from pathlib import Path
import subprocess,json,hashlib,re
import argparse,shutil
parser=argparse.ArgumentParser(description='Historical upstream research probe; not the workstation validation gate.')
parser.add_argument('--references',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);parser.add_argument('--emxx',default=shutil.which('em++'));args=parser.parse_args()
root=args.references;out=args.output;out.mkdir(parents=True,exist_ok=True);cc=args.emxx;assert cc,'--emxx is required'
sets={
'clouds':('eurorack',['clouds/dsp/granular_processor.cc','clouds/dsp/correlator.cc','clouds/dsp/mu_law.cc','clouds/dsp/pvoc/frame_transformation.cc','clouds/dsp/pvoc/phase_vocoder.cc','clouds/dsp/pvoc/stft.cc','clouds/resources.cc','stmlib/dsp/atan.cc','stmlib/dsp/units.cc','stmlib/utils/random.cc']),
'beads':('eurorack',['beads/dsp/processor.cc','beads/dsp/delay_clock.cc','beads/dsp/delay_controller.cc','beads/dsp/trigger_generator.cc','beads/dsp/mu_law.cc','beads/resources.cc','stmlib/dsp/units.cc','stmlib/utils/random.cc']),
'oliverb':('parasites',['clouds/resources.cc','stmlib/utils/random.cc'])}
results={}
for name,(repo,units) in sets.items():
 base=root/repo;folder=out/name;folder.mkdir(exist_ok=True);entries=[];files=set()
 for unit in units:
  cmd=[cc,'-DTEST','-std=c++11','-O2','-fno-exceptions','-fno-rtti','-ffp-contract=off','-Wno-vla-cxx-extension','-I'+str(base),'-MMD','-MF',str(folder/(unit.replace('/','_')+'.d')),'-c',str(base/unit),'-o',str(folder/(unit.replace('/','_')+'.o'))]
  result=subprocess.run(cmd,capture_output=True,text=True);(folder/(unit.replace('/','_')+'.log')).write_text(result.stdout+result.stderr);entries.append({'unit':unit,'exit':result.returncode,'diagnostic':(result.stderr.strip().splitlines() or [''])[0]})
  dep=folder/(unit.replace('/','_')+'.d')
  if dep.exists():
   data=dep.read_text().replace('\\\n',' ');files.update(re.findall(re.escape(str(base))+r'/[^\s]+',data))
 probe=out/(name+'-size.cc')
 cmd=[cc,'-DTEST','-std=c++11','-Wno-vla-cxx-extension','-I'+str(base),'-MM',str(probe)]
 dep=subprocess.run(cmd,capture_output=True,text=True);files.update(re.findall(re.escape(str(base))+r'/[^\s]+',dep.stdout.replace('\\\n',' ')))
 manifest=[]
 for f in sorted(files):
  path=Path(f);text=path.read_text(errors='replace');mit='Permission is hereby granted, free of charge' in text;gpl='GNU General Public License' in text
  manifest.append({'path':str(path.relative_to(base)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'license_header':'MIT notice' if mit else 'GPL text — review' if gpl else 'REVIEW: no standard MIT header'})
 (folder/'dependencies.json').write_text(json.dumps(manifest,indent=2)+'\n');results[name]={'compile_units':entries,'dependency_count':len(manifest),'license_review':[x['path'] for x in manifest if x['license_header']!='MIT notice']}
(out/'compile-results.json').write_text(json.dumps(results,indent=2)+'\n')
for k,v in results.items():print(k, 'compiled',sum(x['exit']==0 for x in v['compile_units']),'/',len(v['compile_units']),'dependencies',v['dependency_count'],'license review',v['license_review']);print([x for x in v['compile_units'] if x['exit']])
