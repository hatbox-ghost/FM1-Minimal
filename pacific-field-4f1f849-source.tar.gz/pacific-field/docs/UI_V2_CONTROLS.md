> Historical implementation record; not the current build or validation guide. See [the current audit](audit-remediation/REPORT.md) and root README.

> Startup update: every power-on opens Mixer with all four faders at 72%, FX1/FX2 sends at zero, SEL/ARP/mute/solo off, and transport stopped. Saved sounds, patterns, tuning and tempo remain intact; startup does not write over the saved file.

> Navigation has been updated. Use [Current navigation](NAVIGATION_REFACTOR.md) for HOME, GLOBAL, EDIT and dedicated-button behavior; the original V2 description below is retained for reference.

# Pacific Field V2 — playing guide

Four instruments remain available together. PRESETS selects the instrument played and edited; the existing selection workflow and saved slot IDs are preserved. HOME and the mixer display Branch / Temple / TORT / LEAD. TEMPLE is the renamed FM synthesizer, with all seven original algorithms.

**HOME** shows four identity symbols, selected instrument, real activity, active/queued blocks, tempo and transport. Knobs: selected Block B1–B4, shared Tempo, absolute Transpose, selected Level. HOME again opens project settings. **EDIT from HOME** opens main voice controls; repeat for related instrument pages.

| Instrument | K1 | K2 | K3 | K4 |
|---|---|---|---|---|
| Branch main | Tone | Ring | Selected-note Fine | Voice Spread |
| Temple main | Oscillator Mix | FM Depth | Algorithm | Detune |
| TORT main | Cutoff | Resonance | Filter Envelope Amount | Filter Model |
| LEAD main | Cutoff | Resonance | Contour | Glide |

Branch's oscillator relationship is fixed. Temple has no independent ratio or FM-feedback knob. These controls are not invented from the artwork. EDIT retains the original wind/rain/LPG, mechanics, FM motion/drift, oscillator, modulation, spread and per-note views. ALGORITHM retains its existing timbre role; on TORT it selects the filter model.

**GLO** opens Mixer VOL immediately; repeat for PAN, FX1, FX2. Knobs always follow Branch / Temple / TORT / LEAD. FX1 sends to original Oliverb reverb; FX2 sends to original Clouds granular/delay. Each has one shared DSP instance. Thin meters reflect real audio activity. MASTER remains the physical full-output control. GLO+ARP mutes the selected instrument; GLO+SEQ solos it. EDIT from Mixer opens global tuning; again returns to VOL.

**ENV** opens the actual envelope directly. Branch and Temple retain attack/release structures. TORT switches filter and amp ADSRs. LEAD amp controls are Attack / Decay / Sustain / Release; its filter contour has the implemented Attack / Decay / Sustain, with no invented independent release. Empty assignments do nothing and remain unlabeled. The graphic changes with the values; its activity dot is a gate indicator, not a simulated envelope-stage measurement.

**LFO** cycles four independent slots per instrument. Main knobs: Rate / Depth / Destination / Shape. EDIT toggles Sync / Key Sync / Phase / Slew. The waveform reads actual phase/output. Depth and rate zero remain valid off settings. Navigation never resets phase.

**SEQ** retains the working SLOOP core. B1–B4 are display names for the existing four patterns. Maximum64 steps and four-note chords remain. White outlines select steps; coral marks playhead A; lavender marks the phasing playhead. Pitch rows keep every chord member visible, including long notes crossing pages. SELECT zooms; PRESETS selects instrument.

While stopped, keys enter the current note/chord and advance after release. During PLAY, keys audition unless REC is lit. Hold SEQ plus white keys for step entry. EDIT deletes the selected note; EDIT+OCT retains undo/redo. Hold OCT+ for the note tools. SEQ repeats Notes / Pattern / Blocks / Step / Rec Setup / Slip. Queued blocks switch at safe boundaries; signed Slip gradually phases the second playhead, with zero disabling it. The existing direction is forward, shown as FWD; timing uses the current shared sequencer clock, shown as GLOBAL. No nonfunctional direction or independent-clock control is added.

**PLAY** controls project sequencers from every page; PLAY+HOME controls existing generators. REC tap arms/finishes recording; hold REC freezes the selected process. SEL latches played notes; their keys remain lit. Saved latch mode now agrees with SEL immediately after boot, while boot still restores no sounding notes. SAVE retains the project; its format remains v16/15584 bytes.

**GLO + musical key** transposes the whole playing field by one multiplier from the selected tuning. C2, the first C at octave0, restores zero. OCT-/+ extends the target. A temporary interval/root overlay confirms the target. It does not trigger an ordinary note, rewrite patterns, reset phases or restart transport. Existing effects tails retain recorded pitch. Hold SEQ first, then GLO + white9/10 for held/next-bar fills.

**FX** retains all original sends, Oliverb, Clouds and detail controls. The graphs respond to effect settings; they do not imply separate effect instances per instrument. A knob turn gives a brief enlarged name/value overlay, then restores the live functional view. Sound and recording remain active during overlays.

In the browser, play with mouse/touch or the documented computer-key mapping. Shift-click a button, or focus it and press Shift+Space, to hold a modifier; press again to release. Graphics run in a separate Worker from audio, with bounded reusable transfer buffers. Pixel previews are available from Screens in the page header.

LEAD remains mono with last-note priority; TORT and LEAD can play together. The native adapter is retained, but hardware linking, physical display/input usability and maximum CPU/stack/flash behavior still require an actual FM-1. Browser results do not establish hardware performance.

Mixer clarification: SELECT and PRESETS both follow the visible Branch / Temple / TORT / LEAD column order, in either direction, with wrap. Outside Mixer the existing PRESETS workflow and saved slot IDs remain unchanged.
