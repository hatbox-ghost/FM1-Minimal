> Historical implementation record; not the current build or validation guide. See [the current audit](audit-remediation/REPORT.md) and root README.

# Pacific Field interface audit and implementation map

Baseline d1b35d454771342be714aec336e08f295ab67ee5; four engines retained. Full baseline regression passed before edits. LEAD is original FMini mono, last-note priority with legato, glide, MIDI bend and CC1; four workstation LFOs remain. No physical board was tested.

## Audit

14 physical buttons and seven encoders use the same app.c handlers in browser and native port. Page IDs 0–46 include voice, envelope, mechanics, global tuning, sends, mixer, arp, eight LFO views, TORT oscillator/filter/modulation, six SLOOP views, original Oliverb/Clouds and five LEAD views. Relative encoders edit visible values, without absolute-value pickup jumps.

Conflicts: GLO entered tuning before mixer; HOME sometimes entered mixer; ARP and SEQ became mute/solo on mixer; PLAY became generator transport on process page; REC became freeze off sequencer pages; EDIT cycled unrelated voice pages while on global/FX pages. Existing GLO+white9/10 fill collided with new transpose. Every keyboard note has a recorded layer owner; sequencer primary/Slip/MIDI have separate slots. New modifiers must consume both edges without releasing an older owned note.

Persistent v15 = 15576 bytes, payload limit16128. Three-engine v14 prefix11688 remains fixed, with appended independent LEAD state. Global tuning parameters20–22 are mirrored across all four layers. Target frequencies use the selected ratio table, root and reference; master transpose must multiply the final pitch without changing those notes or tables.

## Definitive control map

| Control | Before | New |
|---|---|---|
| HOME | Voice, then mixer | Dashboard; repeat Project Clock |
| GLO | Tuning, then mixer | LEVEL → PAN → ECHO → ROOM; entry from elsewhere LEVEL |
| EDIT | Voice carousel / sequencer delete | Current function subpages; mixer opens tuning; tuning returns LEVEL. Sequencer delete/undo preserved |
| ENV | Envelope | Envelope pages; TORT filter/amp envelope, LEAD amp/filter envelope |
| LFO | Four primary LFO pages | Same; EDIT toggles sync/key-sync/phase/slew |
| ARP | Process/arp, or mixer mute | Arp primary/shape; EDIT toggles process voice page |
| SEQ | Sequencer, or mixer solo | Existing six sequencer views, release cycles; hold grid unchanged |
| FX | Sends/effect pages | Same direct family |
| PLAY | Page-dependent transport | Tap project sequencer transport; PLAY+HOME generator transport |
| REC | Recording or freeze | Tap selected sequencer record; hold400ms selected process freeze |
| SEL | Latch | Same, selected instrument only |
| PRESETS | Instrument | Same four instruments |
| ALGORITHM | Voice timbre | Same |
| SAVE | Project save | Same |
| OCT +/- | Keyboard octave / note tools | Same; EDIT+OCT undo and note tools preserved |
| SELECT | Layer on mixer, note/zoom elsewhere | Selected mixer layer; other contexts retained |
| GLO+ARP | None | Selected layer mute |
| GLO+SEQ | Fill conflict | Selected layer solo |
| Hold SEQ then GLO+white9/10 | GLO+white9/10 fill | Held / next-bar fill (SEQ consumed) |
| GLO+key | Fill shortcut | Absolute master transpose; C2 (key7, octave0) zero; +/-octave buttons extend range |

Per user clarification, knobs1–4 are Branch/TORT/Clock/LEAD on every mixer page. Master stays on the physical MASTER control. PRESETS still selects layer for mute/solo. All four strips remain visible. Each page edits exactly its displayed labels.

HOME four macros: Branch tone/resonance/attack/release; TORT cutoff/resonance/attack/release; Clock tone/detune/attack/release; LEAD cutoff/resonance/attack/release. Project Clock knobs: shared BPM, single metronome, absolute transpose, blank. Independent lane tempos remain on existing sequencer controls.

Preserve four patterns with existing64-step maximum (16 visible grid cells), chords, ties, locks, recording and accumulated Slip. The brief’s three-instrument and16-step references predate current functionality.

## Reference patterns adapted

SLOOP91f30182d9095e0ecdb43396554f2ce5a67df179: consumed tap/hold state and held-grid entry; original sequencer untouched. Melodee: direct family navigation, selected-part indicators, contextual EDIT. Felucca406b328ee43ffb8fd3d2eb4cce1a741db4a4cea1: family subpages and contextual four-knob views. These are interaction patterns; no replacement UI dependency is imported.

## Incremental checkpoints

1. LEAD health and audited map.
2. Navigation, mixer/master storage and safe gain smoothing.
3. HOME/dashboard and project clock.
4. Absolute ratio-based transpose and consumed modifier edges.
5. Full regression, migration, load/voice-limit tests and browser review; release source and emulator together.

Native CPU deadlines, linker/stack headroom and physical controls require real target validation. Host/WASM measurements are not hardware CPU claims.

User clarification: four dedicated synth mixer knobs supersedes the brief’s three-synth-plus-master map and the provisional bank plan.
