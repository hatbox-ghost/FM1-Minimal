> Historical implementation record; not the current build or validation guide. See [the current audit](audit-remediation/REPORT.md) and root README.

> Superseded by the SLOOP source port: see `fm1/pacific/SLOOP-PORT.md`. The audit and custom-scheduler implementation notes below are preserved as history.

# Four-pattern sequencer: Gate 0 source audit

Date: 2026-11-01. Status: source audit complete; no sequencer implementation or firmware changes. This replaces the eight-block/FLOW/MORPH proposal. All reuse entries below are **planned**, not claims of completed ports.

## Baseline and preservation

Active clean checkout: `$ARCHIVED_WORKSPACE/pacific-effects`, branch `codex/fx-development`, commit `e03524ff5350874ee148e0b598204005a973d41e`. Audit branch: `codex/four-pattern-sequencer` in `$SCRATCH/pacific-four-pattern`, independent clone. Neither protected original (`pacific-edit-pages`, saved `pacific-field`) was modified. Latest header has **31 pages**, patch **9**, three instruments Branch/TORT/Clock, four LFOs per instrument, 40 voices per instrument. Older descriptive paragraphs in PACIFIC.md are historical; current code and later revision notes take precedence.

Reference-only checkouts live in `$SCRATCH/pacific-sequencer-upstream/`; no upstream source tree is incorporated into production. Read-only by workflow: inspect and pin, do not develop in these clones. Preserve these references outside temporary storage before relying on them for long-term recovery.

## Pinned sources and license scope

| Repository | main HEAD inspected | Submodules |
|---|---|---|
| https://github.com/isod89/sloop-fm1 | `91f30182d9095e0ecdb43396554f2ce5a67df179` | none reported |
| https://github.com/keremimo/melodee | `c14912ba911d4f4fefaa07120eb068a91d7ccb78` | none reported |
| https://github.com/hugelton/Felucca | `406b328ee43ffb8fd3d2eb4cce1a741db4a4cea1` | bsp `5942e68b89ab9ccd23f2c541d712ca38fe635f11`; engines `d0260074ce100a47675814b7f38d61f11176c926`, retrieved |

Read LICENSE, LICENSING.md and selected source SPDX headers. Selected sequencer/input code is GPL-3.0-only, compatible with Pacific Field. Preserve Leo Kuroshita / Hügelton Instruments notices on retained Felucca code; preserve Kerem Kilic / Ellic Studio credit and retained Felucca portions on mixed Melodee code. Inspect git history when extracting SLOOP modifications: inherited header alone does not establish authorship of later changes. New independent adapters must not falsely inherit another author's copyright. Distribute complete corresponding source and retained notices with derivatives.

Do not import assets: SLOOP LICENSING.md excludes certain original Felucca assets from its GPL code license. Current Felucca engines are MIT and BSP MPL-2.0; Melodee bundles additional mixed-license DSP and proprietary factory sound data. None is needed by this sequencer. No factory banks, fonts, drivers, USB, arranger, extra engines or effect code will be copied.

## File/function-level reuse ledger

All paths are relative to the pinned upstream repository. ADAPTED means an identified code algorithm will be extracted with provenance; the resulting diff and tests must be linked here when implementation lands. No entries are COPIED yet.

| Source | Actual path / symbols inspected | Behavior and dependencies | Planned Pacific destination / classification | Required verification |
|---|---|---|---|---|
| SLOOP | `firmware/src/ui_layers.c`: `key_of_white`, `step_down`, `step_up`, `step_pend_off`; `firmware/src/drums.c`: `key_of_lane` | White-key addressing; existing step is marked for deletion on release, knob editing can consume deletion. Depends on TSEL, ui, pen and IRQ guards. | `fm1/pacific/seq-input.h`, called from app.c; **ADAPTED** mapping and deferred-toggle algorithm, no drum dependencies or interrupt-off edits. | all 16 keys; tap toggle; hold-and-edit preserves step; keys captured by grid never latch |
| SLOOP | `firmware/src/ui_input.c`: `seq_entry`, `btn_hold` | Chord capture opens one edit session, accumulates keys, finishes on all-key release; button helper consumes tap after hold. | `seq-input.h`; **ADAPTED**, milliseconds instead of hardware ticks, max two chord notes, existing key-owner releases first. | same gesture in browser and hardware abstraction; release orders; layer change during gesture |
| SLOOP | `firmware/src/seq.c`: `grid_at`, `trk_grid`, `seq_tick`, `seq_release` | Project grid shared via clk_beat/clk_pos; latest code has nudge/ratchet logic and one-event-per-control-block policy. seq_release avoids killing live_has pitches. | `block_seq.h`; **ADAPTED** shared-grid derivation only. Full tick/release **NOT USED**: block quantization and pitch ownership conflict with sample-accurate independent slots. | common epoch, divisions, free clock isolation; exact event frames; no stale gate-off |
| Melodee | `firmware/src/motion.c`: `pattern_request` | While running, stores target or 0xff when target is active; stopped switch is immediate. Has chain/guard dependencies. | `block_seq.h`: queued A-D request; **ADAPTED**, omit chain logic, use audio command ring. | last queue wins, active cancels, stopped selection immediate |
| Melodee | `firmware/src/seq.c`: `seq_grid_tick`; `firmware/src/pattern.c`: `pattern_switch`, `pattern_apply`, `pattern_commit` | Commit queued switch only when local seq_idx wraps; preserve elapsed remainder, start new pattern at step zero. Full storage compresses pattern chunks and can change parameters. | `block_seq.h`: boundary commit; **ADAPTED** boundary/remainder algorithm. Storage/patch switching **NOT USED**; patterns contain notes only. | lengths 1/5/7/16; exact switch, no tempo, DSP, arp or LFO reset |
| Melodee | `firmware/src/seq_notes.c`: `notes_selected`, `notes_cycle`, `notes_step_jog`; `firmware/src/ui_input.c`: `step_length_edit`, `seq_entry_notes` | Note/event selection, pitch and duration editing; recorded event identity and storage generation dependencies. | app.c notes editor; **ADAPTED** bounded note selection/editor behavior; recorded event pool **NOT USED**. | step/pitch/gate/velocity targets; per-note selection; rest entry |
| Melodee | `firmware/src/seq_undo.c`: `step_history_apply`, `step_history_finish`; `firmware/src/ui_patterns.c`: `patterns_queued`, `pt_prog` | Transactional edits/undo; pending vs playing feedback. Undo uses snapshot allocator and generation checks. | app.c bounded single-pattern take backup and scene status; **ADAPTED** transaction/feedback algorithms; allocator and graphics **NOT USED**. | cancel/undo restores only captured track/pattern; no silent overwrite |
| Felucca | `firmware/src/core.h`: `step_t` | Up to four notes, n, ST_NOTE/TIE/REST, velocity, drum/probability fields. | pacific.h compact two-note step; **ADAPTED** note-count/type representation, remove drums/chance/ratchets. | compiled struct sizes, sanitize load, exact round trip |
| Felucca | `firmware/src/seq.c`: `seq_tick`, `seq_release`, `rec_note`, `rec_hold`, `rec_release`; `firmware/src/fx.c`: `div_samples` | Remainder-preserving scheduling; nearest-step recording, ties while held, explicit release. Coupled to tracks, MIDI and shared voice allocator. | `block_seq.h`: **ADAPTED** advance/record/tie rules. New source-owned voice bridge in engine.c **REIMPLEMENTED** for Pacific's fixed slots, not copied trk_note_off. | no duplicate record/play onset; tie only explicit; manual same-pitch note survives stop |
| Felucca | `firmware/src/project.c`: `proj_pack`, `proj_unpack` | Versioned project conversion with per-track data; unrelated native format. | app.c v10 append/migration **REIMPLEMENTED**; upstream serialization **NOT USED**. | fixtures v2-v9, silent reboot, no tuning/mixer/TORT/LFO loss |
| Existing Nachtfahrt tree | `fm1/firmware/src/dsp/seq.{h,c}`: `seq_next`, `seq_grow`, `seq_vary`, `seq_pitch` | Scale-degree generator, skip bits, evolving phrases; no conventional per-owner gates or four-pattern bank. | **NOT USED**: generative behavior conflicts with v1 non-goals. |

## Current audio/data flow and conflicts

```mermaid
flowchart LR
  Keys[Physical keys / MIDI] --> UI[app.c: key_owner / latch]
  UI --> Q[Per-layer command ring: 256 commands]
  Q --> Manual[heldMask: slots 0–26]
  Manual --> Arp[Slip: slots 38–39]
  Process[Branch slots 30–37 / Clock slots 27–28] --> Synth
  Manual --> Synth[Existing instrument DSP]
  Arp --> Synth
  Future[Future sequencer: dedicated slots 40–43] -.-> Synth
  Synth --> FX[Existing layer effects]
  FX --> Mixer[Level / pan / mute / solo]
```

PF_KEY must never be used for sequence events. It modifies heldMask, retriggers first-key LFOs and is the arp bank. Keep manual key ownership, latched bits and Slip untouched. PF_PARAM tuning updates already traverse all PF_NV voices; sequence targets must resolve through pf_hz/freq and copy note fine/level explicitly. Per-note fine currently targets manual slot only: extending it to sounding sequence/arp sources requires a deliberate rule, not an accidental side effect.

Critical renderer trap: `i>=38` currently means arp attack/release AND arpL/arpR mix. Simply increasing PF_NV makes new slots use zero-initialized arp gains and become silent. Replace with exact arp range 38..39; define sequence envelope/pan explicitly. Branch spread position formula also assumes process slots above 29: give new slots explicit balanced positions. Initialize frequency increments at sequence onset (controls currently computes them per render segment). Add generation IDs or cancel old per-slot deadlines on reuse. Stop/disable sequence releases only its own slots; never call silence(). Existing global PLAY stop intentionally stops all layers; preserve that distinction from per-lane stop.

## Resource and save budget

Measured by a separate temporary WASM sizeof probe including the unchanged engine; production sources untouched:

| Item | Bytes |
|---|---:|
| pf_patch v9 | 1,012 |
| browser and native object payload limit | 3,840 |
| Voice / p5_voice_t / Context | 120 / 116 / 84,192 |
| pf_pool_bytes (includes 104-byte ordinary-BSS TORT block) | 257,320 |
| conservative existing strip canvas | 69,120 |
| pool limit | 344,064 |
| conservative arithmetic remainder before other hardware allocations | 17,624 |

Proposed v1 chord cap: **two notes per step**, four sequence slots per layer (two active + two releasing), PF_NV=44. Deterministic stealing: only oldest sequence release, then oldest sequence voice if every reserved slot is held; no manual/process/arp stealing. Added voice arrays cost 4*120*3 + 4*116 = **1,904 bytes**. This is a proposed browser cap, not a verified FM-1 CPU allowance. All 12 extra voices may sound; quantify that worst case before device release.

Proposed packed-by-fields model (ordinary alignment, no pointers): step six uint8 fields {key[2], velocity, gate, count, type}; 97-byte pattern {length, steps[16]}; 396-byte lane {patterns[4], uint16 free_bpm, enabled, active, sync_mode, division, reserved[2]}; three lanes 1,188 bytes. Add four project-tempo/reserved bytes after the old 1,012-byte prefix: **2,204 bytes estimated total**, leaving 1,636 bytes of storage. Assert exact sizeof/offsetof in implementation. Record no queued pattern, running notes, clocks, arm or undo state. Append as v10; preserve all v2-v9 migration paths and disable sequencers on upgrade. Validate indices, count, note/rest/type and tempo on load.

Runtime engine copy of programs, deadlines and one UI take backup also consume RAM; estimated voice bytes alone are not the total. Budget runtime/program duplication explicitly and retain >=8 KiB pool reserve. UI persistent patch and temporary save/load copies belong to ordinary RAM/stack: check native .bss and stack as well as pool. Native linker has 98,304-byte data RAM and separate stacks; source-only arithmetic is insufficient.

Device audio is 44.1 kHz, 256-frame blocks (~5.805 ms). Existing device CPU/peak/xrun hooks exist; browser web_cpu returns zero and cannot benchmark the FM-1. Matching JieLi PI32v2 toolchain/AC79 SDK remain unavailable from the previous verified audit; native compile, flash footprint and physical timing are unverified. No device flashed. Effects port remains separately gated.

## Panel plan before coding

Current SEQ press immediately opens page4 NOTE MIX, except Mixer page7 where it toggles SOLO. ARP cycles Process/Slip/Shape and mutes on Mixer. REC toggles process freeze, SEL latch, EDIT voice pages (local config toggle for LFO). Preserve all.

Propose short SEQ cycle: **NOTE MIX → STEPS → NOTES → PATTERN → TEMPO**, starting NOTE MIX from other sections. Add explicit sequencer dispatch before existing page>=18 TORT and page>=8 ARP paths in every label/value/encoder/LED/page-count handler. Voice-only EDIT must stay unchanged. No `par[page*4+k]` for new pages.

SEQ held outside Mixer captures only new white-key presses as steps. Existing manual key releases still go to original owner, even while in grid. Consume SEQ tap when grid used. Never reuse a held drone as a step press; captured grid keys remain captured through key-up even after SEQ release. Exact mapping F3..G5: [0,2,4,6,7,9,11,12,14,16,18,19,21,23,24,26]. Mixer SEQ remains immediate SOLO; no grid in Mixer.

NOTES knobs: step / pitch-or-rest / gate-or-tie / velocity. SELECT chooses chord note1/2. Keyboard writes notes only while explicit entry is armed, with visible ENTRY status; ordinary keyboard remains live on other pages. PATTERN knobs: edited A-D / queued A-D / enable / lane run-stop. Distinguish edit target from playing/queued target. TEMPO knobs: PROJECT/FREE / global readout or free BPM / division / length; global BPM edited on GLOBAL, tuning remains GLOBAL too. Length changes keep hidden steps, apply at next pattern boundary while running.

REC alone remains freeze. Proposed recording gesture: SEQ+REC on a sequence page only, consume SEQ navigation and REC freeze for that chord. Both press orders require testing/deferred REC action in this context; do not implement naive pressed-bit checks that already freeze before recognizing chord. One-loop count-in, explicit armed indicator, quantized overdub; take backup before arming, safe cancel/undo via on-page action. No new global EDIT gesture. If an unambiguous chord cannot be verified in input tests, expose record/undo as explicit STEPS page controls instead.

## Timing contract

Implement shared project musical epoch with integer/fixed-point sample advancement, plus independent free clocks. Adapt upstream remainder logic at exact sample boundaries, not one-event-per-UI/control-block. Tempo updates preserve fractional progress; free tracks ignore project tempo. PROJECT/FREE changes commit on the lane boundary: entering PROJECT joins the next compatible global grid tick (documented potential wait); entering FREE starts local step0 at that boundary. No instrument/page/pattern edit resets epoch. Restart is explicit. A-D selection stopped applies immediately; running queues, active cancels, last target wins, local pattern end commits without DSP reset.

## Verification and milestones

Gate0 baseline rebuilt from shared web.c/engine.c with existing Emscripten O2 flags and generated font include. Temporary probe exports only size diagnostics. `test-instrument.mjs` and `test-slip.mjs` both PASS, including all81 keys, same-key latch, tuning, mixer, process ownership, exact Slip offsets, persistence and pool bound. No new-sequencer tests can pass yet because no implementation exists.

1. Gate1: pure reusable scheduler, three fixed lanes/four patterns, explicit queue/cancel, project/free timing; temporary engine test commands. Dry/off PCM must match baseline exactly. Dedicated slots with explicit range handling, no UI redesign. Trace exact sample deadlines at awkward BPM, lengths1/5/7/16, rapid requeue, rests, tempo/mode edits and source-only stop.
2. Gate2: adapt SLOOP step-key functions and Melodee editor/queue feedback, preserving Note Mix, mixer SOLO, ARP, REC and EDIT. Test every press/release order and held key across page/layer/SEQ changes.
3. Gate3: two-note cap, explicit ties, independent gate identities, quantized overdub/count-in and cancel/undo. Test same-pitch live+sequence, release-voice reuse, process+arp+Slip+sequence, tuning while tied. Cap admission must never silently discard recorded chords.
4. Gate4: v10 migration fixtures v2-v9 and round trips, all existing test-*.mjs suites (avoid duplicate wrapper runs), 30-minute stress, pool/stack/flash accounting and device peak/xruns when hardware available. Publish browser only after controls and regressions pass. No hardware-ready claim without native build and physical measurements.

Gate0 source-examination requirement is satisfied. Reuse is feasible by extracting the named GPL algorithms; no blanket import is justified. Implementation is deliberately absent in this audit checkpoint. Device CPU validation remains a hardware-release condition, not an emulator result.

## Implementation checkpoint

The planned ADAPTED paths are now implemented in `fm1/pacific/block_seq.h` (Felucca remainder/tie rules and Melodee queue/cancel/boundary switch) and `fm1/pacific/app.c` (SLOOP white-key mapping and deferred-toggle/consume gesture, explicit note capture and bounded recording undo). They are adaptations, not unmodified copied modules. No upstream allocator, pattern compressor, sound-patch switch, IRQ guard, arranger or graphics is imported. Runtime uses an included header so both existing build integrations compile the same code.

Final UI differs from the initial proposal in two deliberate ways: record/count-in/finish/undo uses STEPS knob4, avoiding an ambiguous REC chord; GLOBAL knob4 edits project tempo while SEL retains latch. Final v10 size is2,204 bytes; reported pool is260,784 bytes. See pacific/SEQUENCER.md and test-sequencer*.mjs for executable coverage and limitations. The entire record capture/undo algorithms are bounded Pacific adapters, not a claim to have copied Melodee's recorded-event pool or eight-level allocator-backed undo.
