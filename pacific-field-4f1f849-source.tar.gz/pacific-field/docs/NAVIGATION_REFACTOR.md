> Historical implementation record; not the current build or validation guide. See [the current audit](audit-remediation/REPORT.md) and root README.

# Navigation refactor

HOME opens the mixer from any other screen. Subsequent HOME presses cycle VOL → PAN → FX1 → FX2 → VOL while staying in the mixer. ALGORITHM also changes mixer layer in either direction. SELECT and PRESETS choose Branch → Temple → TORT → LEAD in displayed order. Knobs 1–4 always control those four strips; physical MASTER remains the overall volume. GLO+ARP and GLO+SEQ retain selected-instrument mute and solo.

GLO opens global Tempo / Clock from outside the global area. Repeated GLO presses cycle Tempo / Clock → Tuning → System → Tempo / Clock. SELECT or ALGORITHM browses Tempo / Clock, Tuning, System. Tempo has shared BPM, the existing metronome switch, and global transpose. Tuning has all five existing profiles (12 TET, 5 LIMIT, WTP 7, RILEY 5, PYTHAG), root and reference frequency, inherited by all four instruments. System shows project format/storage and platform status. SAVE remains dedicated to project saving.

EDIT from any other screen family opens the selected instrument's first synthesis page. EDIT inside the synth editor advances only its synthesis pages and wraps. Instrument changes within that editor start the new instrument on its first page. Navigating between families preserves the selected instrument.

| Instrument | EDIT order |
|---|---|
| Branch | Voice → Exciter → Mechanics → Rain → Note Mix (5) |
| Temple | Voice → FM Field → FM Motion → FM Drift → Voice Spread → Note Mix (6) |
| TORT | Filter → Osc A → Osc B → B Waves → Osc Mixer → Voice Behavior → Poly-Mod → Wheel Source → Mod Routes → Voice Spread → Note Mix (11) |
| LEAD | Filter → Osc 1 → Osc 2 → Osc 3 → Noise → Voice Behavior → Voice Spread → Note Mix (8) |

Page orders use the current implemented parameters and retain the original controls. Branch's redundant spread-only page is removed from its EDIT cycle; spread remains on Voice and Mechanics. TORT's native LFO rate/waveform page moves to the dedicated LFO family; its modulation source and routing pages stay in EDIT. No new DSP controls are invented.

ENV cycles actual instrument envelopes (Branch/Temple one AR page; TORT filter/amp ADSR; LEAD amp ADSR/filter contour). LFO cycles each universal LFO's main/configuration pages, then TORT's native LFO page where applicable. FX, ARP and SEQ retain dedicated family cycles. A plain EDIT from any of these families always enters synth page 1.

SEQ+EDIT deletes the selected step. Hold SEQ+EDIT and tap OCT−/OCT+ for the existing undo/redo. This reserves plain EDIT for consistent instrument entry. PLAY+HOME still toggles the existing generators and opens the mixer; plain HOME never changes transport.

## Architecture and conflict removed

Previously `pf_next_page()` interpreted the numeric page ID in context: mixer EDIT opened tuning, tuning EDIT returned to mixer, envelope EDIT cycled envelopes, LFO EDIT toggled configuration, and sequencer EDIT deleted a note. HOME itself alternated overview/project controls. This combined unrelated families and made the requested instrument entry impossible to predict.

`fm1/pacific/navigation.h` now owns family transitions, per-family cursors, page counters and navigation LEDs. A nine-byte UI state tracks screen, EDIT, ENV, LFO, FX, GLOBAL, mixer, sequencer and ARP positions. The active instrument uses the existing `pf_ui.mode` field. Saved numeric page IDs remain compatible and are imported at the boundary; old overview page 47 opens mixer volume. Browser snapshots carry the navigation state to the graphics worker. The patch structure and audio processing/routing remain unchanged.

## Existing limits

External MIDI clock synchronization, configurable MIDI channels/routing/controller assignments, tap tempo, per-instrument tuning overrides, and metronome level/subdivision/accent are not implemented by the existing workstation. No empty controls were added for them. Sequencer divisions and sync remain in SEQ Pattern; universal LFO sync/divisions remain under LFO. Browser platform CPU/overrun hooks are stubs; the page's browser CPU readout is separate. Physical FM-1 checks and native flash/stack measurements remain unverified.

## Verification

The navigation regression exercises every requested transition separately for all four instruments, including repeated HOME/GLO, GLOBAL submenus, EDIT wrap, dedicated ENV/LFO cycles, counters/LEDs, active-instrument persistence, and all four real mixer knobs on Volume/Pan/both Sends. A two-run PCM comparison verifies that hundreds of screen transitions leave four simultaneous latched synths, original FX, four sequencers and Slip bit-identical to uninterrupted playback. The independent published audio reference, existing sequencer/patch migration tests, graphics-worker startup regression and native storage checks remain part of the full check command.

Memory: navigation state is 9 bytes; no new audio allocations or audio buffers; project remains 15,584 bytes in the 16,128-byte native payload, leaving 544 bytes. Engine pool remains 264,976 bytes. This is not a complete native linker/RAM measurement. Browser snapshot grows by 12 aligned bytes, with the same fixed three-snapshot transfer pool. WASM size and the final changed-file list are recorded below after validation.

Final browser WASM: 407,479 bytes versus 410,980 bytes before this refactor (3,501 bytes smaller). This is a browser artifact measurement, not native FM-1 flash usage. Full 23-suite regression and native storage check passed; final title-only rendering changes were rebuilt and rechecked with the navigation, isolated-display, actual-worker startup and independent PCM suites. Browser checks exercised HOME cycling/knob response and GLOBAL Tuning → EDIT.

## Exact changed-file inventory

- `README.md`
- `dist/amb.wasm`
- `dist/index.html`
- `dist/source.tar.gz`
- `dist/ui-v2/branch.png`
- `dist/ui-v2/home.png`
- `dist/ui-v2/lead.png`
- `dist/ui-v2/lfo.png`
- `dist/ui-v2/tort.png`
- `dist/ui-v2/value-overlay.png`
- `docs/NAVIGATION_REFACTOR.md`
- `docs/UI_V2_CONTROLS.md`
- `fm1/pacific/app.c`
- `fm1/pacific/engine.c`
- `fm1/pacific/navigation.h`
- `fm1/pacific/pacific.h`
- `fm1/pacific/preview-ui-v2.mjs`
- `fm1/pacific/test-edit-pages.mjs`
- `fm1/pacific/test-instrument.mjs`
- `fm1/pacific/test-interface.mjs`
- `fm1/pacific/test-lfo.mjs`
- `fm1/pacific/test-navigation.mjs`
- `fm1/pacific/test-octave.mjs`
- `fm1/pacific/test-seq-display.mjs`
- `fm1/pacific/test-seq-slip.mjs`
- `fm1/pacific/test-sloop.mjs`
- `fm1/pacific/test-tort.mjs`
- `fm1/pacific/test-transpose.mjs`
- `fm1/pacific/test-ui-v2.mjs`
- `fm1/pacific/ui-v2.h`
- `fm1/pacific/web.c`
- `fm1/web/emu/index.html`
