> Historical implementation record; not the current build or validation guide. See [the current audit](audit-remediation/REPORT.md) and root README.

# Pacific Field V2 — interface audit and design

Baseline56cbbbb5a0fd80dcabb012f827d8b631d5955d0f, public version25. Work is isolated on codex/ui-redesign-v2 in the FM1 MINIMALIST workspace. Existing published checkout and saved folders are untouched.

## Real hardware and reference discrepancies

FM-1:240×240 RGB565 display,14 buttons,7 relative encoders and an analog MASTER. There are no encoder-click events in plat.h; GLO/ENV/LFO/SEQ/FX repeats and contextual EDIT supply subpage navigation. The existing69120-byte240×144 strip canvas can render two120-row bands. No new full-screen native framebuffer is needed.

The supplied concept sheets use wide screens, simulated grain and fictional parameters. Their typography, high contrast, coral/lavender/yellow/off-white accents, silhouettes and information hierarchy will be adapted to a square pixel layout. Dense stochastic grain is replaced with bounded geometric contours. No tape memory, arbitrary ratio knob, direction mode, waveform-folding or polyphonic LEAD is inferred from the artwork.

## Existing engines and controls

Internal slots remain Branch0/TORT1/Clock2/LEAD3 and the entire v16 project layout stays15584 bytes. Clock's display name becomes TEMPLE, an FM synthesizer. The seven actual FMCONFIG configurations and operator ratios stay unchanged. Main TEMPLE controls: OSC MIX(par1), FM DEPTH(par0), ALGORITHM(par6), DETUNE(par3). There is no independent FM feedback or continuous ratio control. Existing mechanical/quartz modulation remains accessible on detail pages with sound-oriented labels.

Branch's excitation oscillators use a fixed1:1.003 relationship. Main controls: TONE(par0), RING(par1), selected-note FINE(par19) and VOICE SPREAD. Existing wind/rain/LPG controls move to a related EXCITER view. TORT remains the actual Prophet-derived engine: cutoff/resonance/filter envelope amount/filter model. LEAD remains original FMini mono with cutoff/resonance/contour/glide; no unavailable polyphony is shown.

TORT has actual filter and amp ADSRs. LEAD amp ADSR maps existing attack4/decay11/sustain6/release5; original filter contour has attack8/decay9/sustain10, without a separate adjustable release. Branch/TEMPLE use actual attack/release controls; no fake decay/sustain knobs. All16 LFOs remain. Primary knob order becomes Rate/Depth/Destination/Shape; EDIT retains Sync/Key Sync/Phase/Slew.

## Navigation and layouts

HOME: four-symbol overview, selected instrument, real activity/meters, active/queued B1–B4, project tempo/transport. Knobs: selected block, shared tempo, absolute field transpose, selected level. Repeat HOME retains Project settings. EDIT from HOME enters main voice controls; repeat retains related detail pages. All other direct buttons retain their existing sections, modifier gestures, latch, transport and safe sequencer note ownership.

GLO: VOL/PAN/FX1/FX2. Display/knob order Branch/TEMPLE/TORT/LEAD; internal IDs and PRESETS selection workflow stay compatible. FX1 sends to Oliverb(par27), FX2 to Clouds(par24). MASTER remains physical. Existing effects have one real shared instance each.

Common screen: top name/section/status; center signature or functional view; bottom four short labels and readable values. Real240×240 previews are generated from the same C renderer. Knob changes get a nonblocking850ms enlarged-value overlay. Transpose gets a signed interval/root overlay without touching notes. Drawing has a bounded refresh; geometry has fixed iteration counts and no per-frame C heap allocations.

Sequencer keeps four original patterns,64-step capacity, held entry, note span/recording/gate/tie/Slip behavior. Display names B1–B4 replace A–D visually only. Selected step is an outline, current playhead a coral marker, Slip a lavender marker; pitch roll remains visible so all chord notes can be inspected. Direction is the existing forward direction, shown as FWD; no unsupported direction control is invented.

## Processing and budgets

Original native pool accounting264976+canvas69120+reserve8192 leaves1776 of344064; this is not a native linker/stack measurement. Patch payload16128 leaves544 bytes. Preserve DSP allocations and schema. Browser currently draws inside its audio worklet; move display rasterization into a separate worker using read-only snapshots, while sound/input ownership remain in the audio instance. Native drawing remains in the existing main-loop renderer. Browser-only mirror memory is not an FM-1 allocation.

Verify exact PCM against the preceding build for equivalent musical state, all original regression suites, actual-patch compatibility, knob mappings, snapshot rendering isolation, actual meters, large-overlay expiry, render bounds and pixel previews. Hardware CPU/deadlines, flash-region ownership and physical usability require a real FM-1; do not claim them from WASM tests.

Mixer clarification: SELECT and PRESETS both follow the visible Branch / Temple / TORT / LEAD column order, in either direction, with wrap. Outside Mixer the existing PRESETS workflow and saved slot IDs remain unchanged.
