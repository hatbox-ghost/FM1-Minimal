> Historical implementation record; not the current build or validation guide. See [the current audit](audit-remediation/REPORT.md) and root README.

# Interface redesign validation

Validated 2 November2026. Baseline: d1b35d454771342be714aec336e08f295ab67ee5. Source branch: codex/interface-redesign. All four engines retained; LEAD is mono. No physical FM-1 was flashed or tested.

## Checks passed

The automatic check-fx.py build compiles the shared C interface/audio core, original FMini adapter and isolated original Oliverb/Clouds C++ DSP into WASM. It runs interface, transpose, instrument, LEAD, octave, arp Slip, contextual EDIT, TORT, LFO, Clock, spread, SLOOP, sequencer Slip, display, SLOOP stress, original FX and send-routing regressions. The same automatic run also covers the actual-v15 migration fixture and combined four-engine load probe. Native storage backend is exercised by the real storage.c host harness, including16166 interrupted-write points, legacy fallback, object bounds and panel isolation.

- Mixer entry from all52 pages; LEVEL/PAN/ECHO/ROOM cycle; Branch/TORT/Clock/LEAD knob mapping; selected-layer mute/solo; no page-triggered sound.
- Shared physical MASTER fades complete dry/wet output to zero and back without stopping voices. No added master encoder or bank switch. A fixed nominal DSP input level preserves effect resolution even when MASTER is nearly zero at power-on; the restored output matches a normal-volume boot.
- HOME macros reach actual DSP controls. Shared BPM and one metronome follow project transport.
- All four held/latched chords retune with one tuning-derived multiplier. The glide settles over roughly60–100ms; no note retrigger. TORT's original glide runs before the global multiplier. Its non-key-tracked audio oscillator follows transpose while its low-frequency mode stays an independent modulator. Existing echo/reverb audio is not pitch-shifted: buffered tails retain their recorded pitch. Branch retunes both excitation oscillators and resonance coefficient; its existing filter safety limits still apply at extreme pitches.
- Absolute targets and repeated zero resets do not accumulate tuning errors. Both modifier edges are consumed, including GLO release before key release. Older physical note ownership survives layer changes. Octave displacement and save/reload pass.
- Identical parallel instances preserve exact pattern bytes, playhead positions, note-off masks, A/B Slip events and all LFO phases during transpose. Separate arp checks retain exact event counts/times for all four engines and both arp heads.
- Zero-Slip PCM still matches the independent published golden hashes for the original three engines. Original FX tests pass unchanged in algorithm behavior.
- LEAD priority/fallback, original waveforms/ranges/levels, own contour/amp settings, MIDI ownership/bend, simultaneous TORT, storage, sequencing and Slip pass. The newly changed resonance reaches upstream note-on before its self-oscillation nudge; oscillator/noise-zero startup regression passes.
- Default LEAD now takes the same global tuning, initial16-step view and default C step-entry pen as the other three engines.
- Actual published v15 save migrates byte-for-byte across its15576-byte musical payload, except the version word. Fixture fixtures/v15-four-engine.bin was generated with the WASM from baseline d1b35d4, containing four sequencer banks, independent LFO/Slip and LEAD oscillator edits. New globals default to transpose0/metronomeoff. Silent reboot verified.

## Allocation and host load

Current patch15584 bytes, native project payload16128:544 bytes remain. Appended globals retain all original field offsets. Pool accounting264976 + canvas69120 + conservative stack reserve8192 =342288 of344064; remaining1776. This is static allocation accounting, not a successful native linker map or measured stack high-water mark. No long audio buffers or extra effect instances were added.

Combined-load probe: all27 manual keys on each instrument, generator state, four MIDI note owners per layer, sequencer A/B chords,16 active LFOs, original granular Clouds and Oliverb, repeated transpose. LEAD remains one sounding voice.4.354 seconds of audio rendered; finite, bounded output, zero dropped commands/FX faults; all manual/MIDI/sequence/Slip gates clear after stop. This host measured35.17% mean audio-block processing load, worst2.608ms against a2.902ms block interval. Host scheduling and browser/JIT conditions vary; these numbers do not establish FM-1 CPU headroom.

## Browser review

Actual browser AudioWorklet/WASM verified: four instruments layer simultaneously, selected-layer latch lights persist, mixer knob4 edits LEAD, PAN mapping updates visibly, HOME shows four rows and current controls, and held GLO plus key changes transpose without latching the target. Transpose remains after release and HOME navigation. Updated guide, tooltips, live labels and readout reflect the hardware map. Screenshots retained in the task's visualization folder.

## Remaining hardware limitations

Native firmware link, hardware flash-region ownership, physical display/input usability, CPU deadlines and stack high-water must be verified on an FM-1. Existing SDK/toolchain/reference trees were retained. No sound engine was removed or simplified for this redesign. LEAD polyphony remains a separate milestone.
