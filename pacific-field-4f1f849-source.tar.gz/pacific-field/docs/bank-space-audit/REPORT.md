# Pacific Field space audit for instrument and project banks

Compared with commit `7bd4991`. The current Slip implementation advances the four primary clocks. It never enables the old stereo double, but the build still included a second FMini core and the event recorder still allocated storage large enough for a second SLOOP playhead. The cleanup removes that core and its dormant mixing paths, and allocates only the event recorder's actual state. All 60 voice slots per instrument remain available to the existing routing layout.

## Measured savings

| Allocation | Before | After | Reclaimed |
|---|---:|---:|---:|
| PI32v2 engine plus retired LEAD object ordinary RAM, BSS and data | 27,284 B | 25,968 B | 1,316 B |
| PI32v2 engine pool | 27,928 B | 27,896 B | 32 B |
| PI32v2 engine plus retired LEAD object code and read-only data | 83,822 B | 72,510 B | 11,312 B |
| Compiled emulator pool accounting including canvas | 331,644 B | 331,612 B | 32 B |
| Accounted pool headroom after 8 KiB reserve | 4,228 B | 4,260 B | 32 B added |
| Actual v23 saved project | 15,772 B | 15,772 B | 0 B |

The scheduler allocation falls from 928 B to 448 B. The other ordinary RAM savings come from the second FMini instance and retired engine state. The code and read-only data figures are from real unlinked PI32v2 objects compiled with identical flags. Final linker elimination, placement, firmware size, free writable flash, physical CPU load and stack high-water remain unmeasured. The previous full native link is still blocked on C++ headers and runtime symbols. The linker configuration's XIP limit is 581,564 B and its ordinary RAM limit is 96 KiB. See [previous target audit](../audit-remediation/REPORT.md).

## Instrument bank

The existing code binds engine identity, voice state, clips and mixer to the same four layer indexes. Separate channel-owned state from engine-owned state first. Keep four live channels, and let them select from the compiled instrument library. A first implementation can load each engine type once and allocate its active state only while assigned to a channel. Test the switch with the existing four engines before adding a fifth. Verify the heaviest permitted four-engine combination and the combined firmware image before promising six on a device.

The remaining bottleneck for larger live engines is the protected pool. The cleanup adds only 32 B there. A later audit can trace historical routing slots, shared engine scratch and the lifetime of idle engine allocations before changing their sizes. Those potential savings are excluded from this measurement.

## Project bank

Ten current payloads total 157,720 B, about 154 KiB. The browser can store these independently of the firmware layout. The native backend uses two 16 KiB extents at `0xD0000` and `0xD4000` to protect one project against interrupted writes. Calibration begins at `0xDC000`; the legacy fallback is at `0xFC000` and the updater stages its loader from `0xE0000`. The 16 KiB interval `0xD8000–0xDBFFF` is unassigned in this backend. Its ownership still needs verification before any writes.

Duplicating today's native layout ten times would reserve 320 KiB. Ten 16 KiB slots plus one rotating spare would reserve 176 KiB for project extents, plus any indexing or migration space. That design requires a boot scan for each slot's latest valid generation and power-cut coverage before the old extent can be reused. Variable-length clip encoding is another way to reduce typical writes, but its worst-case size must be measured before relying on it for slot count. Reclaimed executable bytes do not by themselves make a writable project region.

## Verification

The full CI inventory passed after retiring the duplicate engine. After shrinking the scheduler allocation, seven focused suites passed, covering PCM identity, Slip, recording, legacy SLOOP, project recall and the storage backend. A separate before/after comparison rendered all four arps and sequencers together with mixer pan and random arp order for 204,800 stereo frames per setting. Each pair was sample-identical.

| Slip | PCM SHA-256 |
|---|---|
| 0 | `4c8ecc6de9dc8ebe562b225e7439c8bd046e0bb975aa5de5bc151e4bc5db998e` |
| 100 | `f73548785b1513f5c0f95ac2d035a26b09ccc0feda00ef1acf0712b811132499` |
