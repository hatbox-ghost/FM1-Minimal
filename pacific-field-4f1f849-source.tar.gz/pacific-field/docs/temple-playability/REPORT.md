> Historical implementation record. Dates, memory projections, controls and validation claims apply to that checkpoint. See [the current audit](../audit-remediation/REPORT.md) and root README for current status.

# TEMPLE: playable FM editing and envelopes

Implemented on `codex/temple-playability`, preserving checkpoint `c73d76f` and its binary separately. Local preview: http://127.0.0.1:8784/ . No public deployment or hardware flash.

## Layout comparison

[FM Lab’s quick reference](https://github.com/jsmith13/fm_lab/blob/main/docs/QUICK-REFERENCE.md) uses a selected operator, consistent knob assignments, direct envelope editing and tap/hold access to deeper controls. [Prysm’s manual](https://github.com/NicholasPratt/Prysm/blob/main/docs/MANUAL.md) groups synthesis into short page families and puts envelopes behind ENV. These are useful hardware interaction patterns; neither firmware’s engine was substituted for TEMPLE.

The previous thirteen-page EDIT cycle made routine sound design too indirect. The replacement keeps common musical controls close and operator detail available deliberately.

## Controls

| Access | Four knobs |
|---|---|
| EDIT: SOUND | FM Depth, Color, Routing, Feedback |
| EDIT: VOICE | Ratio Set, Detune, Spread, signed FM Envelope Amount |
| EDIT: MECHANICS | Existing mechanical controls |
| EDIT: QUARTZ DRIFT | Existing quartz/drift controls |
| ENV | Amp Attack, Decay, Sustain, Release |
| ENV again | Timbre Attack, Decay, Sustain, Release |
| Hold EDIT | Selected operator Ratio, Level, Wave, Decay |
| ENV from operator editor | Selected operator Attack, Decay, Sustain, Release |

SELECT browses the four main pages in either direction. In operator editing or its envelope, SELECT chooses OP1–OP6 without consuming musical keys. A short EDIT returns from deep editing to SOUND. ALGORITHM within deep editing reaches inherited shaping and the existing note mixer. All seven ratio sets, 32 routings, six operators and original mechanical behavior remain.

The amp and timbre ADSRs are independent per note. Operator ADSRs are independently selectable for all six operators. Linear attack and exponential decay/release support plucks, held pads and ringing bells. The first timbre edit connects its envelope if the depth was never configured; VOICE’s bipolar FM ENV amount controls or disables that depth. The per-operator Decay knob edits its ADSR decay once that envelope is enabled. Otherwise it retains the inherited shaping override.

Older sounds retain their exact original amp trajectory until an amp control is edited. This is automatic compatibility, with no Classic mode. New controls do not alter old project bytes during startup. Version 19 adds neutral fields after the preserved v18 prefix. Saving persists the new envelopes.

## Allocation

| Resource | Before | After | Difference |
|---|---:|---:|---:|
| Project bytes | 15,632 | 15,664 | +32 |
| Native project payload capacity | 16,128 | 16,128 | 464 bytes remaining |
| Projected native ordinary BSS + data | 86,774 | 87,726 | +952 |
| Projected native pool | 334,788 | 334,788 | 0 |
| Conservative emulator pool API + canvas | 335,004 | 335,004 | 0 |
| Remaining pool after protected 8,192-byte reserve | 868 | 868 | 0 |

The ordinary RAM increase is 720 bytes of per-voice envelope state, 132 shared coefficient bytes, 32 live parameters, 64 bytes across two project copies and four UI gesture bytes. Existing operator envelope floats and voice amplitude state are reused. All 60 routing/voice slots remain. No other engine was reduced.

The projection uses 32-bit optimized LLVM globals from the native source, not a PI32v2 linker map. Read-only data grows 286 bytes in that projection. Emulator code grows 11,535 bytes; this is not a native flash measurement. Native linking, interrupt deadlines, stack watermark and physical CPU remain unverified.

## Validation

`regression.log` records the complete successful `check-fx.py` run, including immutable original-sound comparisons, all-engine integration, routing, note ownership, sequencer boundaries, UI navigation, original effects and native storage fault/cut-point checks. No sound golden was regenerated to conceal a changed engine.

New tests cover ADSR stages, zero-sustain held plucks, independent held notes, retriggers, long/short releases, signed timbre shaping, six independent operator envelopes, selected-operator navigation, and actual v18 migration/save/reboot. The storage guard remains intact.

`host-stress.json` records an additional simultaneous four-engine/effects stress run with all new TEMPLE ADSRs enabled and routing 32. It rendered 4.35 seconds at about 36.7% average host budget, with a 1.30 ms maximum measured block against 2.90 ms, no dropped commands or FX faults, and finite bounded output. These are host observations, not hardware guarantees.

The browser was checked through actual knobs/buttons: four-page EDIT, hold EDIT, SELECT operator switching, valid operator-envelope titles and changing ADSR values. `browser.png` shows an unsaved pluck with sustain zero; the saved project was not overwritten.

Reproduce with Emscripten/Node using `python3 fm1/pacific/check-fx.py`; run the extra stress case with `PF_TEMPLE_ENVELOPES=1 PF_TEMPLE_ROUTING=31 node fm1/pacific/test-four-engine-load.mjs fm1/build/emu/amb.wasm`. Allocation details and compressed emulator maps accompany this report.
