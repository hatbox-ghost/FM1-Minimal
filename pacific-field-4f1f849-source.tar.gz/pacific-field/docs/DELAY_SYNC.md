> Historical implementation record; not the current build or validation guide. See [the current audit](audit-remediation/REPORT.md) and root README.

# Delay tempo sync

The Delay sync button beside Mixer toggles the shared Clouds looping-delay clock. On the FM-1, hold FX first and tap SEL. This gesture consumes SEL without changing the selected instrument's latch or held notes.

When enabled in DELAY mode, the existing time knob selects quarter, eighth, sixteenth or thirty-second notes, with straight, dotted and triplet variants. FX's SPACE overview uses knob 2; CLOUDS DELAY uses knob 1. GLOBAL Tempo / Clock sets the shared BPM. Sync also follows tempo changes produced by the existing sequencer capture workflow. Turning sync off restores the unchanged free delay time. Granular and stretch positions remain free; the browser button identifies when sync is armed outside delay mode.

The original stereo 16-bit Clouds buffer supports about 1.020 seconds. At a tempo where the requested division exceeds that capacity, sync selects a shorter note of the same straight/dotted/triplet family. The actual audible division is displayed with AUTO. It does not clamp to an arbitrary off-clock time. The original Clouds delay slew, processing latency, freeze-loop-size and pitch-shift behavior remain intact.

No upstream DSP files are modified. The adapter converts musical time into normalized position using the actual original buffer capacity: 65,408 bytes / 2 − 8 interpolation-tail samples − 64 crossfade samples = 32,632 samples at 32 kHz. A compile-time assertion checks that relationship. Free timing takes the existing code path with sync disabled.

Sync and division use previously unused bits 3–7 of the v16 project's seqReserved word; bits 0–2 keep the existing recording settings. Save merges those flags rather than replacing the word. Patch size stays 15,584 bytes. The audio side adds three 16-bit scalar settings and no delay buffers or dynamic allocations. The same physical-panel input and C effects adapter remain available to native firmware; physical FM-1 verification is still pending.

The automatic test covers project BPM changes, straight/dotted/triplet divisions, slow-tempo capacity folding, free-time restoration, physical gesture/latch ownership, persistence, and preservation of the recording flags. It measures actual original Clouds impulse-response spacing within 2 ms after the original slew settles. The full check command also checks sync-off PCM against the pre-sync golden reference, shared routing and native patch storage.
