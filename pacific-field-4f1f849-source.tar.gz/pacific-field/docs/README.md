# Documentation status

Use the [root README](../README.md), [current build guide](../fm1/BUILDING.md), [license inventory](../NOTICE.md) and [audit remediation report](audit-remediation/REPORT.md) for current facts.

Other reports and screenshots are historical checkpoint evidence. In particular, early UI v1/v2, navigation, sequencer and memory reports contain prior page maps and compiler projections. They do not establish current target linking, hardware validation or current sound. Their headings explicitly identify that scope. Reference instrument audio examples remain for provenance; they are not regenerated during validation.
