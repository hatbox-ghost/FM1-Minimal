> Historical implementation record. Dates, memory projections, controls and validation claims apply to that checkpoint. See [the current audit](../audit-remediation/REPORT.md) and root README for current status.

# Expanded Slop response

Historical cc09133 behavior, superseded by [SMOOTH-SLOP.md](SMOOTH-SLOP.md).

Slop now uses a cubic amount curve: the independent oscillator walk is scaled to a ±4,800-cent bound at 100, rather than the previous ±40-cent bound. The bound is not a claim that every voice reaches the extremes: the existing independent, mean-reverting walks continue unchanged. Low values remain gentle; high values create strongly atonal, independently wandering pitches across voices and oscillators. This is a Pacific sound-design choice requested by the user, not a claim to reproduce the proprietary Rev2 response.

Measured from the actual 54 oscillator phase increments across all 27 held notes:

| Slop | Initial largest detuning | Initial spread across oscillators | Largest detuning after ~7 seconds |
|---|---:|---:|---:|
| 10 | 2.32 cents | 4.60 cents | 1.20 cents |
| 25 | 36.33 cents | 71.85 cents | 18.82 cents |
| 50 | 290.62 cents | 574.80 cents | 150.59 cents |
| 75 | 980.86 cents | 1939.97 cents | 508.23 cents |
| 100 | 2325.00 cents | 4598.44 cents | 1204.69 cents |

These are deterministic test captures, not universal minimum/maximum musical results. At 100, most oscillator owners are more than one semitone away from their original tuning, with distinct offsets and continued temporal motion. Slop at zero still bypasses drift and reproduces the preceding saved build's PCM exactly, including all four engines and existing LFOs. Slop's LFO destination retains the full expanded range. Fine tune and ALL FREQ routing remain unchanged.

No new runtime state, voices, buffers, or processing stages. The cubic gain is calculated once per TORT control block. Patch remains 15,664 bytes; pool 269,724 bytes, with the existing 868-byte reserve margin intact. The combined four-engine/39-TORT-owner stress test passed with maximum Slop, oscillator LFOs, sequencers, Slip, Clouds and Oliverb: no nonfinite samples, no DSP faults, no dropped commands. Host timing averaged 34.62% of the real-time budget with a largest measured block of 1.25 ms against a 2.90 ms deadline; hardware CPU remains unverified.

Checks: automatic compilation; new `test-slop-range.mjs`; `test-oscillator-slop.mjs`; `test-simple-lfo.mjs` against c53fbd0; `test-four-engine-load.mjs` with PF_OSC_STRESS=1. The new range test is included in `check-fx.py`. Previous full-suite results remain in regression.log; the full suite was not repeated for this amount-curve-only change. Logs are alongside this report.

The saved c53fbd0 snapshot is preserved. Pre-change browser binary: `$SCRATCH/pacific-before-extreme-slop.wasm`. New work is on `codex/extreme-slop`.
