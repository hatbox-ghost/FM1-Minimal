> Historical implementation record. Dates, memory projections, controls and validation claims apply to that checkpoint. See [the current audit](../audit-remediation/REPORT.md) and root README for current status.

# TORT oscillator Slop and independent oscillator tuning

This describes the initial c53fbd0 implementation. The current implementation is described in [SMOOTH-SLOP.md](SMOOTH-SLOP.md); [EXTREME-RANGE.md](EXTREME-RANGE.md) records the intermediate version.

TORT EDIT now cycles Filter → Osc A → Osc B → **Osc Tuning** → Interaction → Voice → Filter Model → Spread → Note Mix. Osc Tuning has Slop (0–100), Osc 1 Fine (±50 cents), Osc 2 Fine (±50 cents), and Osc 2 Semitone. Existing oscillator-2 detune and Vintage retain their original behavior; the new fine trim is additive.

LEAD EDIT adds **Osc Tuning** after its three oscillator pages, with one ±50-cent trim for each oscillator. These offsets also reach the independent Slip instance. No oscillator is enabled merely by adjusting its pitch.

Each of the four existing LFOs can select these appended destinations:

| Instrument | New destinations |
|---|---|
| TORT | OSC SLOP, ALL FREQ, OSC 1 FINE, OSC 2 FINE |
| LEAD | ALL FREQ, OSC 1 FINE, OSC 2 FINE, OSC 3 FINE |

ALL FREQ is bipolar ±12 semitones at full depth; combined ALL FREQ sources are capped at ±24 semitones. Existing PITCH FINE remains ±100 cents with its old destination ID. Oscillator fine LFO depth is ±100 cents, summed offsets bounded at ±200 cents. Global tuning, root, octave and master transpose remain upstream of these offsets. The LFO navigation remains four main pages and one shared Setup page.

## Slop behavior

Inspired by the Rev2's oscillator drift and modulation choices, documented in the [official Sequential manual](https://www.sequential.com/wp-content/uploads/2019/05/Prophet-Rev2-Users-Guide-1.2.2.pdf). This is a new Pacific adapter implementation, not Sequential's proprietary algorithm.

Two independent, bounded, mean-reverting pitch walks per TORT note owner. Updates are staggered and sparse (one update per oscillator per 256 audio samples), using a deterministic hash independent of OberVave's noise/Vintage RNG. Amount scales their pitch contribution up to a ±40-cent bound; typical motion is substantially smaller. Slop does not modulate filters, envelopes, pan or levels. Amount zero bypasses the walk and its pitch calculations. Hard panic resets walk state; ordinary notes retain their oscillator wander state. An LFO can vary Slop independently of the two oscillator fine destinations.

Original OberVave and FMini-1 oscillator/filter code is retained. LEAD's existing Pacific adapter applies optional pitch multipliers after original increment calculation. TORT applies the two offsets separately before oscillator rendering. No upstream source files changed.

## Storage and memory

No patch structure growth or version change: 15,664-byte v20 project, 464 bytes below the native 16,128-byte guard. Previously unused, zero-initialized bytes store Slop and signed seven-bit cents (zero stays neutral); old destination IDs remain unchanged. New bytes survive saves. Existing neutral boot policy still clears LFO destinations/depth, preserves fine trims, starts on the mixer and does not write storage at boot.

Fixed additional source state: 240 bytes for 60 independent Slop pairs, 64 bytes for per-engine oscillator modulation, 12 bytes for TORT block offsets/amount, and 24 bytes for two LEAD adapter ratio arrays. All are outside the protected audio pool, with no heap or new audio buffers. The optimized WASM linker map has a net BSS increase of **304 bytes** over 716de38; code +5,058 bytes, read-only data +336 bytes. Binary grows 5,395 bytes. Native layout/flash and hardware CPU still need native verification.

Protected pool remains 269,724 bytes; canvas 65,280; reserve 8,192; remaining margin 868 bytes. No voice-count reduction. A reload regression also caught an existing selected-TORT startup queue overflow: shared FX/global initialization now goes through the least-loaded Branch queue before restoring selection, preserving all initialization commands without growing queues.

## Verification

- New `test-oscillator-slop.mjs`: actual TORT oscillator increments validate independent ±25-cent edits, oscillator LFO isolation, and ALL FREQ +1 octave; evolving independent bounded drift, direct/LFO Slop, chords, release safety, LEAD single-oscillator audio response, save/reload and guards.
- `test-simple-lfo.mjs` against protected pre-change binary: exact PCM and phase equality with all four engines, active existing LFOs and extra routes; no old golden data regenerated.
- Extended four-engine stress: 39 simultaneous TORT owners, all 27 manual keys per engine, MIDI, chord sequencers, per-instrument Slip, 16 LFOs, original granular DSP and Oliverb, with maximum Slop and oscillator-pitch modulation enabled. Finite audio, zero dropped commands or DSP faults. This host run averaged 35.15% of real-time budget; largest measured 128-frame block 1.34 ms vs 2.90 ms deadline. These are host measurements, not an FM-1 CPU guarantee.
- Actual firmware framebuffer captures checked for both new tuning pages; graphics remain unobscured.
- Browser interaction was unavailable because automatic approval review previously rejected browser automation at its usage limit. No alternate browser surface was used.

Preserved binary: `$SCRATCH/pacific-before-oscillator-slop.wasm`; previous served preview: `$SCRATCH/pacific-pre-oscillator-slop-preview/`. Branch: `codex/oscillator-slop`.
