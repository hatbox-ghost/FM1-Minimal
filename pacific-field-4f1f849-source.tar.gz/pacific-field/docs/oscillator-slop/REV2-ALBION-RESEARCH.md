> Historical implementation record. Dates, memory projections, controls and validation claims apply to that checkpoint. See [the current audit](../audit-remediation/REPORT.md) and root README for current status.

# Slop reassessment: Rev2, Albion, and Pacific Field

Research date: November 3, 2026. Audio baseline inspected: cc09133. **No DSP or preview changes were made for this investigation.**

## What is verified about the Rev2

Sequential's [official Rev2 manual, oscillator section and modulation destination list](https://www.sequential.com/wp-content/uploads/2019/05/Prophet-Rev2-Users-Guide-1.2.2.pdf) specifies randomized oscillator detuning, 0–127 amount, and Slop as a modulation destination. It does not disclose its time constants, transfer function, random generator, or source implementation. An exact proprietary implementation was not located in the material inspected.

CreativeSpiral's [first-hand Rev2 tests, reply 3](https://forum.sequential.com/index.php?topic=3203.0) describe independently moving oscillator/voice pitches, continued phase between note triggers, varying excursion and center, and eased turnarounds. The author reports maximum excursions around three or four semitones, with smaller swings at other times. Their explanation in terms of nested LFOs is a hypothesis based on observation, not published firmware. Treat these as behavioral targets rather than a verified reconstruction.

The same researcher's [voice component modeling discussion](https://www.presetpatch.com/articles/voice-component-modeling) is useful context: stable component differences and moving Slop are distinct approaches. A static detune table alone would not reproduce the changing Slop behavior described in their measurements.

## What Albion actually does

Source inspected read-only: `$REFERENCE_INSTRUMENTS/albion-latest-code.txt`.

- Lines 6868 and 6873–6891: each drone note gets a random phase and individual base drift rate, 0.008–0.043 Hz. At the default rate multiplier of 1, primary cycles last approximately 23–125 seconds.
- Its drift function adds a main sine and a smaller sine at 2.17 times the rate, with 22% of its depth. It is technically pitch modulation, but independent slow cycles and the extra component make ensemble movement less uniform.
- The drone frequency follows its target with Web Audio `setTargetAtTime(..., 0.12)`, providing continuous exponential smoothing. It updates every fourth animation frame; the smoothing time is in seconds, not frames.
- Default `detuneMax=2`; maximum surface depth gives primary amplitude 14 cents and a combined mathematical bound of 17.08 cents. This file's default drone detune is subtle, not the extreme multi-semitone end of Rev2 Slop.
- Arp voices use a different behavior: one random pitch offset per triggered note, up to ±4.5 cents at maximum default depth. That offset is retained with the arp voice. Copying only this arp code would give note randomization, not the drone's slow motion.
- The tiny randomized initial drone tuning is overwritten by the first drift target; it is not a permanent independent per-note detune contribution.

## Why Pacific sounds modulated

The present adapter in `fm1/pacific/tort.h` updates its random walk once per 256 audio samples per active oscillator: **172.27 updates/second at 44.1 kHz**, one every 5.80 milliseconds. Control coefficients are applied every 16 samples; the oscillator increment jumps to the new walk value without an independent pitch slew.

At Slop 100 the gain is 4800/1024 cents per integer walk unit. The random term alone can step by approximately −75 to +70 cents in one update; mean reversion adds another contribution. That is rapid stepped pitch jitter, not merely a slow detuning trajectory. Multiplying its gain to make 100 extreme amplified this defect. The previous four-octave bound was an overcorrection, not a measured Rev2 range.

The current mean-reversion coefficient also pulls offsets toward the center on a subsecond time scale (approximately 128 updates, or 0.74 seconds, ignoring integer rounding). Its movement is much busier than Albion's default multi-second cycles. Walk state advances only while that owner is rendered, so fully idle owners do not have independently progressing trajectories.

## Revised implementation direction

Retain the single Slop knob and its existing LFO destination, fine-tune controls, engines and saved patch layout. Replace the fast stepped walk rather than merely filtering the final audio or turning its depth down.

1. Give each oscillator of each voice its own smooth, free-running pitch trajectory and seed/phase. No key retrigger reset and no shared audible periodic sweep.
2. Use an Albion-like slow base trajectory, with independently changing depth and center for a closer match to the Rev2 observations. Different oscillators need different rates, not just phase offsets.
3. Interpolate pitch continuously, including the transition when turning Slop or modulating its amount. Changing the amount should not abruptly jump pitches; the external LFO may still deliberately animate its amount.
4. Fit the upper range around several semitones of independently diverging pitch, rather than multiple octaves. This can still sound markedly atonal across a chord. Exact amount/rate calibration remains a listening target, not a verified Rev2 parameter map.
5. Use elapsed audio time to reconstruct an idle oscillator's drift position when it becomes active, avoiding an always-running bank of user-facing LFOs and avoiding per-sample processing for silent voices.
6. Keep the existing 240-byte drift allocation if practical. If more state is necessary, measure the ordinary-RAM delta before adopting it; add no audio buffers and preserve the protected pool.

Acceptance checks need to cover actual pitch-step size and movement speed, not just maximum range and finite audio: independent trajectories, smooth small increments, phase continuity through release/retrigger and silence, useful low settings, strong multi-semitone divergence at maximum, zero-Slop PCM identity, unchanged oscillator isolation, LFO amount routing, save/reload, and combined engine load. Listening is still required to judge the musical match; the current automated range test did not establish that match.
