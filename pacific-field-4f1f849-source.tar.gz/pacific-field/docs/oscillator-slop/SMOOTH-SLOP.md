> Historical implementation record. Dates, memory projections, controls and validation claims apply to that checkpoint. See [the current audit](../audit-remediation/REPORT.md) and root README for current status.

# Smooth, free-running oscillator Slop

Replaces cc09133's fast, unsmoothed random walk. The research basis and distinction between measured Rev2 behavior and proprietary implementation are in [REV2-ALBION-RESEARCH.md](REV2-ALBION-RESEARCH.md). This is a Pacific implementation informed by Albion's code and Rev2 observations; it is not Sequential's original DSP.

Each oscillator/owner derives independent rates and phases from a seed. A slow primary cycle at approximately .008–.043 Hz (23–125 seconds) combines with a 22% secondary component at about 2.17 times that rate. Separate, slower components move depth and center. Pitch changes use the existing interpolated sine table and run at the original 16-sample oscillator control rate. No random pitch steps remain.

Phase is reconstructed from a 64-bit elapsed-sample clock, even across silence. Notes and hard panic do not restart drift phase; boot resets the clock. Inactive oscillators need no running per-voice LFO state. No heap, new audio buffers, or additional user-facing controls. OberVave noise, Vintage, filters and envelopes remain untouched.

Slop has a quadratic amount curve and a nominal ±600-cent maximum bound (actual normalized signal bound .98). The upper range remains markedly dissonant across independent voices; the previous multi-octave range is removed. Knob and external LFO changes use a 120ms exponential amount slew. At zero the gain settles to exact zero, returning to the original oscillator path. Fine-tune and ALL FREQ destinations are unchanged.

## Tests completed

- Compilation passed. Updated `test-slop-range.mjs` is already in the automatic `check-fx.py` sequence.
- Actual oscillator measurements across 27 held notes / 54 oscillators: at Slop 10, peak detuning 4.37 cents; at 50, 109.34 cents; at 100, 437.37 cents, with 738.06 cents spread across oscillators in this deterministic capture. These are observed snapshots, not guaranteed maxima.
- At Slop 100, largest observed successive pitch change over the tested 16-sample updates was **0.050 cents**, rather than the former tens-of-cents jumps. All 54 oscillators move independently; additional tests cover amount changes, return to exact neutral, and continuity when an idle note retriggers after 16 seconds.
- Exact PCM and LFO-phase preservation against the pre-change binary with Slop zero, across all four engines and existing modulation/extra routes.
- Independent oscillator fine/LFO routing, Slop amount modulation, LEAD sound response, notes, releases, saving/loading and guards passed.
- Full TORT suite passed: native controls, six filters, extra routes, all global tunings, velocity, note-offs and envelopes.
- Combined four-engine stress passed with maximum Slop, 39 TORT owners, all manual keys, MIDI, sequencers, Slip, 16 LFOs, original Clouds and Oliverb: no nonfinite audio, DSP faults, or dropped commands. Measured host average 35.12% real-time budget, largest block 1.29ms versus a 2.90ms deadline. Hardware CPU remains unverified. Timing samples are not worst-case execution guarantees.

No full-suite rerun for unaffected systems; relevant DSP and preservation tests are recorded alongside this report. Automated pitch checks establish smoothness and independence, not a subjective listening match to a physical Rev2. Browser UI automation remains unavailable due to the prior approval-review usage limit; the served binary is checked separately.

## Memory

Removed the 240-byte walk-state array; added one 64-bit sample counter and one float for amount smoothing. Source static-state reduction is 228 bytes, with a **224-byte reduction in optimized WASM BSS** after alignment. Linker-map code increases by 192 bytes versus cc09133; read-only data and initialized data are unchanged. No native linker/CPU claims are made from the WASM map.

Patch remains 15,664 bytes. Protected pool remains 269,724 bytes; canvas 65,280; reserve 8,192; remaining pool margin 868 bytes. All four engines retain their existing voices and routing.

Previous build binary: `$SCRATCH/pacific-before-smooth-slop.wasm`. Saved c53fbd0 and cc09133 snapshots remain intact. Work branch: `codex/smooth-slop`.
