> Historical implementation record. Dates, memory projections, controls and validation claims apply to that checkpoint. See [the current audit](../audit-remediation/REPORT.md) and root README for current status.

# BRANCH × Elements — first integrated implementation

BRANCH is replaced directly in the existing workstation, not added as another engine or preset mode. Recovery checkpoint: `13aee02` (neutral startup, including audited memory optimizations). Other engines, shared FX, patch layout, note ownership and startup preferences remain intact. Public distribution remains unchanged; no deployment or hardware flash.

## Try it

Local workstation: http://127.0.0.1:8784/ . Switch on, choose BRANCH and press EDIT. Play keys directly, or enable SEL deliberately for held notes. Hold PLAY and tap HOME to toggle the existing autonomous generator. Releasing a key ends its continuous excitation while the body and existing amp release decay. Empty sequencer playback remains silent.

EDIT cycles:

1. Sound: **BLOW / BOW / STRIKE / BRIGHTNESS**.
2. Atmosphere: **WIND / RAIN / RING / MOTION**.
3. Resonance: **BODY / POSITION / VARIATION / RAIN MS**.
4. Voice Spread.
5. Note mix.

ENV: Attack / Release / Strike strength / Ring. ALGORITHM adjusts BRANCH brightness outside mixer/global navigation. Mixer and global navigation retain their existing behavior. Four universal LFOs remain independent and unassigned at startup; their destination names now match the new functions.

Rain controls event density; Strike controls force, and Variation adjusts both resonator individuality and irregular strike-force spread. Wind drives the original spring mechanics and a shared colored excitation field. Motion transfers the spring displacements into bounded modal-geometry changes. Voice Spread retains the workstation's pan law, including centered output at zero.

## Authentic DSP and explicit adaptations

The original upstream source was read from the separately preserved reference checkout, `$ARCHIVED_WORKSPACE/References/eurorack`. Its commit is recorded in `fm1/pacific/upstream/elements/PIN.json`; MIT notices remain in the source. This is a selected-component port, not a complete Elements voice clone.

- **Resonance:** original Elements modal filter computation and rendering, instantiated as four partials for every one of the existing 60 BRANCH routing slots. No voice stealing, reduced note capacity or shared pitched modal state.
- **Atmospheric body:** eight normal modes and one bowed feedback mode with a 256-sample float delay, shared across the physical object. This is deliberately reduced from Elements' eight bowed modes and 1024-sample lines. Original low-frequency delay folding remains, so low bowed-body behavior differs from full Elements.
- **Blow:** original granular noise-sample exciter, with its original sample table and filter. A small additional colored shared breath component is an adapter choice, not a claim of restoring the original browser's exact pink-noise filter.
- **Bow:** original FLOW excitation and the shared original bowed-feedback mechanism. Independently pitched keyboard modal voices receive FLOW excitation, but do not each instantiate the full bowed delay network. The distinction matters: this is not 60 independent full Elements bowed voices.
- **Strike:** original MALLET pulse generation and filtering. The source is shared, with independent note-on/rain triggers and per-slot body state. Unused sampled-strike model dispatch is excluded so its large sample bank is not linked; no exposed control selects that omitted model.
- Original resonator capacities were made compile-time template arguments; zero-bow instances use zero-capacity `std::array` members. Dependent-template syntax was added for compilation. Filter coefficients update every 16 samples rather than once per one-sample adapter call.
- Internal sample-rate constant is adapted to **44.1 kHz**, matching workstation tuning and sample cadence. This is a rate-adapted implementation, not sample-identical original 32 kHz Elements audio.
- The compatible existing MIT stmlib subset from the Clouds port is reused under its own isolated namespace, with the required original delay-line header supplied from the Elements reference. Elements randomness is isolated from the other engines and effects.

Existing BRANCH spring displacement/velocity, mechanical coupling, irregular mallets, seeded variation, independent generator start/stop and keyboard/sequence/arp ownership remain. No wavefolder, extra complex oscillator, FM cross-modulation, sympathetic audio cross-feedback, convolution, chorus or new external effect was added.

## Memory and CPU

Compiler-measured 32-bit/WASM object capacities:

| Allocation | Bytes |
|---|---:|
| 60 independent modal note states | 10,800 |
| Shared modal/bowed atmospheric body | 1,268 |
| Three shared original exciters | 192 |
| Shared adapter scalars | 24 |
| **Tracked new DSP state** | **12,284** |
| Isolated RNG and exciter dispatch table | 60 |
| **Total additional persistent objects** | **12,344** |

The tracked DSP fits the recommended 12 KiB envelope with 4 B spare; the additional 60 B are ordinary control/dispatch metadata. No old BRANCH routing/mechanical storage is overlaid or reclaimed in this first pass.

The conservative runtime guard reports **269,404 B** engine/effect state + **65,280 B** canvas + **8,192 B** reserve = **342,876 / 344,064 B**, leaving **1,188 B**. It conservatively counts all tracked BRANCH state against pool capacity even though 216 B actually occupy ordinary RAM. Native-source projection therefore places 12,068 B of new state in POOL and 276 B in ordinary RAM, before target linker alignment. The reserve was not lowered.

Patch size remains **15,584 B**, version16, leaving **544 B** in the 16,128 B native storage payload. Existing data loads without a structural migration. Existing BRANCH parameter numbers are reused with new sound meanings; an old BRANCH sound therefore changes, as expected for this direct engine replacement. Other instruments' saved settings and musical data remain preserved.

The original generic BRANCH bank still carries mechanical/routing scaffolding. Removing its obsolete oscillator fields later may recover more memory, but this implementation does not rely on that saving.

Full native ELF/flash layout, target stack watermarks and physical FM-1 CPU performance remain unverified. The native build manifest includes the new C++ units, but no native build success or hardware readiness is claimed. The retained sample-noise table adds about 80 KiB of readonly data; the unused sampled-strike bank is omitted. WASM artifact size is recorded in measurements.json, not treated as native flash usage.

## Dry examples

All examples use zero Oliverb/Clouds sends. These are directly generated from the compiled workstation, with no normalization, reverb or post-processing:

1. [Quiet atmosphere](01-atmosphere.wav)
2. [Continuous Blow](02-blow.wav)
3. [Sustained Bow](03-bow.wav)
4. [Wooden/metallic strikes](04-wood-metal.wav)
5. [Keyboard over the autonomous atmosphere](05-keyboard-over-atmosphere.wav)
6. [Mechanical movement](06-mechanics.wav)

These are implementation audition material, not a claim that a completed listening study established equivalence to the browser original. Source comparison identifies common excitation, individual resonant bodies, mechanical-to-sound relationships and shaped strikes as restored directions. The browser's 2D multi-node tree, parallel warm/bright filter architecture, chorus and convolution are not reproduced literally. Its normal wet output is not a fair dry-audio equivalence reference; judging the recovered character still needs listening.

## Verification

The build/check pipeline now replaces the obsolete all-four-engine golden mix test (which necessarily includes the old BRANCH sound) with dedicated new-BRANCH tests plus exact PCM isolation comparisons for TORT, TEMPLE and LEAD. Original golden fixture files remain untouched. Zero-Slip golden audio remains checked for the unchanged engines; BRANCH retains the full scheduler/ownership/boundary assertions but has a new sound.

Tests verify low/mid/high dry audio for Blow, Bow, Strike, Body, Wind, Rain, Ring and Motion; nonzero distinct output; stronger retained late resonance with higher Ring; six rendered examples; all-voice simultaneous operation; independent sends; original effect impulse/mode/freeze behavior; 16 LFOs; tuning and transpose; pitch/octave; SEL ownership; recording, ties, chords, gate and gradual Slip; display workers; saved-project migration; and native storage interrupted writes. Tests using the old canvas assumption now query actual canvas capacity, retaining the full 8 KiB reserve.

`regressions.log` retains the completed run. `measurements.json` records artifact hash and host stress result. Host timing is a browser/WASM measurement, not FM-1 qualification. No sound-quality claim for the unchanged instruments relies on rebaselining their PCM.
