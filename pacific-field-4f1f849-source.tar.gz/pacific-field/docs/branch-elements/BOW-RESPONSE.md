> Historical implementation record. Dates, memory projections, controls and validation claims apply to that checkpoint. See [the current audit](../audit-remediation/REPORT.md) and root README for current status.

# Bow response and primary controls

BRANCH's first edit page is now Blow / Bow / Strike / Brightness. Body moves to the first knob on the third edit page, retaining its full geometry range and saved parameter ID. No stored parameter values or patch layout change.

The previous held-note path mixed continuous breath according to strike impulse strength, even with Blow turned off. This masked the Bow contribution and made a strike setting behave like continuous excitation. That overlap is removed: explicit Blow/Wind provide breath, original Mallet provides triggered strikes, and Bow provides sustained Flow excitation plus the shared bowed body. Bow's per-note excitation coefficient rises from0.0005 to0.0025 and the shared-body output coefficient from0.12 to0.30. Original upstream DSP algorithms, capacities and sample cadence are unchanged.

The dry sustained test retains the normal Blow/Strike defaults, holds a note, waits through its attack, and measures two seconds:

| Bow | RMS |
|---|---:|
| 0 | 0.00138125 |
| 50 | 0.00560072 |
| 100 | 0.01136730 |

This verifies an increasing, substantial audible-level contribution rather than merely different samples. Subjective timbre still needs auditioning. Six existing dry examples are regenerated, including03-bow.wav. The full workstation check pipeline passes, with exact PCM isolation of TEMPLE/TORT/LEAD, original FX tests, keyboard/sequence/Slip ownership, footer/slow clocks, patch migration and native-storage interrupted writes. DSP allocation sizes remain unchanged; physical hardware is not validated.

Local build: http://127.0.0.1:8784/ . Reload to update. No deployment or hardware flash.
