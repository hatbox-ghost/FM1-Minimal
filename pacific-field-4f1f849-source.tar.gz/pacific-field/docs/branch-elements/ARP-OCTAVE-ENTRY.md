> Historical implementation record. Dates, memory projections, controls and validation claims apply to that checkpoint. See [the current audit](../audit-remediation/REPORT.md) and root README for current status.

# Arp octave entry

OCT−/OCT+ select the range for newly added notes. Existing arp notes now retain the absolute note captured at note-on. With SEL enabled, the same physical key can add independent lower and upper octave entries; pressing it again toggles only the entry at the current octave.

Each instrument has a bounded27-note arp bank and physical-key release ownership, preserving the existing note capacity. Both arp heads read the same captured bank; tempo, gate, ordering, Slip timing and global tuning/transpose remain unchanged. Releasing a physically held key after changing octaves still removes its original note. Turning SEL off clears offscreen latched entries while retaining physically held notes at their original pitches. Overlapping keyboard ranges deduplicate equal absolute pitches and keep them until the final physical owner releases. Key lights show held arp pitches within the current octave range.

Runtime context grows by320 bytes across four instruments. The8KiB pool reserve remains enforced. No serialized patch fields or engine polyphony change; startup still clears live notes. Arp rendering also replaces its former27-int local scratch array with reads from the fixed note bank.

Regression: all four instruments tested with both arp heads, mixed octaves, same-key octave additions, selective removal, physical release after OCT, overlapping pitch ownership, SEL changes while a key remains held, and the27-entry bound. The full workstation suite passes, including original effects, sequencer/Slip, memory bounds and actual native storage backend. Final capacity-guard build was additionally checked with the focused octave-entry tests. Physical FM-1 runtime remains unverified.

Local update: http://127.0.0.1:8784/ . Reload to use it. Public deployment unchanged.
