> Historical implementation record. Dates, memory projections, controls and validation claims apply to that checkpoint. See [the current audit](../audit-remediation/REPORT.md) and root README for current status.

# Footer focus and slow clock access

- Focused parameter name and large value temporarily replace the bottom control strip (LCD rows180–239), then normal readouts return after850ms. Instrument graphics remain unobscured at rows44–179. Transpose feedback uses the same strip.
- The sequencer's existing saved division IDs and audio timing remain unchanged. Knob navigation now places whole and half notes below quarter notes:1/4 →1/2 →1/1. Existing2-bar timing is still available one step slower. Fast/triplet IDs retain their original order.
- Arp whole notes now read1/1 instead of1 BAR, followed by1/2 and1/4. No arp timing, note ownership or saved format changed.
- A pixel-level test compares equal-time/equal-setting frames: body pixels match exactly while footer pixels differ, and all readouts match again after timeout.
- Measured sequencer and arp whole-note intervals are four beats (2.5seconds at96 BPM). Existing workstation/Elements checks and actual native storage backend pass.
- Updated local preview: http://127.0.0.1:8784/ . Reload to use the changes. No public deployment or hardware flash.
