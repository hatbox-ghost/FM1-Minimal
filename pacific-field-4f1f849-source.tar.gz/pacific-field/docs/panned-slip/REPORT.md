> Historical implementation record. Dates, memory projections, controls and validation claims apply to that checkpoint. See [the current audit](../audit-remediation/REPORT.md) and root README for current status.

# Slip: panned doubles with independent slower clocks

Clarifies and supersedes the inter-instrument-only behavior in `bc69a4b`. The prior build and source remain protected on `codex/pre-panned-slip-bc69a4b`.

One global SLIP 0–100 knob now creates a double of each running arp and sequence, even when just one pattern is playing. The original retains its normal clock. Its double starts aligned, runs at `1 − .032 × (SLIP/100)²`, gradually falls behind and naturally realigns. Both sides are separated in stereo with normalized levels. Zero releases doubles without restarting originals. Rate edits slew over about 50ms and never reset an active phase accumulator.

Original sequences retain their SLOOP playhead. Doubles reuse the prior proven playhead structure, separate slots52–59, independent gates/ratchets/ties and queued bank boundaries. Arps use slots38/39 with independent countdowns, gates and matching note order. Q24 fractional carries retain sub-sample clock increments even at slow divisions. Existing RANDOM order has matching independent streams on the two sides while Slip is enabled; zero retains the prior RNG path.

LEAD has a second unchanged original FMini mono instance for the double. Original and double have separate oscillators, filter/envelope state and last-note ownership. Neither steals the other side’s notes. Within each side, simultaneous arp/sequence/manual owners retain mono priority. The second instance is ordinary RAM, and its code is included in both emulator and native build lists.

No extra controls or effects. Both existing Slip access points edit the same amount. Other engines, global tuning, effects and storage remain present.

## Measurements and checks

Projected native ordinary BSS+data: 86,802 → 88,534 bytes (+1,732): 928 sequence-double bytes, 64 arp-double bytes, 740 second-FMini bytes. Native pool stays334,788. Conservative pool API remains269,724, canvas65,280, protected reserve8,192 and spare868 bytes. Project remains v19/15,664 with464 bytes spare in the native payload. Read-only native-source projection grows3,806 bytes. WASM code grows12,526 bytes. These are source/global projections and emulator sections, not a PI32v2 linker map or physical CPU/stack measurements.

`regression.log`: successful complete build/check suite, including two minutes of all four dual-head arps and four dual-head 64-step/four-note sequencers,16 LFOs, original effects and bank switching. Rendered120 audio seconds in24.12 host seconds; finite bounded output, no dropped commands or DSP faults. `host-stress.json` adds all manual/MIDI owners, six-operator envelopes, original effects and the second LEAD instance: about37.94% average host budget, peak1.57ms against a2.90ms block. Host scheduling is not a hardware guarantee.

`timing.log`: single-pattern doubles at0/10/50/100, six-minute subtle drift, cumulative phase, natural full-pattern realignment, independent chords/ties/rests, note-offs and bank boundaries. Slower local gate durations scale correctly: sequence4393/4538 and arp3857/3985 frames at base/double rate. Both arp heads retain identical UP/DOWN/UP-DOWN/RANDOM material. `octave.log` verifies both heads preserve note-octave ownership. `audio.log` verifies actual stereo output on every instrument for both arp and sequence. Original zero-Slip PCM goldens and project migration remain intact.

`temple-arp-demo.wav`: dry18-second example; first3 seconds at zero, then Slip100. It is generated with the actual workstation render path and does not modify the saved project.

The local emulator was updated at http://127.0.0.1:8784/ with backups retained. Browser inspection was blocked by automatic approval review’s usage limit; no browser workaround was attempted. Native flashing and public publishing were not performed.
