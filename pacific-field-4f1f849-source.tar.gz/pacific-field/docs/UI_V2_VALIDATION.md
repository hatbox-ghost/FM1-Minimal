> Historical implementation record; not the current build or validation guide. See [the current audit](audit-remediation/REPORT.md) and root README.

# Pacific Field V2 — validation and limits

Baseline:56cbbbb5a0fd80dcabb012f827d8b631d5955d0f, published version25. Worktree: FM1 MINIMALIST/pacific-field; branch codex/ui-redesign-v2. The previous checkout, original saved folders, SDK/toolchain and separate upstream reference repositories remain untouched.

## Passed checks

The automatic check-fx.py run builds the shared C interface/audio and original DSP adapters, then runs23 suites: V2 controls, display mirror, actual browser-worker assets, four-engine PCM identity, interface, transpose, instruments, LEAD, octave, arp Slip, contextual pages, TORT, LFO, Temple modulation, spread, SLOOP, sequencer Slip, display, SLOOP stress, original effects, send routing, project migration and combined load. The actual native storage.c backend also passes16166 interrupted-write points, capacity/CRC/object bounds, panel isolation and legacy fallback.

- All four instruments, native generators, latched chords, SLOOP/Slip lanes, original Oliverb/Clouds, global transpose and queued block boundaries match the published v25 mix bit-for-bit across256000 stereo frames. Independent reference SHA256:9fc3cea9a41c8f5e5948bf91c61c1a0429f4132884263861985103243fe77407. The actual published WASM generated this fixture; the new renderer did not generate its own expected audio.
- Original zero-Slip hashes, all seven FM configurations, actual TORT controls, original FMini priority/oscillators/ladder/contour, all16 LFOs, per-note ownership, chords, ties, recording/onsets, free take, ratchets, locks, spans, pattern boundaries, undo/redo and signed phasing pass.
- Ordered Branch/Temple/TORT/LEAD mixer knobs reach the actual layers. FX1 is Oliverb's existing send27, FX2 Clouds send24; one original instance of each remains. Actual meter getters feed the displays.
- Main voice controls and actual envelope mappings pass. No independent FM ratio/feedback, invented Branch ADSR, textural waveshaper or unsupported LEAD polyphony is introduced.
- All81 entered notes remain distinguishable in the physical framebuffer. Wide MIDI chords preserve four visible tones. Continuations stay visible after scrolling; selected cells, A and B have separate indicators. Pixel tests wait for intentional value overlays to expire rather than confusing an overlay with a missing note.
- Large-value overlays expire without stopping voices or events. GLO+key still consumes both edges and shows the resulting interval/root. Saved latch mode now matches SEL at boot; startup remains silent, the first key owns exactly its intended note and latch-off releases normally.
- Patch format stays v16/15584 bytes. The real published v15 fixture still migrates byte-for-byte across its musical payload, apart from the version word.

## Graphics/audio isolation

The browser AudioWorklet uses web_audio_boot/render and rasterizes zero frames. A separate Worker owns a WASM display mirror. It receives read-only patch/runtime snapshots, draws with the same C code as hardware, and has no input or audio ownership. Node tests execute the actual two Worker assets with real WASM and true transferable-buffer semantics. Coalescing/backpressure, startup, frame publication and return paths pass. Three snapshot buffers and two pixel buffers are allocated at startup and recycled; no unbounded message queue or per-frame large transfer-buffer allocation is introduced.

Display snapshots leave source PCM/events unchanged. C graphics allocate no heap memory per frame. Trigonometric geometry uses a small constant64-entry lookup table and fixed loop bounds. A small signature preserves unchanged header/parameter pixels on the LCD; normal animation redraws240×136 rather than the whole240×240 screen. This reduces those refresh transfers by43.3%. Native refresh is capped at20Hz and falls to10Hz when the existing platform peak-load reading exceeds85%. Actual high-load behavior still needs a board test.

Browser compilation was tested without a generated proportional-font header. The browser-only pixel path avoids that dependency. The native updater/message fonts and other firmware configurations retain their existing font path. No additional native framebuffer or long audio buffer was added.

## Budgets and measurements

Engine pool accounting remains264976 bytes. Existing canvas69120 plus conservative stack reserve8192 leaves1776 of344064 bytes. The small UI signature/overlay state lives outside the engine pool; immutable pixel glyphs and sine data are constants. These are allocation accounts, not a successful native linker map or measured stack high-water mark. Native project payload16128 leaves544 bytes after the unchanged15584-byte patch.

Combined host probe: all27 manual keys per engine, generator state, four MIDI owners per layer, A/B sequencer chords,16 active LFOs, original granular Clouds/Oliverb and repeated transpose.4.354 seconds of audio rendered with bounded finite output, zero dropped commands/FX faults and all owned gates clearing after stop. This run measured34.43% mean audio processing and1.367ms maximum block time against a2.902ms interval. These computer-specific observations do not prove FM-1 CPU headroom.

## Previews and hardware limits

The preview generator captures actual240×240 C framebuffers for HOME, all four voices, ENV, LFO, sequencer, mixer, both effects and the value overlay. The page's Screens gallery serves those PNGs, not wide concept artwork. Real browser review additionally verifies power-on, independent worker display, live values and navigation.

No physical FM-1 was flashed or tested. Native firmware linking, flash-region ownership, device CPU deadlines, stack high-water, display bandwidth and physical controls remain verification milestones. LEAD remains mono; existing wet tails preserve recorded pitch during field transpose. SLOOP's current scheduler uses the shared project BPM and forward direction; the UI labels those facts rather than presenting nonfunctional independent timing or direction controls.

Mixer follow-up: SELECT and PRESETS are verified to move through Branch / Temple / TORT / LEAD in the visible column order on all four mixer pages, forward and backward, including multi-detent moves and wraparound. The full23-suite build and native storage harness pass again after this correction.
