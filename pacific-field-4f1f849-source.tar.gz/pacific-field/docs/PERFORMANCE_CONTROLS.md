> Historical implementation record; not the current build or validation guide. See [the current audit](audit-remediation/REPORT.md) and root README.

# Pacific Field quick controls

All four instruments remain available together: Branch, TORT, Clock and mono LEAD. Turn PRESETS to choose the instrument played/edited. ALGORITHM still edits its timbre. Four LFOs per instrument, original effects and SLOOP sequencing are retained.

- HOME: four-instrument dashboard with pattern, pending pattern, play/record/armed state, position, selected instrument, root and transpose. Four knobs edit the selected instrument's displayed performance controls. Again: Project Clock (BPM, single metronome, transpose).
- GLO: Mixer LEVEL immediately. Repeat: PAN, ECHO, ROOM, LEVEL. Four knobs always map Branch / TORT / Clock / LEAD. Use physical MASTER for the complete output; its gain fades smoothly. SELECT chooses the layer for mute/solo.
- GLO + ARP: selected instrument mute. GLO + SEQ: selected instrument solo. Other instruments keep running.
- GLO + musical key: absolute project transpose. First C (C2 on the printed/browser keyboard, eighth chromatic key, keyboard octave0) means zero. G2 means +7. OCT-/+ extends the target by octaves. Each target is calculated from the original reference, never compounded. The chosen tuning supplies one multiplier for every voice, preserving just intervals and all pattern data. Releasing GLO restores normal keyboard playing; transpose remains and SAVE retains it.
- ENV: envelopes. TORT toggles filter/amp envelopes; LEAD toggles amp/filter envelopes. EDIT switches related envelope views too.
- LFO: slots1–4. Knobs Rate/Depth/Shape/Destination. EDIT: Sync/Key Sync/Phase/Slew. No phase reset from navigation.
- ARP: primary and shape pages. EDIT cycles primary, shape and existing process/Quartz controls.
- FX: existing sends and original Oliverb/Clouds controls. Repeated FX or contextual EDIT advances this family.
- EDIT from HOME: instrument voice pages. TORT opens Filter first, retaining filter-envelope amount. Branch/Clock mechanics and Quartz remain editable. EDIT from Mixer opens global tuning; again returns to LEVEL.
- SEQ: existing Notes, Pattern, Banks, Step, Rec Setup and Slip views. Four patterns per instrument, maximum64 steps, four-note chords. Tap cycles; hold SEQ plus white keys accesses the existing16-cell grid. Note tools, ties, ratchets, locks, copy/move/delete and EDIT+OCT undo/redo remain.
- PLAY: project sequence transport from every page. Stop preserves SEL-held notes. PLAY held + HOME: existing generator transport.
- REC tap: arm/start/finish recording for selected instrument. Hold400ms: freeze its process, without accidentally arming recording.
- SEL: latch selected instrument's played notes. SAVE: project save. OCT-/+: keyboard octave, plus existing sequencer note-tool gestures.
- Live fill: hold SEQ first, then GLO + ninth white key. Tenth white key queues next-bar fill. This moved to leave GLO+KEY available for transpose.

In the browser, hold a button with the mouse while playing computer keys, or Shift-click it to keep the modifier held. Click again to release. Four mixer knobs work directly; no bank switching. Existing saved projects are migrated, with transpose0 and metronomeoff. Startup remains silent.

The same C input handler and240×240 screen are shared by browser and FM-1 adapter. Physical hardware performance, flash layout ownership and native stack/CPU deadlines are not yet validated on a board. Browser CPU figures describe that computer only. LEAD remains monophonic; saved chords use last-note priority. TORT and LEAD can sound simultaneously in the browser.
