> Historical implementation record. Dates, memory projections, controls and validation claims apply to that checkpoint. See [the current audit](../audit-remediation/REPORT.md) and root README for current status.

# Four LFO pages and one shared setup

Implemented from protected `850f1a4` on `codex/simple-lfo-pages`. Local preview update only; no public deployment or native flashing.

The LFO button now cycles **LFO1 → LFO2 → LFO3 → LFO4 → Setup** on every instrument. Each main page has Rate / Depth / Destination / Shape, in the same knob order. SELECT also browses these pages in either direction.

Setup is one table for the selected instrument’s four LFOs. SELECT chooses Sync, Key Retrigger, Phase or Slew; knobs1–4 adjust that setting independently for LFOs1–4. The highlighted row, native title, browser readout and accessible control descriptions identify the current setting. There is no per-LFO configuration page in the cycle, and TORT no longer inserts its extra routing page between each LFO.

Existing configuration fields, extra-route DSP and saved payload bytes remain supported. Their old internal page IDs remain interpretable for existing control/test adapters, but are not included in physical-button or SELECT browsing. Existing startup normalization still starts modulation depths/destinations off; that policy is unchanged. No synthesis algorithm, LFO waveform, destination, phase progression or audio routing was changed by this navigation refactor.

New UI page68 uses the existing storage schema/version20. Project size remains15,664 bytes, with464 bytes spare in the guarded16,128-byte native payload. No audio buffers, per-voice state or pool allocations were added. The selected setup row uses one UI byte, and its host display snapshot fits into existing padding beside the9-byte navigation state.

## Validation

`regression.log` records the complete successful automatic build/check run, including all synth engines, native storage cut-point tests, original effects/whole-note delay, per-instrument panned Slip, silent startup, all engine sound goldens and two-minute maximum-pattern audio stress.

`preservation.log` additionally compares the actual prior unchanged binary with this build: active modulation across all four engines,16 LFOs and TORT’s extra signed routes matches sample-for-sample while browsing the new pages. Every LFO phase matches; no audio fixture was regenerated. New tests check all four instruments’ five-page cycles, reversible SELECT, every setup row/knob, save/reboot and unchanged project size. A separate display-mirror test verifies that the selected Phase row and45-degree value survive snapshot transfer into the actual framebuffer renderer.

`lfo.png` and `setup.png` are the actual240×240 C framebuffer, rendered offline. The main animated waveform remains intact, and Setup displays all four LFO columns together.

Browser script syntax checks pass. Live browser inspection was not attempted because automatic approval review previously blocked browser access due to a usage limit; these are firmware-renderer and automated audio checks, not a claim of live browser verification.

The existing local preview at http://127.0.0.1:8784/ is updated with matching binary, worklet and HTML. Refresh to load it. Previous served files are retained separately and saved browser project storage was not reset.

Verified emulator SHA-256: `122d6af35eadc64f04b2b19e7ab7156b8246428be67a74c0e86a39e623d895b5`.
