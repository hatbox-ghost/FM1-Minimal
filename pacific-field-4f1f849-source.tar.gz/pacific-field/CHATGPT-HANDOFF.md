# Pacific Field — current source handoff

Saved November 3, 2026. Audited code baseline: Git commit `9ee5413` on `codex/audit-remediation`. This handoff adds documentation only. Read this file first after extracting the ZIP.

Current follow-up: HOLD / SHIFT input cleanup on `codex/hold-shift-cleanup`. Read `docs/hold-shift/REPORT.md` for the final button map and new validation; its test suite brings the current inventory to 51 independent suites. The audit results below remain the earlier 50-suite checkpoint. No synthesis/FX/sequence playback algorithms changed.

## What this is

Pacific Field is an FM-1 workstation with four simultaneous instruments: BRANCH (Elements-derived physical system), TEMPLE (clock-mechanical FM), TORT (OberVave) and FMini LEAD. It includes the SLOOP-derived sequencer, arps, independent Slip doubles, LFOs, original Clouds and Oliverb, and shared C graphics/navigation. The browser preview uses the same DSP/UI source through WASM.

This ZIP contains the actual current source, tests, licenses, immutable audio reference binaries and their complete corresponding source. It is not just a screenshot or an analysis report. Git history and generated build products are omitted. The app can be built from these files.

## Start here

- `README.md`: current project overview and commands.
- `fm1/BUILDING.md`: browser and native build instructions.
- `docs/audit-remediation/REPORT.md`: original findings, causes, fixes, tests and remaining native blockers.
- `docs/audit-remediation/validation-full.json`: 50 independent passing suites with full-duration soaks.
- `docs/audit-remediation/validation-source-export.json`: 50 passing suites from an extracted archive without Git (explicit shorter CI soaks).
- `NOTICE.md` and `LICENSE`: actual source licensing and upstream attribution.
- `SOURCE-MANIFEST.json`: SHA-256 manifest for the exported files.

## Where the working implementation lives

- `fm1/pacific/engine.c`: instrument/routing/modulation runtime.
- `fm1/pacific/app.c`, `navigation.h`, `ui-v2.h`: interface and controls.
- `fm1/pacific/block_seq.h`: current sequencer integration.
- `fm1/pacific/fx.c`, `clouds-port.cc`, `oliverb-port.cc`: original shared effects.
- `fm1/pacific/branch-elements.cc`: BRANCH physical system adapter.
- `fm1/pacific/obervave-*.inc`, `tort.h`: TORT integration.
- `fm1/pacific/temple-fm.h`: TEMPLE FM system.
- `fm1/pacific/lead.c`, `fmini-core.inc`: FMini LEAD.
- `fm1/pacific/upstream/`: selected upstream implementations, pins and notices.
- `fm1/web/emu/`: browser assets; `fm1/pacific/web.c` is the browser bridge.
- `fm1/tools/build.py`, `fm1/firmware/`: native PI32v2 build and platform.

## Verification status

All 50 independent suites passed the full validation gate: 49 JavaScript suites and one C storage suite. Aliases/helpers are not counted again. The source export separately compiled and passed all 50 suites with the declared CI soak duration. The rebuilt browser WASM was byte-identical to the pre-audit binary.

The historical PCM fixture was NOT re-baselined. Its mismatch was traced to prior authorized BRANCH, OberVave and Slip changes. Both old and current epochs have separate frozen reference binaries and corresponding source; both reference source rebuilds reproduce their PCM. Recording-onset failures came from obsolete harness mappings/schema; new coverage includes held notes/chords crossing loop boundaries. Minimum six independently sounding TEMPLE notes are tested.

Native firmware is NOT fully linked or hardware validated. The target is JieLi AC79 PI32v2, not ARM. Native build source selection and C prototype/include problems were corrected. Remaining blockers are missing compatible target C++ standard-library headers for original DSP and unresolved freestanding string functions (`strlen`, `strcmp`, `strcpy`). Target C object measurements exist, but complete linked RAM/flash totals, real stack headroom and hardware CPU/audio behavior remain unavailable. Do not turn browser timings into hardware claims or call the incomplete diagnostic map a complete linker map.

## Build from this ZIP

Prerequisites: Python 3.12+, Emscripten 6.0.13, Node 24.19.0 and a host C compiler. From the extracted `pacific-field` directory:

```sh
EMCC=emcc NODE=node python3 fm1/pacific/check-fx.py --profile full
python3 tools/stage-browser.py build/browser
python3 -m http.server --directory build/browser 8784
```

`--profile ci` explicitly reduces the LFO/sequencer audio soaks from 1,800/600 seconds to 120 seconds each. No external reference checkout or Git history is required. Generated reports go under `fm1/build/validation/`. SDK and native compiler binaries are external prerequisites and are not bundled.

## Preservation requirements for further work

Keep BRANCH, TEMPLE, OberVave TORT and FMini LEAD. Preserve TEMPLE's minimum six-note polyphony. Preserve the current sound, navigation, controls, parameter mappings, graphical behavior and original effects unless the user specifically authorizes a change or a demonstrated bug requires correction. Do not silently re-baseline audio tests, bypass storage/memory guards, substitute simplified DSP or remove an engine to make memory fit.

The audit has been saved. Ask the user which next change they want before treating this handoff as a request to implement a new feature. If continuing native work, address the actual native headers/runtime/link issues and report evidence honestly. Historical reports elsewhere in `docs/` describe older checkpoints and do not override the current source or this audit.
