# Building Pacific Field

Run commands from the repository root. The current browser and firmware implementations share `fm1/pacific/` DSP and UI sources.

## Browser and validation

Prerequisites: Python 3.12+, Emscripten 6.0.13, Node 24.19.0, host clang/cc. Put `emcc`, its matching `em++`, and `node` on PATH, or set `EMCC`, `EMXX`, `NODE`, `HOST_CC`.

```sh
EMCC=emcc NODE=node python3 fm1/pacific/check-fx.py --profile full
python3 tools/stage-browser.py build/browser
python3 -m http.server --directory build/browser 8784
```

`fm1/tools/suite_gate.sh` invokes the same strict gate. `--profile ci` is a declared shorter soak. `--only SUITE` is a filtered diagnostic, not a complete validation pass. Missing references, compilation errors, test failures and timeouts return nonzero. See `fm1/pacific/validation-suites.json` for the exhaustive inventory and timeout budgets. The full-buffer Clouds comparison is compiled from the same source with its explicit reference configuration, not borrowed from a stale distribution.

Validation does not need Pillow or any external reference checkout. Pinned audio oracles and their corresponding source are in `references/`.

## Native PI32v2 target

Use the JieLi Linux x86-64 toolchain (`pi32v2/` and `common/`), the AC79 SDK identified by the checksums in `fm1/tools/build.py`, Python with Pillow, and Docker on macOS. The native compiler is a different compiler from Emscripten.

```sh
export JIELI_TOOLCHAIN=/path/to/jieli-linux-toolchain
export AC79_SDK=/path/to/AC79-SDK
PACIFIC_FIELD=1 python3 fm1/tools/build.py
```

`PACIFIC_FIELD=1` selects this workstation instead of the retained legacy application. Outputs include `fm1/build/amb.elf`, `amb.map`, `amb.dis`, `amb.bin`, loader and package. The build checks storage ownership, section limits, soft-double helpers and an 8 KiB minimum pool reserve. Never bypass these checks to make a package.

On macOS the Linux VM must expose the source directory writable and the toolchain read-only. Set `DOCKER_HOST` for the running VM. If Pillow lacks libraqm, the inherited `EN_FONT_NORAQM=1` fallback is available; it changes legacy font metrics and must be declared when comparing build sizes. It is not a reason to change Pacific Field's graphics or ship a newly generated font silently.

A successful target link is not hardware audio validation. Stack guard allocation is measurable from the linker; actual stack high-water usage and maximum combined CPU load require a real FM-1 run.

## Complete source export

```sh
python3 tools/make-source-archive.py build/pacific-field-source.tar.gz
```

The sorted archive has normalized timestamps/ownership and an embedded SHA-256 file manifest. Extract it, enter its `pacific-field` directory, then run the gate above. No `.git`, personal paths or prior build directory is needed. Reference rebuilds use `tools/rebuild-reference.py` with either `historical-ui` or `current-ui`.
