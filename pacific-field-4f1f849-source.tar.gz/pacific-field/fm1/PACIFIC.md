# Pacific Field

The current project is described in [the root README](../README.md), [build guide](BUILDING.md), [licensing inventory](../NOTICE.md) and [audit report](../docs/audit-remediation/REPORT.md).

The earlier three-instrument Albion/Clock document was superseded by BRANCH Elements, OberVave TORT, TEMPLE, FMini LEAD and the current SLOOP sequencer. Its obsolete page map and build instructions have been removed; the Git history retains the original design record. No runtime control or sound was changed by this documentation correction.
