// Translate a desired saved engine ID into physical detents for the visible selector.
// V2 mixer columns differ from the preserved saved-slot / other-page order.
export function modeDelta(e,target){const page=e.web_page(),order=e.web_visual_snapshot&&(page===7||(page>=49&&page<=51))?[0,2,1,3]:[0,1,2,3];return(order.indexOf(target)-order.indexOf(e.web_mode())+4)%4;}

// Inject a persisted legacy SLOOP step without relying on the retired editor.
export function legacyStep(e,m,step,notes,{bank=0,type=0,flags=0,ratchet=0,micro=0,velocity=100,gate=0,force=0}={}){
 const bytes=Uint8Array.from([0,0,0,0,velocity,gate,notes.length,type,flags,force,ratchet,micro]);bytes.set(notes);
 const data=new DataView(bytes.buffer);
 for(let i=0;i<3;i++)if(!e.web_seq_post(m,20000+(bank*64+step)*3+i,data.getInt32(i*4,true)))throw new Error('legacy test command dropped');
}
