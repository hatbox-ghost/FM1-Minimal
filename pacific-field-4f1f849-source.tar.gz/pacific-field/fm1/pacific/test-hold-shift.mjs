// Real panel gestures: HOLD ownership, consumed SHIFT, timing, saving and undo.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import { modeDelta } from './test-panel-order.mjs';
const B = { FX:0, SEL:1, ENV:2, GLO:5, SAVE:7, ARP:8, SEQ:9, REC:11 };
const bit = b => 1 << b;
let cases = 0;
async function boot() {
  const {instance:{exports:e}} = await WebAssembly.instantiate(fs.readFileSync(process.argv[2]), {
    wasi_snapshot_preview1:new Proxy({}, {get:()=>()=>0}), env:new Proxy({}, {get:()=>()=>0})
  });
  e._initialize(); e.web_audio_boot();
  const run = (frames=128) => {
    for (let n=0;n<frames;n+=128) e.web_audio_render(Math.min(128,frames-n));
    assert.equal(e.web_dropped(),0); assert.equal(e.web_fx_faults(),0);
  };
  const buttons = mask => { e.web_buttons(mask); run(); };
  const tap = b => { buttons(bit(b)); buttons(0); };
  const turn = (role,n=1) => { e.web_enc(role,n); run(); };
  const keys = mask => { e.web_keys(mask); run(); };
  const select = m => turn(2,modeDelta(e,m));
  run();
  return {e,run,buttons,tap,turn,keys,select};
}

// Tap opens/cycles GLOBALS; an unused sustained hold must not navigate on release.
{
  const a=await boot(),{e}=a; e.web_open_page(0);
  a.buttons(bit(B.GLO)); assert.equal(e.web_page(),0);
  a.buttons(0); assert.equal(e.web_page(),48);
  for (const page of [5,53,48]) { a.tap(B.GLO); assert.equal(e.web_page(),page); }
  for (const page of [0,7,32,38,5]) {
    e.web_open_page(page); a.buttons(bit(B.GLO)); a.run(44100/2);
    a.buttons(0); assert.equal(e.web_page(),page,'unused long GLO hold must not open GLOBALS'); cases++;
  }
}

// A final encoder detent may be polled in the same input frame as GLO release.
{
  const a=await boot(),{e}=a; e.web_open_page(6); a.buttons(bit(B.GLO));
  e.web_enc(6,1); e.web_buttons(0); a.run();
  assert.equal(e.web_page(),6,'release-frame timing detent consumes SHIFT');
  assert.equal(e.web_delay_sync_enabled(),1); cases++;
}

// GLO transpose consumes only newly pressed shortcut keys, regardless of release order.
for (let m=0;m<4;m++) for (const latch of [false,true]) for (const globalFirst of [false,true]) {
  const a=await boot(),{e}=a; a.select(m); e.web_open_page(0);
  if (latch) a.tap(B.SEL);
  a.keys(bit(7)|bit(11)); const sounding=e.web_layer_active(m);
  a.buttons(bit(B.GLO)); a.keys(bit(7)|bit(11)|bit(14));
  assert.equal(e.web_transpose(),7); assert.equal(e.web_layer_active(m),sounding);
  if (globalFirst) { a.buttons(0); a.keys(bit(7)|bit(11)); }
  else { a.keys(bit(7)|bit(11)); a.buttons(0); }
  assert.equal(e.web_page(),0,'transpose release must not navigate');
  assert.equal(e.web_param(23),+latch); assert.equal(e.web_layer_active(m),sounding);
  a.keys(0); if (latch) { assert(e.web_lit_buttons()&bit(B.SEL)); a.tap(B.SEL); }
  assert.equal(e.web_layer_active(m),0,'held physical and latched owners release cleanly'); cases++;
}

// SEL is always HOLD, including the obsolete FX+SEL chord and SHIFT+SEL.
for (let m=0;m<4;m++) for (const modifier of [0,bit(B.FX),bit(B.GLO),bit(B.SEQ)]) {
  const a=await boot(),{e}=a; a.select(m); e.web_open_page(0); a.keys(bit(7));
  a.buttons(modifier); const sync=e.web_delay_sync_enabled();
  a.buttons(modifier|bit(B.SEL)); assert.equal(e.web_param(23),1);
  assert(e.web_lit_buttons()&bit(B.SEL)); a.buttons(modifier); a.buttons(0); a.keys(0);
  assert.equal(e.web_layer_active(m),bit(7)); assert.equal(e.web_delay_sync_enabled(),sync);
  a.tap(B.SEL); assert.equal(e.web_param(23),0); assert.equal(e.web_layer_active(m),0);
  assert.equal(e.web_lit_buttons()&bit(B.SEL),0); cases++;
}

// All encoder interactions consume SHIFT but preserve their normal context behavior.
for (let role=0;role<7;role++) {
  const a=await boot(),{e}=a; e.web_open_page(0);
  a.buttons(bit(B.GLO)); a.turn(role); const page=e.web_page();
  a.buttons(0); assert.equal(e.web_page(),page,`encoder ${role} consumes GLO`); cases++;
}
for (const button of [0,1,2,3,4,6,7,8,9,10,11,12,13]) {
  const a=await boot(),{e}=a; e.web_open_page(0);
  a.buttons(bit(B.GLO)); a.buttons(bit(B.GLO)|bit(button)); a.buttons(bit(B.GLO));
  const page=e.web_page(); a.buttons(0); assert.equal(e.web_page(),page,`button ${button} consumes GLO`); cases++;
}

// Existing mute/solo and SEQ-first global fill/alternate gestures do not open GLOBALS.
for (let m=0;m<4;m++) {
  const a=await boot(),{e}=a; a.select(m); e.web_open_page(0);
  for (const [button,read] of [[B.ARP,()=>e.web_layer_mute(m)],[B.SEQ,()=>e.web_layer_solo(m)]]) {
    for (const expected of [1,0]) {
      a.buttons(bit(B.GLO)); a.buttons(bit(B.GLO)|bit(button)); a.buttons(bit(B.GLO)); a.buttons(0);
      assert.equal(read(),expected); assert.equal(e.web_page(),0);
    }
  }
  for (const key of [14,16]) { // ninth/tenth SLOOP white keys
    a.buttons(bit(B.SEQ)); a.buttons(bit(B.SEQ)|bit(B.GLO)); a.keys(bit(key));
    a.buttons(bit(B.SEQ)); assert.equal(e.web_page(),0,'global grid shortcut consumes GLO');
    a.keys(0); a.buttons(0); assert.equal(e.web_page(),0);
  }
  assert.equal(e.web_layer_mute(m),0); assert.equal(e.web_layer_solo(m),0); cases++;
}

// Both delay-time locations, both ARP knobs and SEQ timing knob.
for (let m=0;m<4;m++) for (const [page,role,read] of [
  [6,6,e=>e.web_delay_sync_enabled()], [38,3,e=>e.web_delay_sync_enabled()],
  [8,4,e=>e.web_arp_sync(m)], [8,5,e=>e.web_arp_sync(m)],
  [32,3,e=>e.web_seq_sync(m)]
]) {
  const a=await boot(),{e}=a; a.select(m); e.web_open_page(0); a.tap(B.SEL); a.keys(bit(7)); a.keys(0);
  e.web_open_page(page); const original=read(e),held=e.web_layer_active(m);
  for (const expected of [1-original,original]) {
    a.buttons(bit(B.GLO)); a.turn(role); a.turn(role,3); a.turn(role,-2);
    assert.equal(read(e),expected,'one FREE/SYNC toggle per GLO gesture');
    a.buttons(0); assert.equal(e.web_page(),page); assert.equal(e.web_layer_active(m),held);
    assert.equal(e.web_param(23),1); assert(e.web_lit_buttons()&bit(B.SEL));
  }
  a.tap(B.SEL); assert.equal(e.web_layer_active(m),0); cases++;
}

// Opening Projects does not write or affect recording. Confirming saves once.
for (const active of [false,true]) for (const shift of [false,true]) {
  const a=await boot(),{e}=a; e.web_open_page(40); if (active) { a.tap(B.REC); a.keys(bit(7)); }
  const recording=e.web_seq_state(0,8),armed=e.web_seq_state(0,9),writes=e.web_store_writes();
  a.buttons(shift?bit(B.GLO):0); a.buttons(bit(B.SAVE)|(shift?bit(B.GLO):0));
  assert.equal(e.web_store_writes(),writes,'opening Projects does not write');
  a.buttons(shift?bit(B.GLO):0); a.buttons(1<<4);
  assert.equal(e.web_store_writes(),writes+1,'EDIT confirms the save');
  a.run(44100/2); assert.equal(e.web_store_writes(),writes+1);
  a.buttons(0);
  assert.equal(e.web_page(),40); assert.equal(e.web_seq_state(0,8),recording); assert.equal(e.web_seq_state(0,9),armed);
  assert.equal(e.web_store_len(0),15772); a.keys(0); cases++;
}

// Recording undo is available without using SEL or SAVE.
{
 const a=await boot(),{e}=a;e.web_open_page(40);a.tap(B.REC);a.keys(bit(7));a.keys(0);a.tap(B.REC);
 assert.equal(e.web_clip_event(0,0,-1,0),1);const writes=e.web_store_writes();
 a.buttons(bit(B.GLO)|bit(B.REC));a.buttons(0);
 assert.equal(e.web_clip_event(0,0,-1,0),-1);assert.equal(e.web_param(23),0);assert.equal(e.web_store_writes(),writes);cases++;
}
console.log(JSON.stringify({pass:true,cases,engines:4,holdOnly:true,shiftConsumed:true,savePreserved:true,undoSeparate:true}));
