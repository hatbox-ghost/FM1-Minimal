// Physical panel and clock paths: long held notes, quantization, overdub and undo.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {modeDelta} from './test-panel-order.mjs';
const wasm=fs.readFileSync(process.argv[2]), stub=new Proxy({},{get:()=>()=>0});
const beat=44100*60/96, B={GLO:5,SEQ:9,PLAY:10,REC:11};
async function boot(){
 const {instance:{exports:e}}=await WebAssembly.instantiate(wasm,{wasi_snapshot_preview1:stub,env:stub});
 e._initialize();e.web_audio_boot();
 const tick=(n=128)=>e.web_phase_test_run(n), render=()=>e.web_audio_render(128);
 const tap=b=>{e.web_buttons(1<<b);e.web_buttons(0);tick();};
 const turn=(k,d)=>{e.web_enc(k,d);e.web_buttons(0);tick();};
 const keys=k=>{e.web_keys(k);tick();};
 const state=(m,f)=>e.web_seq_state(m,f),ev=(m,i,f=0,bank=0)=>e.web_clip_event(m,bank,i,f);
 render();return {e,tick,render,tap,turn,keys,state,ev};
}
for(let m=0;m<4;m++){
 const {e,tick,render,tap,turn,keys,state,ev}=await boot();
 turn(2,modeDelta(e,m));assert.equal(e.web_mode(),m);
 for(const p of [32,40,33,32]){tap(B.SEQ);assert.equal(e.web_page(),p);}
 turn(4,-99);assert.equal(state(m,7),1);
 tap(B.SEQ);turn(3,-10);assert.equal(state(m,26),0);
 keys(1<<7);keys(0);assert.equal(ev(m,-1),-1,'unarmed keyboard does not edit');
 tap(B.PLAY);tap(B.REC);assert.equal(state(m,8),1);
 const loop=beat/4;
 tick(Math.floor(loop*.8));keys((1<<7)|(1<<11));
 assert.equal(ev(m,-1),2);assert.equal(ev(m,0,1),0);
 tick(Math.floor(loop*3.2));assert.equal(ev(m,-1),2,'hold never adds another onset');
 keys(1<<11);tick(1024);keys(0);
 assert.equal(ev(m,0,2),60);assert.equal(ev(m,1,2),64);
 assert(ev(m,0,1)>3*16384);assert(ev(m,1,1)>ev(m,0,1));
 tap(B.REC);assert.equal(state(m,8),0);assert.equal(state(m,3),1);
 const original=[0,1].map(i=>[0,1,2,3].map(f=>ev(m,i,f)));
 tap(B.PLAY);assert.equal(state(m,11),0);tap(B.PLAY);
 let budget=loop*2;while(!state(m,11)&&budget>0){render();budget-=128;}
 assert(budget>0,'recorded chord plays through audio render path');
 const attacks=state(m,10);assert.equal(state(m,6),2);
 tick(Math.floor(loop*2.7));assert.equal(state(m,10),attacks,'no retrigger while the chord still sustains');
 tick(Math.floor(loop*.8));assert.equal(state(m,11),0,'scheduled note offs survive wrap');
 tap(B.REC);keys(1<<9);tick(1024);keys(0);tap(B.REC);assert.equal(ev(m,-1),3);
 const other=(m+1)%4,before=e.web_phase_state(2*other+1,1);
 e.web_buttons((1<<B.GLO)|(1<<B.REC));e.web_buttons(0);tick();
 assert.equal(ev(m,-1),2);assert.deepEqual([0,1].map(i=>[0,1,2,3].map(f=>ev(m,i,f))),original);
 assert(e.web_phase_state(2*other+1,1)>before);assert.equal(e.web_dropped(),0);
}
for(const division of [0,2]){
 const {e,tick,tap,turn,keys,state,ev}=await boot();
 tap(B.SEQ);if(division===0)turn(3,-2);
 tap(B.SEQ);assert.equal(state(0,26),3);
 tap(B.PLAY);tap(B.REC);
 tick(Math.floor(beat*.16));keys(1<<7);tick(Math.floor(beat*.40));keys(0);tap(B.REC);
 const loopBeats=(division===0?1:.25)*16;
 assert(Math.abs(ev(0,0)*loopBeats/16384-.25)<.001);
 assert(Math.abs(ev(0,0,1)*loopBeats/16384-.40)<.01);
}
{
 const {e,tick,render,tap,turn,keys,state,ev}=await boot();
 tap(B.SEQ);turn(4,-99);tap(B.SEQ);turn(5,1);
 assert.equal(state(0,13),1);tap(B.PLAY);tap(B.REC);
 assert.equal(state(0,15),4);assert.equal(state(0,8),0);assert.equal(state(0,3),1);
 keys(1<<7);tick(Math.floor(beat*4));assert.equal(state(0,8),1);
 keys(0);assert.equal(ev(0,-1),1);assert(ev(0,0,1)>0);
 tap(B.REC);tap(B.SEQ);const u=e.web_phase_state(1,1),other=e.web_phase_state(3,1);
 turn(4,1);assert.equal(state(0,1),1);assert.equal(state(0,0),0);
 tick(Math.ceil(beat/4));assert.equal(state(0,0),1);assert.equal(state(0,1),-1);
 assert(e.web_phase_state(1,1)<u);assert(e.web_phase_state(3,1)>other);
 tap(B.SEQ);const sync=state(0,5),phase=e.web_phase_state(1,1);
 e.web_buttons(1<<B.GLO);e.web_enc(3,1);e.web_buttons(1<<B.GLO);e.web_buttons(0);render();
 assert.equal(state(0,5),1-sync);assert(e.web_phase_state(1,1)>phase);assert.equal(e.web_page(),32);
}
console.log(JSON.stringify({pass:true,engines:4,heldWraps:3,quantizeDivisions:2,overdubUndo:true,clipQueue:true,liveCountIn:true}));
{
 const {e,tap,turn,render,state}=await boot();
 tap(B.SEQ);tap(B.SEQ);turn(5,1);
 const clicks=e.web_metronome_clicks();assert.equal(e.web_metronome(),0);tap(B.REC);
 let peak=0;for(let f=0;f<beat*4+128;f+=128){
  render();for(const x of new Float32Array(e.memory.buffer,e.web_out_l(),128))peak=Math.max(peak,Math.abs(x));
 }
 assert(peak>.0001,'count-in reaches actual audio output with metronome disabled');
 assert.equal(e.web_metronome_clicks()-clicks,4);assert.equal(state(0,8),1);assert.equal(e.web_metronome(),0);
 tap(B.REC);assert.equal(state(0,3),1);
}
{
 const {e,tick,render,tap,turn,keys,state,ev}=await boot();
 turn(2,modeDelta(e,2));tap(B.SEQ);tap(B.SEQ);turn(3,-10);
 tap(B.REC);keys(0x3f<<7);tick(4096);keys(0);tap(B.REC);
 assert.equal(ev(2,-1),6);
 tap(B.PLAY);tap(B.PLAY);render();assert.equal(state(2,6),6,'TEMPLE retains six sequenced gates');tap(B.PLAY);
 assert.equal(state(2,11),0);
}
{
 const {e,tick,tap,turn,keys,state,ev}=await boot();
 e.web_seq_post(0,10002,97);tick();
 tap(B.SEQ);turn(4,-99);tap(B.SEQ);tap(B.PLAY);tap(B.REC);
 keys(1<<7);tick(1200);keys(0);tap(B.REC);
 assert.equal(ev(0,0,0),0);
 tick(6900);
 assert.equal(state(0,10),1,'a quantized tick-zero onset fires at the first wrap even if it falls between samples');
}

// A free-running raw take can be snapped later without altering gate duration or clock mode.
{
 const {e,tick,tap,turn,keys,state,ev}=await boot();
 tap(B.SEQ);turn(4,-99);
 e.web_buttons(1<<B.GLO);e.web_enc(3,1);e.web_buttons(1<<B.GLO);e.web_buttons(0);tick();
 assert.equal(state(0,5),0);
 tap(B.SEQ);turn(3,-10);
 tap(B.PLAY);tap(B.REC);tick(Math.floor(beat*.09));
 keys(1<<7);tick(Math.floor(beat*.04));keys(0);
 tap(B.REC);tap(B.PLAY);
 const take=[0,1,2,3].map(f=>ev(0,0,f));
 assert(take[0]>4096&&take[0]<8192);
 turn(3,4); // 1/32, one eighth of a beat.
 e.web_buttons(1<<B.GLO);e.web_enc(3,1);e.web_buttons(1<<B.GLO);e.web_buttons(0);tick();
 assert.deepEqual([0,1,2,3].map(f=>ev(0,0,f)),[8192,...take.slice(1)]);
 assert.equal(state(0,5),0,'snapping leaves the transport in FREE');
 // An empty pass and a repeat snap on already aligned notes preserve the undo.
 tap(B.PLAY);tap(B.REC);tick(1000);tap(B.REC);tap(B.PLAY);
 e.web_buttons(1<<B.GLO);e.web_enc(3,1);e.web_buttons(1<<B.GLO);e.web_buttons(0);tick();
 tap(B.SEQ);turn(4,1);assert.equal(state(0,0),1);
 e.web_buttons(1<<B.GLO);e.web_buttons((1<<B.GLO)|(1<<B.REC));e.web_buttons(0);tick();
 assert.deepEqual([0,1,2,3].map(f=>ev(0,0,f)),take);
 assert.equal(state(0,0),1,'undo restores the edited clip without changing selection');
}
