/* SPDX-License-Identifier: GPL-3.0-only
 * Event clips reuse the 768 step bytes; legacy step patterns remain readable. */
#pragma once
#define PF_CLIP_TICKS 16384u
#define PF_CLIP_MAX_EVENTS 127u
typedef struct {uint16_t time,duration;uint8_t note,velocity;} PFClipEvent;
_Static_assert(sizeof(PFClipEvent)==6,"clip event packing");
static inline int pf_clip_events(const PFSeqPattern *p){return !!(p->length&128);}
static inline int pf_clip_length(const PFSeqPattern *p){return pf_clip_events(p)?(p->length&63)+1:p->length;}
static inline void pf_clip_length_set(PFSeqPattern *p,int n){p->length=pf_clip_events(p)?128|(n-1):n;}
static inline unsigned pf_clip_count(const PFSeqPattern *p){return pf_clip_events(p)?((const uint8_t*)p->steps)[4]:0;}
static inline PFClipEvent pf_clip_event(const PFSeqPattern *p,unsigned i){PFClipEvent e={0};if(i<PF_CLIP_MAX_EVENTS)memcpy(&e,(const uint8_t*)p->steps+6*(i+1),6);return e;}
static inline void pf_clip_event_set(PFSeqPattern *p,unsigned i,PFClipEvent e){if(i<PF_CLIP_MAX_EVENTS)memcpy((uint8_t*)p->steps+6*(i+1),&e,6);}
static inline void pf_clip_init(PFSeqPattern *p,int len){memset(p->steps,0,sizeof p->steps);p->length=128|(len-1);uint8_t *h=(uint8_t*)p->steps;h[0]='P';h[1]='F';h[5]=1;}
static inline uint32_t pf_clip_duration(uint16_t d){return d<32768?d:(2048u+(d&2047u))<<(((d>>11)&15u)+4);}
static inline uint16_t pf_clip_duration_pack(uint64_t ticks){if(!ticks)return 1;if(ticks<32768)return ticks;unsigned shift=4;while((ticks>>shift)>4095&&shift<19)shift++;unsigned mantissa=ticks>>shift;if(mantissa>4095)mantissa=4095;return 32768|((shift-4)<<11)|(mantissa-2048);}
static inline int pf_clip_base_gate(const PFSeqPattern*p){unsigned x=((const uint8_t*)p->steps)[2];return x&&x<=128?x:128;}
static inline void pf_clip_save_clean(PFSeqPattern*p){if(!pf_clip_events(p))return;unsigned count=0;for(unsigned i=0;i<pf_clip_count(p);i++){PFClipEvent e=pf_clip_event(p,i);if(!e.duration)continue;e.velocity&=127;pf_clip_event_set(p,count++,e);}((uint8_t*)p->steps)[4]=count;for(unsigned i=count;i<PF_CLIP_MAX_EVENTS;i++)pf_clip_event_set(p,i,(PFClipEvent){0});}
static inline int pf_clip_valid(const PFSeqPattern *p){const uint8_t*h=(const uint8_t*)p->steps;return !pf_clip_events(p)||(!(p->length&64)&&h[0]=='P'&&h[1]=='F'&&h[5]==1&&h[4]<=127);}
static inline int pf_clip_has_notes(const PFSeqPattern*p){if(pf_clip_events(p))return pf_clip_count(p)>0;for(int i=0;i<p->length&&i<64;i++)if(p->steps[i].type==0&&p->steps[i].count)return 1;return 0;}
#define PF_REC_QUANT_SHIFT 12
#define PF_REC_QUANT_MASK 0x7000u
#define PF_REC_QUANT(p) (((p).seqReserved>>PF_REC_QUANT_SHIFT)&7u)
