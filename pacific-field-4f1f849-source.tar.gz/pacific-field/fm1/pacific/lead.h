/* SPDX-License-Identifier: GPL-3.0-only */
#pragma once
#include <stdint.h>
void pf_lead_init(void);
void pf_lead_patch(int index,int value);
void pf_lead_bend(int bend);
void pf_lead_wheel(int value);
void pf_lead_event(int slot);
float pf_lead_sample(const float *hz,const float *level,const uint8_t *gates,const float *parameters,float pitchMod,float amplitudeMod,float modulation,float transpose,const float *oscFine);
uint32_t pf_lead_bytes(void);
uint32_t pf_lead_pool_bytes(void);
float pf_lead_frequency(void);
int pf_lead_slot(void);
uint32_t pf_lead_key_age(int key);
