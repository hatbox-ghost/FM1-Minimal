/* SPDX-License-Identifier: GPL-3.0-only
 * UI-only navigation. Patch page IDs remain stable; screen families never share
 * button meanings. No audio state, allocations or persistent patch additions. */
enum { NAV_MIXER, NAV_EDIT, NAV_ENV, NAV_LFO, NAV_FX, NAV_GLOBAL, NAV_SEQ, NAV_ARP };
typedef struct { uint8_t screen,edit,env,lfo,fx,global,mix,seq,arp; } PFNavigation;
static PFNavigation nav;
static const uint8_t global_order[]={PF_PROJECT,5,PF_SYSTEM};
static const uint8_t fx_order[]={6,35,36,37,38};
static const uint8_t seq_order[]={32,40,33};
static int nav_index(const uint8_t *order,int count,int page){for(int i=0;i<count;i++)if(order[i]==page)return i;return 0;}
static int nav_wrap(int value,int count){return (value%count+count)%count;}
static int nav_lfo_count(void){return 5;}
static int nav_env_count(void){return pf_ui.mode==PF_TORT||pf_ui.mode==PF_LEAD||pf_ui.mode==PF_CLOCK?2:1;}
static int nav_env_page(int index){return pf_ui.mode==PF_TORT?23+index:pf_ui.mode==PF_CLOCK?(index?65:1):index?45:1;}
/* Import a saved/debug page or a sequencer gesture at the UI boundary only. */
static void nav_adopt(void){
 int p=pf_ui.page;if(p==31||p==34||p==41)p=pf_ui.page=32;if(p==39){pf_ui.page=p=38;fxRows[1]=1;}
 if(p==PF_HOME){p=pf_ui.page=7;} /* old overview projects open the mixer */
 if(mixer_page()){nav.screen=NAV_MIXER;nav.mix=mixer_index();}
 else if(p==PF_PROJECT||p==5||p==PF_SYSTEM){nav.screen=NAV_GLOBAL;nav.global=nav_index(global_order,3,p);}
 else if(p==66&&pf_ui.mode==PF_CLOCK){nav.screen=NAV_ENV;nav.edit=nav_wrap(nav.edit,6);}
 else if(p==1||p==23||p==24||p==45||(p==65&&pf_ui.mode==PF_CLOCK)){nav.screen=NAV_ENV;nav.env=p==24||p==45||p==65;}
 else if(pf_lfo_page()){nav.screen=NAV_LFO;nav.lfo=p==PF_LFO_SETUP?4:p>=54?p-54:(p-10)/2;}
 else if(fx_page()||p==6){nav.screen=NAV_FX;nav.fx=nav_index(fx_order,5,p);}
 else if(seq_page()){nav.screen=NAV_SEQ;nav.seq=nav_index(seq_order,3,p);}
 else if(p==8||p==9){nav.screen=NAV_ARP;nav.arp=p-8;}
 else if(temple_deep()){nav.screen=NAV_EDIT;nav.edit=nav_wrap(nav.edit,6);}
 else {nav.screen=NAV_EDIT;nav.edit=nav_index(voice_order(),pf_voice_page_count(),p);}
 arpContext=nav.screen==NAV_ARP;
}
static void nav_show(int screen,int index){
 nav.screen=screen;arpContext=screen==NAV_ARP;
 switch(screen){
 case NAV_MIXER:nav.mix=nav_wrap(index,4);pf_ui.page=nav.mix?PF_MIX_PAN+nav.mix-1:7;break;
 case NAV_EDIT:nav.edit=nav_wrap(index,pf_voice_page_count());pf_ui.page=voice_order()[nav.edit];break;
 case NAV_ENV:nav.env=nav_wrap(index,nav_env_count());pf_ui.page=nav_env_page(nav.env);break;
 case NAV_LFO:nav.lfo=nav_wrap(index,nav_lfo_count());pf_ui.page=nav.lfo==4?PF_LFO_SETUP:10+2*nav.lfo;break;
 case NAV_FX:nav.fx=nav_wrap(index,5);pf_ui.page=fx_order[nav.fx];break;
 case NAV_GLOBAL:nav.global=nav_wrap(index,3);pf_ui.page=global_order[nav.global];break;
 case NAV_SEQ:nav.seq=nav_wrap(index,3);pf_ui.page=seq_order[nav.seq];break;
 case NAV_ARP:nav.arp=nav_wrap(index,2);pf_ui.page=8+nav.arp;break;
 }
 ui_overlay_until=0;pf_dirty=1;
}
static void nav_button(int button){
 switch(button){
 case B_HOME:nav_show(NAV_MIXER,nav.screen==NAV_MIXER?nav.mix+1:0);break;
 case B_GLO:nav_show(NAV_GLOBAL,nav.screen==NAV_GLOBAL?nav.global+1:0);break;
 case B_EDIT:nav_show(NAV_EDIT,nav.screen==NAV_EDIT?nav.edit+1:0);break;
 case B_ENV:if(pf_ui.mode==PF_CLOCK&&pf_ui.page==59){pf_ui.page=66;nav.screen=NAV_ENV;ui_overlay_until=0;pf_dirty=1;break;}if(pf_ui.mode==PF_CLOCK&&pf_ui.page==66){nav_show(NAV_ENV,0);break;}nav_show(NAV_ENV,nav.screen==NAV_ENV?nav.env+1:0);break;
 case B_LFO:nav_show(NAV_LFO,nav.screen==NAV_LFO?nav.lfo+1:0);break;
 case B_FX:nav_show(NAV_FX,nav.screen==NAV_FX?nav.fx+1:0);break;
 case B_SEQ:nav_show(NAV_SEQ,nav.screen==NAV_SEQ?nav.seq+1:0);break;
 case B_ARP:nav_show(NAV_ARP,nav.screen==NAV_ARP?nav.arp+1:0);break;
 }
}
static int pf_page_count(void){if(temple_deep())return (pf_ui.page==59||pf_ui.page==66)?6:1;switch(nav.screen){case NAV_MIXER:return 4;case NAV_EDIT:return pf_voice_page_count();case NAV_ENV:return nav_env_count();case NAV_LFO:return nav_lfo_count();case NAV_FX:return 5;case NAV_SEQ:return 3;case NAV_GLOBAL:return 3;default:return 2;}}
static int pf_page_position(void){if(temple_deep())return (pf_ui.page==59||pf_ui.page==66)?nav.edit+1:1;switch(nav.screen){case NAV_MIXER:return nav.mix+1;case NAV_EDIT:return nav.edit+1;case NAV_ENV:return nav.env+1;case NAV_LFO:return nav.lfo+1;case NAV_FX:return nav.fx+1;case NAV_GLOBAL:return nav.global+1;case NAV_SEQ:return nav.seq+1;default:return nav.arp+1;}}
static uint32_t nav_led(void){return 1u<<(const int[]){B_HOME,B_EDIT,B_ENV,B_LFO,B_FX,B_GLO,B_SEQ,B_ARP}[nav.screen];}
