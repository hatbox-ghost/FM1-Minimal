import {modeDelta} from './test-panel-order.mjs';
import fs from 'node:fs';import assert from 'node:assert/strict';
const {instance:{exports:e}}=await WebAssembly.instantiate(fs.readFileSync(process.argv[2]),{wasi_snapshot_preview1:new Proxy({},{get:()=>()=>0}),env:new Proxy({},{get:()=>()=>0})});e._initialize();e.web_boot();
function run(seconds=.03){let peak=0;for(let i=0;i<Math.ceil(seconds*44100/128);i++){e.web_render(128);for(let p of [e.web_out_l(),e.web_out_r()])for(let x of new Float32Array(e.memory.buffer,p,128)){assert(Number.isFinite(x));peak=Math.max(peak,Math.abs(x));}}return peak;}
const tap=b=>{e.web_buttons(1<<b);e.web_buttons(0);run();};const turn=(r,d)=>{e.web_enc(r,d);run();};
run();e.web_open_page(33);tap(10);assert.equal(run(4),0,'Empty patterns must remain silent: no automatically started drone');for(let m=0;m<4;m++){assert.equal(e.web_seq_state(m,3),1);assert(e.web_seq_events(m)>0);assert.equal(e.web_layer_active(m),0);}assert.equal(e.web_clock_frequency(0),0);assert.equal(e.web_clock_frequency(1),0);
turn(2,(4-e.web_mode())%4);e.web_keys(1<<7);e.web_keys(0);run();assert.equal(e.web_layer_active(0),0,'PLAY must not latch a manual tap');tap(1);e.web_keys(1<<7);e.web_keys(0);run();assert.equal(e.web_layer_active(0),1<<7);
tap(10);for(let m=0;m<4;m++)assert.equal(e.web_seq_state(m,3),0);assert.equal(e.web_layer_active(0),1<<7,'seq stop must preserve explicit SEL drone');tap(10);assert.equal(e.web_layer_active(0),1<<7);tap(1);assert.equal(e.web_layer_active(0),0);assert.equal(e.web_dropped(),0);
// Note Mix belongs to the sequence transport too.
tap(10);e.web_open_page(4);tap(10);assert.equal(e.web_clock_frequency(0),0);assert.equal(e.web_seq_state(0,3),1);
console.log('PASS: SEQ PLAY runs four enabled lanes silently when empty, starts no Branch/Clock drones, never latches notes, preserves SEL-held notes on stop/restart; Note Mix uses the same transport.');
