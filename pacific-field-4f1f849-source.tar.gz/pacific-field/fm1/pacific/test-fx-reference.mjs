import {setFx} from './test-fx-controls.mjs';
import fs from 'node:fs';import assert from 'node:assert/strict';
async function boot(path){const {instance:{exports:e}}=await WebAssembly.instantiate(fs.readFileSync(path),{wasi_snapshot_preview1:new Proxy({},{get:()=>()=>0}),env:new Proxy({},{get:()=>()=>0})});e._initialize();e.web_boot();e.web_render(128);return e;}
const actual=await boot(process.argv[2]),reference=await boot(process.argv[3]);
function set(e,i,value){setFx(e,i,value,()=>e.web_render(128));}
for(let mode=0;mode<3;mode++){for(const e of [actual,reference]){set(e,9,mode);set(e,11,mode===2?-7:7);set(e,16,25);e.web_fx_reset();}for(let j=0;j<1600;j++){for(const e of [actual,reference]){if(j===900)set(e,14,1);e.web_fx_probe(0,128,j<800?1:0);}for(const f of ['web_out_l','web_out_r'])assert.deepEqual(new Float32Array(actual.memory.buffer,actual[f](),128),new Float32Array(reference.memory.buffer,reference[f](),128));}}
assert.equal(actual.web_fx_faults(),0);assert.equal(reference.web_fx_faults(),0);console.log('PASS: reduced workspace is sample-identical to full original allocation in delay, granular, WSOLA, pitch and freeze; zero DSP faults.');
