/* SPDX-License-Identifier: GPL-3.0-only */
#include <stdint.h>
#include <string.h>
#ifndef EN_HOST
#define EN_HOST
#endif
#include "pacific.h"
#include "lead.h"
#include "fx.h"
static uint32_t lastBlitY,lastBlitH;
static uint16_t fb[240*240];static uint32_t blits,now,buttons,keys,master=2200,litb,litk,writes;
static int32_t enc[NE];static uint8_t store[PF_STORE_MAX];static int storelen=-1;
static void lcd_sync(void){}
static void lcd_blit(uint32_t x,uint32_t y,uint32_t w,uint32_t h,const uint16_t *px){lastBlitY=y;lastBlitH=h;for(uint32_t j=0;j<h;j++)for(uint32_t i=0;i<w;i++)if(x+i<240&&y+j<240)fb[(y+j)*240+x+i]=px[j*w+i];blits++;}
static void lcd_fill(uint32_t x,uint32_t y,uint32_t w,uint32_t h,uint16_t c){for(uint32_t j=y;j<y+h&&j<240;j++)for(uint32_t i=x;i<x+w&&i<240;i++)fb[j*240+i]=c;blits++;}
#define PF_PIXEL_UI 1
#include "../firmware/src/gfx.c"
uint32_t plat_ms(void){return now;}uint32_t plat_buttons(void){return buttons;}uint32_t plat_keys(void){return keys;}int32_t plat_enc(int r){int d=enc[r];enc[r]=0;return d;}uint32_t plat_master(void){return master;}void plat_leds(uint32_t b,uint32_t k){litb=b;litk=k;}void plat_glow(int on){(void)on;}void plat_play_red(int on){(void)on;}
int plat_store_load(uint32_t obj,void *dst,uint32_t max){if(obj||storelen<0||(uint32_t)storelen>max)return -1;memcpy(dst,store,storelen);return storelen;}
int plat_store_save(uint32_t obj,const void *src,uint32_t len){if(obj||len>PF_STORE_MAX)return -1;memcpy(store,src,len);storelen=len;writes++;return 0;}
static uint32_t midiQueue[64],mw,mr;
int plat_midi_in(uint32_t *p){if(mr==mw)return 0;*p=midiQueue[mr++%64];return 1;}void plat_midi_out(uint32_t p){(void)p;}
uint32_t plat_cpu_pct(void){return 0;}uint32_t plat_xruns(void){return 0;}uint32_t plat_cpu_peak(void){return 0;}int32_t plat_battery(void){return -1;}int plat_usb_power(void){return 1;}
/* Browser-only display mirror. The audio instance never rasterizes a frame.
 * A separate Worker owns a second WASM instance for drawing read-only snapshots.
 * This host bridge is not linked into native FM-1 firmware. */
typedef struct {
 uint32_t serial,time,buttons,keys,transport,processTransport,savedUntil,overlayUntil,transposeUntil;
 int overlayKnob,overlayPage,overlayMode,arpContext,saveFailed;
 pf_patch patch;
 uint8_t navigation[9],lfoRow,fxRows[2],instrumentOrder[4];
 uint8_t picker,choice,swapPending,swapFailed;
 uint8_t projectMenu,projectExists,projectAction,projectConfirm;
 uint32_t active[4],lit[4],running[4],play[4],freeze[4];
 float fxMeter[4],cutoff[2],templeMotion,templeDrift;float leadHz;float meter[4],frequency[4][27],phase[4][4],lfo[4][4];
 int seq[4][27],slip[4][15];
} PFVisualPacket;
static PFVisualPacket visualPacket;
static int visualMirror;
static uint32_t visualSerial;
static uint32_t visual_active(int m){return visualMirror?visualPacket.active[m]:pf_layer_active(m);}
static uint32_t visual_lit(int m){return visualMirror?visualPacket.lit[m]:pf_layer_lit(m);}
static uint32_t visual_running(int m){return visualMirror?visualPacket.running[m]:pf_layer_running(m);}
static float visual_meter(int m){return visualMirror?visualPacket.meter[m]:pf_layer_meter(m);}
static float visual_fx_meter(int f){return visualMirror?visualPacket.fxMeter[f]:pf_fx_meter(f);}
static float visual_lead_frequency(void){return visualMirror?visualPacket.leadHz:pf_lead_frequency();}
static float visual_frequency(int m,int k){return visualMirror?visualPacket.frequency[m][k]:pf_voice_current_frequency(m,k);}
static float visual_phase(int m,int k){return visualMirror?visualPacket.phase[m][k]:pf_lfo_phase(m,k);}
static float visual_lfo(int m,int k){return visualMirror?visualPacket.lfo[m][k]:pf_lfo_output(m,k);}
static int visual_seq(int m,int f){return visualMirror?visualPacket.seq[m][f]:pf_seq_state(m,f);}
static int visual_slip(int m,int f){return visualMirror?visualPacket.slip[m][f]:pf_seq_slip_state(m,f);}
static float visual_cutoff(int m){return visualMirror?visualPacket.cutoff[m==PF_LEAD]:pf_visual_cutoff(m);}
static float visual_temple_motion(void){return visualMirror?visualPacket.templeMotion:pf_clock_macro();}
static float visual_temple_drift(void){return visualMirror?visualPacket.templeDrift:pf_clock_quartz();}
#define pf_clock_quartz visual_temple_drift
#define pf_visual_cutoff visual_cutoff
#define pf_clock_macro visual_temple_motion
#define pf_layer_active visual_active
#define pf_layer_lit visual_lit
#define pf_layer_running visual_running
#define pf_layer_meter visual_meter
#define pf_fx_meter visual_fx_meter
#define pf_lead_frequency visual_lead_frequency
#define pf_voice_current_frequency visual_frequency
#define pf_lfo_phase visual_phase
#define pf_lfo_output visual_lfo
#define pf_seq_state visual_seq
#define pf_seq_slip_state visual_slip
static int recallPending;
static void project_recall(void){recallPending=1;}
#include "app.c"
_Static_assert(sizeof nav==sizeof visualPacket.navigation,"visual navigation layout");
#undef pf_visual_cutoff
#undef pf_clock_macro
#undef pf_clock_quartz
#undef pf_layer_active
#undef pf_layer_lit
#undef pf_layer_running
#undef pf_layer_meter
#undef pf_fx_meter
#undef pf_lead_frequency
#undef pf_voice_current_frequency
#undef pf_lfo_phase
#undef pf_lfo_output
#undef pf_seq_state
#undef pf_seq_slip_state

#define EXPORT __attribute__((used,visibility("default")))
static float outl[1024],outr[1024],msfrac;
EXPORT float *web_out_l(void){return outl;}EXPORT float *web_out_r(void){return outr;}
EXPORT void web_boot(void){visualMirror=0;pf_init();pf_load();pf_apply();pf_app_init();pf_app_frame();}
static void web_recall(void){
 if(!recallPending)return;
 recallPending=0;
 pf_init();pf_load();pf_apply();pf_app_init();
 pf_oldbuttons=buttons;pf_oldkeys=keys;
}
EXPORT void web_render(uint32_t n){if(n>1024)n=1024;pf_app_input();web_recall();pf_render(outl,outr,n,(float)master/4096.f*1.8f);msfrac+=n*1000.f/PF_SR;uint32_t dt=(uint32_t)msfrac;msfrac-=dt;now+=dt;if(now%32<dt)pf_app_frame();}
EXPORT void web_audio_boot(void){visualMirror=0;pf_init();pf_load();pf_apply();pf_app_init();pf_app_input();}
EXPORT void web_audio_render(uint32_t n){if(n>1024)n=1024;pf_app_input();web_recall();pf_render(outl,outr,n,(float)master/4096.f*1.8f);msfrac+=n*1000.f/PF_SR;uint32_t dt=(uint32_t)msfrac;msfrac-=dt;now+=dt;}
EXPORT uint32_t web_visual_size(void){return sizeof visualPacket;}
EXPORT uint8_t *web_visual_buffer(void){return (uint8_t*)&visualPacket;}
EXPORT uint8_t *web_visual_snapshot(void){
 PFVisualPacket *q=&visualPacket;q->serial=++visualSerial;q->time=now;q->buttons=buttons;q->keys=keys;q->transport=pf_transport;q->processTransport=pf_process_transport;q->savedUntil=pf_saved_until;q->saveFailed=saveFailed;q->patch=pf_ui;q->leadHz=pf_lead_frequency();q->cutoff[0]=pf_visual_cutoff(PF_TORT);q->cutoff[1]=pf_visual_cutoff(PF_LEAD);q->templeMotion=pf_clock_macro();q->templeDrift=pf_clock_quartz();
 memcpy(q->instrumentOrder,ui_order,sizeof ui_order);q->picker=instrumentPicker;q->choice=instrumentChoice;q->swapPending=instrumentSwapPending;q->swapFailed=instrumentSwapFailed;
 q->projectMenu=hardwareProjectMenu;q->projectExists=hardwareProjectExists;q->projectAction=hardwareProjectAction;q->projectConfirm=hardwareProjectConfirm;
 memcpy(q->navigation,&nav,sizeof nav);q->lfoRow=lfoConfigRow;memcpy(q->fxRows,fxRows,2);for(int f=0;f<4;f++)q->fxMeter[f]=pf_fx_meter(f);q->overlayUntil=ui_overlay_until;q->transposeUntil=ui_transpose_until;q->overlayKnob=ui_overlay_knob;q->overlayPage=ui_overlay_page;q->overlayMode=ui_overlay_mode;q->arpContext=arpContext;
 memcpy(q->play,layer_play,sizeof q->play);memcpy(q->freeze,layer_freeze,sizeof q->freeze);
 for(int m=0;m<4;m++){q->active[m]=pf_layer_active(m);q->lit[m]=pf_layer_lit(m);q->running[m]=pf_layer_running(m);q->meter[m]=pf_layer_meter(m);for(int k=0;k<27;k++)q->frequency[m][k]=pf_voice_current_frequency(m,k);for(int k=0;k<4;k++){q->phase[m][k]=pf_lfo_phase(m,k);q->lfo[m][k]=pf_lfo_output(m,k);}for(int f=0;f<27;f++)q->seq[m][f]=pf_seq_state(m,f);for(int f=0;f<15;f++)q->slip[m][f]=pf_seq_slip_state(m,f);}
 return (uint8_t*)q;
}
EXPORT int web_visual_draw(uint32_t size){
 if(size!=sizeof visualPacket)return 0;PFVisualPacket *q=&visualPacket;visualMirror=1;pf_ui=q->patch;now=q->time;buttons=q->buttons;keys=q->keys;pf_transport=q->transport;pf_process_transport=q->processTransport;pf_saved_until=q->savedUntil;saveFailed=q->saveFailed;
 memcpy(ui_order,q->instrumentOrder,sizeof ui_order);instrumentPicker=q->picker;instrumentChoice=q->choice;instrumentSwapPending=q->swapPending;instrumentSwapFailed=q->swapFailed;
 hardwareProjectMenu=q->projectMenu;hardwareProjectExists=q->projectExists;hardwareProjectAction=q->projectAction;hardwareProjectConfirm=q->projectConfirm;
 memcpy(&nav,q->navigation,sizeof nav);lfoConfigRow=q->lfoRow;memcpy(fxRows,q->fxRows,2);ui_overlay_until=q->overlayUntil;ui_transpose_until=q->transposeUntil;ui_overlay_knob=q->overlayKnob;ui_overlay_page=q->overlayPage;ui_overlay_mode=q->overlayMode;arpContext=q->arpContext;
 memcpy(layer_play,q->play,sizeof q->play);memcpy(layer_freeze,q->freeze,sizeof q->freeze);
 pf_draw();return q->serial;
}
EXPORT void web_buttons(uint32_t m){buttons=m;pf_app_input();}EXPORT void web_keys(uint32_t m){keys=m;pf_app_input();}EXPORT void web_enc(int role,int32_t n){if(role>=0&&role<NE)enc[role]+=n;}EXPORT void web_master(uint32_t v){master=v>4096?4096:v;}
EXPORT uint32_t web_lit_buttons(void){return litb;}EXPORT uint32_t web_lit_keys(void){return litk;}EXPORT uint16_t *web_fb(void){return fb;}EXPORT uint32_t web_blits(void){return blits;}EXPORT uint32_t web_now(void){return now;}EXPORT uint32_t web_cpu(void){return 0;}
EXPORT int web_save_project(void){return pf_save();}
EXPORT uint8_t *web_store(uint32_t obj){return store;}EXPORT int web_store_len(uint32_t obj){return obj?-1:storelen;}EXPORT void web_store_set_len(uint32_t obj,int n){if(!obj)storelen=n<0?-1:n>PF_STORE_MAX?PF_STORE_MAX:n;}EXPORT uint32_t web_store_writes(void){return writes;}EXPORT uint32_t web_nobj(void){return 1;}EXPORT uint32_t web_store_max(void){return PF_STORE_MAX;}
static uint8_t sx[64];EXPORT uint8_t *web_said_buf(void){return sx;}EXPORT uint32_t web_said_len(void){return 0;}EXPORT void web_said_clear(void){}EXPORT uint8_t *web_sysex_buf(void){return sx;}EXPORT void web_sysex(uint32_t n){(void)n;}
EXPORT void web_midi(uint32_t packet){if(mw-mr<64)midiQueue[mw++%64]=packet;}
EXPORT int web_mode(void){return pf_ui.mode;}EXPORT int web_page(void){return pf_ui.page;}EXPORT int web_selected(void){return pf_ui.selected;}EXPORT int web_param(int i){return i>=0&&i<PF_NPAR?PF_PAR(pf_ui,pf_ui.mode)[i]:0;}EXPORT uint32_t web_active(void){return pf_active;}EXPORT float web_peak(void){return pf_peak;}EXPORT uint32_t web_running(void){return pf_running;}EXPORT uint32_t web_dropped(void){return pf_dropped;}
EXPORT const char *web_label(int i){int knob=i-pf_ui.page*4;return knob>=0&&knob<4?pf_control_label(knob):"";}
EXPORT const char *web_value(int knob){static char values[4][32];if(knob<0||knob>3)return "";pf_control_value(knob,values[knob]);return values[knob];}
EXPORT float web_note_hz(int key){return pf_hz(key,PF_PAR(pf_ui,pf_ui.mode),pf_ui.octave,0);}
EXPORT uint32_t web_layer_active(int m){return pf_layer_active(m);}
EXPORT uint32_t web_layer_running(int m){return pf_layer_running(m);}
EXPORT int web_layer_level(int m){return m>=0&&m<PF_LAYERS?PF_PAR(pf_ui,m)[7]:0;}
EXPORT uint32_t web_pool_bytes(void){return pf_pool_bytes();}
EXPORT uint32_t web_clock_step(void){return pf_clock_step;}

EXPORT int web_layer_mute(int m){return m>=0&&m<PF_LAYERS?PF_MUTE(pf_ui,m):0;}
EXPORT int web_layer_solo(int m){return m>=0&&m<PF_LAYERS?PF_SOLO(pf_ui,m):0;}
EXPORT int web_layer_pan(int m){return m>=0&&m<PF_LAYERS?PF_MIXPAN(pf_ui,m):0;}
EXPORT float web_layer_meter(int m){return pf_layer_meter(m);}
EXPORT float web_voice_frequency(int m,int key){return pf_voice_frequency(m,key);}
EXPORT uint32_t web_transport(void){return pf_transport;}

EXPORT int web_arp_setting(int m,int i){return m>=0&&m<PF_LAYERS&&i>=0&&i<8?PF_ARPSETTINGS(pf_ui,m)[i]:0;}
EXPORT uint32_t web_arp_events(int m,int h){return pf_arp_events(m,h);}
EXPORT uint32_t web_arp_last(int m,int h){return pf_arp_last(m,h);}

EXPORT int web_page_position(void){return pf_page_position();}
EXPORT int web_page_count(void){return pf_page_count();}

EXPORT int web_lfo_setting(int m,int slot,int field){return m>=0&&m<PF_LAYERS&&slot>=0&&slot<4&&field>=0&&field<8?PF_LFO(pf_ui,m)[slot][field]:0;}
EXPORT float web_lfo_phase(int m,int slot){return pf_lfo_phase(m,slot);}
EXPORT float web_lfo_output(int m,int slot){return pf_lfo_output(m,slot);}
EXPORT int web_patch_bytes(void){return sizeof(pf_patch);}
EXPORT void web_open_page(int page){if(page>=0&&page<PF_PAGES){pf_ui.page=page;nav_adopt();pf_dirty=1;}}

EXPORT float web_lfo_sample(int shape,float phase,float held){return pf_lfo_sample(shape,phase,held);}
EXPORT float web_lfo_effective(int m,int parameter){return pf_lfo_effective(m,parameter);}
EXPORT uint32_t web_lfo_cycles(int m,int slot){return pf_lfo_cycles(m,slot);}

EXPORT int web_tort_param(int i){return i>=0&&i<56?pf_ui.tort[i]:0;}

EXPORT int web_lfo_config(int m,int slot,int field){return pf_lfo_config(m,slot,field);}

EXPORT float web_clock_macro(void){return pf_clock_macro();}
EXPORT float web_clock_quartz(void){return pf_clock_quartz();}

EXPORT float web_clock_frequency(int voice){return pf_clock_frequency(voice);}

EXPORT int web_voice_spread(int m){return m>=0&&m<PF_LAYERS?PF_SPREAD(pf_ui,m):0;}

EXPORT int web_seq_state(int m,int f){return pf_seq_state(m,f);}
EXPORT uint32_t web_seq_events(int m){return pf_seq_events(m);}
EXPORT uint32_t web_seq_last(int m){return pf_seq_last(m);}
EXPORT int web_seq_post(int m,int a,int b){pf_post(PF_MODE,m,0);int result=pf_post(PF_SEQ,a,b);pf_post(PF_MODE,pf_ui.mode,0);return result;}
EXPORT int web_seq_step(int m,int p,int st,int field){if(m<0||m>=PF_LAYERS||p<0||p>3||st<0||st>63||field<0||field>11)return -1;return ((uint8_t*)&PF_SEQ(pf_ui,m).pattern[p].steps[st])[field];}

EXPORT int web_fx_setting(int i){return i>=0&&i<20?pf_ui.fx[i]:0;}
EXPORT void web_fx_reset(void){pf_fx_init();}
EXPORT void web_fx_probe(int effect,int n,int impulse){if(n>1024)n=1024;for(int i=0;i<n;i++){float v=impulse&&i==0?.25f:0;pf_fx_frame(effect==0?v:0,effect==0?v:0,effect==1?v:0,effect==1?v:0,&outl[i],&outr[i]);}}
EXPORT uint32_t web_fx_bytes(void){return pf_fx_bytes();}

EXPORT uint32_t web_fx_faults(void){return pf_fx_faults();}


EXPORT int web_seq_slip_setting(int m,int field){return m>=0&&m<PF_LAYERS&&field>=0&&field<4?PF_SEQSLIP(pf_ui,m)[field]:0;}
EXPORT int web_seq_slip_state(int m,int field){return pf_seq_slip_state(m,field);}

EXPORT float web_voice_current_frequency(int m,int key){return pf_voice_current_frequency(m,key);}

#include "lead.h"
#include "fx.h"
EXPORT float web_lead_frequency(void){return pf_lead_frequency();}
EXPORT int web_lead_slot(void){return pf_lead_slot();}
EXPORT int web_lead_param(int i){return i>=0&&i<32?pf_ui.lead.mini[i]:0;}

EXPORT int web_master_gain(void){return pf_ui.masterGain;}
EXPORT int web_transpose(void){return pf_ui.transpose;}
EXPORT int web_metronome(void){return pf_ui.metronome;}

EXPORT uint32_t web_metronome_clicks(void){return pf_metronome_clicks();}

EXPORT float web_transpose_ratio(void){return pf_transpose_ratio();}

EXPORT uint32_t web_last_blit_y(void){return lastBlitY;}
EXPORT uint32_t web_last_blit_h(void){return lastBlitH;}

EXPORT int web_nav_screen(void){return nav.screen;}
EXPORT int web_nav_bytes(void){return sizeof nav;}

EXPORT void web_delay_sync(int on){delay_set_sync(on);}
EXPORT int web_delay_sync_enabled(void){return delay_sync_on();}
EXPORT int web_delay_division(void){return pf_delay_div(pf_ui.seqReserved);}
EXPORT int web_delay_effective_division(void){return pf_delay_fit_div(pf_ui.seqBpm,pf_delay_div(pf_ui.seqReserved));}
EXPORT float web_delay_time_ms(void){return pf_delay_sync_ms(pf_fx_bpm,pf_fx_delay_division);}

__attribute__((used,visibility("default"))) uint32_t web_canvas_bytes(void){return sizeof cv_px;}

EXPORT int web_arp_note(int m,int index){return pf_arp_note(m,index);}
EXPORT float web_arp_frequency(int m,int head){return pf_arp_frequency(m,head);}

extern uint32_t pf_tort_voice_bytes(void);
extern int pf_tort_voice_state(int,int);
EXPORT int web_tort_voice_bytes(void){return pf_tort_voice_bytes();}
EXPORT int web_tort_voice_state(int i,int f){return pf_tort_voice_state(i,f);}
EXPORT int web_tort_route(int slot,int field){return slot>=0&&slot<4&&field>=0&&field<4?pf_ui.tortRoutes[slot][field]:0;}

EXPORT int web_temple_param(int i){return i>=0&&i<PF_TEMPLE_BYTES?pf_ui.temple[i]:0;}
extern int pf_temple_runtime(int);
EXPORT int web_temple_runtime(int i){return pf_temple_runtime(i);}

extern float pf_temple_env(int,int);
EXPORT float web_temple_env(int slot,int field){return pf_temple_env(slot,field);}

EXPORT int web_temple_operator(void){return temple_deep()?nav.edit%6:-1;}

extern float pf_temple_operator_env(int,int,int);
EXPORT float web_temple_operator_env(int slot,int op,int field){return pf_temple_operator_env(slot,op,field);}

extern void pf_phase_test_run(uint32_t);extern double pf_phase_test_state(int,int);
EXPORT void web_phase_test_run(uint32_t frames){pf_phase_test_run(frames);}
EXPORT double web_phase_state(int id,int field){return pf_phase_test_state(id,field);}
EXPORT int web_global_slip(void){return PF_INSTRUMENT_SLIP(pf_ui,pf_ui.mode);}

EXPORT int web_instrument_slip(int m){return m>=0&&m<PF_LAYERS?PF_INSTRUMENT_SLIP(pf_ui,m):0;}

EXPORT uint32_t web_lead_double_calls(void){return 0;}

EXPORT int web_lfo_setup_row(void){return lfoConfigRow;}

EXPORT float web_fx_meter(int i){return pf_fx_meter(i);}
EXPORT int web_fx_row(void){return pf_ui.page==36?fxRows[0]:pf_ui.page==38?fxRows[1]:0;}
EXPORT int web_arp_sync(int m){return m>=0&&m<4?PF_ARP_SYNC(pf_ui,m):0;}
EXPORT int web_seq_sync(int m){return m>=0&&m<4?PF_SEQ(pf_ui,m).sync:0;}
EXPORT int web_seq_free_bpm(int m){return m>=0&&m<4?PF_SEQ(pf_ui,m).bpm:0;}

EXPORT int web_clip_event(int m,int bank,int index,int field){return pf_clip_event_state(m,bank,index,field);}
