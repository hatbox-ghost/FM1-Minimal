/* SPDX-License-Identifier: GPL-3.0-only
 * Pacific Field V2. Original bounded pixel geometry; no heap, DSP or audio writes.
 * All coordinates are physical LCD pixels. A 120-row canvas is reused twice. */
#include "../firmware/src/dsp/fastmath.h"
#include "lead.h"
#include "upstream/fm-lab/algorithms.h"
static int ui_band;static uint32_t ui_last_stamp;static int ui_have_frame;
#define UI_INK RGB(244,237,218)
#define UI_DIM RGB(135,132,129)
#define UI_FAINT RGB(37,36,39)
#define UI_CORAL RGB(255,145,119)
#define UI_LAVENDER RGB(184,165,237)
#define UI_LAVENDER_DIM RGB(117,95,172)
#define UI_YELLOW RGB(233,237,121)
static uint16_t ui_color(int m){return m==PF_BRANCH?UI_CORAL:m==PF_CLOCK?UI_INK:m==PF_TORT?UI_LAVENDER:UI_YELLOW;}
static void ur(int x,int y,int w,int h,uint16_t c){cv_rect(x,y-ui_band,w,h,c);}
static void ul(int x,int y,int xx,int yy,uint16_t c){cv_line(x,y-ui_band,xx,yy-ui_band,c);}
static void ub(int x,int y,int w,int h,uint16_t c){ul(x,y,x+w-1,y,c);ul(x,y+h-1,x+w-1,y+h-1,c);ul(x,y,x,y+h-1,c);ul(x+w-1,y,x+w-1,y+h-1,c);}
typedef struct {char c;uint8_t r[7];} UiGlyph;
/* Compact original 5x7 pixel alphabet. Unsupported characters are visibly '?'. */
static const UiGlyph ui_glyphs[]={
 {'A',{14,17,17,31,17,17,17}},{'B',{30,17,17,30,17,17,30}},{'C',{14,17,16,16,16,17,14}},{'D',{30,17,17,17,17,17,30}},
 {'E',{31,16,16,30,16,16,31}},{'F',{31,16,16,30,16,16,16}},{'G',{14,17,16,23,17,17,15}},{'H',{17,17,17,31,17,17,17}},
 {'I',{14,4,4,4,4,4,14}},{'J',{7,2,2,2,18,18,12}},{'K',{17,18,20,24,20,18,17}},{'L',{16,16,16,16,16,16,31}},
 {'M',{17,27,21,21,17,17,17}},{'N',{17,25,25,21,19,19,17}},{'O',{14,17,17,17,17,17,14}},{'P',{30,17,17,30,16,16,16}},
 {'Q',{14,17,17,17,21,18,13}},{'R',{30,17,17,30,20,18,17}},{'S',{15,16,16,14,1,1,30}},{'T',{31,4,4,4,4,4,4}},
 {'U',{17,17,17,17,17,17,14}},{'V',{17,17,17,17,17,10,4}},{'W',{17,17,17,21,21,21,10}},{'X',{17,17,10,4,10,17,17}},
 {'Y',{17,17,10,4,4,4,4}},{'Z',{31,1,2,4,8,16,31}},
 {'0',{14,17,19,21,25,17,14}},{'1',{4,12,4,4,4,4,14}},{'2',{14,17,1,2,4,8,31}},{'3',{30,1,1,14,1,1,30}},
 {'4',{2,6,10,18,31,2,2}},{'5',{31,16,16,30,1,1,30}},{'6',{14,16,16,30,17,17,14}},{'7',{31,1,2,4,8,8,8}},
 {'8',{14,17,17,14,17,17,14}},{'9',{14,17,17,15,1,1,14}},
 {'-',{0,0,0,31,0,0,0}},{'+',{0,4,4,31,4,4,0}},{'.',{0,0,0,0,0,6,6}},{':',{0,6,6,0,6,6,0}},
 {'/',{1,2,2,4,8,8,16}},{'%',{17,2,4,4,8,16,17}},{'#',{10,10,31,10,31,10,10}},
 {'>',{16,8,4,2,4,8,16}},{'<',{1,2,4,8,4,2,1}},{'=',{0,0,31,0,31,0,0}},{'?',{14,17,1,2,4,0,4}}
};
static int uw(const char *s,int scale){return (int)strlen(s)*6*scale-scale;}
static void ut(int x,int y,const char *s,int scale,uint16_t c){for(;*s;s++,x+=6*scale){char ch=*s;if(ch==' ')continue;if(ch>='a'&&ch<='z')ch-=32;const uint8_t *r=ui_glyphs[sizeof(ui_glyphs)/sizeof(ui_glyphs[0])-1].r;for(unsigned j=0;j<sizeof(ui_glyphs)/sizeof(ui_glyphs[0]);j++)if(ui_glyphs[j].c==ch){r=ui_glyphs[j].r;break;}for(int yy=0;yy<7;yy++)for(int xx=0;xx<5;xx++)if(r[yy]&(16>>xx))ur(x+xx*scale,y+yy*scale,scale,scale,c);}}
static void uc(int x,int y,const char *s,int scale,uint16_t c){ut(x-uw(s,scale)/2,y,s,scale,c);}
static const int16_t ui_sine[64]={0,3212,6393,9512,12539,15446,18204,20787,23170,25329,27245,28898,30273,31356,32137,32609,32767,32609,32137,31356,30273,28898,27245,25329,23170,20787,18204,15446,12539,9512,6393,3212,0,-3212,-6393,-9512,-12539,-15446,-18204,-20787,-23170,-25329,-27245,-28898,-30273,-31356,-32137,-32609,-32767,-32609,-32137,-31356,-30273,-28898,-27245,-25329,-23170,-20787,-18204,-15446,-12539,-9512,-6393,-3212};
static float us(float turns){float p=turns*64;int i=(int)p;float f=p-i;if(f<0){i--;f++;}return (ui_sine[i&63]+(ui_sine[(i+1)&63]-ui_sine[i&63])*f)/32767.f;}
static void ue(int x,int y,int rx,int ry,float spin,uint16_t c){int px=0,py=0;for(int j=0;j<=48;j++){float a=j/48.f;int xx=x+(int)(us(a+.25f)*rx),yy=y+(int)(us(a)*ry+us(a+.25f)*spin);if(j)ul(px,py,xx,yy,c);px=xx;py=yy;}}
static void udot(int x,int y,int r,uint16_t c){for(int yy=-r;yy<=r;yy++)for(int xx=-r;xx<=r;xx++)if(xx*xx+yy*yy<=r*r)ur(x+xx,y+yy,1,1,c);}
static const char *ui_title(void){if(seq_page())return pf_ui.page==32?"SEQ / TIMING":pf_ui.page==40?"SEQ / RECORD":"SEQ / CLIP LAUNCH";if(fx_page())return pf_ui.page==6?"EFX MAIN":pf_ui.page==35?"OLIVERB":pf_ui.page==36?(fxRows[0]?"OLIVERB 2 / RETURN":"OLIVERB 2 / MOTION"):pf_ui.page==37?"CLOUDS":fxRows[1]?"CLOUDS 2 / RETURN":"CLOUDS 2 / RECORD";if(pf_ui.page==PF_LFO_SETUP)return (const char*[]){"LFO SETUP / SYNC","LFO SETUP / KEY","LFO SETUP / PHASE","LFO SETUP / SLEW"}[lfoConfigRow];if(pf_ui.mode==PF_CLOCK){if(pf_ui.page==0)return "CLOCK";if(pf_ui.page==3)return "FM ROUTING";if(pf_ui.page==67)return "QUARTZ DETAIL";if(pf_ui.page==58)return "FM SOUND";if(pf_ui.page==1)return "AMP ENV";if(pf_ui.page==65)return "TIMBRE ENV";if(pf_ui.page==59)return (const char*[]){"OPERATOR 1","OPERATOR 2","OPERATOR 3","OPERATOR 4","OPERATOR 5","OPERATOR 6"}[nav.edit%6];if(pf_ui.page==60)return "INHERITED SHAPE";if(pf_ui.page==66)return (const char*[]){"OP1 ENV","OP2 ENV","OP3 ENV","OP4 ENV","OP5 ENV","OP6 ENV"}[nav.edit%6];}int p=pf_ui.page;if(p==41)return "SLIP DOUBLE";if(p==PF_HOME)return "OVERVIEW";if(p==PF_PROJECT)return "TEMPO / CLOCK";if(p==5)return "TUNING";if(p==PF_SYSTEM)return "SYSTEM";if(mixer_page())return (const char*[]){"MIX VOL","MIX PAN","MIX FX1 OLIVERB","MIX FX2 CLOUDS"}[mixer_index()];if(p==0&&pf_ui.mode==PF_LEAD)return "FILTER";if(p==25)return "FILTER MODEL";if(p==3&&pf_ui.mode==PF_BRANCH)return "RAIN";if(p==3&&pf_ui.mode==PF_LEAD)return "VOICE BEHAVIOR";if(p==PF_EXCITER)return pf_ui.mode==PF_CLOCK?"FM FIELD":"EXCITER";if(p==2)return pf_ui.mode==PF_CLOCK?"FM MOTION":"MECHANICS";if(p==3&&pf_ui.mode==PF_CLOCK)return "FM DRIFT";if(p==31)return "SEQ NOTES";if(p==32)return "SEQ PATTERN";if(p==33)return "SEQ BLOCKS";if(p==34)return "SEQ STEP";return pf_pages[p];}
static void ui_short(const char *src,char *dst){static const char *names[][2]={{"AMP ATTACK","ATTACK"},{"AMP RELEASE","RELEASE"},{"AMP DECAY","DECAY"},{"AMP SUSTAIN","SUSTAIN"},{"FLT ATTACK","ATTACK"},{"FLT RELEASE","RELEASE"},{"FLT DECAY","DECAY"},{"FLT SUSTAIN","SUSTAIN"},{"FILTER ATK","ATTACK"},{"FILTER DEC","DECAY"},{"FILTER SUS","SUSTAIN"},{"DESTINATION","DEST"},{"DELAY / POS MS","POSITION"},{"CLOUDS MODE","MODE"},{"GRAIN / LOOP SIZE","GRAIN"},{"VOICE SPREAD","SPREAD"},{"MOD AMOUNT","MOD DEPTH"},{"RECOVERY MS","RECOVERY"}};for(unsigned j=0;j<sizeof(names)/sizeof(names[0]);j++)if(!strcmp(src,names[j][0])){strcpy(dst,names[j][1]);return;}int n=0;for(;*src&&n<9;src++)if(*src!=' '||n<7)dst[n++]=*src;dst[n]=0;}
static void ui_value_fit(char *b){static const char *names[][2]={{"FILTER DEC","FLT DEC"},{"FILTER ATK","FLT ATK"},{"FILTER SUS","FLT SUS"},{"FILTER DEPTH","FLT DEPTH"},{"AMP ATTACK","AMP ATK"},{"AMP RELEASE","AMP REL"},{"REVERSE SAW","REV SAW"},{"SAMPLE HOLD","S/H"},{"FIRST NOTE","FIRST"},{"DUAL STACK","DUAL STK"}};for(unsigned j=0;j<sizeof(names)/sizeof(names[0]);j++)if(!strcmp(b,names[j][0])){strcpy(b,names[j][1]);return;}if(uw(b,1)>54){b[8]='.';b[9]=0;}}
static void ui_values(void){uint16_t c=fx_page()?(pf_ui.page>=37?UI_CORAL:UI_LAVENDER):ui_color(pf_ui.mode);char b[40],label[12];for(int k=0;k<4;k++){const char *name=pf_control_label(k);if(!*name)continue;int x=4+k*60;ui_short(name,label);ut(x,185,label,1,UI_DIM);b[0]=0;pf_control_value(k,b);ui_value_fit(b);int scale=uw(b,2)<=54?2:1;ut(x,200,b,scale,c);udot(x+2,231,1,k==ui_overlay_knob&&plat_ms()<ui_overlay_until?UI_INK:UI_DIM);}}
static void ui_header(void){int m=pf_ui.mode,p=pf_ui.page;char b[24],n[12];uint16_t c=fx_page()?(p>=37?UI_CORAL:UI_LAVENDER):ui_color(m);ut(8,7,nav.screen==NAV_GLOBAL?"GLOBAL":p==PF_HOME?"PACIFIC FIELD":mixer_page()?"MIX":fx_page()?(p==6?"EFX MAIN":p<37?"OLIVERB":"CLOUDS"):pf_modes[m],2,p==PF_HOME||mixer_page()?UI_INK:c);ut(8,30,ui_title(),1,UI_DIM);pf_num(b,pf_page_position());pf_cat(b,"/");pf_num(n,pf_page_count());pf_cat(b,n);ut(202,30,b,1,UI_DIM);const char *state=pf_seq_state(m,8)?"REC":pf_seq_state(m,9)?"ARM":pf_transport?"PLAY":pf_layer_active(m)?"HELD":"";ut(204-uw(state,1),10,state,1,c);if(p==PF_HOME){pf_num(b,pf_ui.seqBpm);ut(236-uw(b,1),10,b,1,UI_INK);}else{udot(228,13,3,pf_layer_active(m)||pf_seq_state(m,3)?c:UI_FAINT);}}
/* The layer meter already carries a release tail into the display snapshot. */
static float ui_activity(int mode){
 return fm_clampf(pf_layer_meter(mode)*14.f,0,1);
}
static void ui_icon(int m,int x,int y,int size,float t){
 uint16_t color=ui_color(m);
 int pulse=(int)(ui_activity(m)*(1+us(t*.8f)));
 if(m==PF_BRANCH){
  ue(x,y-5,size,4+pulse,0,color);
  ue(x,y-5,size,13+pulse,0,UI_DIM);
  ur(x-size,y-19,size*2+1,10,C_BLACK);
  ue(x,y-5,size,4+pulse,0,UI_INK);
 }else if(m==PF_CLOCK){
  for(int i=-1;i<=1;i++){
   int center=x+i*8, peak=y-(i?3:10)-pulse;
   ul(center-5,y+6,center-5,y,color);
   ul(center-5,y,center,peak,color);
   ul(center,peak,center+5,y,color);
   ul(center+5,y,center+5,y+6,color);
  }
  ul(x-size,y+7,x+size,y+7,color);
 }else if(m==PF_TORT){
  ue(x,y,9,9,0,UI_INK);
  for(int stripe=0;stripe<3;stripe++)ue(x,y,size-stripe*2,4+pulse,-4,color);
 }else{
  for(int i=0;i<3;i++){
   ul(x-size,y+4+i,x-5,y+i,color);
   ul(x-5,y+i,x+5,y+2+i,color);
   ul(x+5,y+2+i,x+11,y-4+i,color);
  }
  ul(x+10,y-3,x+14,y-9-pulse,color);
  udot(x+14,y-9-pulse,1,color);
 }
}
static void ui_branch(float t){
 float energy=ui_activity(PF_BRANCH);
 int16_t *params=PF_PAR(pf_ui,PF_BRANCH);
 float motion=energy*(2+params[1]*.09f);
 int ribs=12+params[0]/13;
 int spread=PF_SPREAD(pf_ui,PF_BRANCH)/12;
 for(int j=0;j<ribs;j++){
  float angle=j/(float)ribs;
  float side=us(angle+.25f);
  float wobble=motion*us(t*(1.2f+params[1]*.013f)+angle*3);
  int x=120+(int)(side*(92+spread));
  int y=98+(int)(us(angle)*17+wobble);
  int px=x,py=y;
  for(int n=1;n<=16;n++){
   float u=n/16.f, curve=us(u*.25f+.25f);
   int xx=120+(int)((x-120)*curve+side*18*u);
   int yy=y+(int)((153-y)*us(u*.25f)+wobble*us(u*.5f));
   ul(px,py,xx,yy,j<ribs/2?UI_CORAL:UI_INK);
   px=xx;py=yy;
  }
 }
 ue(120,98,92+spread,17+(int)(motion*us(t*1.2f)),0,UI_INK);
 ue(120,153,21,5,0,UI_CORAL);
 for(int j=0;j<36;j++){
  float a=j/36.f;
  ur(120+(int)(us(a+.25f)*83),158+(int)(us(a)*10),1,1,UI_DIM);
 }
}
static void ui_temple(float t){
 int16_t *params=PF_PAR(pf_ui,PF_CLOCK);
 float energy=fm_sqrtf(ui_activity(PF_CLOCK));
 float mechanics=params[10]*.01f, orbit=params[2]*.01f;
 float clock=pf_clock_macro();
 float motion=energy*(.62f+.38f*clock);
 float drift=energy*pf_clock_quartz()*params[13]*.16f;
 static const uint8_t roofPitch[7]={8,4,13,6,11,7,10};
 static const uint8_t roofWidth[7]={76,84,70,90,73,81,67};
 unsigned profile=(unsigned)params[6]%7;
 int height=56+(int)(motion*(34+19*mechanics));
 int ribs=2+params[0]/28;
 int base=160;
 for(int tier=0;tier<4;tier++){
  int y=base-height*(tier+1)/5;
  int half=roofWidth[profile]-tier*15+(int)(energy*orbit*(7+12*clock));
  int center=120+(int)(drift*(tier+1)/4);
  int lift=roofPitch[profile]+(int)(10*motion)+(int)(energy*params[3]*.07f*us(t*.72f+tier*.19f));
  lift=pf_clip(lift,2,y-48);
  for(int rib=0;rib<ribs;rib++){
   int edge=y+rib*3;
   uint16_t ink=rib==0?UI_INK:UI_CORAL;
   ul(center-half,edge,center-half/2,edge-lift,ink);
   ul(center-half/2,edge-lift,center,edge-lift-4,ink);
   ul(center,edge-lift-4,center+half/2,edge-lift,ink);
   ul(center+half/2,edge-lift,center+half,edge,ink);
  }
  int foot=tier?base-height*tier/5-4:base;
  ul(center-half/2,y,center-half/2,foot,UI_DIM);
  ul(center+half/2,y,center+half/2,foot,UI_DIM);
 }
 int crown=base-height-4;
 ul(120+(int)drift,crown,120+(int)drift,base-height*4/5-10,UI_INK);
 udot(120+(int)drift,crown,energy>.1f?2:1,UI_CORAL);
 ub(111,base-20,19,21,UI_INK);
 if(energy>.03f)udot(120,base-8-(int)(energy*6),1+(int)(energy*3),UI_CORAL);
 for(int step=0;step<3;step++)ul(66-step*12,base+step*3,174+step*12,base+step*3,UI_INK);
}
/* Actual routing, not a decorative approximation: edges follow the same FM bus flags as the DSP. */
static void ui_temple_ops(void){uint8_t owners[3]={0,0,0};int x[6],y[6],carrier[6]={0},routing=pf_ui.temple[28],fbfrom=-1,fbto=-1;for(int op=0;op<6;op++){x[op]=40+(op/2)*80;y[op]=(op&1)?76:128;}
 for(int order=0;order<6;order++){int op=5-order;uint8_t fl=DX_ALG[routing][order];int input=(fl>>4)&3,dest=fl&3;for(int prev=0;prev<6;prev++)if(input&&(owners[input]&(1u<<prev))){ul(x[prev],y[prev]+9,x[op],y[op]-9,UI_DIM);udot(x[op],y[op]-11,2,UI_LAVENDER);}if(fl&0x40)fbto=op;if(fl&0x80)fbfrom=op;if(!dest){carrier[op]=1;ul(x[op],y[op]+10,x[op],158,UI_DIM);}if(fl&4)owners[dest]|=1u<<op;else owners[dest]=1u<<op;}
 if(fbto>=0&&fbfrom>=0){uint16_t c=pf_ui.temple[2]?UI_CORAL:UI_FAINT;int xx=x[fbto]+18;ul(x[fbfrom]+9,y[fbfrom],xx,y[fbfrom],c);ul(xx,y[fbfrom],xx,y[fbto]-15,c);ul(xx,y[fbto]-15,x[fbto],y[fbto]-15,c);ul(x[fbto],y[fbto]-15,x[fbto],y[fbto]-10,c);}
 ul(20,158,220,158,UI_DIM);for(int op=0;op<6;op++){int selected=pf_ui.page==59&&nav.edit%6==op;uint16_t c=selected?UI_CORAL:carrier[op]?UI_INK:UI_LAVENDER;ur(x[op]-12,y[op]-10,25,21,C_BLACK);ub(x[op]-12,y[op]-10,25,21,c);char b[2]={'1'+op,0};ut(x[op]-2,y[op]-6,b,1,c);ur(x[op]-9,y[op]+6,pf_ui.temple[10+op]*19/100,2,c);}ut(99,164,"OUTPUT",1,UI_DIM);
}
static void ui_tort(float t){
 float cutoff=pf_visual_cutoff(PF_TORT);
 float res=pf_ui.tort[P_RESO]/127.f;
 float amount=pf_ui.tort[P_FENV_AMT]/127.f;

 float energy=ui_activity(PF_TORT);
 int bands=pf_ui.tort[P_FTYPE]?13:8;
 int voices=0;
 uint32_t notes=pf_layer_lit(PF_TORT);
 for(;notes;notes&=notes-1)voices++;
 bands=pf_clip(bands+voices/2,8,15);
 ue(120,106,46,46,0,UI_INK);
 for(int latitude=-4;latitude<=4;latitude++){
  int radius=(int)(46*fm_sqrtf(1-latitude*latitude/25.f));
  ue(120,106+latitude*8,radius,4,0,UI_INK);
 }
 for(int band=0;band<bands;band++){
  int px=0,py=0;
  for(int j=0;j<=48;j++){
   float a=j/48.f;
   float wave=us(a*(1.5f+cutoff*2)+t*.06f+band*.035f);
   float radius=66+band*3.7f+(band/4)*5;
   float ripple=wave*(3+amount*8)*(1-res*.4f)*energy;
   float across=us(a+.25f), depth=us(a);
   int x=120+(int)(across*(radius+ripple));
   int y=108+(int)(depth*(radius*.23f+ripple)-across*radius*.28f);
   /* Leave the far side of the rings behind the planet. */
   int dx=x-120,dy=y-106;
   if(j&&(depth>=0||dx*dx+dy*dy>46*46))ul(px,py,x,y,band%4==3?UI_LAVENDER_DIM:UI_LAVENDER);
   px=x;py=y;
  }
 }
}
static void ui_lead(float t){
 float hz=fm_maxf(pf_lead_frequency(),65.4f);
 float energy=ui_activity(PF_LEAD);
 float cutoff=pf_visual_cutoff(PF_LEAD);
 float contour=pf_ui.lead.par[2]*.01f;
 int lift=(int)(energy*fm_clampf(fm_log2f(hz/65.4f)*4,0,12));
 int head=91-lift;
 for(int band=0;band<12;band++){
  int px=0,py=0;
  for(int x=0;x<=216;x+=4){
   float u=x/216.f;
   float taper=us(u*.5f);
   float phase=u*(2+cutoff*2)+t*.22f*(energy>.001f)+band*.008f;
   float wave=us(phase)*(9+contour*13+energy*18)*taper;
   int y=151-(int)(u*(151-head)+wave)+(int)((band-5)*(1+2.8f*taper));
   if(x)ul(px,py,x,y,band==0?UI_INK:UI_YELLOW);
   if(energy>.04f&&band==11&&(x&7)==4)ur(x,y+3+(x%5),1,1,UI_YELLOW);
   px=x;py=y;
  }
 }
 udot(215,head,6,UI_YELLOW);
 ul(213,head-3,213,head-24,UI_YELLOW);
 ul(219,head-3,233,head-21,UI_YELLOW);
 udot(213,head-24,2,UI_YELLOW);
 udot(233,head-21,2,UI_YELLOW);
 if(energy>.03f)for(int j=0;j<17;j++){
  int x=j*3;
  ur(x,164-j/3+j%3,1,1,j%3?UI_DIM:UI_YELLOW);
 }
}
static void ui_envelope(void){int m=pf_ui.mode;float a,d,s,r;int adsr=m==PF_TORT||m==PF_LEAD||m==PF_CLOCK;if(m==PF_CLOCK&&pf_ui.page==66){int base=40+(nav.edit%6)*4;a=pf_ui.temple[base]*.01f;d=pf_ui.temple[base+1]*.01f;s=pf_ui.temple[base+2]*.01f;r=pf_ui.temple[base+3]*.01f;}else if(m==PF_CLOCK){int tone=pf_ui.page==65;a=(tone?pf_ui.temple[34]:PF_PAR(pf_ui,m)[4])*.01f;d=pf_ui.temple[tone?35:32]*.01f;s=pf_ui.temple[tone?36:33]*.01f;r=(tone?pf_ui.temple[37]:PF_PAR(pf_ui,m)[5])*.01f;}else if(m==PF_TORT){int filter=pf_ui.page==23;a=pf_ui.tort[filter?P_FA:P_AA]/127.f;d=pf_ui.tort[filter?P_FD:P_AD]/127.f;s=pf_ui.tort[filter?P_FS:P_AS]/127.f;r=pf_ui.tort[filter?P_FR:P_AR]/127.f;}else if(m==PF_LEAD){int filter=pf_ui.page==45;a=PF_PAR(pf_ui,m)[filter?8:4]*.01f;d=PF_PAR(pf_ui,m)[filter?9:11]*.01f;s=PF_PAR(pf_ui,m)[filter?10:6]*.01f;r=filter?d:PF_PAR(pf_ui,m)[5]*.01f;}else{a=PF_PAR(pf_ui,m)[4]*.01f;r=PF_PAR(pf_ui,m)[5]*.01f;d=0;s=1;}
 int ax=20+(int)(a*50),dx=ax+15+(int)(d*35),rx=170-(int)(r*20),sy=145-(int)(s*75);for(int band=0;band<7;band++){int off=band*2;uint16_t c=band?ui_color(m):UI_INK;ul(12,150+off,ax,64+off,c);if(adsr){ul(ax,64+off,dx,sy+off,c);ul(dx,sy+off,rx,sy+off,c);ul(rx,sy+off,228,150+off,c);}else{ul(ax,64+off,rx,64+off,c);ul(rx,64+off,228,150+off,c);}}if(pf_layer_active(m))udot(217,56,4,ui_color(m));}
static void ui_lfo_setup(void){int m=pf_ui.mode;char b[12];const char *rows[4]={"SYNC","KEY","PHASE","SLEW"};ut(8,51,"SELECT: SETTING",1,UI_DIM);for(int slot=0;slot<4;slot++){pf_num(b,slot+1);ut(64+slot*42,70,b,1,ui_color(m));}for(int row=0;row<4;row++){int y=91+row*21;ut(8,y,rows[row],1,row==lfoConfigRow?ui_color(m):UI_DIM);if(row==lfoConfigRow)ul(8,y+12,230,y+12,ui_color(m));for(int slot=0;slot<4;slot++){int value=PF_LFO(pf_ui,m)[slot][4+row];if(row<2){b[0]=0;pf_cat(b,value?"ON":"OFF");}else pf_num(b,value);ut(62+slot*42,y,b,1,row==lfoConfigRow?UI_INK:UI_DIM);}}}
static void ui_lfo(void){if(pf_ui.page==PF_LFO_SETUP){ui_lfo_setup();return;}int m=pf_ui.mode,slot=pf_ui.page>=54?pf_ui.page-54:(pf_ui.page-10)/2;int16_t *cfg=PF_LFO(pf_ui,m)[slot];float phase=pf_lfo_phase(m,slot),output=pf_lfo_output(m,slot),amp=16+cfg[1]*.3f;for(int trail=0;trail<7;trail++){int px=0,py=0;for(int x=12;x<=228;x+=3){float p=(x-12)/216.f+phase+trail*.012f;float wave=pf_lfo_sample(cfg[2],p,cfg[2]==5?output:0);int y=109-(int)(wave*amp)+trail*2-6;if(x>12)ul(px,py,x,y,trail?UI_INK:ui_color(m));px=x;py=y;}}udot(120,109-(int)(output*amp),4,UI_YELLOW);for(int j=0;j<4;j++)udot(95+j*17,164,slot==j?3:1,slot==j?ui_color(m):UI_DIM);}
enum { SEQ_ROLL_X=9, SEQ_ROLL_W=222, SEQ_ROLL_TOP=64, SEQ_ROLL_H=87 };
static void ui_seq_note(unsigned onset,unsigned duration,int pitch,int low,int high,uint16_t ink){
 int x=SEQ_ROLL_X+onset*SEQ_ROLL_W/PF_CLIP_TICKS;
 int y=SEQ_ROLL_TOP+SEQ_ROLL_H-4-(pitch-low)*(SEQ_ROLL_H-8)/(high-low);
 if(duration>PF_CLIP_TICKS)duration=PF_CLIP_TICKS;
 int width=pf_clip(duration*SEQ_ROLL_W/PF_CLIP_TICKS,3,SEQ_ROLL_W);
 int remaining=SEQ_ROLL_X+SEQ_ROLL_W-x;
 ur(x,y,width<remaining?width:remaining,3,ink);
 if(width>remaining)ur(SEQ_ROLL_X,y,width-remaining,3,ink);
}
static void ui_seq_roll(int mode,int clip){
 const PFSeqPattern *pattern=&PF_SEQ(pf_ui,mode).pattern[clip];
 const int length=pf_clip(pf_clip_length(pattern),1,64);
 const int eventClip=pf_clip_events(pattern);
 int entries=eventClip?pf_clip_count(pattern):length;
 int low=127,high=0;
 uint16_t ink=ui_color(mode);
 char label[]="CLIP A";
 label[5]='A'+clip;
 ut(9,48,label,1,ink);
 ub(SEQ_ROLL_X-1,SEQ_ROLL_TOP-1,SEQ_ROLL_W+2,SEQ_ROLL_H+2,UI_DIM);
 for(int i=1;i<length;i++){
  int x=SEQ_ROLL_X+i*SEQ_ROLL_W/length;
  ul(x,SEQ_ROLL_TOP,x,SEQ_ROLL_TOP+SEQ_ROLL_H-1,UI_FAINT);
 }
 if(pf_seq_state(mode,3)){
  int phase=pf_clip(pf_seq_state(mode,25),0,999);
  int x=SEQ_ROLL_X+phase*SEQ_ROLL_W/1000;
  ul(x,SEQ_ROLL_TOP,x,SEQ_ROLL_TOP+SEQ_ROLL_H-1,UI_DIM);
  udot(x,59,2,ink);
 }
 // First find the pitch range, then paint from the same clip without a note buffer.
 for(int pass=0;pass<2;pass++){
  for(int i=0;i<entries;i++){
   unsigned onset,duration;
   uint8_t eventNote;
   const uint8_t *notes;
   int count;
   if(eventClip){
    PFClipEvent event=pf_clip_event(pattern,i);
    onset=event.time&(PF_CLIP_TICKS-1);
    duration=pf_clip_duration(event.duration);
    eventNote=event.note&127;
    notes=&eventNote;
    count=1;
   }else{
    const PFSeqStep *step=&pattern->steps[i];
    if(step->type!=0)continue;
    onset=i*PF_CLIP_TICKS/length;
    int span=1;
    while(span<length&&pattern->steps[(i+span)%length].type==1)span++;
    duration=span*PF_CLIP_TICKS/length;
    notes=step->key;
    count=pf_clip(step->count,0,4);
   }
   for(int n=0;n<count;n++){
    int pitch=notes[n]&127;
    if(pass)ui_seq_note(onset,duration,pitch,low,high,ink);
    else{
     if(pitch<low)low=pitch;
     if(pitch>high)high=pitch;
    }
   }
  }
  if(pass==0){
   if(low>high){uc(120,102,"EMPTY CLIP",1,UI_DIM);break;}
   if(high-low<12){int center=(low+high)/2;low=center-6;high=center+6;}
  }
 }
 ut(8,166,"GLO + DIV: FREE / SYNC",1,UI_DIM);
}
static void ui_seq(void){int m=pf_ui.mode;char b[24];int playing=pf_seq_state(m,0),queued=pf_seq_state(m,1),record=pf_seq_state(m,8),count=pf_seq_state(m,15);
 if(pf_ui.page==33){for(int clip=0;clip<4;clip++){int x=8+clip*57,has=pf_clip_has_notes(&PF_SEQ(pf_ui,m).pattern[clip]),active=playing==clip;uint16_t c=active?ui_color(m):UI_DIM;ub(x,56,51,93,c);if(active&&pf_seq_state(m,3))ur(x+2,58,47,22,c);if(queued==clip)ub(x+2,58,47,89,UI_YELLOW);b[0]='A'+clip;b[1]=0;uc(x+25,66,b,2,active&&pf_seq_state(m,3)?C_BLACK:UI_INK);uc(x+25,102,queued==clip?"NEXT":active&&pf_seq_state(m,3)?"PLAY":active?"SEL":"",1,queued==clip?UI_YELLOW:UI_INK);uc(x+25,126,has?"READY":"EMPTY",1,has?UI_INK:UI_DIM);}ut(8,163,"TURN K1-K4 TO QUEUE CLIP",1,UI_DIM);return;}
 if(pf_ui.page==40){b[0]='A'+playing;b[1]=0;ut(8,48,b,2,ui_color(m));uc(132,69,count?"COUNT-IN":record?"RECORDING":pf_seq_state(m,9)?"ARMED":"READY",2,record?UI_CORAL:UI_INK);if(count){pf_num(b,count);uc(120,103,b,3,UI_CORAL);}else{ut(12,110,"REC: START / FINISH TAKE",1,UI_INK);ut(12,134,"GLO + REC: UNDO",1,UI_DIM);}if(pf_seq_state(m,24))ut(12,157,"CLIP FULL",1,UI_CORAL);else ut(12,157,pf_seq_state(m,3)?"STOP TO SNAP CLIP":"GLO + K1: SNAP CLIP",1,UI_DIM);return;}
 ui_seq_roll(m,playing);
}

static void ui_instrument_picker(float t){
 int from=pf_ui.mode,to=instrumentChoice;
 char channel[]="CHANNEL 1";
 channel[8]='1'+instrument_slot(from);
 ur(0,0,240,240,C_BLACK);
 ut(8,7,"INSTRUMENTS",2,UI_INK);
 ut(8,30,channel,1,ui_color(from));
 for(int slot=0;slot<PF_LAYERS;slot++){
  int engine=ui_order[slot],x=30+slot*60;
  ui_icon(engine,x,82,15,t);
  uc(x,107,pf_modes[engine],1,ui_color(engine));
  char knob[]="K1";knob[1]+=slot;
  uc(x,119,knob,1,UI_DIM);
  if(engine==to)ub(x-25,58,50,64,ui_color(engine));
 }
 if(to!=from){
  char target[]="SWAP WITH CHANNEL 1";
  target[18]='1'+instrument_slot(to);
  uc(120,139,target,1,UI_INK);
 }else uc(120,139,"CURRENT INSTRUMENT",1,UI_DIM);
 if(instrumentSwapFailed)uc(120,159,"STOP PLAYBACK AND RELEASE NOTES",1,UI_CORAL);
 else if(instrumentSwapPending)uc(120,159,"SWAPPING",1,UI_DIM);
 ut(8,185,"KNOBS 1-4",1,UI_DIM);
 ut(8,201,"CHOOSE",1,UI_INK);
 ut(101,185,"EDIT",1,UI_DIM);
 ut(101,201,"SWAP",1,UI_INK);
 ut(180,185,"HOME",1,UI_DIM);
 ut(180,201,"CANCEL",1,UI_INK);
}
static void ui_mixer(float t){char b[16];int index=mixer_index();for(int k=0;k<4;k++){int m=ui_order[k],x=30+k*60,selected=m==pf_ui.mode;uint16_t c=ui_color(m);ui_icon(m,x,69,15,t);uc(x,91,pf_modes[m],1,c);if(selected)ur(x-22,102,44,2,c);int value=index==0?PF_PAR(pf_ui,m)[7]:index==1?PF_MIXPAN(pf_ui,m):PF_PAR(pf_ui,m)[index==2?27:24];int h=index==1?(value+100)*54/200:value*54/100;ur(x-18,111,27,54,UI_FAINT);if(index==1){ul(x-18,138,x+9,138,UI_DIM);ur(x-18,165-h,27,2,c);}else ur(x-18,165-h,27,h,c);int meter=pf_clip((int)((60+6.0206f*fm_log2f(fm_maxf(pf_layer_meter(m),.000001f)))*13/60),0,13);for(int j=0;j<13;j++)ur(x+14,162-j*4,5,2,j<meter?c:UI_FAINT);if(PF_MUTE(pf_ui,m))uc(x,172,"MUTE",1,c);else if(PF_SOLO(pf_ui,m))uc(x,172,"SOLO",1,c);}}
#include "fx-visual.h"
static void ui_arp(float t){int m=pf_ui.mode;uint32_t held=PF_LATCHED(pf_ui,m)|pf_layer_active(m);int keys[27],count=0;for(int k=0;k<27;k++)if(held&(1u<<k))keys[count++]=k;int px=0,py=0;for(int j=0;j<(count?count:8);j++){int x=18+j*204/(count>1?count-1:7),note=count?keys[j]:j*3;int y=142-note*3;ue(x,y,3,3,0,count?ui_color(m):UI_DIM);if(j&&count)ul(px,py,x,y,ui_color(m));px=x;py=y;}ut(8,162,PF_ARPSETTINGS(pf_ui,m)[0]?"ARP RUN":"ARP OFF",1,ui_color(m));}
static void ui_project(void){char b[20];pf_num(b,pf_ui.seqBpm);uc(120,77,b,5,UI_INK);uc(120,123,"BEATS PER MINUTE",1,UI_DIM);uc(120,151,pf_ui.metronome?"METRONOME ON":"METRONOME OFF",1,UI_YELLOW);}
static void ui_global(void){char b[24];if(pf_ui.page==PF_PROJECT){ui_project();uc(120,169,"INTERNAL CLOCK",1,UI_DIM);}else if(pf_ui.page==5){uc(120,79,pf_tunings[PF_PAR(pf_ui,0)[20]],3,UI_INK);uc(120,120,"ALL FOUR INSTRUMENTS",1,UI_LAVENDER);uc(120,147,"GLOBAL TUNING / ROOT / HZ",1,UI_DIM);}else{uc(120,66,"PACIFIC FIELD",2,UI_INK);uc(120,93,"PROJECT FORMAT 23",1,UI_DIM);pf_num(b,sizeof(PFPerformanceSave));pf_cat(b," BYTES / 16128");uc(120,113,b,1,UI_DIM);pf_num(b,plat_cpu_pct());pf_cat(b,"% CPU");uc(120,137,b,1,UI_DIM);pf_num(b,plat_xruns());pf_cat(b," AUDIO OVERRUNS");uc(120,159,b,1,UI_DIM);}}
static void ui_overlay(void){uint32_t now=plat_ms();char label[40],value[40];uint16_t c=ui_color(pf_ui.mode);int visible=ui_overlay_knob>=0&&now<ui_overlay_until&&pf_ui.page==ui_overlay_page&&pf_ui.mode==ui_overlay_mode;
 if(now<pf_saved_until){strcpy(label,saveFailed?"SAVE FAILED":"PROJECT SAVED");value[0]=0;visible=1;}else if(now<ui_transpose_until){strcpy(label,"FIELD TRANSPOSE");value[0]=0;if(pf_ui.transpose>=0)pf_cat(value,"+");pf_num(value+(pf_ui.transpose>=0?1:0),pf_ui.transpose);pf_cat(value," ST / ");pf_cat(value,pf_note_names[(PF_PAR(pf_ui,0)[21]+pf_ui.transpose+120)%12]);visible=1;c=UI_CORAL;}else if(visible){strcpy(label,pf_control_label(ui_overlay_knob));value[0]=0;pf_control_value(ui_overlay_knob,value);if(!label[0])visible=0;}
 if(!visible)return;
 /* Reuse only the footer; the animated body at y44..179 stays unobscured. */
 ur(0,180,240,60,C_BLACK);ul(4,181,236,181,c);
 int vs=uw(value,3)<=132?3:uw(value,2)<=160?2:1;
 int vx=236-uw(value,vs),available=vx-12;
 int ls=uw(label,2)<=available?2:1;
 if(uw(label,ls)>available){char shortLabel[12];ui_short(label,shortLabel);strcpy(label,shortLabel);}
 ut(4,204,label,ls,UI_INK);ut(vx,199,value,vs,c);
 if(ui_overlay_knob>=0)udot(8+ui_overlay_knob*60,233,2,c);

}
static void ui_hardware_projects(void){
 ut(8,7,"PROJECTS",2,UI_INK);
 ut(8,30,"FM-1 / INTERNAL MEMORY",1,UI_DIM);
 ub(10,56,220,34,UI_LAVENDER);
 ut(19,69,hardwareProjectExists?"01  SAVED PROJECT":"01  EMPTY",1,UI_INK);
 for(int action=0;action<2;action++){
  int x=10+action*111;
  uint16_t ink=action==hardwareProjectAction?UI_LAVENDER:UI_DIM;
  ub(x,106,108,24,ink);
  uc(x+54,114,action?"RECALL":"SAVE",1,action&&!hardwareProjectExists?UI_FAINT:ink);
 }
 if(hardwareProjectConfirm)
  uc(120,148,hardwareProjectAction?"RESTART AND RECALL?":"REPLACE SAVED PROJECT?",1,UI_CORAL);
 else uc(120,148,"ONE INTERNAL PROJECT SLOT",1,UI_DIM);
 ut(8,185,"K1 / SELECT",1,UI_DIM);ut(8,201,"CHOOSE",1,UI_INK);
 ut(101,185,"EDIT / SAVE",1,UI_DIM);ut(101,201,"CONFIRM",1,UI_INK);
 ut(181,185,"HOME",1,UI_DIM);ut(181,201,"CANCEL",1,UI_INK);
}
static void ui_content(void){
 if(hardwareProjectMenu){ui_hardware_projects();return;}
int m=pf_ui.mode,p=pf_ui.page;float t=(plat_ms()%600000u)*.001f;if(instrumentPicker){ui_instrument_picker(t);return;}ui_header();if(nav.screen==NAV_GLOBAL)ui_global();else if(mixer_page()){ui_mixer(t);uc(120,48,"HOLD HOME: INSTRUMENTS",1,UI_DIM);}else if(seq_page())ui_seq();else if(p==1||p==23||p==24||p==45||((p==65||p==66)&&m==PF_CLOCK))ui_envelope();else if(pf_lfo_page())ui_lfo();else if(fx_page()||p==6)ui_fx(t);else if(p==8||p==9||(p==3&&arpContext))ui_arp(t);else if(m==PF_BRANCH)ui_branch(t);else if(m==PF_CLOCK){if(temple_deep()&&p!=2&&p!=67)ui_temple_ops();else{ui_temple(t);if(p==0||p==58)ut(8,46,"HOLD EDIT: OPERATORS",1,UI_DIM);}}else if(m==PF_TORT)ui_tort(t);else ui_lead(t);ui_values();ui_overlay();}
/* Cache only a small signature, never another native framebuffer or patch.
 * Stable header/knob bands remain on the LCD while the 136-row center animates. */
static uint32_t ui_stamp(void){uint32_t hash=2166136261u;char value[40];
 const uint32_t words[]={pf_ui.mode,pf_ui.page,pf_ui.selected,pf_transport,pf_ui.seqBpm,ui_overlay_knob,(uint32_t)(plat_ms()<pf_saved_until),(uint32_t)(ui_overlay_until&&plat_ms()<ui_overlay_until)};
 for(unsigned j=0;j<sizeof(words)/sizeof(words[0]);j++)hash=(hash^words[j])*16777619u;
 for(int m=0;m<4;m++){hash=(hash^pf_layer_active(m))*16777619u;hash=(hash^PF_MUTE(pf_ui,m)^(PF_SOLO(pf_ui,m)<<1))*16777619u;}
 hash=(hash^(hardwareProjectMenu|(hardwareProjectAction<<1)|(hardwareProjectConfirm<<2)|(hardwareProjectExists<<3)))*16777619u;
 hash=(hash^(instrumentPicker|(instrumentChoice<<1)|(instrumentSwapFailed<<4)|(instrumentSwapPending<<5)))*16777619u;
 hash=(hash^pf_seq_state(pf_ui.mode,8)^(pf_seq_state(pf_ui.mode,9)<<1))*16777619u;
 for(int k=0;k<4;k++){value[0]=0;pf_control_value(k,value);for(const char *c=value;*c;c++)hash=(hash^(uint8_t)*c)*16777619u;}
 return hash;
}
static void ui_draw(void){uint32_t stamp=ui_stamp();if(!ui_have_frame||stamp!=ui_last_stamp){for(int band=0;band<2;band++){ui_band=band*120;cv_begin(240,120,C_BLACK);ui_content();cv_blit(0,band*120);}}else{ui_band=44;cv_begin(240,136,C_BLACK);ui_content();cv_blit(0,44);}ui_last_stamp=stamp;ui_have_frame=1;}
