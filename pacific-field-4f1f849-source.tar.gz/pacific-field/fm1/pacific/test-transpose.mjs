import {modeDelta,legacyStep} from './test-panel-order.mjs';
import fs from 'node:fs';import assert from 'node:assert/strict';
async function boot(){const{instance:{exports:e}}=await WebAssembly.instantiate(fs.readFileSync(process.argv[2]),{wasi_snapshot_preview1:new Proxy({},{get:()=>()=>0}),env:new Proxy({},{get:()=>()=>0})});e._initialize();e.web_boot();return e;}
function api(e){const run=(n=1024)=>{let sum=0;for(let i=0;i<n;i+=128){e.web_render(Math.min(128,n-i));for(let p of[e.web_out_l(),e.web_out_r()])for(let x of new Float32Array(e.memory.buffer,p,Math.min(128,n-i))){assert(Number.isFinite(x)&&Math.abs(x)<=.951);sum+=x*x;}}assert.equal(e.web_dropped(),0);assert.equal(e.web_fx_faults(),0);return sum;},tap=b=>{e.web_buttons(1<<b);e.web_buttons(0);run();},turn=(r,d)=>{e.web_enc(r,d);run();},select=m=>turn(2,modeDelta(e,m)),trans=k=>{e.web_buttons(1<<5);e.web_keys(1<<k);e.web_buttons(0);e.web_keys(0);};return{run,tap,turn,select,trans};}
// Coherent absolute JI multiplier, all four latched chords, smooth active retuning, no extra key/retrigger.
{const e=await boot(),a=api(e);a.run();e.web_open_page(5);a.turn(3,1);const chord=(1<<7)|(1<<11)|(1<<14);for(let m=0;m<4;m++){a.select(m);e.web_open_page(0);a.tap(1);e.web_keys(chord);e.web_keys(0);a.run();}const before=[0,1,2,3].map(m=>[7,11,14].map(k=>e.web_voice_frequency(m,k)));const ratio=e.web_note_hz(14)/e.web_note_hz(7);a.trans(14);assert.equal(e.web_transpose(),7);a.run(128);let smooth=e.web_transpose_ratio();assert(smooth>1&&smooth<ratio);a.run(4410);assert(Math.abs(e.web_transpose_ratio()-ratio)<.005);for(let m=0;m<4;m++){assert.equal(e.web_layer_active(m),chord);for(let j=0;j<3;j++){assert(Math.abs(e.web_voice_frequency(m,[7,11,14][j])/before[m][j]-ratio)<.00001);assert(Math.abs(e.web_voice_current_frequency(m,[7,11,14][j])/before[m][j]-ratio)<.006);}assert(Math.abs(e.web_voice_frequency(m,11)/e.web_voice_frequency(m,7)-before[m][1]/before[m][0])<.00001);}assert(Math.abs(e.web_lead_frequency()/before[3][2]-ratio)<.006);for(let n=0;n<10;n++){a.trans(11);a.run(128);a.trans(7);a.run(4410);assert.equal(e.web_transpose(),0);assert(Math.abs(e.web_transpose_ratio()-1)<.003);}assert.equal(e.web_save_project(),0);const bytes=new Uint8Array(e.memory.buffer,e.web_store(0),e.web_store_len(0)).slice();assert.equal(bytes.length,15772);a.trans(14);a.run();assert.equal(e.web_save_project(),0);e.web_boot();a.run();assert.equal(e.web_transpose(),7);assert(Math.abs(e.web_transpose_ratio()-ratio)<.00001);for(let m=0;m<4;m++)assert.equal(e.web_layer_active(m),chord);}
// GLO tap/cycle, consumed up after modifier release, physical note ownership across layer changes, octave reset.
{const e=await boot(),a=api(e);a.run();e.web_keys(1<<7);a.run();a.select(1);e.web_buttons(1<<5);e.web_keys((1<<7)|(1<<14));a.run();assert.equal(e.web_layer_active(1),0);const page=e.web_page();e.web_buttons(0);assert.equal(e.web_page(),page,'transpose consumes GLO without opening GLOBALS');e.web_keys(1<<7);a.run();assert.equal(e.web_layer_active(0),1<<7);e.web_keys(0);a.run(4410);assert.equal(e.web_layer_active(0),0);a.tap(5);assert.equal(e.web_page(),48);a.tap(5);assert.equal(e.web_page(),5);a.tap(12);a.trans(7);assert.equal(e.web_transpose(),-12);a.tap(13);a.trans(7);assert.equal(e.web_transpose(),0);}
// Compare two otherwise identical projects: transpose must leave all clock/Slip/LFO trajectories and pattern bytes identical.
{const e=await boot(),f=await boot(),a=api(e),b=api(f);for(const [x,c]of[[e,a],[f,b]]){c.run();for(let m=0;m<4;m++){c.select(m);legacyStep(x,m,0,[60,64]);legacyStep(x,m,1,[67]);c.run();x.web_open_page(32);c.turn(4,-14);c.turn(6,25);x.web_open_page(10);c.turn(3,55);c.turn(4,30);c.turn(5,1);}c.tap(10);c.run(60000);}const patterns=()=>[0,1,2,3].map(m=>Array.from({length:4},(_,p)=>Array.from({length:64},(_,s)=>Array.from({length:12},(_,k)=>e.web_seq_step(m,p,s,k)))));const before=patterns();a.trans(14);for(let n=0;n<40;n++){a.run(1024);b.run(1024);for(let m=0;m<4;m++){for(let field of[0,1,2,3,6,10,11])assert.equal(e.web_seq_state(m,field),f.web_seq_state(m,field));for(let field of [0,1,2,5,6])assert.equal(e.web_phase_state(2*m+1,field),f.web_phase_state(2*m+1,field));for(let slot=0;slot<4;slot++)assert.equal(e.web_lfo_phase(m,slot),f.web_lfo_phase(m,slot));}}assert.deepEqual(patterns(),before);a.tap(10);a.run(50000);for(let m=0;m<4;m++){assert.equal(e.web_seq_state(m,11),0);assert.equal(e.web_seq_slip_state(m,14),0);}assert(e.web_pool_bytes()+e.web_canvas_bytes()+8192<344064);}
console.log('PASS: all four engines/chords/latched drones transpose by one JI ratio, active glide, absolute root reset, consumed keyboard edges and octaves, persistent migration, unchanged pattern/clock/Slip/LFO trajectories and safe note-offs.');

// Arpeggiator clocks and each head remain independent of the global pitch reference.
{const e=await boot(),f=await boot(),a=api(e),b=api(f);for(const[x,c]of[[e,a],[f,b]]){c.run();for(let m=0;m<4;m++){c.select(m);c.tap(1);x.web_keys((1<<7)|(1<<11)|(1<<14));x.web_keys(0);c.run();x.web_open_page(8);c.turn(3,1);c.turn(6,60);}c.run(10000);}a.trans(14);for(let j=0;j<25;j++){a.run(1024);b.run(1024);for(let m=0;m<4;m++)for(let h=0;h<2;h++){assert.equal(e.web_arp_events(m,h),f.web_arp_events(m,h));assert.equal(e.web_arp_last(m,h),f.web_arp_last(m,h));}}}
console.log('PASS: master transpose preserves all four arpeggiators and both original arp Slip clock trajectories.');

// Change the master profile, root and reference while every engine holds the same note.
{
 const e=await boot(),a=api(e);
 a.run();
 const key=11;
 const modes=[0,1,2,3];
 for(const m of modes){a.select(m);a.tap(1);e.web_keys(1<<key);e.web_keys(0);a.run();}
 const check=()=>{
  const expected=e.web_note_hz(key);
  for(const m of modes){
   assert(Math.abs(e.web_voice_frequency(m,key)-expected)<.001);
   assert.equal(e.web_layer_active(m),1<<key);
  }
  return expected;
 };
 const initial=check();
 a.tap(5);a.tap(5);assert.equal(e.web_page(),5);
 for(const [knob,delta] of [[3,1],[4,2],[5,37]]){
  const before=check();
  a.turn(knob,delta);a.run(32768);
  assert.notEqual(check(),before);
  assert(Math.abs(e.web_lead_frequency()-e.web_note_hz(key))<.01);
 }
 assert.notEqual(check(),initial);
}
