/* SPDX-License-Identifier: GPL-3.0-only. Compact four-instrument performance view. */
static void home_content(void){uint16_t ink=RGB(228,222,199),dim=RGB(143,157,148),line=RGB(48,65,61);char b[40],n[16];
 mx_text(8,5,pf_ui.page==PF_HOME?"PACIFIC FIELD":"PROJECT CLOCK",ink);pf_num(b,pf_ui.seqBpm);pf_cat(b," BPM");mx_text(174,5,b,dim);mx_line(8,22,232,22,line);
 for(int m=0;m<PF_LAYERS;m++){int y=31+m*25;uint16_t c=mx_color(m);if(m==pf_ui.mode)mx_rect(4,y-3,232,22,RGB(29,43,37));mx_text(9,y,pf_modes[m],c);int pattern=pf_seq_state(m,0),queued=pf_seq_state(m,1),step=pf_seq_state(m,2),run=pf_seq_state(m,3);b[0]='A'+pattern;b[1]=0;if(queued>=0){pf_cat(b,">");n[0]='A'+queued;n[1]=0;pf_cat(b,n);}mx_text(71,y,b,c);mx_text(108,y,pf_seq_state(m,8)?"REC":pf_seq_state(m,9)?"ARM":run?"PLAY":"STOP",c);pf_num(b,step<0?0:step+1);pf_cat(b,"/");pf_num(n,PF_SEQ(pf_ui,m).pattern[pattern].length);pf_cat(b,n);mx_text(154,y,b,c);if(PF_MUTE(pf_ui,m))mx_text(213,y,"M",c);else if(PF_SOLO(pf_ui,m))mx_text(213,y,"S",c);}
 mx_line(8,132,232,132,line);b[0]=0;pf_cat(b,"ROOT ");pf_cat(b,pf_note_names[PF_PAR(pf_ui,0)[21]%12]);pf_cat(b,"  TRANS ");if(pf_ui.transpose>=0)pf_cat(b,"+");pf_num(n,pf_ui.transpose);pf_cat(b,n);mx_text(9,140,b,ink);b[0]=0;pf_cat(b,"SELECTED ");pf_cat(b,pf_modes[pf_ui.mode]);mx_text(9,159,b,mx_color(pf_ui.mode));
 mx_text(9,181,pf_ui.page==PF_HOME?"GLO+KEY: TRANSPOSE / EDIT: VOICE":"HOME: DASH / GLO: MIXER",dim);
 for(int k=0;k<4;k++){int y=201+(k/2)*20,x=8+(k%2)*116;mx_text(x,y,pf_control_label(k),dim);pf_control_value(k,b);mx_text(x+74,y,b,mx_color(pf_ui.mode));}
}
static void pf_draw_home(void){for(int band=0;band<2;band++){mx_offset=band*120;cv_begin(240,120,RGB(13,22,22));home_content();cv_blit(0,band*120);}}
