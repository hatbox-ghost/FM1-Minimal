/* SPDX-License-Identifier: GPL-3.0-only
 * Sequencer input portions adapted from SLOOP (isod89), Felucca and Melodee.
 * Portions Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments
 * Portions Copyright (C) 2026 Kerem Kilic (Ellic Studio)
 * The same 240x240 UI and panel logic are used by web.c and the FM-1 port.
 * Included after gfx.c; uses only the original plat.h interface.
 */
#include "pacific.h"
#include "fx.h"
#include "lead.h"
#include "../firmware/src/dsp/fastmath.h"
#include <string.h>
#include <stddef.h>
pf_patch pf_ui;
static uint32_t pf_oldkeys,pf_oldbuttons,pf_press_ms[NB],pf_last_draw;
static uint32_t pf_saved_until;
static int savePending,saveFailed;
static int hardwareProjectMenu,hardwareProjectExists,hardwareProjectAction,hardwareProjectConfirm;
static int homePickerUsed;
/* Visual state only: no patch fields, audio state or dynamic allocations. */
static const uint8_t factoryOrder[4]={PF_BRANCH,PF_CLOCK,PF_TORT,PF_LEAD};
static uint8_t ui_order[4]={PF_BRANCH,PF_CLOCK,PF_TORT,PF_LEAD};
static int instrumentPicker,instrumentChoice,instrumentSwapPending,instrumentSwapFailed;
static int instrument_slot(int engine){
 for(int i=0;i<PF_LAYERS;i++)if(ui_order[i]==engine)return i;
 return 0;
}
static void instrument_order_load(int packed){
 memcpy(ui_order,factoryOrder,sizeof ui_order);
 if((packed&0xff00)!=0x5100)return;
 unsigned seen=0;
 for(int i=0;i<PF_LAYERS;i++)seen|=1u<<((packed>>(2*i))&3);
 if(seen!=15)return;
 for(int i=0;i<PF_LAYERS;i++)ui_order[i]=(packed>>(2*i))&3;
}
/* The v23 master field is reserved because MASTER is a physical control. */
static int instrument_order_save(void){
 if(!memcmp(ui_order,factoryOrder,sizeof ui_order))return 100;
 int packed=0x5100;
 for(int i=0;i<PF_LAYERS;i++)packed|=ui_order[i]<<(2*i);
 return packed;
}
static int ui_next_mode(int mode,int delta){int slot=0;for(int i=0;i<4;i++)if(ui_order[i]==mode)slot=i;return ui_order[(slot+delta%4+4)%4];}
static uint32_t ui_overlay_until,ui_transpose_until;static int ui_overlay_knob=-1,ui_overlay_page,ui_overlay_mode;
static int ui_lfo_index(int page,int k){return (page%2)?4+k:(int[]){0,1,3,2}[k];}
static int ui_voice_param(int m,int k){return m==PF_BRANCH?(int[]){11,6,13,8}[k]:m==PF_CLOCK?(int[]){1,0,6,3}[k]:(int[]){0,1,19,-1}[k];}
static int ui_env_param(int m,int k){return m==PF_BRANCH?(int[]){4,5,13,1}[k]:m==PF_LEAD?(int[]){4,11,6,5}[k]:m==PF_CLOCK?(int[]){4,5,7,-1}[k]:(int[]){4,5,1,6}[k];}
static int ui_exciter_param(int m,int k){return m==PF_CLOCK?(int[]){2,7,0,1}[k]:(int[]){2,3,6,7}[k];}
static int branch_edit_param(int page,int k){return page==2?(int[]){2,3,1,10}[k]:(int[]){0,14,15,12}[k];}
static void ui_touch(int k){ui_overlay_knob=k;ui_overlay_until=plat_ms()+850;ui_overlay_page=pf_ui.page;ui_overlay_mode=pf_ui.mode;}

static uint32_t layer_play[PF_LAYERS],layer_freeze[PF_LAYERS],pf_transport,pf_process_transport;
#define pf_play_state layer_play[pf_ui.mode]
#define pf_freeze_state layer_freeze[pf_ui.mode]
static int pf_dirty=1;
static int key_owner[27];
static uint32_t transposeCaptured;
static uint8_t arpContext;
static uint8_t playUsed,recUsed,globalUsed,globalTimingUsed,fxRows[2];
#define PF_SHIFT_TAP_MS 400u
static int mixer_page(void){return pf_ui.page==7||(pf_ui.page>=PF_MIX_PAN&&pf_ui.page<=PF_MIX_ROOM);}
static int mixer_index(void){return pf_ui.page==7?0:pf_ui.page-PF_MIX_PAN+1;}
static int fx_page(void){return pf_ui.page==6||(pf_ui.page>=35&&pf_ui.page<40);}
static int seq_page(void){return pf_ui.page==32||pf_ui.page==40||pf_ui.page==33;}
static const int16_t fxLow[20]={0,0,0,0,0,0,0,0,5,0,0,-24,0,0,0,0,0,0,0,0};
static const int16_t fxHigh[20]={100,100,100,100,100,100,1,100,1000,2,100,24,95,100,1,100,100,100,100,100};
static const char *fxLabels[20]={"SIZE","DECAY","DAMPING","DIFFUSION","MOD AMOUNT","MOD RATE","REV FREEZE","REV RETURN","DELAY / POS MS","CLOUDS MODE","GRAIN / LOOP SIZE","PITCH","FEEDBACK","TEXTURE","CLOUD FREEZE","DELAY RETURN","DENSITY","STEREO SPREAD","REV HIGH PASS","FX MASTER"};
/* Stable saved parameter IDs; negative IDs are selected-instrument sends. */
static int fx_ui_index(int page,int k){
 if(page==6)return (int[]){-27,-24,12,8}[k];
 if(page==35)return (int[]){0,1,2,4}[k];
 if(page==36)return fxRows[0]?(int[]){18,19,-100,-100}[k]:(int[]){3,5,6,7}[k];
 if(page==37)return (int[]){9,11,10,13}[k];
 if(page==38)return fxRows[1]?(int[]){15,-100,-100,-100}[k]:(int[]){8,16,17,14}[k];
 return -100;
}
static const char *fx_ui_label(int k){int i=fx_ui_index(pf_ui.page,k);if(i==-27)return "REVERB SEND";if(i==-24)return "DELAY SEND";if(i<0)return "";if(i==4)return "MODULATION";if(i==9)return "MODE";if(i==8)return pf_ui.fx[9]?"POSITION":(pf_ui.seqReserved&PF_DELAY_SYNC_BIT)?"DELAY DIV":"DELAY TIME";return fxLabels[i];}
static void fx_defaults(pf_patch *p){const int16_t d[20]={45,65,45,70,8,30,0,55,280,0,45,0,25,50,0,65,30,60,5,100};memcpy(p->fx,d,sizeof d);int m=p->mode;if(m<0||m>2)m=0;p->fx[8]=p->par[m][25];p->fx[12]=p->par[m][26];}

static uint8_t seqOct[27],seqCaptureKind[27],seqCaptureOwner[27];
static uint32_t seqMidiHeld[PF_LAYERS][4],seqRevision[PF_LAYERS];
static uint8_t seqMidiOwner[16][128],seqMidiKind[16][128];
static uint32_t seqCaptured,seqUsed;
static const uint8_t seqWhite[16]={0,2,4,6,7,9,11,12,14,16,18,19,21,23,24,26};
static void seq_defaults(pf_patch *p){p->seqBpm=96;p->seqReserved=(3u<<PF_REC_QUANT_SHIFT)|(((1u<<PF_LAYERS)-1)<<PF_ARP_SYNC_SHIFT);memset(p->seq,0,sizeof p->seq);for(int m=0;m<3;m++){p->seq[m].bpm=96;p->seq[m].sync=1;p->seq[m].division=2;p->seq[m].gate=102;p->seq[m].enabled=1;for(int b=0;b<4;b++){p->seq[m].pattern[b].length=16;for(int l=0;l<24;l++)p->seq[m].pattern[b].locks[l].step=255;for(int j=0;j<64;j++){PFSeqStep *st=&p->seq[m].pattern[b].steps[j];st->key[0]=60;st->key[1]=67;st->gate=80;st->velocity=100;}}}}
static void seq_send(int offset,int value){pf_post(PF_SEQ,offset,value);}


/* EDIT stays inside voice design. Performance/global pages use direct buttons. */
static const uint8_t temple_edit_order[3]={0,58,3};
static const uint8_t pf_edit_order[5]={0,2,3,30,4};
static const uint8_t tort_edit_order[9]={22,18,19,69,20,21,25,30,4};
static const uint8_t lead_edit_order[9]={0,42,43,44,69,46,3,30,4};
static const uint8_t *voice_order(void){return pf_ui.mode==PF_LEAD?lead_edit_order:pf_ui.mode==PF_TORT?tort_edit_order:pf_ui.mode==PF_CLOCK?temple_edit_order:pf_edit_order;}
static int pf_voice_page_count(void){return pf_ui.mode==PF_LEAD?9:pf_ui.mode==PF_TORT?9:pf_ui.mode==PF_CLOCK?3:5;}
static int pf_lfo_page(void){return pf_ui.page==PF_LFO_SETUP||(pf_ui.page>=10&&pf_ui.page<18)||(pf_ui.mode==PF_TORT&&pf_ui.page>=54&&pf_ui.page<58);}
static void pf_num(char*,int);
static void pf_cat(char*,const char*);
static int temple_edit_pending;
static uint8_t lfoConfigRow;
static int temple_deep(void){return pf_ui.mode==PF_CLOCK&&(pf_ui.page==59||pf_ui.page==60||pf_ui.page==4||pf_ui.page==66||pf_ui.page==2||pf_ui.page==67);}
#include "navigation.h"
static int temple_ui_page(void){int p=pf_ui.page;return pf_ui.mode==PF_CLOCK&&(p==0||p==1||p==2||p==3||p==67||p==58||p==59||p==60||p==65||p==66);}
static int temple_ui_param(int k){int p=pf_ui.page,op=nav.edit%6;if(p==0)return (int[]){6,10,13,2}[k];if(p==58)return (int[]){0,1,3,166}[k];if(p==3)return (int[]){156,130,-1,9}[k];if(p==2)return 8+k;if(p==67)return 12+k;if(p==1)return (int[]){4,160,161,5}[k];if(p==65)return 162+k;if(p==66)return 168+op*4+k;if(p==59)return (int[]){132+op,138+op,150+op,(pf_ui.temple[3]&(1u<<op))?169+op*4:144+op}[k];return (int[]){128,129,2,9}[k];}
static const char *temple_ui_label(int k){int p=pf_ui.page;if(p==0)return (const char*[]){"CLOCK SET","MECHANICS","DRIFT","ORBIT"}[k];if(p==58)return (const char*[]){"FM DEPTH","COLOR","DETUNE","FM ENV"}[k];if(p==3)return (const char*[]){"ROUTING","FEEDBACK","SPREAD","EVOLUTION"}[k];if(p==2)return (const char*[]){"MECH RATE","EVOLVE","REMONTOIRE","REWIND MS"}[k];if(p==67)return (const char*[]){"QTZ RATE","QTZ DEPTH","QTZ SLEW","MOTION"}[k];if(p==1||p==65||p==66)return (const char*[]){"ATTACK","DECAY","SUSTAIN","RELEASE"}[k];if(p==59)return (const char*[]){"RATIO","LEVEL","WAVE","DECAY"}[k];return (const char*[]){"BODY DECAY","STRIKE DECAY","MOTION DEPTH","EVOLUTION"}[k];}
static float temple_time(int param,int x){float v=x*.01f;if((param==4||param==5)&&!(pf_ui.temple[39]&1))return param==4?.005f+7*v*v*v:.02f+9*v*v*v;if(param==4||param==34||(param>=40&&(param-40)%4==0))return .002f+7*v*v*v;if(param==5||param==37||(param>=40&&(param-40)%4==3))return .005f+9*v*v*v;return .005f+8*v*v*v;}
static void temple_format_time(char *b,float seconds){int ms=(int)(seconds*1000+.5f);b[0]=0;if(ms<1000){pf_num(b,ms);pf_cat(b," MS");}else{pf_num(b,ms/1000);pf_cat(b,".");char n[8];pf_num(n,(ms%1000)/100);pf_cat(b,n);pf_cat(b," S");}}

static const int pf_page_button[7]={B_HOME,B_ENV,B_LFO,B_ARP,B_SEQ,B_GLO,B_FX};
static const char *const pf_note_names[12]={"C","C#","D","Eb","E","F","F#","G","Ab","A","Bb","B"};
static int pf_clip(int v,int lo,int hi){return v<lo?lo:v>hi?hi:v;}
static void pf_num(char *s,int v){char b[12];int n=0,i=0;if(v<0){s[i++]='-';v=-v;}do{b[n++]=(char)('0'+v%10);v/=10;}while(v);while(n)s[i++]=b[--n];s[i]=0;}
static void pf_cat(char *s,const char *a){while(*s)s++;while((*s++=*a++));}
static void pf_limits(int m,int i,int *lo,int *hi){*lo=0;*hi=100;if(i==17){*lo=-2;*hi=2;}if(i==18){*lo=-100;*hi=100;}if(i==19){*lo=-50;*hi=50;}if(i==20)*hi=4;if(i==21)*hi=11;if(i==22){*lo=650;*hi=2600;}if(i==23)*hi=1;if(i==25){*lo=30;*hi=360;}if(i==26)*hi=78;if(m==PF_LEAD&&i==12)*hi=1;if(m==PF_LEAD&&i==14)*hi=12;if(m==1){if(i==8){*lo=2;*hi=180;}if(i==11)*hi=2;if(i==12){*lo=30;*hi=240;}if(i==13){*lo=1;*hi=27;}if(i==14)*hi=3;}if(m==0&&i==12){*lo=60;*hi=2000;}if(m==2){if(i==6)*hi=6;if(i==8){*lo=1;*hi=240;}if(i==11){*lo=80;*hi=4000;}if(i==12||i==14)*lo=1;if(i==15)*hi=1;}}
void pf_value(char *dst,int size,int m,int i,int x){(void)size;dst[0]=0;if(i==18){if(!x){pf_cat(dst,"C");return;}pf_cat(dst,x<0?"L":"R");pf_num(dst+1,x<0?-x:x);return;}if(i==20){pf_cat(dst,pf_tunings[x%5]);return;}if(i==21){pf_cat(dst,pf_note_names[x%12]);return;}if(i==23||((m==2)&&i==15)){pf_cat(dst,x?"ON":"OFF");return;}if(i==22){pf_num(dst,x/10);pf_cat(dst,".");char b[4];pf_num(b,x%10);pf_cat(dst,b);pf_cat(dst," Hz");return;}if(m==1&&i==11){pf_cat(dst,(const char*[]){"LOWPASS","NOTCH","HIPASS"}[x%3]);return;}if(m==1&&i==14){pf_cat(dst,(const char*[]){"UP","DOWN","UP DOWN","RANDOM"}[x%4]);return;}if(m==2&&i==6){pf_cat(dst,(const char*[]){"PAD","GLASS","BELL","HARMONIUM","PARALLEL","DUAL STACK","STACK"}[x%7]);return;}if(m==2&&(i==8||i==9||i==12)){int units=i==8?x*5:i==9?20+(x*118+5)/10:50+(x*795+5)/10;pf_num(dst,units/10000);pf_cat(dst,".");char digits[8];pf_num(digits,units%10000);for(int z=1000;z>1&&units%10000<z;z/=10)pf_cat(dst,"0");pf_cat(dst,digits);pf_cat(dst," Hz");return;}if(m==2&&(i==3||i==13)){int c=i==3?x*22:x*2;pf_num(dst,c/100);pf_cat(dst,".");char digits[8];if(c%100<10)pf_cat(dst,"0");pf_num(digits,c%100);pf_cat(dst,digits);pf_cat(dst," c");return;}if(m==2&&i==10){pf_num(dst,x);pf_cat(dst," %");return;}if(m==2&&i==14){pf_num(dst,20+x*40);pf_cat(dst," ms");return;}pf_num(dst,x);if(i==25||(m==0&&i==12)||(m==2&&i==11))pf_cat(dst," ms");if(m==1&&i==8)pf_cat(dst," s");if(m==1&&i==12)pf_cat(dst," BPM");if(i==19)pf_cat(dst," c");}
static void clock_defaults(pf_patch *p){const int16_t v[8]={18,28,100,1000,12,15,45,1};memcpy(p->par[PF_CLOCK]+8,v,sizeof v);}
static void pf_lead_defaults(pf_patch *p){PFLeadPatch *q=&p->lead;memset(q,0,sizeof *q);const int16_t par[PF_NPAR]={72,35,40,0,2,40,80,72,2,55,40,45,1,50,2,0,65,0,0,0,0,0,1308,0,20,280,25,35};memcpy(q->par,par,sizeof par);for(int k=0;k<27;k++)q->level[k]=65;const int16_t arp[8]={0,96,3,0,27,0,70,85};memcpy(q->arpSettings,arp,sizeof arp);q->seq.bpm=96;q->seq.sync=1;q->seq.enabled=1;q->seq.division=2;q->seq.gate=102;for(int b=0;b<4;b++){q->seq.pattern[b].length=16;for(int l=0;l<24;l++)q->seq.pattern[b].locks[l].step=255;}q->seqSlip[1]=q->seqSlip[2]=100;q->seqSlip[3]=1;q->mini[0]=q->mini[1]=q->mini[2]=3;q->mini[3]=q->mini[4]=2;q->mini[5]=0;q->mini[6]=q->mini[7]=64;q->mini[8]=90;q->mini[9]=70;q->mini[12]=1|2|4|8|32|64;q->mini[14]=64;}
/* Startup performance state is predictable even when loading a saved project.
 * Sound design, tuning, patterns and effect algorithms remain in the project. */
static void pf_startup_profile(pf_patch *p){memset(p->tortRoutes,0,sizeof p->tortRoutes);
 p->page=7;p->latch=p->arp=0;
 for(int m=0;m<PF_LAYERS;m++){
  PF_PAR(*p,m)[7]=72;PF_PAR(*p,m)[24]=PF_PAR(*p,m)[27]=PF_PAR(*p,m)[23]=0;
  PF_LATCHED(*p,m)=0;PF_MUTE(*p,m)=PF_SOLO(*p,m)=0;PF_ARPSETTINGS(*p,m)[0]=0;
  for(int slot=0;slot<PF_LFO_COUNT;slot++)PF_LFO(*p,m)[slot][1]=PF_LFO(*p,m)[slot][3]=0;
 }
 p->lead.mini[3]=2;p->lead.mini[8]=90;p->lead.mini[9]=p->lead.mini[10]=p->lead.mini[11]=0;p->lead.mini[12]=(p->lead.mini[12]&112)|1; /* one audible saw oscillator, with others available to enable */
 p->lead.par[3]=p->lead.par[15]=0; /* direct pitch, no native LFO depth */
 p->tort[P_LFO_PITCH]=p->tort[P_LFO_PWM]=p->tort[P_LFO_FLT]=p->tort[P_LFO_AMP]=p->tort[P_MOD_DEPTH]=0;
}
void pf_defaults(pf_patch *p){memset(p,0,sizeof *p);p->magic=0x50464332;p->version=22;p->masterGain=100;temple_defaults(p->temple);seq_defaults(p);for(int m=0;m<3;m++){p->seqSlip[m][1]=100;p->seqSlip[m][2]=100;p->seqSlip[m][3]=1;}p->page=7;p->selected=7;p->latch=0;
 const int16_t defaults[3][PF_NPAR]={
 {45,70,35,20,8,50,0,72,45,50,50,28,650,70,50,25,65,0,0,0,1,0,1308,0,20,280,30,35},
 {18,64,20,8,30,40,50,74,24,12,25,0,92,12,0,70,65,0,0,0,1,0,1308,0,28,330,38,40},
 {35,22,40,18,30,45,0,76,20,55,0,12,4,1,1,0,65,0,0,0,1,0,1308,0,15,310,28,50}};
 memcpy(p->par,defaults,sizeof defaults);for(int m=0;m<3;m++)for(int i=0;i<27;i++){p->level[m][i]=65;p->pan[m][i]=0;}for(int m=0;m<3;m++){int16_t def[8]={0,96,3,0,27,0,70,85};memcpy(p->arpSettings[m],def,sizeof def);}p->arpSettings[1][1]=92;tort_defaults(p->tort);clock_defaults(p);fx_defaults(p);pf_lead_defaults(p);for(int i=20;i<=22;i++)p->lead.par[i]=p->par[0][i];pf_startup_profile(p);}
typedef struct {uint8_t key[2],velocity,gate,count,type;} LegacyStep;
typedef struct {uint8_t length;LegacyStep steps[16];} LegacyPattern;
typedef struct {LegacyPattern pattern[4];uint16_t bpm;uint8_t enabled,active,sync,division,reserved[2];} LegacyLane;
typedef struct {uint32_t magic,version; int16_t mode,page,selected,octave,arp,latch; int16_t par[3][PF_NPAR]; int16_t level[3][27],pan[3][27],fine[3][27];uint32_t latched[3];int16_t mixpan[3],mute[3],solo[3];int16_t arpSettings[3][8];int16_t lfo[3][4][8] __attribute__((aligned(4)));uint8_t tort[56];int16_t spread[3];uint16_t seqBpm __attribute__((aligned(4)));uint16_t seqReserved;LegacyLane seq[3];int16_t fx[20];} LegacyPatch;
static LegacyPatch legacyOut;
/* Audit candidate: main-thread, non-reentrant storage operations share one scratch patch. */
typedef struct {
 pf_patch patch;
 uint8_t held[PF_LAYERS][27];
} PFPerformanceSave;
_Static_assert(sizeof(PFPerformanceSave)<=PF_STORE_MAX,"performance exceeds project storage");
static PFPerformanceSave projectSave;
#define projectScratch projectSave.patch
static int restorePerformance;
static void legacy_seq_defaults(LegacyPatch *p){p->seqBpm=96;memset(p->seq,0,sizeof p->seq);for(int m=0;m<3;m++){p->seq[m].bpm=96;p->seq[m].sync=1;p->seq[m].division=3;for(int b=0;b<4;b++){p->seq[m].pattern[b].length=16;for(int j=0;j<16;j++)p->seq[m].pattern[b].steps[j]=(LegacyStep){{7,14},100,80,0,0};}}}
static void legacy_defaults(LegacyPatch *p){pf_defaults(&projectScratch);memcpy(p,&projectScratch,1012);legacy_seq_defaults(p);memcpy(p->fx,projectScratch.fx,sizeof p->fx);p->version=11;}
static void legacy_clock_defaults(LegacyPatch *p){const int16_t values[8]={18,28,100,1000,12,15,45,1};memcpy(p->par[2]+8,values,sizeof values);}
static void legacy_fx_defaults(LegacyPatch *p){pf_defaults(&projectScratch);memcpy(p->fx,projectScratch.fx,sizeof p->fx);}
static int legacy_load(void){LegacyPatch p;int bytes=plat_store_load(OBJ_PROJ,&p,sizeof p);if(bytes!=(int)sizeof p||p.magic!=0x50464332||p.version!=11){typedef struct {uint32_t magic,version;int16_t mode,page,selected,octave,arp,latch;int16_t par[3][PF_NPAR];int16_t level[27],pan[27],fine[27];uint32_t latched;} Legacy;Legacy old;if(bytes==(int)offsetof(LegacyPatch,fx)&&p.magic==0x50464332&&p.version==10){/* original FX defaults below */}else if(bytes==(int)offsetof(LegacyPatch,seqBpm)&&p.magic==0x50464332&&p.version==9){/* sequencer defaults below */}else if(bytes==(int)offsetof(LegacyPatch,spread)&&p.magic==0x50464332&&p.version==8){/* spread migrates below */}else if(bytes==(int)offsetof(LegacyPatch,spread)&&p.magic==0x50464332&&p.version==7){/* v7 musical data preserved; clock controls migrate below. */}else if(bytes==(int)offsetof(LegacyPatch,tort)&&p.magic==0x50464332&&p.version==6){tort_defaults(p.tort);p.version=7;}else if(bytes==(int)offsetof(LegacyPatch,lfo)&&p.magic==0x50464332&&p.version==5){memset(p.lfo,0,sizeof p.lfo);p.version=6;}else if(bytes==(int)((offsetof(LegacyPatch,arpSettings)+3u)&~3u)&&p.magic==0x50464332&&p.version==4){for(int m=0;m<3;m++){int16_t def[8]={0,96,3,0,27,0,70,85};memcpy(p.arpSettings[m],def,sizeof def);}p.arpSettings[1][0]=p.arp;p.arpSettings[1][1]=p.par[1][12];p.arpSettings[1][4]=p.par[1][13];p.arpSettings[1][5]=p.par[1][14];p.arpSettings[1][6]=p.par[1][15];p.version=6;memset(p.lfo,0,sizeof p.lfo);}else if(bytes==(int)offsetof(LegacyPatch,mixpan)&&p.magic==0x50464332&&p.version==3){memset(p.mixpan,0,sizeof p.mixpan);memset(p.mute,0,sizeof p.mute);memset(p.solo,0,sizeof p.solo);for(int m=0;m<3;m++){int16_t def[8]={0,96,3,0,27,0,70,85};memcpy(p.arpSettings[m],def,sizeof def);}p.version=6;memset(p.lfo,0,sizeof p.lfo);}else if(bytes==(int)sizeof old&&p.magic==0x50464332&&p.version==2){memcpy(&old,&p,sizeof old);legacy_defaults(&p);p.mode=old.mode;p.page=old.page;p.selected=old.selected;p.octave=old.octave;p.arp=old.arp;p.latch=old.latch;memcpy(p.par,old.par,sizeof p.par);for(int m=0;m<3;m++){memcpy(p.level[m],old.level,sizeof old.level);memcpy(p.pan[m],old.pan,sizeof old.pan);memcpy(p.fine[m],old.fine,sizeof old.fine);}}else{legacy_defaults(&legacyOut);return -1;}}if(p.version<7)tort_defaults(p.tort);if(p.version<8){legacy_clock_defaults(&p);p.version=8;}if(p.version<9){memset(p.spread,0,sizeof p.spread);for(int m=0;m<3;m++)for(int k=0;k<27;k++)if(p.pan[m][k]==(k%7-3)*12)p.pan[m][k]=0;p.version=9;}if(p.version<10){legacy_seq_defaults(&p);p.version=10;}if(p.version<11){legacy_fx_defaults(&p);p.version=11;}for(int i=0;i<20;i++)p.fx[i]=pf_clip(p.fx[i],fxLow[i],fxHigh[i]);p.seqBpm=pf_clip(p.seqBpm,30,240);for(int m=0;m<3;m++){LegacyLane *q=&p.seq[m];q->bpm=pf_clip(q->bpm,30,240);q->active=pf_clip(q->active,0,3);q->enabled=!!q->enabled;q->sync=!!q->sync;q->division=pf_clip(q->division,0,5);for(int b=0;b<4;b++){q->pattern[b].length=pf_clip(q->pattern[b].length,1,16);for(int j=0;j<16;j++){LegacyStep *st=&q->pattern[b].steps[j];st->count=pf_clip(st->count,0,2);st->type=pf_clip(st->type,0,2);st->gate=pf_clip(st->gate,1,100);st->velocity=pf_clip(st->velocity,1,127);st->key[0]=pf_clip(st->key[0],0,26);st->key[1]=pf_clip(st->key[1],0,26);}}}for(int m=0;m<3;m++)p.spread[m]=pf_clip(p.spread[m],0,100);p.mode=pf_clip(p.mode,0,2);p.page=pf_clip(p.page,0,PF_PAGES-1);p.selected=pf_clip(p.selected,0,26);p.octave=pf_clip(p.octave,-2,2);p.arp=!!p.arp;p.latch=!!p.latch;memset(p.latched,0,sizeof p.latched);for(int m=0;m<3;m++)for(int i=0;i<PF_NPAR;i++){int lo,hi;pf_limits(m,i,&lo,&hi);p.par[m][i]=pf_clip(p.par[m][i],lo,hi);}for(int m=0;m<3;m++)for(int i=0;i<27;i++){p.level[m][i]=pf_clip(p.level[m][i],0,100);p.pan[m][i]=pf_clip(p.pan[m][i],-100,100);p.fine[m][i]=pf_clip(p.fine[m][i],-50,50);}for(int m=0;m<3;m++){p.mixpan[m]=pf_clip(p.mixpan[m],-100,100);p.mute[m]=!!p.mute[m];p.solo[m]=!!p.solo[m];for(int i=20;i<=22;i++)p.par[m][i]=p.par[p.mode][i];}for(int m=0;m<3;m++){const int lo[8]={0,30,0,0,1,0,2,0},hi[8]={1,240,5,100,27,3,95,100};for(int i=0;i<8;i++)p.arpSettings[m][i]=pf_clip(p.arpSettings[m][i],lo[i],hi[i]);}for(int m=0;m<3;m++)for(int slot=0;slot<4;slot++){const int hi[8]={100,100,5,pf_lfo_count(m)-1,1,1,359,100};for(int k=0;k<8;k++)p.lfo[m][slot][k]=pf_clip(p.lfo[m][slot][k],0,hi[k]);}for(int i=0;i<56;i++)p.tort[i]=pf_clip(p.tort[i],0,tort_max(i));if(p.mode==PF_TORT&&p.page<3)p.page=p.page==1?23:22;if(p.mode!=PF_TORT&&p.page>=18&&p.page!=30&&p.page<31)p.page=0;legacyOut=p;return 0;}
static int load_project(void){
 instrument_order_load(0);
 memset(&projectSave,0,sizeof projectSave);
 int bytes=plat_store_load(OBJ_PROJ,&projectSave,sizeof projectSave);
 restorePerformance=bytes==(int)sizeof projectSave&&projectScratch.magic==0x50464332&&projectScratch.version==23;
 if(!restorePerformance&&(bytes!=(int)sizeof projectScratch||projectScratch.magic!=0x50464332||projectScratch.version!=22)){if(bytes==(int)sizeof projectScratch&&projectScratch.magic==0x50464332&&projectScratch.version==21){/* v21 fields retained; global phasing migrates below. */}else if(bytes==(int)sizeof projectScratch&&projectScratch.magic==0x50464332&&projectScratch.version==20){/* v20: timing modes initialized below. */}else if(bytes==(int)sizeof projectScratch&&projectScratch.magic==0x50464332&&projectScratch.version==19){/* Complete v19 patch; global Slip migrates below. */}else if(bytes==15632&&projectScratch.magic==0x50464332&&projectScratch.version==18){/* v18 operator patch retained; new envelope fields below. */}else if(bytes==(int)offsetof(pf_patch,temple)&&projectScratch.magic==0x50464332&&projectScratch.version==17){/* Complete pre-expansion patch retained; neutral TEMPLE fields below. */}else if(bytes==(int)offsetof(pf_patch,tortRoutes)&&projectScratch.magic==0x50464332&&projectScratch.version==16){/* Prophet payload: converted explicitly below. */}else if(bytes==(int)offsetof(pf_patch,masterGain)&&projectScratch.magic==0x50464332&&projectScratch.version==15){/* Preserve the complete four-engine v15 payload. */}else if(bytes==(int)offsetof(pf_patch,lead)&&projectScratch.magic==0x50464332&&projectScratch.version==14){pf_lead_defaults(&projectScratch);projectScratch.version=15;}else if(bytes==(int)offsetof(pf_patch,lead)&&projectScratch.magic==0x50464332&&projectScratch.version==13){pf_lead_defaults(&projectScratch);for(int m=0;m<3;m++)PF_SEQSLIP(projectScratch,m)[0]=0;projectScratch.version=15;}else if(bytes==(int)offsetof(pf_patch,seqSlip)&&projectScratch.magic==0x50464332&&projectScratch.version==12){pf_lead_defaults(&projectScratch);memset(projectScratch.seqSlip,0,sizeof projectScratch.seqSlip);for(int m=0;m<3;m++){PF_SEQSLIP(projectScratch,m)[1]=PF_SEQSLIP(projectScratch,m)[2]=100;PF_SEQSLIP(projectScratch,m)[3]=1;}projectScratch.version=15;}else{int result=legacy_load();pf_defaults(&projectScratch);if(result<0){pf_ui=projectScratch;return -1;}memcpy(&projectScratch,&legacyOut,1012);projectScratch.version=15;projectScratch.seqBpm=legacyOut.seqBpm;memcpy(projectScratch.fx,legacyOut.fx,sizeof projectScratch.fx);for(int m=0;m<3;m++){PF_SEQ(projectScratch,m).bpm=legacyOut.seq[m].bpm;PF_SEQ(projectScratch,m).sync=legacyOut.seq[m].sync;PF_SEQ(projectScratch,m).active=legacyOut.seq[m].active;PF_SEQ(projectScratch,m).enabled=legacyOut.seq[m].enabled;const int div[6]={7,6,0,1,2,3};PF_SEQ(projectScratch,m).division=div[legacyOut.seq[m].division%6];for(int b=0;b<4;b++){PF_SEQ(projectScratch,m).pattern[b].length=legacyOut.seq[m].pattern[b].length;for(int j=0;j<16;j++){LegacyStep *src=&legacyOut.seq[m].pattern[b].steps[j];PFSeqStep *dst=&PF_SEQ(projectScratch,m).pattern[b].steps[j];dst->count=src->count;dst->type=src->type;dst->velocity=src->velocity;dst->gate=src->gate;for(int k=0;k<2;k++)dst->key[k]=src->key[k]+53+12*projectScratch.octave;}}}}}for(int m=0;m<PF_LAYERS;m++){PFSeqLane *q=&PF_SEQ(projectScratch,m);q->active=pf_clip(q->active,0,3);q->bpm=pf_clip(q->bpm,30,240);q->division=pf_clip(q->division,0,8);q->swing=pf_clip(q->swing,0,100);q->gate=pf_clip(q->gate,1,128);for(int b=0;b<4;b++){if(projectScratch.version>=22&&pf_clip_events(&q->pattern[b])){if(!pf_clip_valid(&q->pattern[b])){restorePerformance=0;pf_defaults(&pf_ui);return -1;}pf_clip_save_clean(&q->pattern[b]);continue;}q->pattern[b].length=pf_clip(q->pattern[b].length,1,64);for(int j=0;j<64;j++){PFSeqStep *st=&q->pattern[b].steps[j];st->count=pf_clip(st->count,0,4);st->type=pf_clip(st->type,0,2);st->micro=pf_clip(st->micro,-32,31);for(int k=0;k<4;k++)st->key[k]&=127;}}}projectScratch.mode=pf_clip(projectScratch.mode,0,3);projectScratch.page=pf_clip(projectScratch.page,0,PF_PAGES-1);projectScratch.selected=pf_clip(projectScratch.selected,0,26);projectScratch.octave=pf_clip(projectScratch.octave,-2,2);projectScratch.seqBpm=pf_clip(projectScratch.seqBpm,30,240);memset(projectScratch.latched,0,sizeof projectScratch.latched);projectScratch.lead.latched=0;projectScratch.latch=0;for(int m=0;m<PF_LAYERS;m++)for(int k=0;k<4;k++)PF_SEQSLIP(projectScratch,m)[k]=pf_clip(PF_SEQSLIP(projectScratch,m)[k],k==0?-100:0,k==3?1:100);for(int m=0;m<PF_LAYERS;m++)PF_SPREAD(projectScratch,m)=pf_clip(PF_SPREAD(projectScratch,m),0,100);projectScratch.mode=pf_clip(projectScratch.mode,0,3);projectScratch.page=pf_clip(projectScratch.page,0,PF_PAGES-1);projectScratch.selected=pf_clip(projectScratch.selected,0,26);projectScratch.octave=pf_clip(projectScratch.octave,-2,2);projectScratch.arp=!!projectScratch.arp;projectScratch.latch=!!projectScratch.latch;memset(projectScratch.latched,0,sizeof projectScratch.latched);projectScratch.lead.latched=0;for(int m=0;m<PF_LAYERS;m++)for(int i=0;i<PF_NPAR;i++){int lo,hi;pf_limits(m,i,&lo,&hi);PF_PAR(projectScratch,m)[i]=pf_clip(PF_PAR(projectScratch,m)[i],lo,hi);}for(int m=0;m<PF_LAYERS;m++)for(int i=0;i<27;i++){PF_LEVEL(projectScratch,m)[i]=pf_clip(PF_LEVEL(projectScratch,m)[i],0,100);PF_PAN(projectScratch,m)[i]=pf_clip(PF_PAN(projectScratch,m)[i],-100,100);PF_FINE(projectScratch,m)[i]=pf_clip(PF_FINE(projectScratch,m)[i],-50,50);}for(int m=0;m<PF_LAYERS;m++){PF_MIXPAN(projectScratch,m)=pf_clip(PF_MIXPAN(projectScratch,m),-100,100);PF_MUTE(projectScratch,m)=!!PF_MUTE(projectScratch,m);PF_SOLO(projectScratch,m)=!!PF_SOLO(projectScratch,m);for(int i=20;i<=22;i++)PF_PAR(projectScratch,m)[i]=PF_PAR(projectScratch,projectScratch.mode)[i];}for(int m=0;m<PF_LAYERS;m++){const int lo[8]={0,30,0,0,1,0,2,0},hi[8]={1,240,5,100,27,3,95,100};for(int i=0;i<8;i++)PF_ARPSETTINGS(projectScratch,m)[i]=pf_clip(PF_ARPSETTINGS(projectScratch,m)[i],lo[i],hi[i]);}for(int m=0;m<PF_LAYERS;m++)for(int slot=0;slot<4;slot++){const int hi[8]={100,100,5,pf_lfo_count(m)-1,1,1,359,100};for(int k=0;k<8;k++)PF_LFO(projectScratch,m)[slot][k]=pf_clip(PF_LFO(projectScratch,m)[slot][k],0,hi[k]);}for(int i=0;i<56;i++)projectScratch.tort[i]=pf_clip(projectScratch.tort[i],0,tort_max(i));if(projectScratch.mode==PF_TORT&&projectScratch.page<3)projectScratch.page=projectScratch.page==1?23:22;if(projectScratch.mode!=PF_TORT&&projectScratch.page>=18&&projectScratch.page!=30&&projectScratch.page<31)projectScratch.page=0;for(int i=0;i<20;i++)projectScratch.fx[i]=pf_clip(projectScratch.fx[i],fxLow[i],fxHigh[i]);projectScratch.page=pf_clip(projectScratch.page,0,PF_PAGES-1);if(projectScratch.page>=42&&projectScratch.page<=46&&projectScratch.mode!=PF_LEAD)projectScratch.page=0;projectScratch.lead.latched=0;for(int z=0;z<32;z++)projectScratch.lead.mini[z]&=127;for(int z=0;z<6;z++)projectScratch.lead.mini[z]%=6;if(projectScratch.version<16){projectScratch.masterGain=100;projectScratch.transpose=projectScratch.metronome=0;}if(projectScratch.page>=54&&projectScratch.page<58&&projectScratch.mode!=PF_TORT)projectScratch.page=0;if(!restorePerformance&&projectScratch.page>=27&&projectScratch.page<=29)projectScratch.page=22;if(projectScratch.version<17){tort_defaults(projectScratch.tort);memset(projectScratch.tortRoutes,0,sizeof projectScratch.tortRoutes);for(int z=0;z<4;z++)projectScratch.lfo[PF_TORT][z][1]=projectScratch.lfo[PF_TORT][z][3]=0;}for(int slot=0;slot<4;slot++)for(int k=0;k<4;k++)projectScratch.tortRoutes[slot][k]=pf_clip(projectScratch.tortRoutes[slot][k],k%2?-100:0,k%2?100:pf_lfo_count(PF_TORT)-1);if(projectScratch.version<18)temple_defaults(projectScratch.temple);for(int i=0;i<PF_TEMPLE_BYTES;i++)projectScratch.temple[i]=pf_clip(projectScratch.temple[i],0,temple_max(i));if(projectScratch.version<19)temple_envelope_defaults(projectScratch.temple);if(projectScratch.version<20){int old=pf_clip(PF_GLOBAL_SLIP(projectScratch),0,100);for(int m=0;m<PF_LAYERS;m++)PF_INSTRUMENT_SLIP(projectScratch,m)=0;PF_INSTRUMENT_SLIP(projectScratch,projectScratch.mode)=old;projectScratch.seqReserved&=255u;}for(int m=0;m<PF_LAYERS;m++)PF_INSTRUMENT_SLIP(projectScratch,m)=pf_clip(PF_INSTRUMENT_SLIP(projectScratch,m),0,100);if(projectScratch.version<21){projectScratch.seqReserved&=255u;for(int m=0;m<PF_LAYERS;m++)PF_SEQ(projectScratch,m).sync=1;}for(int m=0;m<PF_LAYERS;m++)PF_SEQ(projectScratch,m).sync=!!PF_SEQ(projectScratch,m).sync;if(projectScratch.version<22){for(int m=0;m<PF_LAYERS;m++){PF_SEQSLIP(projectScratch,m)[1]=PF_INSTRUMENT_SLIP(projectScratch,m);PF_INSTRUMENT_SLIP(projectScratch,m)=0;}projectScratch.seqReserved=(projectScratch.seqReserved&~PF_REC_QUANT_MASK)|((projectScratch.seqReserved&4?0:3)<<PF_REC_QUANT_SHIFT);}if(PF_REC_QUANT(projectScratch)>5)projectScratch.seqReserved=(projectScratch.seqReserved&~PF_REC_QUANT_MASK)|(3u<<PF_REC_QUANT_SHIFT);projectScratch.version=restorePerformance?23:22;if(restorePerformance)instrument_order_load(projectScratch.masterGain);projectScratch.masterGain=100;/* Reserved v16 field: volume belongs to physical MASTER. */projectScratch.transpose=pf_clip(projectScratch.transpose,-48,48);projectScratch.metronome=!!projectScratch.metronome;pf_ui=projectScratch;return 0;}
int pf_load(void){
 int result=load_project();
 hardwareProjectExists=result==0;
 if(result<0){
  /* A fresh set starts with harmonic Bowl modes and no factory pitch offsets.
   * Keep existing saved timbres and their intentional detuning on recall. */
  PF_PAR(pf_ui,PF_BRANCH)[0]=30;
  PF_PAR(pf_ui,PF_CLOCK)[2]=0;  /* orbit */
  PF_PAR(pf_ui,PF_CLOCK)[3]=0;  /* carrier detune */
  PF_PAR(pf_ui,PF_CLOCK)[13]=0; /* quartz drift depth */
  pf_ui.tort[P_O2_FINE]=64;
  pf_ui.tort[P_VINTAGE]=0;
 }
 return result;
}
int pf_save(void){
 projectScratch=pf_ui;
 projectScratch.version=23;
 projectScratch.masterGain=instrument_order_save();
 memset(projectSave.held,0,sizeof projectSave.held);
 projectScratch.seqReserved=(pf_ui.seqReserved&~7u)|pf_seq_state(0,12)
                          |(pf_seq_state(0,13)<<1)|(pf_seq_state(0,14)<<2);
 for(int m=0;m<PF_LAYERS;m++){
  PFSeqLane *lane=&PF_SEQ(projectScratch,m);
  pf_seq_read(m,lane);
  lane->active=pf_seq_state(m,0);
  for(int bank=0;bank<4;bank++)pf_clip_save_clean(&lane->pattern[bank]);

  if(!PF_PAR(pf_ui,m)[23])continue;
  int arp=PF_ARPSETTINGS(pf_ui,m)[0],count=0;
  uint8_t *notes=projectSave.held[m];
  for(int key=0;key<27;key++){
   if(!arp&&!(PF_LATCHED(pf_ui,m)&(1u<<key)))continue;
   int packed=pf_held_key(m,key,arp);
   if(packed<1||packed>135)continue;
   int pos=count++;
   /* Replay the mono keys oldest first to preserve last-note priority. */
   if(m==PF_LEAD&&!arp){
    uint32_t age=pf_lead_key_age(key);
    while(pos>0&&pf_lead_key_age((notes[pos-1]-1)%27)>age){
     notes[pos]=notes[pos-1];
     pos--;
    }
   }
   notes[pos]=packed;
  }
 }
 memset(projectScratch.latched,0,sizeof projectScratch.latched);
 projectScratch.lead.latched=0;
 return plat_store_save(OBJ_PROJ,&projectSave,sizeof projectSave);
}
void pf_apply(void){lfoConfigRow=0;if(!restorePerformance)pf_startup_profile(&pf_ui);int selectedMode=pf_ui.mode;seq_send(10010,1);seq_send(10020,PF_REC_QUANT(pf_ui));seq_send(10011,(pf_ui.seqReserved>>1)&1);seq_send(10012,(pf_ui.seqReserved>>2)&1);for(int m=0;m<PF_LAYERS;m++){pf_ui.mode=m;pf_seq_load(m,&PF_SEQ(pf_ui,m),pf_ui.seqBpm);pf_post(PF_MODE,pf_ui.mode,0);pf_post(PF_GLOBAL,3,PF_INSTRUMENT_SLIP(pf_ui,0));pf_post(PF_GLOBAL,4,PF_ARP_SYNC(pf_ui,m));if(m==PF_LEAD)for(int z=0;z<32;z++)pf_post(PF_LEAD_PARAM,z,pf_ui.lead.mini[z]);for(int i=0;i<PF_NPAR;i++)pf_post(PF_PARAM,i,PF_PAR(pf_ui,pf_ui.mode)[i]);pf_post(PF_NOTE,1,pf_ui.octave);for(int k=0;k<27;k++){pf_post(PF_NOTE,100+k,PF_LEVEL(pf_ui,pf_ui.mode)[k]);pf_post(PF_NOTE,200+k,PF_PAN(pf_ui,pf_ui.mode)[k]);pf_post(PF_NOTE,300+k,PF_FINE(pf_ui,pf_ui.mode)[k]);}if(m==PF_CLOCK)for(int i=0;i<PF_TEMPLE_BYTES;i++)pf_post(PF_TEMPLE_PARAM,i,pf_ui.temple[i]);if(m==PF_TORT){for(int i=0;i<56;i++)pf_post(PF_TORT_PARAM,i,pf_ui.tort[i]);for(int i=0;i<16;i++)pf_post(PF_TORT_ROUTE,i,pf_ui.tortRoutes[i/4][i%4]);}for(int slot=0;slot<4;slot++)for(int k=0;k<8;k++)pf_post(PF_LFO,slot*8+k,PF_LFO(pf_ui,m)[slot][k]);for(int i=0;i<8;i++)pf_post(PF_ARP,i,PF_ARPSETTINGS(pf_ui,m)[i]);pf_post(PF_MIX,3,PF_SPREAD(pf_ui,m));pf_post(PF_MIX,0,PF_MIXPAN(pf_ui,m));pf_post(PF_MIX,1,PF_MUTE(pf_ui,m));pf_post(PF_MIX,2,PF_SOLO(pf_ui,m));pf_play_state=0;pf_freeze_state=0;PF_LATCHED(pf_ui,m)=0;
 if(restorePerformance&&PF_PAR(pf_ui,m)[23])for(int n=0;n<27;n++){
  int packed=projectSave.held[m][n];
  if(packed<1||packed>135)continue;
  int key=(packed-1)%27,keyOct=(packed-1)/27-2;
  if(!PF_ARPSETTINGS(pf_ui,m)[0])PF_LATCHED(pf_ui,m)|=1u<<key;
  pf_post(PF_RECALL_KEY,key,keyOct);
 }
 pf_oldkeys=plat_keys();pf_dirty=1;}pf_transport=pf_process_transport=0;pf_ui.mode=selectedMode;pf_ui.latch=!!PF_PAR(pf_ui,selectedMode)[23];/* Shared startup commands use the least-loaded queue, avoiding TORT overflow. */pf_post(PF_MODE,PF_BRANCH,0);for(int i=0;i<20;i++)pf_post(PF_FX,i,pf_ui.fx[i]);pf_post(PF_GLOBAL,2,pf_ui.metronome);pf_post(PF_GLOBAL,0,pf_ui.transpose);pf_post(PF_FX,20,!!(pf_ui.seqReserved&PF_DELAY_SYNC_BIT));pf_post(PF_FX,21,pf_delay_div(pf_ui.seqReserved));pf_post(PF_MODE,selectedMode,0);}
static void pf_play_on(void){pf_play_state=1;pf_post(PF_PLAY,1,0);}
static void pf_key_on(void){if(!pf_play_state){pf_play_state=1;pf_post(PF_PLAY,2,0);}}
static void pf_stop(void){pf_play_state=0;PF_LATCHED(pf_ui,pf_ui.mode)=0;pf_post(PF_PANIC,0,0);}
static void pf_press_key(int k,int on){if(k<0||k>=27)return;if(on){key_owner[k]=pf_ui.mode;pf_key_on();pf_ui.selected=k;if(PF_ARPSETTINGS(pf_ui,pf_ui.mode)[0]){pf_post(PF_KEY,k,pf_ui.latch?2:1);}else if(pf_ui.latch){PF_LATCHED(pf_ui,pf_ui.mode)^=1u<<k;pf_post(PF_KEY,k,(PF_LATCHED(pf_ui,pf_ui.mode)>>k)&1u);}else pf_post(PF_KEY,k,1);}else {int layer=key_owner[k];if(!PF_PAR(pf_ui,layer)[23]){pf_post(PF_MODE,layer,0);pf_post(PF_KEY,k,0);pf_post(PF_MODE,pf_ui.mode,0);}}pf_dirty=1;}
static void pf_set_mode(int m){int previous=pf_ui.mode;pf_ui.mode=(m%PF_LAYERS+PF_LAYERS)%PF_LAYERS;if(previous!=pf_ui.mode){if(nav.screen==NAV_EDIT)nav_show(NAV_EDIT,0);else if(nav.screen==NAV_ENV)nav_show(NAV_ENV,0);else if(nav.screen==NAV_LFO)nav_show(NAV_LFO,0);}pf_ui.latch=PF_PAR(pf_ui,pf_ui.mode)[23];pf_post(PF_MODE,pf_ui.mode,0);pf_post(PF_NOTE,1,pf_ui.octave);pf_dirty=1;}
static void pf_latch(int enabled){int m=pf_ui.mode;uint32_t old=PF_LATCHED(pf_ui,m),physical=0;for(int k=0;k<27;k++)if((plat_keys()&(1u<<k))&&!(transposeCaptured&(1u<<k))&&key_owner[k]==m)physical|=1u<<k;pf_ui.latch=!!enabled;PF_PAR(pf_ui,m)[23]=pf_ui.latch;if(PF_ARPSETTINGS(pf_ui,m)[0]){PF_LATCHED(pf_ui,m)=0;if(!enabled){pf_post(PF_ARP,8,physical);}pf_dirty=1;return;}if(enabled){PF_LATCHED(pf_ui,m)=pf_layer_active(m)|physical;for(int k=0;k<27;k++)if(PF_LATCHED(pf_ui,m)&(1u<<k))pf_post(PF_KEY,k,1);}else{PF_LATCHED(pf_ui,m)=0;for(int k=0;k<27;k++)if((old&(1u<<k))&&!(physical&(1u<<k)))pf_post(PF_KEY,k,0);}pf_dirty=1;}
static void pf_slip_turn(int d){int value=pf_clip(PF_INSTRUMENT_SLIP(pf_ui,0)+d,0,100);for(int m=0;m<PF_LAYERS;m++)PF_INSTRUMENT_SLIP(pf_ui,m)=value;pf_post(PF_GLOBAL,3,value);pf_dirty=1;}
static void pf_arp_set(int index,int delta){if(index==3){pf_slip_turn(delta);return;}int m=pf_ui.mode;const int lo[8]={0,30,0,0,1,0,2,0},hi[8]={1,240,5,100,27,3,95,100};int value=pf_clip(PF_ARPSETTINGS(pf_ui,m)[index]+delta,lo[index],hi[index]);PF_ARPSETTINGS(pf_ui,m)[index]=value;if(index==0&&!value&&pf_ui.latch)PF_LATCHED(pf_ui,m)=pf_layer_active(m);pf_post(PF_ARP,index,value);if(m==1){int params[4]={12,13,14,15};int setting[4]={1,4,5,6};for(int k=0;k<4;k++)if(index==setting[k])PF_PAR(pf_ui,1)[params[k]]=value;}pf_dirty=1;}
static void pf_set_param(int i,int delta){if(pf_ui.mode==1&&i>=12&&i<=15){pf_arp_set((int[]){1,4,5,6}[i-12],delta);return;}int m=pf_ui.mode,lo,hi;pf_limits(m,i,&lo,&hi);int step=i==22?1:(m==2&&i==11)?20:i==25||(m==0&&i==12)?5:1;int base=i==16?PF_LEVEL(pf_ui,pf_ui.mode)[pf_ui.selected]:i==17?pf_ui.octave:i==18?PF_PAN(pf_ui,pf_ui.mode)[pf_ui.selected]:i==19?PF_FINE(pf_ui,pf_ui.mode)[pf_ui.selected]:PF_PAR(pf_ui,m)[i];int value=pf_clip(base+delta*step,lo,hi);PF_PAR(pf_ui,m)[i]=value;if(i>=20&&i<=22){for(int layer=0;layer<PF_LAYERS;layer++){PF_PAR(pf_ui,layer)[i]=value;pf_post(PF_MODE,layer,0);pf_post(PF_PARAM,i,value);}pf_post(PF_MODE,m,0);}else pf_post(PF_PARAM,i,value);if(i==16){PF_LEVEL(pf_ui,pf_ui.mode)[pf_ui.selected]=value;pf_post(PF_NOTE,100+pf_ui.selected,value);}if(i==17){pf_ui.octave=value;pf_post(PF_NOTE,1,value);}if(i==18){PF_PAN(pf_ui,pf_ui.mode)[pf_ui.selected]=value;pf_post(PF_NOTE,200+pf_ui.selected,value);}if(i==19){PF_FINE(pf_ui,pf_ui.mode)[pf_ui.selected]=value;pf_post(PF_NOTE,300+pf_ui.selected,value);}if(i==23)pf_latch(value);pf_dirty=1;}

static int delay_sync_on(void){return !!(pf_ui.seqReserved&PF_DELAY_SYNC_BIT);}
static void delay_set_sync(int enabled){if(enabled)pf_ui.seqReserved|=PF_DELAY_SYNC_BIT;else pf_ui.seqReserved&=~PF_DELAY_SYNC_BIT;pf_post(PF_FX,20,!!enabled);pf_dirty=1;}
static void delay_div_knob(int d){const uint8_t order[16]={13,12,0,1,2,3,15,14,4,5,6,7,8,9,10,11};int slot=2;for(int i=0;i<16;i++)if(order[i]==pf_delay_div(pf_ui.seqReserved))slot=i;int value=order[pf_clip(slot+d,0,15)];pf_ui.seqReserved=(pf_ui.seqReserved&~PF_DELAY_DIV_MASK)|(value<<PF_DELAY_DIV_SHIFT);pf_post(PF_FX,21,value);pf_dirty=1;}
static void delay_div_value(char *b){int selected=pf_delay_div(pf_ui.seqReserved),actual=pf_delay_fit_div(pf_ui.seqBpm,selected);b[0]=0;pf_cat(b,pf_delay_div_name(actual));if(selected!=actual)pf_cat(b," AUTO");}
static int seq_division_turn(int,int);
static int timing_knob(int k,int d,uint32_t buttons){
 int target=fx_page()&&fx_ui_index(pf_ui.page,k)==8&&pf_ui.fx[9]==0?1:pf_ui.page==8&&(k==1||k==2)?2:(pf_ui.page==32&&k==0)?3:0;
 if(pf_ui.page==40&&k==0&&(buttons&(1u<<B_GLO))){
  unsigned gesture=1u<<4;
  if(!(globalTimingUsed&gesture)){
   globalTimingUsed|=gesture;
   int quant=PF_REC_QUANT(pf_ui);
   if(quant)seq_send(10041,quant);
  }
  return 1;
 }
 if(!target)return 0;int m=pf_ui.mode;PFSeqLane *q=&PF_SEQ(pf_ui,m);
 if(buttons&(1u<<B_GLO)){unsigned bit=1u<<target;globalUsed=1;if(!(globalTimingUsed&bit)){globalTimingUsed|=bit;if(target==1)delay_set_sync(!delay_sync_on());if(target==2){pf_ui.seqReserved^=1u<<(PF_ARP_SYNC_SHIFT+m);pf_post(PF_GLOBAL,4,PF_ARP_SYNC(pf_ui,m));}if(target==3){q->sync=!q->sync;seq_send(offsetof(PFSeqLane,sync),q->sync);}}pf_dirty=1;return 1;}
 if(target==1){if(delay_sync_on())delay_div_knob(d);else{pf_ui.fx[8]=pf_clip(pf_ui.fx[8]+d*5,5,1000);pf_post(PF_FX,8,pf_ui.fx[8]);}}
 if(target==2)pf_arp_set(PF_ARP_SYNC(pf_ui,m)?2:1,d);
 if(target==3){if(q->sync){q->division=seq_division_turn(q->division,d);seq_send(offsetof(PFSeqLane,division),q->division);}else{q->bpm=pf_clip(q->bpm+d,30,240);seq_send(offsetof(PFSeqLane,bpm),q->bpm&255);seq_send(offsetof(PFSeqLane,bpm)+1,q->bpm>>8);}}
 pf_dirty=1;return 1;
}
static void fx_ui_knob(int k,int d){int i=fx_ui_index(pf_ui.page,k);if(i==-100)return;if(i<0)pf_set_param(-i,d);else{pf_ui.fx[i]=pf_clip(pf_ui.fx[i]+d*(i==8?5:1),fxLow[i],fxHigh[i]);pf_post(PF_FX,i,pf_ui.fx[i]);}pf_dirty=1;}
static void fx_ui_value(int k,char *b){int i=fx_ui_index(pf_ui.page,k);b[0]=0;if(i==-100)return;if(i<0){pf_num(b,PF_PAR(pf_ui,pf_ui.mode)[-i]);pf_cat(b," %");return;}if(i==8&&pf_ui.fx[9]==0&&delay_sync_on()){delay_div_value(b);return;}int v=pf_ui.fx[i];if(i==9)pf_cat(b,(const char*[]){"DELAY","GRANULAR","STRETCH"}[v]);else if(i==6||i==14)pf_cat(b,v?"FROZEN":"LIVE");else{pf_num(b,v);pf_cat(b,i==8?(pf_ui.fx[9]?" POS":" ms"):i==11?" ST":" %");}}
static const uint8_t lead_mini_map[3][4]={{3,0,8,14},{4,1,9,6},{5,2,10,7}};
static void lead_knob(int k,int d){if(pf_ui.page==45){if(k<3)pf_set_param(8+k,d);return;}if(pf_ui.page==46){if(k==3){pf_set_param(13,d);return;}int id=k==0?11:k==1?12:15,value=pf_ui.lead.mini[id];if(k==1)value=(value&~16)|(pf_clip(!!(value&16)+d,0,1)?16:0);else value=pf_clip(value+d,0,127);pf_ui.lead.mini[id]=value;pf_post(PF_LEAD_PARAM,id,value);if(k==0){if(value)pf_ui.lead.mini[12]|=8;pf_post(PF_LEAD_PARAM,12,pf_ui.lead.mini[12]);}return;}int row=pf_ui.page-42,id=lead_mini_map[row][k],value=pf_ui.lead.mini[id];int high=k<2?5:127;value=pf_clip(value+d,0,high);pf_ui.lead.mini[id]=value;pf_post(PF_LEAD_PARAM,id,value);if(k==2){int bit=1<<row;if(value)pf_ui.lead.mini[12]|=bit;pf_post(PF_LEAD_PARAM,12,pf_ui.lead.mini[12]);}if(row>0&&k==3){int cents=pf_clip((value-64)*11,-700,700),mag=cents<0?-cents:cents,lo=row==1?18:20;pf_ui.lead.mini[lo]=mag&127;pf_ui.lead.mini[lo+1]=((mag>>7)&7)|(cents<0?8:0);pf_post(PF_LEAD_PARAM,lo,pf_ui.lead.mini[lo]);pf_post(PF_LEAD_PARAM,lo+1,pf_ui.lead.mini[lo+1]);}}

/* SLOOP step_down/up and its original note-editor and recording core.
 * Upstream notices and exact pins are in docs/SEQUENCER_UPSTREAM_REUSE.md. */
/* Saved division IDs stay stable; expose slow values before the quarter note. */
static int seq_division_turn(int value,int delta){
 const uint8_t order[9]={8,7,6,0,1,2,3,4,5};int slot=3;
 for(int i=0;i<9;i++)if(order[i]==value)slot=i;
 return order[pf_clip(slot+delta,0,8)];
}
static void seq_knob(int k,int d){int m=pf_ui.mode,b=pf_seq_state(m,0);PFSeqLane*q=&PF_SEQ(pf_ui,m);
 if(pf_ui.page==32){if(k==1){int n=pf_clip(pf_clip_length(&q->pattern[b])+d,1,64);pf_clip_length_set(&q->pattern[b],n);seq_send(b*sizeof(PFSeqPattern),q->pattern[b].length);}if(k==2){q->swing=pf_clip(q->swing+d,0,100);seq_send(offsetof(PFSeqLane,swing),q->swing);}if(k==3)pf_slip_turn(d);}
 if(pf_ui.page==40){if(k==0){int quant=pf_clip(PF_REC_QUANT(pf_ui)+d,0,5);pf_ui.seqReserved=(pf_ui.seqReserved&~PF_REC_QUANT_MASK)|(quant<<PF_REC_QUANT_SHIFT);seq_send(10020,quant);}if(k==1){q->gate=pf_clip(q->gate+d,1,128);seq_send(offsetof(PFSeqLane,gate),q->gate);}if(k==2){int on=d>0;pf_ui.seqReserved=(pf_ui.seqReserved&~2u)|(on<<1);seq_send(10011,on);}if(k==3){pf_ui.metronome=pf_clip(pf_ui.metronome+d,0,1);pf_post(PF_GLOBAL,2,pf_ui.metronome);}}
 if(pf_ui.page==33)seq_send(10000,k);pf_dirty=1;
}
static void seq_poll_record(void){pf_ui.seqBpm=pf_seq_state(0,16);for(int m=0;m<PF_LAYERS;m++){unsigned revision=pf_seq_state(m,22);if(revision!=seqRevision[m]){pf_seq_read(m,&PF_SEQ(pf_ui,m));seqRevision[m]=revision;}}}

static void global_knob(int k,int d){
 if(k==0){pf_ui.seqBpm=pf_clip(pf_ui.seqBpm+d,30,240);seq_send(10002,pf_ui.seqBpm);}
 if(k==1){pf_ui.metronome=pf_clip(pf_ui.metronome+d,0,1);pf_post(PF_GLOBAL,2,pf_ui.metronome);}
 if(k==2){pf_ui.transpose=pf_clip(pf_ui.transpose+d,-48,48);pf_post(PF_GLOBAL,0,pf_ui.transpose);ui_transpose_until=plat_ms()+1200;}
}
static void mixer_knob(int m,int d){m=ui_order[m];
 if(mixer_index()==1){PF_MIXPAN(pf_ui,m)=pf_clip(PF_MIXPAN(pf_ui,m)+d,-100,100);pf_post(PF_MODE,m,0);pf_post(PF_MIX,0,PF_MIXPAN(pf_ui,m));pf_post(PF_MODE,pf_ui.mode,0);}
 else{int saved=pf_ui.mode;pf_set_mode(m);pf_set_param((int[]){7,0,27,24}[mixer_index()],d);pf_set_mode(saved);}
}
static void project_transport(void){int target=pf_ui.mode,any=0,countOwner=-1,started=0;for(int m=0;m<PF_LAYERS;m++)any|=pf_seq_state(m,3)||pf_seq_state(m,15);
 if(!any&&pf_seq_state(0,13))for(int m=0;m<PF_LAYERS;m++)if(pf_seq_state(m,9)){countOwner=m;break;}
 for(int m=0;m<PF_LAYERS;m++){pf_post(PF_MODE,m,0);if(any)seq_send(10001,0);else if(countOwner<0||m==countOwner){seq_send(10001,1);started=1;}}pf_transport=started?2:0;pf_post(PF_MODE,target,0);}
static void process_transport(void){int target=pf_ui.mode,any=pf_process_transport;pf_process_transport=!any;for(int m=0;m<PF_LAYERS;m++){pf_ui.mode=m;pf_post(PF_MODE,m,0);if(any)pf_stop();else pf_play_on();}pf_ui.mode=target;pf_post(PF_MODE,target,0);}
static void instrument_swap_finish(void){
 int result=pf_channel_swap_result();
 if(!result)return;
 instrumentSwapPending=0;
 instrumentSwapFailed=result<0;
 if(result<0)return;

 int from=pf_ui.mode,to=instrumentChoice;
 int first=instrument_slot(from),second=instrument_slot(to);
 ui_order[first]=to;ui_order[second]=from;
 pf_seq_read(from,&PF_SEQ(pf_ui,from));
 pf_seq_read(to,&PF_SEQ(pf_ui,to));
 for(int i=0;i<3;i++){
  int param=(int[]){7,24,27}[i],value=PF_PAR(pf_ui,from)[param];
  PF_PAR(pf_ui,from)[param]=PF_PAR(pf_ui,to)[param];PF_PAR(pf_ui,to)[param]=value;
 }
 int value=PF_MIXPAN(pf_ui,from);
 PF_MIXPAN(pf_ui,from)=PF_MIXPAN(pf_ui,to);PF_MIXPAN(pf_ui,to)=value;
 value=PF_MUTE(pf_ui,from);
 PF_MUTE(pf_ui,from)=PF_MUTE(pf_ui,to);PF_MUTE(pf_ui,to)=value;
 value=PF_SOLO(pf_ui,from);
 PF_SOLO(pf_ui,from)=PF_SOLO(pf_ui,to);PF_SOLO(pf_ui,to)=value;
 for(int i=0;i<8;i++){
  value=PF_ARPSETTINGS(pf_ui,from)[i];
  PF_ARPSETTINGS(pf_ui,from)[i]=PF_ARPSETTINGS(pf_ui,to)[i];
  PF_ARPSETTINGS(pf_ui,to)[i]=value;
 }
 if(PF_ARP_SYNC(pf_ui,from)!=PF_ARP_SYNC(pf_ui,to))
  pf_ui.seqReserved^=(1u<<(PF_ARP_SYNC_SHIFT+from))|(1u<<(PF_ARP_SYNC_SHIFT+to));
 pf_set_mode(to);
 instrumentPicker=0;
 pf_dirty=1;
}

void pf_app_input(void){nav_adopt();uint32_t buttons=plat_buttons(),pressed=buttons&~pf_oldbuttons,keys=plat_keys(),down=keys&~pf_oldkeys,up=pf_oldkeys&~keys;uint32_t now=plat_ms();for(int b=0;b<NB;b++)if(pressed&(1u<<b))pf_press_ms[b]=now;
 uint32_t released=pf_oldbuttons&~buttons,shiftButtons=buttons|(released&(1u<<B_GLO));int encoder[NE];
 if(pressed&(1u<<B_PLAY))playUsed=0;
 if(pressed&(1u<<B_REC)){recUsed=0;if(buttons&(1u<<B_GLO)){globalUsed=1;recUsed=1;seq_send(10042,0);}}
 if(pressed&(1u<<B_GLO)){globalUsed=globalTimingUsed=0;}
 /* Poll before resolving GLO release: the final detent can share its frame.
  * Navigation encoders still perform their original context-specific action. */
 for(int r=0;r<NE;r++){encoder[r]=plat_enc(r);if(encoder[r]&&(shiftButtons&(1u<<B_GLO)))globalUsed=1;}
 /* A tap navigates; a held modifier or any consumed chord never does. Existing
  * physical notes are not shortcut keys: only fresh downs consume transpose. */
 if((buttons&(1u<<B_GLO))&&((pressed&~(1u<<B_GLO))||down))globalUsed=1;
 int recordLayer=pf_ui.mode,recStarting=0;
 if(pressed&(1u<<B_HOME))homePickerUsed=!!(buttons&(1u<<B_PLAY));
 if(instrumentSwapPending)instrument_swap_finish();
 if(!hardwareProjectMenu&&!instrumentPicker&&(pressed&(1u<<B_SAVE))){
  hardwareProjectMenu=1;
  hardwareProjectAction=hardwareProjectConfirm=0;
  pressed&=~(1u<<B_SAVE);
 }
 if(hardwareProjectMenu){
  int delta=encoder[EN_K1]+encoder[EN_SELECT]+encoder[EN_PRESET];
  if(delta){
   hardwareProjectAction=delta>0&&hardwareProjectExists;
   hardwareProjectConfirm=0;
  }
  if(pressed&(1u<<B_HOME)){hardwareProjectMenu=0;homePickerUsed=1;}
  else if((!hardwareProjectAction||!(keys|up))&&(pressed&((1u<<B_SAVE)|(1u<<B_EDIT)))){
   if(hardwareProjectExists&&!hardwareProjectConfirm)hardwareProjectConfirm=1;
   else if(hardwareProjectAction){hardwareProjectMenu=0;project_recall();}
   else{hardwareProjectMenu=0;savePending=1;}
  }
  pf_dirty=1;
  goto performance_keys;
 }
 int pickerShortcut=mixer_page()&&(buttons&(1u<<B_GLO))&&(pressed&(1u<<B_EDIT));
 int homeHold=(buttons&(1u<<B_HOME))&&!(buttons&(1u<<B_PLAY))&&!homePickerUsed
              &&now-pf_press_ms[B_HOME]>=500;
 if(!instrumentPicker&&(pickerShortcut||homeHold)){
  if(homeHold)homePickerUsed=1;
  if(pickerShortcut)globalUsed=1;
  instrumentPicker=1;
  instrumentChoice=pf_ui.mode;
  instrumentSwapFailed=0;
  pressed&=~(1u<<B_EDIT);
  ui_overlay_until=0;
  pf_dirty=1;
 }
 if(instrumentPicker){
  if(!instrumentSwapPending){
   int delta=encoder[EN_SELECT]+encoder[EN_PRESET];
   if(delta){instrumentChoice=ui_next_mode(instrumentChoice,delta);instrumentSwapFailed=0;pf_dirty=1;}
   for(int slot=0;slot<PF_LAYERS;slot++)if(encoder[EN_K1+slot]){instrumentChoice=ui_order[slot];instrumentSwapFailed=0;pf_dirty=1;}
   if(pressed&(1u<<B_HOME))instrumentPicker=0;
   else if(pressed&(1u<<B_EDIT)){
    if(instrumentChoice==pf_ui.mode)instrumentPicker=0;
    else if(!keys&&!up&&!pf_commands_pending()&&pf_post(PF_CHANNEL_SWAP,instrumentChoice,0))instrumentSwapPending=1;
    else instrumentSwapFailed=1;
   }
  }
  if(pressed&(1u<<B_HOME))homePickerUsed=1;
  goto performance_keys;
 }
if((released&(1u<<B_GLO))&&!globalUsed&&now-pf_press_ms[B_GLO]<PF_SHIFT_TAP_MS)nav_button(B_GLO);
 if((buttons&(1u<<B_GLO))&&(pressed&((1u<<B_ARP)|(1u<<B_SEQ)))){globalUsed=1;int m=pf_ui.mode;if(pressed&(1u<<B_ARP)){PF_MUTE(pf_ui,m)=!PF_MUTE(pf_ui,m);pf_post(PF_MIX,1,PF_MUTE(pf_ui,m));}if(pressed&(1u<<B_SEQ)){PF_SOLO(pf_ui,m)=!PF_SOLO(pf_ui,m);pf_post(PF_MIX,2,PF_SOLO(pf_ui,m));seqUsed=1;}pressed&=~((1u<<B_ARP)|(1u<<B_SEQ));pf_dirty=1;}
 if(pressed&(1u<<B_SEQ))seqUsed=0;
 if((released&(1u<<B_SEQ))&&!seqUsed)nav_button(B_SEQ);
 seq_poll_record();
 for(int p=0;p<7;p++)if(pressed&(1u<<pf_page_button[p])){
 if(p==5||p==4)continue;
 if(p==0&&(buttons&(1u<<B_PLAY))){process_transport();playUsed=1;}
 nav_button(pf_page_button[p]);
 }
 if((released&(1u<<B_PLAY))&&!playUsed)project_transport();
 if((buttons&(1u<<B_REC))&&!recUsed&&now-pf_press_ms[B_REC]>=400){recUsed=1;pf_freeze_state=!pf_freeze_state;pf_post(PF_FREEZE,pf_freeze_state,0);pf_dirty=1;}
 recordLayer=pf_ui.mode;
 recStarting=(released&(1u<<B_REC))&&!recUsed&&!pf_seq_state(pf_ui.mode,8)&&!pf_seq_state(pf_ui.mode,9);
 if((released&(1u<<B_REC))&&!recUsed){
  int m=pf_ui.mode;
  seq_send(10003,1);
  if(recStarting&&(pf_seq_state(m,3)||pf_seq_state(m,13))){
   for(int k=0;k<27;k++)if((pf_oldkeys&(1u<<k))&&!(transposeCaptured&(1u<<k))&&seqCaptureOwner[k]==m){seq_send(10004,seqOct[k]|128);seqCaptureKind[k]=3;}
   for(int n=0;n<128;n++)if(seqMidiHeld[m][n>>5]&(1u<<(n&31)))seq_send(10004,n|128);
  }
  pf_dirty=1;
 }
 if(pressed&(1u<<B_SEL))pf_latch(!pf_ui.latch);
 if(pressed&(1u<<B_EDIT)){if(pf_ui.mode==PF_CLOCK)temple_edit_pending=1;else nav_button(B_EDIT);}
 if(temple_edit_pending==1&&(buttons&(1u<<B_EDIT))&&pf_ui.mode==PF_CLOCK&&now-pf_press_ms[B_EDIT]>=400){temple_edit_pending=2;nav.screen=NAV_EDIT;nav.edit=0;pf_ui.page=59;ui_overlay_until=0;pf_dirty=1;}
 if((released&(1u<<B_EDIT))&&temple_edit_pending){if(temple_edit_pending==1&&pf_ui.mode==PF_CLOCK){if(temple_deep())nav_show(NAV_EDIT,0);else nav_button(B_EDIT);}temple_edit_pending=0;}

 
 if(pressed&(1u<<B_OCTDN)){pf_ui.octave=pf_clip(pf_ui.octave-1,-2,2);pf_post(PF_NOTE,1,pf_ui.octave);pf_dirty=1;}
 if(pressed&(1u<<B_OCTUP)){pf_ui.octave=pf_clip(pf_ui.octave+1,-2,2);pf_post(PF_NOTE,1,pf_ui.octave);pf_dirty=1;}
 int d=encoder[EN_PRESET];if(d)pf_set_mode((mixer_page()||memcmp(ui_order,factoryOrder,sizeof ui_order))?ui_next_mode(pf_ui.mode,d):pf_ui.mode+d);d=encoder[EN_SELECT];if(d){if(mixer_page())pf_set_mode(ui_next_mode(pf_ui.mode,d));else if(nav.screen==NAV_GLOBAL)nav_show(NAV_GLOBAL,nav.global+d);else if(nav.screen==NAV_FX)nav_show(NAV_FX,nav.fx+d);else if(nav.screen==NAV_LFO){if(pf_ui.page==PF_LFO_SETUP)lfoConfigRow=nav_wrap(lfoConfigRow+d,4);else nav_show(NAV_LFO,nav.lfo+d);}else if(pf_ui.mode==PF_CLOCK&&pf_ui.page==66){nav.edit=nav_wrap(nav.edit+d,6);}else if(temple_deep()){if(pf_ui.page==4)pf_ui.selected=(pf_ui.selected+d+2700)%27;else{nav.edit=nav_wrap(nav.edit+d,6);pf_ui.page=59;}}else if(pf_ui.mode==PF_CLOCK&&nav.screen==NAV_ENV)nav_show(NAV_ENV,nav.env+d);else if(pf_ui.mode==PF_CLOCK&&nav.screen==NAV_LFO)nav_show(NAV_LFO,nav.lfo+d);else if(pf_ui.mode==PF_CLOCK&&nav.screen==NAV_FX)nav_show(NAV_FX,nav.fx+d);else if(pf_ui.mode==PF_CLOCK&&nav.screen==NAV_ARP)nav_show(NAV_ARP,nav.arp+d);else if(pf_ui.mode==PF_CLOCK&&nav.screen==NAV_EDIT)nav_show(NAV_EDIT,nav.edit+d);else if(seq_page()){ /* no note editor */ }else pf_ui.selected=(pf_ui.selected+d+2700)%27;pf_dirty=1;}d=encoder[EN_ALGO];if(d&&!seq_page()){if(nav.screen==NAV_MIXER){nav_show(NAV_MIXER,nav.mix+d);}else if(nav.screen==NAV_GLOBAL){nav_show(NAV_GLOBAL,nav.global+d);}else if(nav.screen==NAV_FX){if(pf_ui.page==36||pf_ui.page==38)fxRows[pf_ui.page==38]=(fxRows[pf_ui.page==38]+d%2+2)%2;else nav_show(NAV_FX,nav.fx+d);pf_dirty=1;}else if(pf_ui.mode==PF_TORT){pf_ui.tort[P_CUTOFF]=pf_clip(pf_ui.tort[P_CUTOFF]+d,0,127);pf_post(PF_TORT_PARAM,P_CUTOFF,pf_ui.tort[P_CUTOFF]);pf_dirty=1;}else if(pf_ui.mode==PF_BRANCH)pf_set_param(8,d);else if(temple_deep()){pf_ui.page=pf_ui.page==59?60:pf_ui.page==60?2:pf_ui.page==2?67:pf_ui.page==67?4:59;ui_overlay_until=0;pf_dirty=1;}else if(pf_ui.mode==2){pf_set_param(6,d);pf_dirty=1;}else pf_set_param(6,d*3);}
 for(int k=0;k<4;k++){d=encoder[EN_K1+k];if(!d)continue;ui_touch(k);if(timing_knob(k,d,shiftButtons))continue;if(fx_page()){fx_ui_knob(k,d);continue;}if(pf_ui.page==PF_OSC_TUNING){int m=pf_ui.mode;if(m==PF_TORT){int id=(int[]){52,53,54,P_O2_SEMI}[k],x=pf_ui.tort[id];if(k==1||k==2)x=((int)pf_clip(pf_fine_decode(x)+d,-50,50))&127;else x=pf_clip(x+d,0,tort_max(id));pf_ui.tort[id]=x;pf_post(PF_TORT_PARAM,id,x);}else if(m==PF_LEAD&&k<3){int id=28+k,x=((int)pf_clip(pf_fine_decode(pf_ui.lead.mini[id])+d,-50,50))&127;pf_ui.lead.mini[id]=x;pf_post(PF_LEAD_PARAM,id,x);}pf_dirty=1;continue;}if(pf_ui.page==PF_LFO_SETUP){int m=pf_ui.mode,index=4+lfoConfigRow;const int hi[4]={1,1,359,100};int16_t *value=&PF_LFO(pf_ui,m)[k][index];*value=pf_clip(*value+d,0,hi[lfoConfigRow]);pf_post(PF_LFO,k*8+index,*value);pf_dirty=1;continue;}if(temple_ui_page()){int i=temple_ui_param(k);if(i==-1){PF_SPREAD(pf_ui,PF_CLOCK)=pf_clip(PF_SPREAD(pf_ui,PF_CLOCK)+d,0,100);pf_post(PF_MIX,3,PF_SPREAD(pf_ui,PF_CLOCK));}else if(i>=128){int id=i-128;pf_ui.temple[id]=pf_clip(pf_ui.temple[id]+d,0,temple_max(id));pf_post(PF_TEMPLE_PARAM,id,pf_ui.temple[id]);}else pf_set_param(i,d);if(pf_ui.page==1){pf_ui.temple[39]|=1;pf_post(PF_TEMPLE_PARAM,39,pf_ui.temple[39]);}if(pf_ui.page==65||i==166){if(pf_ui.page==65&&!(pf_ui.temple[39]&2)&&pf_ui.temple[38]==100){pf_ui.temple[38]=200;pf_post(PF_TEMPLE_PARAM,38,200);}pf_ui.temple[39]|=2;pf_post(PF_TEMPLE_PARAM,39,pf_ui.temple[39]);}if(pf_ui.page==66||(pf_ui.page==59&&i>=168)){pf_ui.temple[3]|=1u<<(nav.edit%6);pf_post(PF_TEMPLE_PARAM,3,pf_ui.temple[3]);}pf_dirty=1;continue;}if(pf_ui.mode==PF_BRANCH&&(pf_ui.page==2||pf_ui.page==3)){pf_set_param(branch_edit_param(pf_ui.page,k),d);pf_dirty=1;}else if(pf_ui.page==PF_SYSTEM){continue;}else if(pf_ui.page==5){if(k<3)pf_set_param(20+k,d);pf_dirty=1;}else if(pf_ui.page==PF_EXCITER){pf_set_param(ui_exciter_param(pf_ui.mode,k),d);pf_dirty=1;}else if(pf_ui.page==0&&pf_ui.mode!=PF_LEAD&&pf_ui.mode!=PF_TORT){int i=ui_voice_param(pf_ui.mode,k);if(i<0){int m=pf_ui.mode;PF_SPREAD(pf_ui,m)=pf_clip(PF_SPREAD(pf_ui,m)+d,0,100);pf_post(PF_MIX,3,PF_SPREAD(pf_ui,m));}else pf_set_param(i,d);pf_dirty=1;}else if(pf_ui.page==1){int i=ui_env_param(pf_ui.mode,k);if(i>=0)pf_set_param(i,d);pf_dirty=1;}else if(mixer_page()){mixer_knob(k,d);pf_dirty=1;}else if(pf_ui.mode==PF_LEAD&&pf_ui.page>=42&&pf_ui.page<=46){lead_knob(k,d);pf_dirty=1;}else if(pf_ui.page==PF_PROJECT){global_knob(k,d);pf_dirty=1;}else if(seq_page()){seq_knob(k,d);}else if(pf_ui.page==30||(pf_ui.mode==PF_BRANCH&&pf_ui.page==2&&k==3)){if(k==0||pf_ui.page!=30){int m=pf_ui.mode;PF_SPREAD(pf_ui,m)=pf_clip(PF_SPREAD(pf_ui,m)+d,0,100);pf_post(PF_MIX,3,PF_SPREAD(pf_ui,m));pf_dirty=1;}}else if(pf_ui.mode==PF_CLOCK&&pf_ui.page>=58){int i=temple_controls[pf_ui.page-58][k];pf_ui.temple[i]=pf_clip(pf_ui.temple[i]+d,0,temple_max(i));pf_post(PF_TEMPLE_PARAM,i,pf_ui.temple[i]);pf_dirty=1;}else if(pf_ui.page>=54&&pf_ui.mode==PF_TORT){int slot=pf_ui.page-54;int8_t *value=&pf_ui.tortRoutes[slot][k];*value=pf_clip(*value+d,k%2?-100:0,k%2?100:pf_lfo_count(PF_TORT)-1);pf_post(PF_TORT_ROUTE,slot*4+k,*value);pf_dirty=1;}else if(pf_ui.page>=18){int i=tort_controls[pf_ui.page-18][k];int value=pf_ui.tort[i];int step=1;if(i==P_FMORPH){pf_ui.tort[P_FTYPE]=F_SEM;pf_post(PF_TORT_PARAM,P_FTYPE,F_SEM);}pf_ui.tort[i]=pf_clip(value+d*step,0,tort_max(i));pf_post(PF_TORT_PARAM,i,pf_ui.tort[i]);pf_dirty=1;}else if(pf_ui.page>=10){int m=pf_ui.mode,slot=(pf_ui.page-10)/2,index=ui_lfo_index(pf_ui.page,k);const int hi[8]={100,100,5,pf_lfo_count(m)-1,1,1,359,100};int16_t *value=&PF_LFO(pf_ui,pf_ui.mode)[slot][index];*value=pf_clip(*value+d,0,hi[index]);pf_post(PF_LFO,slot*8+index,*value);pf_dirty=1;}else if(pf_ui.page>=8){pf_arp_set((pf_ui.page-8)*4+k,d);}else if(pf_ui.page==7){if(k==0)pf_set_param(7,d);if(k==1){int m=pf_ui.mode;PF_MIXPAN(pf_ui,m)=pf_clip(PF_MIXPAN(pf_ui,m)+d*2,-100,100);pf_post(PF_MIX,3,PF_SPREAD(pf_ui,m));pf_post(PF_MIX,0,PF_MIXPAN(pf_ui,m));}if(k==2)pf_set_param(24,d);if(k==3)pf_set_param(27,d);pf_dirty=1;}else if((buttons&(1u<<B_HOME))&&k<PF_LAYERS){int target=pf_ui.mode;pf_set_mode(k);pf_set_param(7,d);pf_set_mode(target);}else pf_set_param(pf_ui.page*4+k,d);}

performance_keys:
 for(int k=0;k<27;k++){uint32_t bit=1u<<k;int m=pf_ui.mode;
 if((up&bit)&&(transposeCaptured&bit)){transposeCaptured&=~bit;continue;}
 if((up&bit)&&(seqCaptured&bit)){seqCaptured&=~bit;if(k==seqWhite[8]){for(int layer=0;layer<PF_LAYERS;layer++){pf_post(PF_MODE,layer,0);seq_send(10013,0);}pf_post(PF_MODE,m,0);}continue;}
 if((down&bit)&&(buttons&(1u<<B_SEQ))&&(buttons&(1u<<B_GLO))&&(k==seqWhite[8]||k==seqWhite[9])){
  seqUsed=globalUsed=1;seqCaptured|=bit;
  for(int layer=0;layer<PF_LAYERS;layer++){pf_post(PF_MODE,layer,0);seq_send(k==seqWhite[8]?10013:10014,1);}
  pf_post(PF_MODE,m,0);continue;
 }
 if((down&bit)&&(buttons&(1u<<B_GLO))){transposeCaptured|=bit;pf_ui.transpose=pf_clip(k-7+12*pf_ui.octave,-48,48);pf_post(PF_GLOBAL,0,pf_ui.transpose);ui_transpose_until=now+1200;pf_dirty=1;continue;}
 if(down&bit){seqCaptureOwner[k]=m;seqOct[k]=pf_clip(53+k+12*pf_ui.octave,0,127);seqCaptureKind[k]=0;if((recStarting&&m==recordLayer)||pf_seq_state(m,8)||pf_seq_state(m,9)||pf_seq_state(m,15)){seq_send(10004,seqOct[k]|128);seqCaptureKind[k]=3;}pf_press_key(k,1);}
 if(up&bit){int owner=seqCaptureOwner[k];pf_press_key(k,0);if(seqCaptureKind[k]==3||pf_seq_state(owner,8)){pf_post(PF_MODE,owner,0);seq_send(10004,seqOct[k]);pf_post(PF_MODE,pf_ui.mode,0);}seqCaptureKind[k]=0;}}

 uint32_t midi;while(plat_midi_in(&midi)){int status=(midi>>8)&255,note=(midi>>16)&127,vel=(midi>>24)&127,ch=status&15;if((status&240)==176&&note==1){pf_post(PF_MODE,PF_LEAD,0);pf_post(PF_LEAD_BEND,1,vel);pf_post(PF_MODE,pf_ui.mode,0);}if((status&240)==224){pf_post(PF_MODE,PF_LEAD,0);pf_post(PF_LEAD_BEND,0,(note|(vel<<7))-8192);pf_post(PF_MODE,pf_ui.mode,0);}if((status&240)==144||(status&240)==128){int on=(status&240)==144&&vel>0;int m=on?pf_ui.mode:seqMidiOwner[ch][note];if(m>=PF_LAYERS)m=pf_ui.mode;pf_post(PF_MODE,m,0);if(on){seqMidiOwner[ch][note]=m;seqMidiHeld[m][note>>5]|=1u<<(note&31);
 if((recStarting&&m==recordLayer)||pf_seq_state(m,8)||pf_seq_state(m,9)){seqMidiKind[ch][note]=3;seq_send(10004,note|128|(vel<<8));}pf_post(PF_MIDI,note,vel);
 }else{seqMidiHeld[m][note>>5]&=~(1u<<(note&31));pf_post(PF_MIDI,note,0);if(seqMidiKind[ch][note]==3||pf_seq_state(m,8)||pf_seq_state(m,15))seq_send(10004,note);seqMidiKind[ch][note]=0;}pf_post(PF_MODE,pf_ui.mode,0);}
 if((status&240)==176&&note==123){for(int m=0;m<PF_LAYERS;m++){pf_post(PF_MODE,m,0);for(int n=0;n<128;n++)if(seqMidiHeld[m][n>>5]&(1u<<(n&31))){pf_post(PF_MIDI,n,0);seq_send(10004,n);}}memset(seqMidiHeld,0,sizeof seqMidiHeld);pf_post(PF_MODE,pf_ui.mode,0);}}

 pf_transport=(pf_seq_state(0,3)||pf_seq_state(1,3)||pf_seq_state(2,3)||pf_seq_state(3,3)||pf_seq_state(3,15)||pf_seq_state(0,15)||pf_seq_state(1,15)||pf_seq_state(2,15))?2:pf_process_transport;
 if(savePending&&!pf_commands_pending()){
  savePending=0;saveFailed=pf_save()!=0;pf_saved_until=now+1500;pf_dirty=1;
  if(!saveFailed)hardwareProjectExists=1;
 }
 pf_oldbuttons=buttons;pf_oldkeys=keys;
 nav_adopt();uint32_t led=nav_led();if(pf_transport)led|=1u<<B_PLAY;if(pf_freeze_state||pf_seq_state(pf_ui.mode,8)||pf_seq_state(pf_ui.mode,9))led|=1u<<B_REC;plat_play_red(pf_seq_state(pf_ui.mode,8));if(pf_ui.latch)led|=1u<<B_SEL;if(PF_ARPSETTINGS(pf_ui,pf_ui.mode)[0]||(pf_ui.page>=8&&pf_ui.page<10))led|=1u<<B_ARP;uint32_t lights=keys|pf_layer_lit(pf_ui.mode)|(PF_ARPSETTINGS(pf_ui,pf_ui.mode)[0]?0:PF_LATCHED(pf_ui,pf_ui.mode));plat_leds(led,lights);}
static const char *pf_control_label(int knob){if(seq_page())return (const char*[][4]){{"DIVISION","LENGTH","SWING","SLIP"},{"QUANTIZE","GATE","COUNT-IN","METRONOME"},{"CLIP A","CLIP B","CLIP C","CLIP D"}}[pf_ui.page==32?0:pf_ui.page==40?1:2][knob];if(fx_page())return fx_ui_label(knob);if(pf_ui.page==8&&(knob==1||knob==2))return knob==1?"ARP RATE":"DIV / RATE";if(pf_ui.page==32&&knob==0)return "DIVISION";if(pf_ui.page==PF_OSC_TUNING)return pf_ui.mode==PF_TORT?(const char*[]){"OSC SLOP","OSC 1 FINE","OSC 2 FINE","OSC 2 SEMI"}[knob]:(const char*[]){"OSC 1 FINE","OSC 2 FINE","OSC 3 FINE",""}[knob];if(pf_ui.page==PF_LFO_SETUP)return (const char*[]){"LFO 1","LFO 2","LFO 3","LFO 4"}[knob];if(temple_ui_page())return temple_ui_label(knob);if(pf_ui.mode==PF_BRANCH&&(pf_ui.page==2||pf_ui.page==3))return pf_labels[0][branch_edit_param(pf_ui.page,knob)];if(pf_ui.page==PF_SYSTEM)return "";if(pf_ui.page==5)return knob<3?pf_labels[pf_ui.mode][20+knob]:"";if(pf_ui.page==PF_EXCITER)return pf_labels[pf_ui.mode][ui_exciter_param(pf_ui.mode,knob)];if(pf_ui.page==0&&(pf_ui.mode==PF_BRANCH||pf_ui.mode==PF_CLOCK)){int i=ui_voice_param(pf_ui.mode,knob);return i<0?"SPREAD":i==19?"FINE":pf_ui.mode==PF_CLOCK&&i==0?"FM DEPTH":pf_ui.mode==PF_CLOCK&&i==3?"DETUNE":pf_labels[pf_ui.mode][i];}if(pf_ui.page==1){int i=ui_env_param(pf_ui.mode,knob);return i<0?"":pf_labels[pf_ui.mode][i];}if(mixer_page())return pf_modes[ui_order[knob]];if(pf_ui.page==PF_PROJECT)return (const char*[]){"PROJECT BPM","METRONOME","TRANSPOSE",""}[knob];if(pf_ui.mode==PF_LEAD&&pf_ui.page>=42&&pf_ui.page<=46)return (const char*[][4]){{"WAVE 1","RANGE 1","OSC 1 LEVEL","MASTER TUNE"},{"WAVE 2","RANGE 2","OSC 2 LEVEL","DETUNE 2"},{"WAVE 3","RANGE 3","OSC 3 LEVEL","DETUNE 3"},{"FILTER ATK","FILTER DEC","FILTER SUS",""},{"NOISE LEVEL","PINK NOISE","MOD MIX","KBD TRACK"}}[pf_ui.page-42][knob];if(seq_page())return (const char*[][4]){{"NOTE","PITCH","LENGTH","FORCE"},{"LENGTH","DIVISION","SWING","GATE"},{"PATTERN","QUEUE","BPM","RECORD"},{"RATCHET","NUDGE","SLIDE","TIME"},{"REC MODE","START","QUANTIZE","RECORD"},{"SLIP","","",""}}[pf_ui.page>=40?pf_ui.page-36:pf_ui.page-31][knob];if(pf_ui.page==30)return knob==0?"VOICE SPREAD":"";if(pf_ui.mode==PF_BRANCH&&pf_ui.page==2&&knob==3)return "VOICE SPREAD";if(pf_ui.mode==PF_CLOCK&&pf_ui.page>=58)return temple_labels[pf_ui.page-58][knob];if(pf_ui.page>=54&&pf_ui.mode==PF_TORT)return (const char*[]){"DEST A","AMOUNT A","DEST B","AMOUNT B"}[knob];if(pf_ui.page>=18)return tort_labels[pf_ui.page-18][knob];if(pf_ui.page>=10)return (const char*[]){"RATE","DEPTH","SHAPE","DESTINATION","SYNC","KEY SYNC","PHASE","SLEW"}[ui_lfo_index(pf_ui.page,knob)];if(pf_ui.page>=8)return (const char*[]){"ARP ON","ARP BPM","DIVISION","SLIP","LENGTH","ORDER","GATE","ARP LEVEL"}[(pf_ui.page-8)*4+knob];if(pf_ui.page==7)return (const char*[]){"LEVEL","PAN","DELAY","REVERB"}[knob];return pf_labels[pf_ui.mode][pf_ui.page*4+knob];}
static void pf_control_value(int knob,char *b){if(fx_page()){fx_ui_value(knob,b);return;}if(pf_ui.page==8&&(knob==1||knob==2)){b[0]=0;if(PF_ARP_SYNC(pf_ui,pf_ui.mode)){pf_cat(b,(const char*[]){"1/1","1/2","1/4","1/8","1/16","1/32"}[PF_ARPSETTINGS(pf_ui,pf_ui.mode)[2]]);pf_cat(b," SYNC");}else{pf_num(b,PF_ARPSETTINGS(pf_ui,pf_ui.mode)[1]);pf_cat(b," BPM F");}return;}if(pf_ui.page==PF_OSC_TUNING){int m=pf_ui.mode;b[0]=0;if(m==PF_TORT){int x=pf_ui.tort[(int[]){52,53,54,P_O2_SEMI}[knob]];pf_num(b,knob==0?x:knob==3?x-24:pf_fine_decode(x));pf_cat(b,knob==0?" %":knob==3?" ST":" c");}else if(m==PF_LEAD&&knob<3){pf_num(b,pf_fine_decode(pf_ui.lead.mini[28+knob]));pf_cat(b," c");}return;}if(pf_ui.page==PF_LFO_SETUP){int value=PF_LFO(pf_ui,pf_ui.mode)[knob][4+lfoConfigRow];b[0]=0;if(lfoConfigRow==0)pf_cat(b,value?"TEMPO":"FREE");else if(lfoConfigRow==1)pf_cat(b,value?"RETRIG":"FREE");else{pf_num(b,value);pf_cat(b,lfoConfigRow==2?" DEG":" %");}return;}if(temple_ui_page()){int id=temple_ui_param(knob),p=pf_ui.page;int x=id==-1?PF_SPREAD(pf_ui,PF_CLOCK):id>=128?pf_ui.temple[id-128]:PF_PAR(pf_ui,PF_CLOCK)[id];b[0]=0;
 if(p==1||p==65||p==66){if(knob==2){pf_num(b,x);pf_cat(b," %");}else temple_format_time(b,temple_time(id>=128?id-128:id,x));return;}
 if(id>=0&&id<128&&(p==0||p==2||p==3||p==58||p==67)){pf_value(b,32,PF_CLOCK,id,x);if(id==2||id==0||id==1)pf_cat(b," %");return;}
 if(id==156){pf_cat(b,"ALG ");char n[8];pf_num(n,x+1);pf_cat(b,n);}else if(id==166){x-=100;if(x>=0)pf_cat(b,"+");char n[8];pf_num(n,x);pf_cat(b,n);pf_cat(b," %");}
 else if(p==59){if(knob==0){if(!x)pf_cat(b,"PROFILE");else{pf_num(b,x/4);pf_cat(b,(const char*[]){".00",".25",".50",".75"}[x%4]);}}else if(knob==2)pf_cat(b,(const char*[]){"SINE","HALF","ABS","QUARTER","ALT","CAMEL","SQUARE","SAW"}[x]);else if(knob==3){if(id>=168)temple_format_time(b,temple_time(id-128,x));else if(!x)pf_cat(b,"INHERIT");else temple_format_time(b,.02f*fm_exp2f((x-1)*.125f));}else{pf_num(b,x);pf_cat(b," %");}}
 else if(p==60&&knob<2){if(!x)pf_cat(b,"SUSTAIN");else temple_format_time(b,.02f*fm_exp2f((x-1)*.125f));}else{pf_num(b,x);if(id==-1||id==0||id==1||id==130)pf_cat(b," %");}return;}if(pf_ui.mode==PF_BRANCH&&(pf_ui.page==2||pf_ui.page==3)){pf_value(b,32,0,branch_edit_param(pf_ui.page,knob),PF_PAR(pf_ui,0)[branch_edit_param(pf_ui.page,knob)]);return;}if(pf_ui.page==PF_SYSTEM){b[0]=0;return;}if(pf_ui.page==5){b[0]=0;if(knob<3)pf_value(b,32,pf_ui.mode,20+knob,PF_PAR(pf_ui,pf_ui.mode)[20+knob]);return;}if(pf_ui.page==PF_EXCITER){int i=ui_exciter_param(pf_ui.mode,knob);pf_value(b,32,pf_ui.mode,i,PF_PAR(pf_ui,pf_ui.mode)[i]);return;}if(pf_ui.page==0&&(pf_ui.mode==PF_BRANCH||pf_ui.mode==PF_CLOCK)){int m=pf_ui.mode,i=ui_voice_param(m,knob);if(i<0){pf_num(b,PF_SPREAD(pf_ui,m));pf_cat(b,"%");}else pf_value(b,32,m,i,i==19?PF_FINE(pf_ui,m)[pf_ui.selected]:PF_PAR(pf_ui,m)[i]);return;}if(pf_ui.page==1){int i=ui_env_param(pf_ui.mode,knob);b[0]=0;if(i>=0)pf_value(b,32,pf_ui.mode,i,PF_PAR(pf_ui,pf_ui.mode)[i]);return;}if(mixer_page()){int m=ui_order[knob];if(mixer_index()==1){pf_value(b,32,m,18,PF_MIXPAN(pf_ui,m));return;}pf_num(b,mixer_index()==0?PF_PAR(pf_ui,m)[7]:mixer_index()==1?PF_MIXPAN(pf_ui,m):PF_PAR(pf_ui,m)[mixer_index()==2?27:24]);if(mixer_index()!=1)pf_cat(b,"%");return;}if(pf_ui.page==PF_PROJECT){if(knob==1){b[0]=0;pf_cat(b,pf_ui.metronome?"ON":"OFF");}else if(knob<3)pf_num(b,(int[]){pf_ui.seqBpm,0,pf_ui.transpose}[knob]);else b[0]=0;return;}int m=pf_ui.mode;if(m==PF_LEAD&&pf_ui.page>=42&&pf_ui.page<=46){b[0]=0;if(pf_ui.page==45){if(knob<3)pf_num(b,PF_PAR(pf_ui,m)[8+knob]);return;}if(pf_ui.page==46){if(knob==1)pf_cat(b,pf_ui.lead.mini[12]&16?"PINK":"WHITE");else pf_num(b,knob==3?PF_PAR(pf_ui,m)[13]:pf_ui.lead.mini[knob==0?11:15]);return;}int row=pf_ui.page-42,value=pf_ui.lead.mini[lead_mini_map[row][knob]];if(knob==0)pf_cat(b,(const char*[]){"TRI","SHARK","SAW","SQUARE","PULSE W","PULSE N"}[value%6]);else if(knob==1)pf_cat(b,(const char*[]){"LO","32 FT","16 FT","8 FT","4 FT","2 FT"}[value%6]);else if(knob==3){pf_num(b,(value-64)*(row?11:100)/ (row?1:64));pf_cat(b," c");}else pf_num(b,value);return;}if(seq_page()){int m=pf_ui.mode;PFSeqLane*q=&PF_SEQ(pf_ui,m);b[0]=0;if(pf_ui.page==32){if(knob==0){if(q->sync){pf_cat(b,(const char*[]){"1/4","1/8","1/16","1/32","1/12","1/24","1/2","1/1","2/1"}[q->division]);pf_cat(b," SYNC");}else{pf_num(b,q->bpm);pf_cat(b," FREE");}}if(knob==1)pf_num(b,pf_clip_length(&q->pattern[pf_seq_state(m,0)]));if(knob==2){pf_num(b,q->swing);pf_cat(b," %");}if(knob==3)pf_num(b,PF_INSTRUMENT_SLIP(pf_ui,0));}else if(pf_ui.page==40){if(knob==0)pf_cat(b,(const char*[]){"OFF","1/4","1/8","1/16","1/32","1/64"}[PF_REC_QUANT(pf_ui)]);if(knob==1){PFSeqPattern*p=&q->pattern[pf_seq_state(m,0)];pf_num(b,q->gate*100/(pf_clip_events(p)?pf_clip_base_gate(p):128));pf_cat(b," %");}if(knob==2)pf_cat(b,pf_seq_state(m,13)?"ON":"OFF");if(knob==3)pf_cat(b,pf_ui.metronome?"ON":"OFF");}else{int active=pf_seq_state(m,0),queued=pf_seq_state(m,1);pf_cat(b,queued==knob?"QUEUED":active==knob?(pf_seq_state(m,3)?"PLAY":"SELECTED"):pf_clip_has_notes(&q->pattern[knob])?"READY":"EMPTY");}return;}if(pf_ui.page==30||(m==PF_BRANCH&&pf_ui.page==2&&knob==3)){b[0]=0;if(knob==0||pf_ui.page!=30){pf_num(b,PF_SPREAD(pf_ui,m));pf_cat(b," %");}return;}if(m==PF_CLOCK&&pf_ui.page>=58){int i=temple_controls[pf_ui.page-58][knob],x=pf_ui.temple[i];b[0]=0;if(i==28){pf_cat(b,"ALG ");pf_num(b+4,x+1);}else if(i>=4&&i<10){if(!x)pf_cat(b,"PROFILE");else{pf_num(b,x/4);pf_cat(b,(const char*[]){".00",".25",".50",".75"}[x%4]);}}else if(i>=22){pf_cat(b,(const char*[]){"SINE","HALF","ABS","QUARTER","ALT","CAMEL","SQUARE","SAW"}[x]);}else if(i==0||i==1||(i>=16&&i<22)){if(!x)pf_cat(b,i>=16?"INHERIT":"SUSTAIN");else{int ms=(int)(20*fm_exp2f((x-1)*.125f));pf_num(b,ms);pf_cat(b," ms");}}else{pf_num(b,x);pf_cat(b," %");}return;}if(pf_ui.page>=54&&m==PF_TORT){int x=pf_ui.tortRoutes[pf_ui.page-54][knob];b[0]=0;if(knob%2){pf_num(b,x);pf_cat(b," %");}else pf_cat(b,pf_lfo_destination(m,x));return;}if(pf_ui.page>=18){int i=tort_controls[pf_ui.page-18][knob],x=pf_ui.tort[i];b[0]=0;if(i==P_FTYPE){pf_cat(b,(const char*[]){"LP12","HP12","BP12","NOTCH","LP24","SEM"}[x%6]);return;}if(i==P_O1_WAVE||i==P_O2_WAVE){pf_cat(b,(const char*[]){"OFF","SAW","PULSE","SAW+PLS"}[x%4]);return;}if(i==P_FENV_AMT||i==P_ENV_O2||i==P_O2_FINE){int v=x-64;if(v>=0)pf_cat(b,"+");pf_num(b+(v>=0),v);return;}if(i==P_O2_SEMI){pf_num(b,x-24);pf_cat(b," ST");return;}if(i==P_CUTOFF){pf_num(b,(int)(8.1757989f*fm_exp2f((x+8)/12.f)));pf_cat(b," Hz");return;}if(i==P_FMORPH){pf_num(b,x*100/127);pf_cat(b," %");return;}if(tort_max(i)==1){pf_cat(b,x?"ON":"OFF");return;}pf_num(b,x);return;}if(pf_ui.page>=10){int slot=(pf_ui.page-10)/2,index=ui_lfo_index(pf_ui.page,knob);int16_t *cfg=PF_LFO(pf_ui,m)[slot];int x=cfg[index];b[0]=0;if(index==0){if(cfg[4]){pf_cat(b,(const char*[]){"8 BAR","4 BAR","2 BAR","1 BAR","1/2","1/4","1/8","1/16","1/32"}[(x*8+50)/100]);pf_cat(b," SYNC");}else{int hz=(int)(pf_lfo_rate(x,0,96)*100+.5f);pf_num(b,hz/100);pf_cat(b,".");char n[8];if(hz%100<10)pf_cat(b,"0");pf_num(n,hz%100);pf_cat(b,n);pf_cat(b," Hz");}}else if(index==2)pf_cat(b,(const char*[]){"SINE","TRIANGLE","SAW","REVERSE SAW","SQUARE","SAMPLE HOLD"}[x]);else if(index==3)pf_cat(b,pf_lfo_destination(m,x));else if(index==4)pf_cat(b,x?"TEMPO":"FREE");else if(index==5)pf_cat(b,x?"FIRST KEY":"FREE RUN");else{pf_num(b,x);pf_cat(b,index==6?" DEG":" %");}return;}if(pf_ui.page>=8){int i=(pf_ui.page-8)*4+knob,x=i==3?PF_INSTRUMENT_SLIP(pf_ui,pf_ui.mode):PF_ARPSETTINGS(pf_ui,m)[i];b[0]=0;if(i==0)pf_cat(b,x?"ON":"OFF");else if(i==2)pf_cat(b,(const char*[]){"1/1","1/2","1/4","1/8","1/16","1/32"}[x]);else if(i==5)pf_cat(b,(const char*[]){"UP","DOWN","UP DOWN","RANDOM"}[x]);else{pf_num(b,x);if(i==6||i==7)pf_cat(b," %");}return;}if(pf_ui.page==7){pf_num(b,(int[]){PF_PAR(pf_ui,m)[7],PF_MIXPAN(pf_ui,m),PF_PAR(pf_ui,m)[24],PF_PAR(pf_ui,m)[27]}[knob]);return;}int i=pf_ui.page*4+knob,x=PF_PAR(pf_ui,m)[i];if(i==16)x=PF_LEVEL(pf_ui,m)[pf_ui.selected];if(i==17)x=pf_ui.octave;if(i==18)x=PF_PAN(pf_ui,m)[pf_ui.selected];if(i==19)x=PF_FINE(pf_ui,m)[pf_ui.selected];pf_value(b,32,m,i,x);}
#include "ui-v2.h"
static void pf_draw(void){ui_draw();}
void pf_app_init(void){homePickerUsed=hardwareProjectMenu=0;instrumentPicker=instrumentSwapPending=instrumentSwapFailed=0;savePending=saveFailed=0;pf_saved_until=0;temple_edit_pending=0;pf_oldbuttons=pf_oldkeys=transposeCaptured=0;arpContext=0;playUsed=recUsed=globalUsed=globalTimingUsed=0;memset(fxRows,0,sizeof fxRows);memset(seqMidiHeld,0,sizeof seqMidiHeld);memset(seqMidiKind,0,sizeof seqMidiKind);seqCaptured=seqUsed=0;memset(seqRevision,0,sizeof seqRevision);ui_have_frame=0;ui_overlay_until=ui_transpose_until=0;ui_overlay_knob=-1;pf_last_draw=0;pf_dirty=1;memset(&nav,0,sizeof nav);nav_adopt();palette_set(0);plat_glow(1);}
void pf_app_frame(void){pf_app_input();uint32_t interval=plat_cpu_peak()>85?100:50;if(!ui_have_frame||plat_ms()-pf_last_draw>=interval){pf_draw();pf_last_draw=plat_ms();pf_dirty=0;}}
