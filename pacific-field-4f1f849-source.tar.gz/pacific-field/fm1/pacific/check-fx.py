#!/usr/bin/env python3
"""Pacific Field validation gate. No expected-failure exemptions or silent skips."""
import argparse,hashlib,json,os,pathlib,shutil,subprocess,sys,tempfile,time
ROOT=pathlib.Path(__file__).resolve().parents[2];PF=ROOT/'fm1/pacific'
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--profile',choices=['full','ci'],default='full',help='full: original 30min LFO/10min mixed-clock soaks; ci: explicitly120s each');ap.add_argument('--no-build',action='store_true');ap.add_argument('--only',action='append',default=[]);ap.add_argument('--output',type=pathlib.Path,default=ROOT/'fm1/build/validation');a=ap.parse_args();a.output.mkdir(parents=True,exist_ok=True)
 manifest=json.loads((PF/'validation-suites.json').read_text());declared={s['script'] for s in manifest['suites']}|set(manifest['helpers'])|set(manifest['aliases']);found={p.name for p in PF.glob('test-*.mjs')}
 if found!=declared:raise SystemExit('Validation inventory mismatch: '+str({'unclassified':sorted(found-declared),'missing':sorted(declared-found)}))
 node=os.environ.get('NODE') or shutil.which('node');cc=os.environ.get('HOST_CC') or shutil.which('clang') or shutil.which('cc');assert node and cc,'NODE and a host C compiler are required'
 refs=json.loads((ROOT/'references/manifest.json').read_text())['references']
 for r in refs.values():
  for filekey,hashkey in [('wasm','sha256'),('source','sourceSha256')]:
   p=ROOT/'references'/r[filekey];assert p.exists() and hashlib.sha256(p.read_bytes()).hexdigest()==r[hashkey],f'Reference missing/corrupt: {p.name}'
 wasm=ROOT/'fm1/build/emu/amb.wasm';full=a.output/'full-fx-reference.wasm';summary={'profile':a.profile,'independentJavaScriptSuites':len(manifest['suites']),'independentNativeSuites':len(manifest['nativeSuites']),'aliasesNotCounted':manifest['aliases'],'helpersNotCounted':manifest['helpers'],'results':[],'hardwareCPU':'not measured','nativeFirmwareLink':'separate target audit'}
 def run(id,cmd,timeout,env=None):
  start=time.monotonic();status='PASS';code=None
  try:
   with (a.output/(id+'.log')).open('w') as log:
    result=subprocess.run(list(map(str,cmd)),cwd=ROOT,env=env or os.environ.copy(),stdout=log,stderr=subprocess.STDOUT,timeout=timeout);code=result.returncode
   if code:status='FAIL'
  except subprocess.TimeoutExpired:status='TIMEOUT'
  row={'id':id,'status':status,'exitCode':code,'timeoutSeconds':timeout,'elapsedSeconds':round(time.monotonic()-start,3),'command':[str(x).replace(str(ROOT),'$SOURCE') for x in cmd]};summary['results'].append(row);(a.output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(f'{status:7} {id} ({row["elapsedSeconds"]}s / timeout {timeout}s)',flush=True);return status=='PASS'
 if not a.no_build:
  if not run('compile-emulator',[sys.executable,PF/'build-fx.py'],240):return 1
 if (not a.no_build or not full.exists()) and (not a.only or 'fx-reference' in a.only):
  env=os.environ.copy();env.update(PF_CLOUDS_FULL_BUFFER='1',PF_WASM_OUTPUT=str(full));
  if not run('compile-full-fx-reference',[sys.executable,PF/'build-fx.py'],240,env):return 1
 context={'wasm':str(wasm),'full_fx_reference':str(full),'current_reference':str(ROOT/'references'/refs['current-ui']['wasm'])}
 known={s['id'] for s in manifest['suites']}|{'native-storage'}
 if set(a.only)-known:raise SystemExit('Unknown suite IDs: '+str(set(a.only)-known))
 for s in manifest['suites']:
  if a.only and s['id'] not in a.only:continue
  env=os.environ.copy();env.update(s.get('env',{}));
  if a.profile=='ci' and s['id'] in ['lfo-long','sequencer-stress']:env['PF_SOAK_SECONDS']='120'
  run(s['id'],[node,PF/s['script'],*[v.format(**context) for v in s['args']]],s['timeoutSeconds'],env)
 if not a.only or 'native-storage' in a.only:
  with tempfile.TemporaryDirectory(prefix='pf-storage-') as d:
   exe=pathlib.Path(d)/'storage-test'
   if run('compile-native-storage',[cc,'-std=c11','-O2',PF/'test-storage-native.c','-o',exe],60):run('native-storage',[exe],120)
 failed=[r['id'] for r in summary['results'] if r['status']!='PASS'];summary['failedOrTimedOut']=failed;summary['selectedIndependentSuites']=sum(r['id'] in known for r in summary['results']);summary['completeInventory']=not bool(a.only);summary['audioSoakSeconds']={'lfo-long':120 if a.profile=='ci' else 1800,'sequencer-stress':120 if a.profile=='ci' else 600};(a.output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print(json.dumps({k:summary[k] for k in ['independentJavaScriptSuites','independentNativeSuites','selectedIndependentSuites','completeInventory','audioSoakSeconds','failedOrTimedOut']},indent=2));return int(bool(failed))
if __name__=='__main__':sys.exit(main())
