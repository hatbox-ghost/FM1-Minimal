> Historical implementation note. Page maps, memory numbers and build status describe that checkpoint. Current status: [root README](../../README.md) and [audit report](../../docs/audit-remediation/REPORT.md).

Historical foundation checkpoint; current implemented four-engine status is in LEAD-INTEGRATION.md.

# Four-engine foundation candidate

Branch codex/four-engine-foundation, isolated from the published e94a7c0 build. Branch, Clock and TORT are preserved. LEAD is not wired into this candidate yet. No deployment or hardware flash occurred.

- One main-thread projectScratch replaces four11688-byte scratch allocations: ordinary RAM saving35064 bytes. The live patch remains separate; the audio thread never uses this scratch.
- Removed unused Slip delay/velocity arrays:216 pool bytes plus216 ordinary-static bytes saved.
- Existing three256-entry command rings moved from inline pool Context fields to explicit ordinary RAM, retaining all capacities and ordering. Measured pool saving6120 bytes after pointer/alignment overhead; ordinary RAM now accounts for6144 bytes of command rings.
- Full browser regression suite passes, including original golden audio, migration, latch, octave pitch, tuning, mixer, four LFOs, phasing, recording, full three-layer stress and original shared effects. Pool accounting now259716 plus69120 canvas plus8192 reserve =337028 /344064. Conservative remaining pool margin7036 bytes. This is not a native linker-fit guarantee.

Pacific's actual native storage backend now uses two16KiB project banks at D0000/D4000, with a real16128-byte payload and256-byte streaming scratch. The native capacity guard remains enabled and passes against that physical payload when PACIFIC_FIELD is defined. Old FC000/FD000 projects remain read-only fallback; panel calibration remains DC000/DD000 with3840-byte payload. Non-Pacific builds retain the original backend/capacity through conditional compilation.

The test includes the actual storage.c, rather than a separate model. It passed16166 interrupted-write points, legacy fallback, calibration isolation, invalid-object rejection,16129-byte rejection and3841-byte panel rejection. It is now part of check-fx.py. This does not verify external firmware ownership of D0000..D7FFF or physical SPI NOR behavior; both remain prerequisites before flashing.

Native SDK/toolchain remain preserved. No current PI32v2 ELF/link map or hardware CPU deadline proof is claimed. The native build manifest still needs separate shared effects C/C++ units linked, and physical flash-map verification is pending. The old patch guard must never be disabled for a build with the old backend.

Next: compact LEAD mono runtime with original FMini DSP, independent note state, shared tuning and MIDI ownership, modulation, mixer and sends. Preserve simultaneous TORT/LEAD operation; increase LEAD voices only after integrated timing/ownership/tail tests.
