/* SPDX-License-Identifier: GPL-3.0-only */
#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include "tort-patch.h"
#include "temple-patch.h"
#include "delay-sync.h"
#include "../firmware/src/app/plat.h"
#define PF_SR 44100.f
#define PF_NV 60
#define PF_PAGES 70
#define PF_OSC_TUNING 69
#define PF_ARP_SYNC_SHIFT 8
#define PF_ARP_SYNC(p,m) (!!((p).seqReserved&(1u<<(PF_ARP_SYNC_SHIFT+(m)))))
/* Stable destination IDs; append rather than renumber saved routings. */
static inline int pf_lfo_count(int m){return m==1?18:m==3?15:11;}
/* Signed seven-bit cents: unused zero bytes in existing projects stay neutral. */
static inline int pf_fine_decode(int x){return x>=64?x-128:x;}
#define PF_LFO_SETUP 68
#define PF_SYSTEM 53
#define PF_EXCITER 52
enum { PF_HOME=47,PF_PROJECT,PF_MIX_PAN,PF_MIX_ECHO,PF_MIX_ROOM };
#define PF_LAYERS 4
#define PF_LFO_COUNT 4
#define PF_NPAR 28
/* Four values per page: HOME, ENV, LFO, ARP, note mixer, GLO, FX. */
typedef struct { union {uint8_t key[4],note[4];}; union {uint8_t velocity,vel;}; uint8_t gate; union {uint8_t count,n;}; union {uint8_t type,time;}; uint8_t flags,lvl,rat; int8_t micro; } PFSeqStep;
typedef struct {uint8_t step,param;int16_t val;} PFSeqLock;
typedef struct { uint8_t length; PFSeqStep steps[64]; uint8_t fill[16];PFSeqLock locks[24]; } PFSeqPattern;
typedef struct { PFSeqPattern pattern[4]; uint16_t bpm; uint8_t enabled,active,sync,division,swing,gate; } PFSeqLane;
#include "clip-format.h"
enum { PF_BRANCH,PF_TORT,PF_CLOCK,PF_LEAD };
enum { PF_MODE,PF_PARAM,PF_KEY,PF_PLAY,PF_FREEZE,PF_ACTION,PF_NOTE,PF_ARP,PF_PANIC,PF_MIX,PF_LFO,PF_TORT_PARAM,PF_FX,PF_SEQ,PF_MIDI,PF_LEAD_PARAM,PF_LEAD_BEND,PF_GLOBAL,PF_TORT_ROUTE,PF_TEMPLE_PARAM,PF_RECALL_KEY,PF_CHANNEL_SWAP };
typedef struct {int16_t par[PF_NPAR],level[27],pan[27],fine[27];uint32_t latched;int16_t mixpan,mute,solo,arpSettings[8],lfo[4][8],spread;PFSeqLane seq;int16_t seqSlip[4];uint8_t mini[32];} PFLeadPatch;
typedef struct {uint32_t magic,version; int16_t mode,page,selected,octave,arp,latch; int16_t par[3][PF_NPAR]; int16_t level[3][27],pan[3][27],fine[3][27]; uint32_t latched[3]; int16_t mixpan[3],mute[3],solo[3]; int16_t arpSettings[3][8]; int16_t lfo[3][4][8] __attribute__((aligned(4)));uint8_t tort[56];int16_t spread[3];uint16_t seqBpm __attribute__((aligned(4)));uint16_t seqReserved;PFSeqLane seq[3];int16_t fx[20];int16_t seqSlip[3][4];PFLeadPatch lead;int16_t masterGain,transpose,metronome;int8_t tortRoutes[4][4] __attribute__((aligned(4)));uint8_t temple[PF_TEMPLE_BYTES];} pf_patch;
extern pf_patch pf_ui;
int pf_clip_event_state(int m,int bank,int index,int field);
extern volatile uint32_t pf_active, pf_steps, pf_clock_step, pf_running, pf_frozen;
extern volatile float pf_energy[8],pf_clock_phase,pf_peak;
extern volatile uint32_t pf_dropped;
extern volatile uint8_t en_load;
void pf_init(void);
int pf_post(int op,int a,int b);
void pf_render(float *l,float *r,uint32_t n,float gain);
float pf_hz(int key,const int16_t *p,int octave,int fine);
void pf_defaults(pf_patch *p);
void pf_app_init(void);
void pf_app_input(void);
void pf_app_frame(void);
int pf_save(void);
int pf_load(void);
void pf_apply(void);
extern const char *const pf_modes[PF_LAYERS];
extern const char *const pf_labels[PF_LAYERS][PF_NPAR];
extern const char *const pf_tunings[5];
extern const char *const pf_pages[PF_PAGES];
void pf_value(char *dst,int size,int mode,int index,int value);

uint32_t pf_layer_active(int m);
uint32_t pf_layer_running(int m);
uint32_t pf_layer_lit(int m);
uint32_t pf_pool_bytes(void);

float pf_layer_meter(int m);
float pf_voice_frequency(int m,int key);

uint32_t pf_arp_events(int layer,int head);
uint32_t pf_arp_last(int layer,int head);

const char *pf_lfo_destination(int m,int d);
float pf_lfo_rate(int rate,int sync,int bpm);
float pf_lfo_phase(int m,int slot);
float pf_lfo_output(int m,int slot);

float pf_lfo_sample(int shape,float phase,float held);
float pf_lfo_effective(int m,int parameter);
uint32_t pf_lfo_cycles(int m,int slot);

#ifdef EN_HOST
#define PF_STORE_MAX 16384u
#else
#define PF_STORE_MAX PLAT_STORE_MAX
#endif
_Static_assert(sizeof(pf_patch)<=PF_STORE_MAX,"Pacific patch exceeds flash object capacity");

int pf_lfo_config(int m,int slot,int field);

float pf_clock_macro(void);
float pf_visual_cutoff(int m);
float pf_clock_quartz(void);

float pf_clock_frequency(int voice);

void pf_seq_load(int m,const PFSeqLane *lane,int bpm);
int pf_seq_state(int m,int field);
uint32_t pf_seq_events(int m);
uint32_t pf_seq_last(int m);

_Static_assert(sizeof(PFSeqStep)==12,"SLOOP adapter step layout");
_Static_assert(offsetof(pf_patch,seqBpm)==1012,"preserve musical prefix");
void pf_seq_read(int m,PFSeqLane *lane);
int pf_seq_span(int m,int step,int note,int delta);

_Static_assert(sizeof(PFSeqPattern)==882 && sizeof(PFSeqLane)==3536 && offsetof(pf_patch,lead)==11688,"SLOOP save layout changed");

int pf_seq_slip_state(int m,int field);

float pf_voice_current_frequency(int m,int key);

/* Appended fourth-layer data preserves every v14 prefix byte. */
#define PF_PAR(p,m) ((m)==PF_LEAD?(p).lead.par:(p).par[m])
#define PF_LEVEL(p,m) ((m)==PF_LEAD?(p).lead.level:(p).level[m])
#define PF_PAN(p,m) ((m)==PF_LEAD?(p).lead.pan:(p).pan[m])
#define PF_FINE(p,m) ((m)==PF_LEAD?(p).lead.fine:(p).fine[m])
#define PF_ARPSETTINGS(p,m) ((m)==PF_LEAD?(p).lead.arpSettings:(p).arpSettings[m])
#define PF_LFO(p,m) ((m)==PF_LEAD?(p).lead.lfo:(p).lfo[m])
#define PF_SEQSLIP(p,m) ((m)==PF_LEAD?(p).lead.seqSlip:(p).seqSlip[m])
#define PF_LATCHED(p,m) (*((m)==PF_LEAD?&(p).lead.latched:&(p).latched[m]))
#define PF_MIXPAN(p,m) (*((m)==PF_LEAD?&(p).lead.mixpan:&(p).mixpan[m]))
#define PF_MUTE(p,m) (*((m)==PF_LEAD?&(p).lead.mute:&(p).mute[m]))
#define PF_SOLO(p,m) (*((m)==PF_LEAD?&(p).lead.solo:&(p).solo[m]))
#define PF_SPREAD(p,m) (*((m)==PF_LEAD?&(p).lead.spread:&(p).spread[m]))
#define PF_SEQ(p,m) (*((m)==PF_LEAD?&(p).lead.seq:&(p).seq[m]))

uint32_t pf_metronome_clicks(void);

float pf_transpose_ratio(void);

int pf_arp_note(int m,int index);
int pf_held_key(int m,int index,int arp);
int pf_commands_pending(void);
int pf_channel_swap_result(void);
float pf_arp_frequency(int m,int head);

_Static_assert(offsetof(pf_patch,tortRoutes)==15584 && sizeof(pf_patch)==15664,"TORT and TEMPLE expansions must preserve the complete v16 prefix");

_Static_assert(offsetof(pf_patch,temple)==15600,"TEMPLE v18 preserves every v17 byte");

/* v19 migration reader only: the retired global value lived in the high byte.
 * v20 keeps count-in and delay sync in the low byte and uses per-layer slots. */
#define PF_GLOBAL_SLIP(p) (((p).seqReserved&0x8000u)?(((p).seqReserved>>8)&127u):0u)

/* v20 reuses the existing per-layer Slip slot; no project growth. */
#define PF_INSTRUMENT_SLIP(p,m) (PF_SEQSLIP(p,m)[0])
