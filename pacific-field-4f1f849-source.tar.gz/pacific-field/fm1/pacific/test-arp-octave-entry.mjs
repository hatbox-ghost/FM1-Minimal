import fs from 'node:fs';import assert from 'node:assert/strict';import{modeDelta}from'./test-panel-order.mjs';
async function boot(){const{instance:{exports:e}}=await WebAssembly.instantiate(fs.readFileSync(process.argv[2]),{wasi_snapshot_preview1:new Proxy({},{get:()=>()=>0}),env:new Proxy({},{get:()=>()=>0})});e._initialize();e.web_audio_boot();return e;}
for(let m=0;m<4;m++){
 const e=await boot(),run=(n=128)=>{for(let i=0;i<n;i+=128)e.web_audio_render(Math.min(128,n-i));},turn=(r,d)=>{e.web_enc(r,d);run();},tap=b=>{e.web_buttons(1<<b);e.web_buttons(0);run();},key=k=>{e.web_keys(1<<k);run();e.web_keys(0);run();},notes=()=>Array.from({length:e.web_arp_note(m,-1)},(_,i)=>e.web_arp_note(m,i));
 turn(2,modeDelta(e,m));e.web_open_page(8);turn(3,1);turn(6,60);tap(1);key(7);assert.deepEqual(notes(),[60]);run(20000);const base=e.web_arp_frequency(m,0);tap(13);run(44100);assert.deepEqual(notes(),[60]);for(let h=0;h<1;h++)assert(Math.abs(e.web_arp_frequency(m,h)-base)<.01,'octave button must not transpose existing head');
 key(7);assert.deepEqual(notes(),[60,72],'same key at upper octave must add, not toggle lower note');let seen=[new Set()],prior=[0];for(let i=0;i<44100*3;i+=128){run();for(let h=0;h<1;h++){let n=e.web_arp_events(m,h);if(n!==prior[h]){seen[h].add(Math.round(e.web_arp_frequency(m,h)/base*100));prior[h]=n;}}}for(const s of seen)assert.deepEqual([...s].sort((a,b)=>a-b),[100,200]);
 tap(12);key(11);assert.deepEqual(notes(),[60,64,72]);tap(13);key(7);assert.deepEqual(notes(),[60,64],'toggling upper C must preserve lower C');run(44100);e.web_buttons(0);assert.equal(e.web_lit_keys()&(1<<7),0,'upper C light clears when only lower-octave notes remain');tap(1);assert.deepEqual(notes(),[],'SEL off clears offscreen latched entries');run(44100);assert.equal(e.web_layer_active(m),0);assert.equal(e.web_dropped(),0);assert.equal(e.web_fx_faults(),0);
 // Physical note-off still belongs to its original octave after switching range.
 e.web_keys(1<<7);run();assert.deepEqual(notes(),[72]);tap(12);e.web_keys(0);run();assert.deepEqual(notes(),[]);
 // Overlapping keyboard ranges can address the same absolute note: last release owns it.
 e.web_keys(1<<19);run();tap(13);e.web_keys((1<<19)|(1<<7));run();assert.deepEqual(notes(),[72]);e.web_keys(1<<7);run();assert.deepEqual(notes(),[72]);e.web_keys(0);run();assert.deepEqual(notes(),[]);
 // Turning SEL off must retain the original octave of a physically held note.
 tap(12);e.web_keys(1<<7);run();tap(1);tap(13);tap(1);assert.deepEqual(notes(),[60]);e.web_keys(0);run();assert.deepEqual(notes(),[]);
 tap(1);tap(12);for(let k=0;k<27;k++)key(k);assert.equal(notes().length,27);tap(13);for(let k=15;k<27;k++)key(k);assert.equal(notes().length,27,'extra octave entries must respect the existing27-note limit');tap(1);assert.deepEqual(notes(),[]);run(4410);
 assert(e.web_pool_bytes()+e.web_canvas_bytes()+8192<344064);
 console.log('PASS arp octave entry engine',m,': arp retains pitches, same-key octaves coexist, toggles and physical release preserve ownership.');
}
