// A single global setting survives save/boot and never starts an extra FMini DSP.
import {boot,select,turn,arp} from './test-slip-panel.mjs';
import fs from 'node:fs';
import assert from 'node:assert/strict';
const e=await boot();for(let m=0;m<4;m++){arp(e,m);e.web_seq_post(m,10001,1);}
e.web_open_page(32);turn(e,6,57);select(e,3);e.web_open_page(8);assert.equal(e.web_global_slip(),57);
for(let i=0;i<800;i++)e.web_audio_render(128);
assert.equal(e.web_lead_double_calls(),0);
assert.equal(e.web_save_project(),0);assert.equal(e.web_store_len(0),15772);
e.web_boot();e.web_render(128);assert.equal(e.web_global_slip(),57);for(let m=0;m<4;m++)assert.equal(e.web_seq_state(m,3),0);
const old=await boot(),bytes=fs.readFileSync(new URL('./fixtures/v19-global-slip.bin',import.meta.url));
new Uint8Array(old.memory.buffer,old.web_store(0),bytes.length).set(bytes);old.web_store_set_len(0,bytes.length);
const writes=old.web_store_writes();old.web_boot();old.web_render(128);assert.equal(old.web_mode(),2);assert.equal(old.web_global_slip(),0);
assert.equal(old.web_store_writes(),writes);assert.deepEqual(new Uint8Array(old.memory.buffer,old.web_store(0),bytes.length),new Uint8Array(bytes));
assert.equal(old.web_save_project(),0);const patch=new DataView(old.memory.buffer,old.web_store(0),15664);
assert.equal(patch.getUint32(4,true),23);assert.equal(patch.getInt16(11682,true),61);
console.log('PASS global Slip persistence, legacy amount retained in its historical slot, and no extra LEAD render.');
