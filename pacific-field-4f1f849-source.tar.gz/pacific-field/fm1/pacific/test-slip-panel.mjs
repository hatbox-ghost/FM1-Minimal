import {startupExpected} from './test-startup-profile.mjs';
import fs from 'node:fs';import assert from 'node:assert/strict';
import {modeDelta} from './test-panel-order.mjs';
const wasm=process.argv[2];export async function boot(){const{instance:{exports:e}}=await WebAssembly.instantiate(fs.readFileSync(wasm),{wasi_snapshot_preview1:new Proxy({},{get:()=>()=>0}),env:new Proxy({},{get:()=>()=>0})});e._initialize();e.web_boot();e.web_render(128);return e;}
export function turn(e,r,n){e.web_enc(r,n);e.web_buttons(0);}
export function select(e,m){turn(e,2,modeDelta(e,m));}
export function slip(e,n,page=8){e.web_open_page(page);turn(e,page===8?6:3,n-e.web_instrument_slip(e.web_mode()));assert.equal(e.web_instrument_slip(e.web_mode()),n);}
export function seq(e,m){select(e,m);e.web_open_page(31);e.web_keys((1<<7)|(1<<11)|(1<<14)|(1<<18));e.web_keys(0);e.web_keys(1<<9);e.web_keys(0);e.web_open_page(32);turn(e,3,-13);e.web_seq_post(m,10002,120);}
export function arp(e,m){select(e,m);e.web_open_page(8);if(e.web_arp_sync){e.web_buttons(1<<5);e.web_enc(5,1);e.web_buttons(1<<5);e.web_buttons(0);}turn(e,4,120-e.web_arp_setting(m,1));turn(e,5,4-e.web_arp_setting(m,2));if(e.web_arp_sync){e.web_buttons(1<<5);e.web_enc(5,1);e.web_buttons(1<<5);e.web_buttons(0);}turn(e,3,1);e.web_buttons(1<<1);e.web_buttons(0);e.web_keys((1<<7)|(1<<11)|(1<<14));e.web_keys(0);}
