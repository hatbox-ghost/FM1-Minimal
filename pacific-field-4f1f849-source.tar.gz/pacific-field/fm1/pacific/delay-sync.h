/* SPDX-License-Identifier: GPL-3.0-only */
#pragma once
/* Existing v16 seqReserved bits 0..2 belong to recording. Bits 3..7 were
 * unused. Keep the patch size and all existing saved IDs unchanged. */
#define PF_DELAY_SYNC_BIT 8u
#define PF_DELAY_DIV_SHIFT 4
#define PF_DELAY_DIV_MASK 240u
#define PF_DELAY_DIV_COUNT 16
/* Original stereo 16-bit Clouds workspace minus interpolation/crossfade tails. */
#define PF_DELAY_MAX_SAMPLES (65408/2-8-64)
#define PF_DELAY_MAX_MS (PF_DELAY_MAX_SAMPLES/32.f)
#define PF_DELAY_LONG_MAX_SAMPLES (65408-8-64)
#define PF_DELAY_LONG_MAX_MS (PF_DELAY_LONG_MAX_SAMPLES/16.f)
static inline int pf_delay_div(int bits){int d=(bits&PF_DELAY_DIV_MASK)>>PF_DELAY_DIV_SHIFT;return d<PF_DELAY_DIV_COUNT?d:0;}
static inline float pf_delay_beats(int d){static const float beats[16]={1,.5f,.25f,.125f,1.5f,.75f,.375f,.1875f,2.f/3,1.f/3,1.f/6,1.f/12,2,4,3,6};return beats[d>=0&&d<16?d:0];}
/* Only newly added long divisions use original Clouds' stereo 8-bit/16k mode. */
static inline int pf_delay_long(int bpm,int d){if(bpm<30)bpm=30;if(bpm>240)bpm=240;return d>=12&&d<16&&60000.f/bpm*pf_delay_beats(d)>PF_DELAY_MAX_MS;}
static inline int pf_delay_fit_div(int bpm,int d){if(bpm<30)bpm=30;if(bpm>240)bpm=240;if(d<0||d>=16)d=0;float max=pf_delay_long(bpm,d)?PF_DELAY_LONG_MAX_MS:PF_DELAY_MAX_MS;while(60000.f/bpm*pf_delay_beats(d)>max){if(d>=12)d=(const int[]){0,12,4,14}[d-12];else if(d%4<3)d++;else break;}return d;}
static inline float pf_delay_sync_ms(int bpm,int d){if(bpm<30)bpm=30;if(bpm>240)bpm=240;return 60000.f/bpm*pf_delay_beats(pf_delay_fit_div(bpm,d));}
static inline const char *pf_delay_div_name(int d){static const char *const names[16]={"1/4","1/8","1/16","1/32","1/4 D","1/8 D","1/16 D","1/32 D","1/4 T","1/8 T","1/16 T","1/32 T","1/2","1/1","1/2 D","1/1 D"};return names[d>=0&&d<16?d:0];}
