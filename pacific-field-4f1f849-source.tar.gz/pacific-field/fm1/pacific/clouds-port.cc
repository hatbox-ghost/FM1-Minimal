/* SPDX-License-Identifier: GPL-3.0-only
 * Pacific adapter around unchanged MIT Clouds DSP. See upstream notices. */
#include "fx.h"
#include "clouds/dsp/granular_processor.h"
#include <cstring>
static clouds::GranularProcessor processor PF_FX_POOL;
#ifdef PF_CLOUDS_FULL_BUFFER
static const size_t large_bytes=118784;
#else
static const size_t large_bytes=114688;
#endif
static_assert(large_bytes-65408 >= 2048*sizeof(float)+16384*sizeof(uint16_t)+4096*sizeof(uint16_t),"Clouds stereo workspace including aliased pitch shifter must fit");
static uint8_t large_buffer[large_bytes] PF_FX_POOL,small_buffer[65408] PF_FX_POOL;
extern "C" void pf_clouds_init(){memset(static_cast<void*>(&processor),0,sizeof processor);memset(large_buffer,0,sizeof large_buffer);memset(small_buffer,0,sizeof small_buffer);processor.Init(large_buffer,sizeof large_buffer,small_buffer,sizeof small_buffer);processor.set_quality(0);processor.set_playback_mode(clouds::PLAYBACK_MODE_LOOPING_DELAY);processor.Prepare();}
extern "C" void pf_clouds_block(const float *in,float *out,const float *c){
 clouds::ShortFrame input[32],output[32];for(int i=0;i<32;i++){input[i].l=(int16_t)(stmlib::Clip16((int32_t)(in[i*2]*32767.f)));input[i].r=(int16_t)(stmlib::Clip16((int32_t)(in[i*2+1]*32767.f)));}
 int mode=(int)(c[9]+.5f);int long_delay=mode==0&&pf_fx_delay_sync&&pf_delay_long(pf_fx_bpm,pf_fx_delay_division);processor.set_quality(long_delay?2:0);processor.set_playback_mode(mode==1?clouds::PLAYBACK_MODE_GRANULAR:mode==2?clouds::PLAYBACK_MODE_STRETCH:clouds::PLAYBACK_MODE_LOOPING_DELAY);processor.Prepare();
 clouds::Parameters *p=processor.mutable_parameters();p->position=c[8]/1020.f;
 // Only the original looping-delay mode uses tempo-derived delay length.
 // Leave free timing and granular/stretch position bit-identical when bypassed.
 if(mode==0&&pf_fx_delay_sync){
  static_assert(sizeof small_buffer/2-kInterpolationTail-64==PF_DELAY_MAX_SAMPLES,"sync timing must match original Clouds delay capacity");
  p->position=pf_delay_sync_ms(pf_fx_bpm,pf_fx_delay_division)*(long_delay?16.f:32.f)/(long_delay?PF_DELAY_LONG_MAX_SAMPLES:PF_DELAY_MAX_SAMPLES);
 }
 p->size=c[10]*.01f;p->pitch=c[11];p->density=c[16]*.01f;p->texture=c[13]*.01f;p->dry_wet=1.f;p->stereo_spread=c[17]*.01f;p->feedback=c[12]*.01f;p->reverb=0;p->freeze=c[14]>.5f;p->trigger=false;p->gate=false;
 processor.Process(input,output,32);for(int i=0;i<32;i++){out[i*2]=output[i].l/32768.f;out[i*2+1]=output[i].r/32768.f;}}
extern "C" uint32_t pf_clouds_bytes(){return sizeof processor+sizeof large_buffer+sizeof small_buffer;}
