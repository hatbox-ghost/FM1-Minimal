/* SPDX-License-Identifier: GPL-3.0-only. Four independent layer strips, original strip canvas. */
static int mx_offset;
static void mx_rect(int x,int y,int w,int h,uint16_t c){cv_rect(x,y-mx_offset,w,h,c);}
static void mx_line(int x,int y,int xx,int yy,uint16_t c){cv_line(x,y-mx_offset,xx,yy-mx_offset,c);}
static void mx_text(int x,int y,const char *s,uint16_t c){cv_text(x,y-mx_offset,&FONT_XS,s,c);}
static uint16_t mx_color(int m){return (const uint16_t[]){RGB(158,196,139),RGB(232,191,118),RGB(159,198,219),RGB(205,149,128)}[m%PF_LAYERS];}
static int mixer_value(int m){return mixer_index()==0?PF_PAR(pf_ui,m)[7]:mixer_index()==1?PF_MIXPAN(pf_ui,m):PF_PAR(pf_ui,m)[mixer_index()==2?24:27];}
static void mx_content(void){uint16_t dim=RGB(135,151,144),line=RGB(48,65,61);char b[32];mx_text(8,4,(const char*[]){"MIX / LEVEL","MIX / PAN","MIX / ECHO","MIX / ROOM"}[mixer_index()],RGB(228,222,199));pf_num(b,mixer_index()+1);pf_cat(b,"/4");mx_text(202,4,b,dim);b[0]=0;pf_cat(b,pf_ui.transpose>=0?"T+":"T");char trans[12];pf_num(trans,pf_ui.transpose);pf_cat(b,trans);mx_text(147,4,b,mx_color(pf_ui.mode));
 for(int m=0;m<PF_LAYERS;m++){int x=3+m*59,selected=m==pf_ui.mode;uint16_t c=mx_color(m);mx_rect(x,27,56,136,RGB(21,33,31));mx_rect(x,27,56,18,selected?c:line);mx_text(x+4,30,pf_modes[m],selected?RGB(13,22,22):c);float meter=pf_layer_meter(m);int lit=pf_clip((int)((60.f+6.0206f*fm_log2f(fm_maxf(meter,.000001f)))*20.f/60.f),0,20);for(int j=0;j<20;j++)mx_rect(x+40,129-j*4,7,3,j<lit?c:line);
 int value=mixer_value(m);int height=mixer_index()==1?(value+100)*72/200:value*72/100;mx_rect(x+9,132-height,22,height,c);pf_num(b,value);mx_text(x+7,140,b,c);mx_text(x+4,170,PF_MUTE(pf_ui,m)?"MUTE":PF_SOLO(pf_ui,m)?"SOLO":pf_layer_active(m)?"HELD":"",c);}
 mx_text(7,186,"KNOBS: FOUR LAYERS / MASTER: PANEL",dim);
 for(int k=0;k<4;k++){int x=3+k*59,m=k;const char *label=pf_modes[m];mx_rect(x,204,56,34,RGB(28,42,36));mx_text(x+3,206,label,dim);pf_num(b,mixer_value(m));mx_text(x+4,222,b,mx_color(m));}
}
static void pf_draw_mixer(void){for(int band=0;band<2;band++){mx_offset=band*120;cv_begin(240,120,RGB(13,22,22));mx_content();cv_blit(0,band*120);}}
