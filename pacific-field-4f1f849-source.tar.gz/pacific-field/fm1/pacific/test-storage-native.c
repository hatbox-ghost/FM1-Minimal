/* SPDX-License-Identifier: GPL-3.0-only. Tests the actual production storage backend in fake NOR. */
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>
#define PACIFIC_FIELD 1
#include "pacific.h"
#include "../firmware/src/storage.c"
static uint8_t nor[0x100000];static int budget=-1;
static int st_read(uint32_t at,void *dst,uint32_t n){if(at+n>sizeof nor)return -1;memcpy(dst,nor+at,n);return 0;}
static int st_erase(uint32_t at){if(budget==0)return -1;if(budget>0)budget--;assert(!(at&4095));memset(nor+at,255,4096);return 0;}
static int st_prog(uint32_t at,const void *src,uint32_t n){const uint8_t *p=src;for(unsigned j=0;j<n;j++){if(budget==0)return -1;if(budget>0)budget--;assert((nor[at+j]&p[j])==p[j]);nor[at+j]&=p[j];}return 0;}
static void legacy(const uint8_t *body,unsigned n){st_hdr_t h={ST_MAGIC,OBJ_PROJ,0,10,n,st_crc32(body,n),{0,0},0};h.hcrc=st_crc32(&h,sizeof h-4);memcpy(nor+ST_LEGACY_BASE,&h,sizeof h);memcpy(nor+ST_LEGACY_BASE+ST_PAYLOAD_OFF,body,n);}
int main(void){static uint8_t a[PLAT_STORE_MAX],b[PLAT_STORE_MAX],out[PLAT_STORE_MAX],snapshot[2*ST_PROJECT_SPAN],legacySnapshot[8192],panelSnapshot[8192];memset(nor,255,sizeof nor);for(unsigned i=0;i<sizeof a;i++){a[i]=i*17;b[i]=255-a[i];}legacy(a,2000);memcpy(legacySnapshot,nor+ST_LEGACY_BASE,8192);assert(st_load(OBJ_PROJ,out,sizeof out)==2000&&!memcmp(a,out,2000));assert(st_load(OBJ_PROJ,out,100)==-2);assert(!st_save(OBJ_PANEL,b,300));memcpy(panelSnapshot,nor+ST_PANEL_BASE,8192);assert(!st_save(OBJ_PROJ,a,sizeof(pf_patch)));memcpy(snapshot,nor+ST_PROJECT_BASE,sizeof snapshot);unsigned tested=0;
for(int cut=0;cut<4+PLAT_STORE_MAX+(int)sizeof(st_hdr_t)+2;cut++){memcpy(nor+ST_PROJECT_BASE,snapshot,sizeof snapshot);budget=cut;int result=st_save(OBJ_PROJ,b,sizeof b);int n=st_load(OBJ_PROJ,out,sizeof out);assert((n==(int)sizeof(pf_patch)&&!memcmp(out,a,n))||(n==(int)sizeof b&&!memcmp(out,b,n)));if(!result)assert(n==sizeof b);tested++;}budget=-1;assert(st_save(OBJ_PROJ,b,PLAT_STORE_MAX+1)<0);assert(st_save(OBJ_PANEL,b,3841)<0);assert(st_save(OBJ_NOBJ,b,20)<0);assert(!memcmp(nor+ST_LEGACY_BASE,legacySnapshot,8192));assert(!memcmp(nor+ST_PANEL_BASE,panelSnapshot,8192));printf("PASS actual native backend: capacity=%u, patch=%zu, scratch=%zu, %u cut points, legacy fallback, panel isolation and bounds.\n",PLAT_STORE_MAX,sizeof(pf_patch),sizeof st_buf,tested);}
