import {modeDelta,legacyStep} from './test-panel-order.mjs';
import fs from'node:fs';import assert from'node:assert/strict';
const bytes=fs.readFileSync(process.argv[2]);async function boot(){const{instance:{exports:e}}=await WebAssembly.instantiate(bytes,{wasi_snapshot_preview1:new Proxy({},{get:()=>()=>0}),env:new Proxy({},{get:()=>()=>0})});e._initialize();e.web_boot();return e;}
function api(e){const run=(n=1024)=>{for(let i=0;i<n;i+=128)e.web_render(Math.min(128,n-i));assert.equal(e.web_dropped(),0);assert.equal(e.web_fx_faults(),0);},turn=(r,d)=>{e.web_enc(r,d);run();},tap=b=>{e.web_buttons(1<<b);e.web_buttons(0);run();},select=m=>turn(2,modeDelta(e,m)),text=p=>{let n=0,b=new Uint8Array(e.memory.buffer);while(b[p+n])n++;return new TextDecoder().decode(b.slice(p,p+n));},label=k=>text(e.web_label(e.web_page()*4+k)),value=k=>text(e.web_value(k)),fb=()=>new Uint8Array(e.memory.buffer,e.web_fb(),240*240*2).slice();return{run,turn,tap,select,text,label,value,fb};}
// New mixer order and actual effect send identities; native saved IDs remain untouched.
{const e=await boot(),a=api(e);a.run();e.web_open_page(7);for(let[k,m]of[0,2,1,3].entries()){const n=e.web_layer_level(m);a.turn(3+k,-3);assert.equal(e.web_layer_level(m),n-3);assert.equal(a.label(k),['BOWL','TEMPLE','POLY','LEAD'][k]);}a.tap(6);for(let[k,m]of[0,2,1,3].entries()){a.turn(3+k,11);assert.equal(e.web_layer_pan(m),11);}a.tap(6);a.turn(3,7);e.web_open_page(6);assert.equal(e.web_param(27),7);e.web_open_page(51);a.turn(3,9);e.web_open_page(6);assert.equal(e.web_param(24),9);assert.equal(e.web_patch_bytes(),15664);}
// Main FM controls address actual existing DSP parameters; all seven configurations stay reachable.
{const e=await boot(),a=api(e);a.run();a.select(2);a.tap(4);assert.equal(e.web_page(),0);assert.deepEqual([0,1,2,3].map(a.label),['CLOCK SET','MECHANICS','DRIFT','ORBIT']);for(let[k,p]of[6,10,13,2].entries()){let before=e.web_param(p);let d=before===100?-1:1;a.turn(3+k,d);assert.equal(e.web_param(p),before+d);}e.web_open_page(3);for(let algo=0;algo<32;algo++){a.turn(3,algo-e.web_temple_param(28));assert.equal(e.web_temple_param(28),algo);}a.select(0);e.web_open_page(0);assert.deepEqual([0,1,2,3].map(a.label),['BLOW','BOW','STRIKE','BRIGHTNESS']);for(const[k,p]of[11,6,13,8].entries()){const before=e.web_param(p);let d=before===100?-1:1;a.turn(3+k,d);assert.equal(e.web_param(p),before+d);}a.tap(4);assert.equal(e.web_page(),2);let wind=e.web_param(2);a.turn(3,8);assert.equal(e.web_param(2),wind+8);}

// True amp ADSR on LEAD, real AR on Branch/Temple; no invented decay or sustain.
{const e=await boot(),a=api(e);a.run();a.select(3);a.tap(2);for(let[k,p]of[4,11,6,5].entries()){let n=e.web_param(p);a.turn(3+k,1);assert.equal(e.web_param(p),n+1);}a.tap(2);assert.equal(e.web_page(),45);assert.equal(a.label(3),'');let old=e.web_param(11);a.turn(6,10);assert.equal(e.web_param(11),old);a.select(2);a.tap(2);assert.equal(e.web_page(),65);assert.equal(a.label(3),'RELEASE');a.tap(2);assert.equal(e.web_page(),1);assert.equal(a.label(3),'RELEASE');}
// LFO mapping, phase continuity and overlay expiry while notes/clock keep running.
{const e=await boot(),a=api(e);a.run();a.tap(3);assert.deepEqual([0,1,2,3].map(a.label),['RATE','DEPTH','DESTINATION','SHAPE']);a.turn(5,3);assert.equal(e.web_lfo_setting(0,0,3),3);a.turn(6,2);assert.equal(e.web_lfo_setting(0,0,2),2);e.web_open_page(0);e.web_keys(1<<7);a.run(50000);const notes=e.web_layer_active(0);a.turn(3,1);a.run(2048);const overlay=a.fb();a.run(44100);assert.notDeepEqual(a.fb(),overlay);assert.equal(e.web_layer_active(0),notes);a.tap(9);a.tap(10);let frames=e.web_seq_events(0);a.turn(3,1);a.run(30000);assert(e.web_seq_events(0)>frames);}
console.log('PASS: V2 Temple rename/control mapping, ordered mixer/real FX1-FX2 sends, four LFOs, actual envelopes, nonblocking overlays, continued voices/transport and unchanged patch size.');

// A recalled HOLD can be released with the normal SEL control.
{const e=await boot(),a=api(e);a.run();a.tap(1);assert.equal(e.web_param(23),1);e.web_keys(1<<7);a.run();e.web_keys(0);a.run();a.tap(7);a.tap(4);e.web_boot();a.run();assert.equal(e.web_lit_buttons()&(1<<1),1<<1);assert.equal(e.web_param(23),1);assert.equal(e.web_layer_active(0),1<<7);a.tap(1);assert.equal(e.web_layer_active(0),0);}
console.log('PASS: saved HOLD and note recall, then normal SEL release.');

// Both physical selectors traverse mixer columns in visual order, including reverse and wrap.
{const e=await boot(),a=api(e);a.run();e.web_open_page(7);for(const role of[0,2]){for(const want of[2,1,3,0,2,1,3,0]){a.turn(role,1);assert.equal(e.web_mode(),want);}for(const want of[3,1,2,0,3,1,2,0]){a.turn(role,-1);assert.equal(e.web_mode(),want);}a.turn(role,5);assert.equal(e.web_mode(),2);a.turn(role,-5);assert.equal(e.web_mode(),0);}for(const page of[49,50,51]){e.web_open_page(page);for(const want of[2,1,3,0]){a.turn(0,1);assert.equal(e.web_mode(),want);assert.equal(e.web_page(),page);}}}
console.log('PASS: SELECT and PRESETS scroll BOWL / TEMPLE / POLY / LEAD in visual mixer order, forward/backward, multi-step and wrap, on all four mixer pages.');

// Swap engines through the panel while the channel keeps its mix, arp and clips.
{
 const e=await boot(),a=api(e);
 a.run();e.web_open_page(7);a.select(0);
 a.turn(3,-19);a.turn(5,-7);
 e.web_open_page(49);a.turn(3,23);
 e.web_open_page(50);a.turn(3,15);
 e.web_open_page(51);a.turn(3,31);
 legacyStep(e,0,0,[57]);legacyStep(e,1,0,[76]);a.run();
 e.web_open_page(8);a.turn(4,13);
 const arpBpm=e.web_arp_setting(0,1);
 e.web_open_page(7);
 const open=()=>{
  e.web_buttons(1<<6);a.run(24000);e.web_buttons(0);
  a.turn(5,1);
 };
 a.tap(10);open();a.tap(4);
 assert.equal(e.web_mode(),0,'swap rejected while the channel is playing');
 a.tap(6);a.tap(10);open();a.tap(4);
 assert.equal(e.web_mode(),1);
 assert.deepEqual([0,1,2,3].map(a.label),['POLY','TEMPLE','BOWL','LEAD']);
 assert.equal(e.web_layer_level(1),53);
 assert.equal(e.web_layer_level(0),65);
 assert.equal(e.web_layer_pan(1),23);
 assert.equal(e.web_param(27),15);
 assert.equal(e.web_param(24),31);
 assert.equal(e.web_arp_setting(1,1),arpBpm);
 assert.equal(e.web_seq_step(1,0,0,0),57);
 assert.equal(e.web_seq_step(0,0,0,0),76);
 a.tap(10);a.run(4096);assert(e.web_seq_state(1,10)>0);a.tap(10);
 a.tap(7);a.tap(4);e.web_boot();a.run();
 assert.equal(e.web_store_len(0),15772);
 assert.deepEqual([0,1,2,3].map(a.label),['POLY','TEMPLE','BOWL','LEAD']);
 assert.equal(e.web_seq_step(1,0,0,0),57);
 a.tap(10);a.run(4096);
 assert(e.web_seq_state(1,10)>0,'the moved clip plays through its new engine');
}
console.log('PASS instrument picker swap, active-transport protection and SAVE recall.');

// The LCD opens without saving, HOME cancels, and Recall restores the saved set.
{
 const e=await boot(),a=api(e);
 e.web_open_page(7);a.run();
 const original=e.web_layer_level(0);
 a.tap(7);assert.equal(e.web_store_writes(),0);
 a.tap(6);assert.equal(e.web_store_writes(),0);
 a.tap(7);a.tap(4);assert.equal(e.web_store_writes(),1);
 a.turn(3,-8);assert.equal(e.web_layer_level(0),original-8);
 a.tap(7);a.turn(3,1);a.tap(4);
 assert.equal(e.web_layer_level(0),original-8,'recall requires confirmation');
 a.tap(4);assert.equal(e.web_layer_level(0),original);
 assert.equal(e.web_store_writes(),1,'recall never overwrites the save');
}
