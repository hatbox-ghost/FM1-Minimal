// Measure real oscillator pitch, drift speed and continuity, not only finite PCM.
import fs from 'node:fs';import assert from 'node:assert/strict';import {modeDelta} from './test-panel-order.mjs';
const bytes=fs.readFileSync(process.argv[2]);
async function boot(amount,keys=(1<<27)-1){const {instance:{exports:e}}=await WebAssembly.instantiate(bytes,{wasi_snapshot_preview1:new Proxy({},{get:()=>()=>0}),env:new Proxy({},{get:()=>()=>0})});e._initialize();e.web_boot();run(e,128);e.web_enc(2,modeDelta(e,1));e.web_buttons(0);run(e,128);e.web_open_page(21);turn(e,2,-127);e.web_open_page(20);turn(e,2,64-e.web_tort_param(10));e.web_open_page(69);turn(e,0,amount);e.web_keys(keys);run(e,128);return e;}
function run(e,n){for(let i=0;i<n;i+=128)e.web_audio_render(Math.min(128,n-i));assert.equal(e.web_dropped(),0);assert.equal(e.web_fx_faults(),0);}
function turn(e,k,d){e.web_enc(3+k,d);e.web_buttons(0);run(e,128);}
const inc=(e,k,j)=>e.web_tort_voice_state(k,4+j)>>>0;
const cents=(a,b)=>1200*Math.log2(a/b);
const all=e=>Array.from({length:54},(_,i)=>inc(e,i>>1,i&1));
const neutral=await boot(0);run(neutral,88200);const base=all(neutral),stats=[];
for(const amount of[10,25,50,75,100]){const e=await boot(amount);run(e,88200);const initial=all(e),offsets=initial.map((x,i)=>cents(x,base[i]));let prev=initial,maxStep=0,maxOwnerStep=Array(54).fill(0),movement=Array(54).fill(0);
 for(let n=0;n<4096;n++){e.web_audio_render(16);const a=all(e);for(let i=0;i<54;i++){const step=Math.abs(cents(a[i],prev[i]));maxStep=Math.max(maxStep,step);maxOwnerStep[i]=Math.max(maxOwnerStep[i],step);movement[i]=Math.max(movement[i],Math.abs(cents(a[i],initial[i])));}prev=a;}
 assert(maxStep<.11,'maximum drift increment remains below .11 cents per 16-sample update, not tens of cents');assert(maxOwnerStep.every(x=>x>0),'all 54 oscillators move');const bound=600*(amount/100)**2;assert(offsets.every(x=>Math.abs(x)<=bound+.05));if(amount===10)assert(Math.max(...offsets.map(Math.abs))<6.05,'low settings remain subtle');
 if(amount===100){assert(Math.max(...offsets)-Math.min(...offsets)>500,'multi-semitone divergence across voices at maximum');assert(offsets.filter(x=>Math.abs(x)>50).length>25,'many independent strongly detuned oscillators');assert(new Set(offsets.map(x=>Math.round(x*10))).size>48,'independent voice and oscillator offsets');assert(movement.some(x=>x>15),'drift keeps moving over seconds');for(const ptr of[e.web_out_l(),e.web_out_r()])assert(new Float32Array(e.memory.buffer,ptr,16).every(x=>Number.isFinite(x)&&Math.abs(x)<=.951));}
 stats.push({amount,peakCents:Math.max(...offsets.map(Math.abs)),spreadCents:Math.max(...offsets)-Math.min(...offsets),maxStepCents:maxStep});}
// A silent oscillator resumes the global-time trajectory instead of restarting it.
{const a=await boot(100,1<<7),b=await boot(100,1<<7);run(a,44100);run(b,44100);b.web_keys(0);run(a,44100*16);run(b,44100*16);assert.equal(b.web_tort_voice_state(7,1),0,'comparison voice has reached idle');b.web_keys(1<<7);run(a,128);run(b,128);for(let j=0;j<2;j++)assert(Math.abs(cents(inc(a,7,j),inc(b,7,j)))<.01,'silent/retriggered drift rejoins uninterrupted oscillator phase');}
// Turning Slop on/off follows a 120ms target slew; no sudden initial cents jump.
{const e=await boot(0,1<<7);run(e,88200);e.web_open_page(69);e.web_enc(3,100);e.web_buttons(0);e.web_audio_render(16);const before=inc(e,7,0);e.web_audio_render(16);assert(Math.abs(cents(inc(e,7,0),before))<2);run(e,44100);const strong=inc(e,7,0);turn(e,0,-100);const after=inc(e,7,0);assert(Math.abs(cents(after,strong))<20,'turning off fades instead of instantly resetting pitch');run(e,44100*3);assert(Math.abs(cents(inc(e,7,0),base[14]))<.01,'zero settles exactly to neutral tuning');}
console.log(JSON.stringify({pass:true,oscillators:54,freeRunningAcrossSilence:true,retriggerContinuity:true,amountSlew:true,range:stats}));
