/* GPL-3.0-only. OberVave DSP copyright2026 zvenson; Pacific adapter. */
#include "upstream/obervave/obv_dsp.h"
#define ENV_ONE (1<<24)
#define LEVEL_FLOOR 2048
#define NCARD 8u
enum {E_IDLE,E_ATT,E_DEC,E_SUS,E_REL};
typedef struct {uint32_t stage;int32_t level;} env_t;
typedef struct {
 osc_t o1,o2;env_t fe,amp;
 union {struct {svf_state_t f1;svf_coef_t c1;};struct {lad_state_t lad;lad_coef_t lc;};};
 int32_t drift;uint32_t noise,inc1,inc2,pw1,pw2;int32_t amp0,amp1;float glidePitch;
 uint8_t tick,gate,filterType,retrigger;
} ov_voice_t;
static ov_voice_t tort_voices[PF_NV] EN_POOL;
/* Slop trajectories are reconstructed from elapsed audio time, including silence.
 * No per-voice LFO state, no key reset, no dependency on OberVave's noise RNG. */
static uint64_t tort_slop_clock;
static float tort_pitch_offset[2],tort_slop_scale,tort_slop_gain;
static float tort_slop_wave(uint64_t time,uint32_t rate,uint32_t phase){
 uint32_t p=(uint32_t)(time*rate)+phase;unsigned i=p>>21;
 return sine[i]+(sine[i+1]-sine[i])*((p&2097151u)*(1.f/2097152.f));
}
static float tort_slop_motion(int owner,int osc){
 uint32_t h=(owner*2+osc+1)*2654435761u;h=(h^(h>>16))*2246822519u;h^=h>>13;
 uint32_t r=(779u+(h&65535u)*3420u/65535u)|1u;
 /* Albion-like independent slow cycles; depth and center evolve more slowly.
  * Main rates .008-.043 Hz; second component is about 2.17 times faster. */
 float a=tort_slop_wave(tort_slop_clock,r,h);
 float b=tort_slop_wave(tort_slop_clock,(r*217u/100u)|1u,h*3266489917u);
 float depth=.55f+.25f*tort_slop_wave(tort_slop_clock,(211u+((h>>8)&1023u))|1u,h^0x9e3779b9u);
 float center=.18f*tort_slop_wave(tort_slop_clock,(147u+((h>>19)&511u))|1u,h*668265263u);
 return center+depth*(a+.22f*b)*(1.f/1.22f); /* bound +/- .98 */
}
static uint8_t tort_effective[56],tort_velocity[PF_NV];
static const int16_t VINT_TUNE8[8]={-20,12,7,-15,18,-9,3,-17},VINT_CUT8[8]={-300,250,120,-380,60,330,-180,220};
static const int8_t VINT_ENV[8]={10,-6,14,-12,3,-16,8,-4};
typedef struct {int32_t lvl1,lvl2,lvln,drive_q12,morph_q,reso_k,lad_k,cut_sm,reso_sm;uint32_t w1,w2,ftype,sync_on,xmod_q,pw1_base,pw2_base,clock;} part_t;
static part_t tort_block;
#include "obervave-envelope.inc"
static void tort_note(int index,const uint8_t *p,float hz,float velocity){tort_velocity[index]=(uint8_t)CL(velocity*127,1,127);ov_voice_t *v=&tort_voices[index];if(!v->noise)v->noise=71771+index*179;v->fe.stage=v->amp.stage=E_ATT;v->retrigger=1;v->tick=0;if(!v->inc1)v->glidePitch=fm_log2f(fm_maxf(hz,1));}
static void tort_prepare(const uint8_t *p,const float *effective,const int *base,const float *osc){float slop=CL(p[52]+osc[3],0,100)*.01f;tort_slop_scale=600.f*slop*slop;for(int j=0;j<2;j++)tort_pitch_offset[j]=pf_fine_decode(p[53+j])+CL(osc[j],-200,200);memcpy(tort_effective,p,56);const int param[10]={P_CUTOFF,P_RESO,P_FMORPH,P_O1_LVL,P_O1_PW,P_O2_PW,P_DRIVE,P_XMOD,P_FENV_AMT,P_NOISE};const int generic[10]={1,2,3,0,6,10,8,9,11,12};for(int i=0;i<10;i++){int id=param[i],g=generic[i];tort_effective[id]=(uint8_t)CL(p[id]+(effective[g]-base[g])*1.27f,0,127);if(g==0)tort_effective[P_O2_LVL]=(uint8_t)CL(p[P_O2_LVL]-(effective[g]-base[g])*1.27f,0,127);}}
static void tort_wheel_sample(void){
 tort_slop_clock++;
 if(!tort_block.clock){tort_block.cut_sm=tort_effective[P_CUTOFF]<<8;tort_block.reso_sm=tort_effective[P_RESO]<<8;}if(tort_block.clock++%CTL)return;const uint8_t *p=tort_effective;part_t *g=&tort_block;int d;
 tort_slop_gain+=(tort_slop_scale-tort_slop_gain)*(CTL/(PF_SR*.12f));
 if(tort_slop_scale==0&&tort_slop_gain<.0001f)tort_slop_gain=0;
 d=p[P_O1_LVL];g->lvl1=d*d>>7;d=p[P_O2_LVL];g->lvl2=d*d>>7;d=p[P_NOISE];g->lvln=d*d>>7;
 d=p[P_DRIVE];g->drive_q12=4096+d*d*15*4096/16129;g->cut_sm+=((p[P_CUTOFF]<<8)-g->cut_sm)>>6;g->reso_sm+=((p[P_RESO]<<8)-g->reso_sm)>>6;
 g->reso_k=8192-g->reso_sm*8400/(127*256);g->lad_k=(8192-g->reso_k)>>1;g->morph_q=p[P_FMORPH];g->ftype=p[P_FTYPE];g->w1=p[P_O1_WAVE];g->w2=p[P_O2_WAVE];g->sync_on=p[P_SYNC];d=p[P_XMOD];g->xmod_q=d*d>>7;
 g->pw1_base=((uint32_t)p[P_O1_PW]<<25)+(1u<<24);g->pw2_base=((uint32_t)p[P_O2_PW]<<25)+(1u<<24);
}
#include "obervave-render.inc"
static float tort_sample(int index,float hz,int gate,float transpose){
 ov_voice_t *v=&tort_voices[index];const uint8_t *p=tort_effective;part_t *g=&tort_block;
 if(gate!=v->gate||v->retrigger){if(gate){v->fe.stage=v->amp.stage=E_ATT;}v->tick=0;v->gate=!!gate;v->retrigger=0;}
 if(v->tick==0){
  int32_t susf=p[P_FS]*(ENV_ONE/127),susa=p[P_AS]*(ENV_ONE/127);int vint=p[P_VINTAGE],vt=(vint*VINT_ENV[index%8])>>7;env_tick(&v->fe,p[P_FA],p[P_FD],susf,p[P_FR],gate,vt);env_tick(&v->amp,p[P_AA],p[P_AD],susa,p[P_AR],gate,vt);v->drift+=(int32_t)(xorshift(&v->noise)&31u)-16;v->drift-=v->drift>>11;
  float logTarget=fm_log2f(fm_maxf(hz,1));if(!p[P_GLIDE])v->glidePitch=logTarget;else v->glidePitch+=(logTarget-v->glidePitch)*GLIDE_K[p[P_GLIDE]]/65536.f;
  int32_t drift8=((VINT_TUNE8[index%8]*vint)>>7)+((v->drift*vint)>>10);float played=transpose*fm_exp2f(v->glidePitch+drift8/3072.f);v->inc1=(uint32_t)CL(played*(4294967296.f/PF_SR),1,2147483000.f);
  float cents[2]={tort_pitch_offset[0],tort_pitch_offset[1]};
  if(tort_slop_gain>0)for(int j=0;j<2;j++)cents[j]+=tort_slop_gain*tort_slop_motion(index,j);
  uint32_t base_inc=v->inc1;
  if(cents[0]!=0)v->inc1=(uint32_t)CL(base_inc*fm_exp2f(cents[0]/1200.f),1,2147483000.f);
  int32_t fe=v->fe.level>>9;float semis=(int)p[P_O2_SEMI]-24+((int)p[P_O2_FINE]-64)/128.f+((fe*((int)p[P_ENV_O2]-64)*97)>>15)/256.f;
  v->inc2=(uint32_t)CL(base_inc*fm_exp2f(semis/12.f+cents[1]/1200.f),1,2147483000.f);v->pw1=g->pw1_base;v->pw2=g->pw2_base;
  if(v->filterType!=g->ftype){memset(&v->lad,0,sizeof v->lad+sizeof v->lc);v->filterType=g->ftype;}
  float midi=69+12*fm_log2f(fm_maxf(played,1)/440.f);int32_t cut=g->cut_sm+8*256+((fe*((int)p[P_FENV_AMT]-64)*390)>>15)+(int)((midi-60)*p[P_KEYTRK]*2)+(((int)tort_velocity[index]-64)*p[P_VEL_FLT]>>1)+((VINT_CUT8[index%8]*vint)>>7)+((v->drift*vint)>>7);
  if(g->ftype==F_LP24)lad_coef(&v->lc,cut,g->lad_k);else svf_coef(&v->c1,cut,g->reso_k);
  int velg=32767-((((127-(int)tort_velocity[index])*p[P_VEL_AMP])>>7)*258);v->amp0=v->amp1;v->amp1=(int)(((int64_t)(v->amp.level>>9)*velg)>>15);
 }
 float out=obv_sample(v);v->tick=(v->tick+1)%CTL;return out;
}
