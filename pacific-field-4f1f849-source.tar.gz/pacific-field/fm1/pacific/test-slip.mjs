// Shared phasing replaces the retired fixed stereo-offset assertions.
await import('./test-global-slip.mjs');
