/* SPDX-License-Identifier: GPL-3.0-only
 * Pacific piano roll: absolute pitches, unclipped rows and visible continuation.
 * Drawing only; recorded notes and original SLOOP playback are untouched. */
typedef struct {int base,zoom,stride,low,high,length,playing;} PFSeqRollView;
static const PFSeqStep *seq_roll_notes(const PFSeqPattern *pattern,int step,int *continuation){
 const PFSeqStep *st=&pattern->steps[step];*continuation=0;
 if(st->type==2)return 0;
 if(st->type==1){*continuation=1;for(int back=1;back<pattern->length;back++){st=&pattern->steps[(step+pattern->length-back)%pattern->length];if(st->type==1)continue;return st->type==0&&st->count?st:0;}return 0;}
 return st->count?st:0;
}
static PFSeqRollView seq_roll_view(int m){
 PFSeqPattern *pattern=&PF_SEQ(pf_ui,m).pattern[seqEdit[m]];
 PFSeqRollView view={0,seqZoomSteps[seqZoom[m]],0,127,0,pattern->length,-1};view.stride=224/view.zoom;
 if(pf_seq_state(m,3)&&pf_seq_state(m,0)==seqEdit[m])view.playing=pf_seq_state(m,2);
 int focus=view.playing>=0&&plat_ms()>=seqRollEditUntil[m]?view.playing:seqCursor[m];view.base=(focus/view.zoom)*view.zoom;
 for(int j=0;j<view.length;j++){PFSeqStep *st=&pattern->steps[j];if(st->type!=0)continue;for(int n=0;n<st->count;n++){int note=st->key[n];if(note<view.low)view.low=note;if(note>view.high)view.high=note;}}
 if(view.high<view.low){view.low=pf_clip(53+pf_ui.octave*12,0,101);view.high=view.low+26;}
 if(view.high-view.low<26){int extra=26-(view.high-view.low);view.low-=extra/2;view.high+=extra-extra/2;if(view.low<0){view.high-=view.low;view.low=0;}if(view.high>127){view.low-=view.high-127;view.high=127;}}
 return view;
}
static int seq_roll_row(const PFSeqRollView *view,int note){return 97-(note-view->low)*40/(view->high-view->low);}
/* Four chord tones must stay distinguishable even when a wide MIDI range
 * compresses neighboring pitches onto one LCD row. Keep pitch order and bound
 * the small visual offsets within the roll; identical pitches share a row. */
static void seq_roll_chord_rows(const PFSeqRollView *view,const PFSeqStep *st,int *rows){
 int count=st->count<4?st->count:4,order[4],groups[4],ys[4],ng=0;
 for(int n=0;n<count;n++)order[n]=n;
 for(int n=1;n<count;n++)for(int j=n;j>0&&st->key[order[j]]>st->key[order[j-1]];j--){int swap=order[j];order[j]=order[j-1];order[j-1]=swap;}
 for(int n=0;n<count;n++){int note=st->key[order[n]];if(!n||note!=st->key[order[n-1]]){int y=seq_roll_row(view,note);if(ng&&y<ys[ng-1]+2)y=ys[ng-1]+2;ys[ng++]=y;}groups[n]=ng-1;}
 if(ng&&ys[ng-1]>97){ys[ng-1]=97;for(int n=ng-2;n>=0;n--)if(ys[n]>ys[n+1]-2)ys[n]=ys[n+1]-2;}
 for(int n=0;n<count;n++)rows[order[n]]=ys[groups[n]];
}
