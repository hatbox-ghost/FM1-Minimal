import {modeDelta} from './test-panel-order.mjs';
import fs from 'node:fs';import assert from 'node:assert/strict';
async function boot(){const {instance:{exports:e}}=await WebAssembly.instantiate(fs.readFileSync(process.argv[2]),{wasi_snapshot_preview1:new Proxy({},{get:()=>()=>0}),env:new Proxy({},{get:()=>()=>0})});e._initialize?.();e.web_boot();return e;}
let e=await boot();
function render(seconds=.05){let sum=0,ls=0,rs=0,peak=0,frames=0;for(let b=0;b<Math.ceil(seconds*44100/128);b++){e.web_render(128);const l=new Float32Array(e.memory.buffer,e.web_out_l(),128),r=new Float32Array(e.memory.buffer,e.web_out_r(),128);for(let i=0;i<128;i++){assert(Number.isFinite(l[i])&&Number.isFinite(r[i]));ls+=l[i]*l[i];rs+=r[i]*r[i];peak=Math.max(peak,Math.abs(l[i]),Math.abs(r[i]));frames++;}}return {rms:Math.sqrt((ls+rs)/(frames*2)),ls,rs,peak};}
const combo=(a,b)=>{e.web_buttons(1<<a);e.web_buttons((1<<a)|(1<<b));e.web_buttons(0);render();};const processes=()=>combo(10,6);const tap=b=>{e.web_buttons(1<<b);e.web_buttons(0);render();};const turn=(r,n)=>{e.web_enc(r,n);render();};const select=m=>{turn(2,modeDelta(e,m));assert.equal(e.web_mode(),m);};
render();assert.equal(e.web_page(),7);assert.equal(render().peak,0);
// One physical press latches exactly one note and never starts other generators.
for(let m=0;m<3;m++){select(m);tap(1);e.web_keys(1<<7);e.web_keys(0);render(.3);assert.equal(e.web_layer_active(m),1<<7);assert.equal(e.web_lit_keys(),1<<7);assert(render(.2).rms>.0001);}
for(let m=0;m<3;m++){select(m);assert.equal(e.web_lit_keys(),1<<7);}
// Tuning edits from one layer affect every held voice immediately.
tap(5);turn(0,1);assert.equal(e.web_page(),5);const before=[0,1,2].map(m=>e.web_voice_frequency(m,7));turn(4,2);for(let m=0;m<3;m++){assert(e.web_voice_frequency(m,7)>before[m]);assert(Math.abs(e.web_voice_frequency(m,7)-e.web_voice_frequency(0,7))<.001);}
turn(3,1);turn(5,10);const map=e.web_param(20),root=e.web_param(21),anchor=e.web_param(22);for(let m=0;m<3;m++){select(m);assert.equal(e.web_param(20),map);assert.equal(e.web_param(21),root);assert.equal(e.web_param(22),anchor);}
// Mixer: selecting strips, mute, solo, post-effects fader and pan operate on live audio.
e.web_open_page(7);assert.equal(e.web_page(),7);select(0);combo(5,9);assert.equal(e.web_layer_solo(0),1);render(1);assert(e.web_layer_meter(0)>.0001);assert(e.web_layer_meter(1)<.00001);combo(5,8);assert.equal(e.web_layer_mute(0),1);render(.2);assert(render(.1).rms<1e-7);assert.equal(e.web_layer_active(0),1<<7);combo(5,8);render(.3);e.web_open_page(49);turn(3,100);assert.equal(e.web_layer_pan(0),100);const pan=render(.3);assert(pan.rs>pan.ls*100);turn(3,-100);e.web_open_page(7);turn(3,-1000);assert.equal(e.web_layer_level(0),0);render(.6);assert(render(.1).rms<1e-6);turn(3,72);combo(5,9);
// Latch off releases chosen notes without stopping or resetting other layers.
select(1);tap(1);assert.equal(e.web_layer_active(1),0);assert.equal(e.web_layer_active(0),1<<7);assert.equal(e.web_layer_active(2),1<<7);
// Save mixer/tuning and latched notes. The sequencer remains stopped.
assert.equal(e.web_save_project(),0);e.web_boot();render();assert.deepEqual([0,1,2].map(m=>e.web_layer_active(m)),[1<<7,0,1<<7]);for(let m=0;m<3;m++)assert.equal(e.web_seq_state(m,3),0);assert.equal(e.web_param(20),map);
// A fast, non-latched tap is audible even if release arrives before the next audio block.
select(1);if(e.web_param(23))tap(1);e.web_keys(1<<7);e.web_keys(0);const quick=render(.25);assert(quick.rms>.0005,`quick tap too quiet: ${quick.rms}`);assert.equal(e.web_layer_active(1),0);
// All physical notes, and a key released after changing selected layer.
for(let m=0;m<3;m++){select(m);if(e.web_param(23))tap(1);for(let k=0;k<27;k++){e.web_keys(1<<k);render(.01);assert.equal(e.web_layer_active(m),1<<k);e.web_keys(0);render(.01);assert.equal(e.web_layer_active(m),0);}}
select(0);e.web_keys(1<<9);render();select(2);e.web_keys(0);render();assert.equal(e.web_layer_active(0),0);
// Explicit PLAY starts the processes, then stops all notes and effect tails.
e.web_open_page(3);processes();assert.equal(e.web_layer_running(0),1);assert(render(10).peak<.951);processes();assert.equal(render(.1).peak,0);assert.equal(e.web_dropped(),0);assert(e.web_pool_bytes()+240*144*2<0x54000);
console.log(JSON.stringify({passed:true,oneKeyOneLatch:true,globalHeldTuning:true,mixerMuteSoloPan:true,postEffectsFader:true,fastTapRms:quick.rms,all81Keys:true,releaseOwnership:true,explicitProcesses:true,noDroppedCommands:true}));

select(2);e.web_open_page(3);processes();const fixed=[e.web_voice_frequency(2,7),e.web_voice_frequency(2,14)];render(6);assert.equal(e.web_clock_step(),0);assert.deepEqual([e.web_voice_frequency(2,7),e.web_voice_frequency(2,14)],fixed);
e.web_open_page(3);for(let a=0;a<32;a++){turn(3,a-e.web_temple_param(28));assert.equal(e.web_temple_param(28),a);assert(render(.2).peak<.951);}e.web_open_page(0);for(let a=0;a<7;a++){turn(3,a-e.web_param(6));assert.equal(e.web_param(6),a);assert(render(.2).peak<.951);}processes();
console.log('PASS: Clock has no climbing note wheel; all seven FM configurations remain functional.');
