// Compare the primary arp and sequencer clocks with all four lanes running.
import assert from 'node:assert/strict';
import {boot,turn,arp} from './test-slip-panel.mjs';
const e=await boot(),clock=(id,f)=>e.web_phase_state(id,f),run=n=>e.web_phase_test_run(n);
for(let m=0;m<4;m++){arp(e,m);e.web_seq_post(m,10001,1);}
run(44100);
assert.deepEqual([1,3,5,7].map(id=>clock(id,1)),Array(4).fill(clock(1,1)));
e.web_open_page(32);turn(e,6,40);
const before=clock(3,1);run(0);assert.equal(clock(3,1),before);
run(44100);
const rate=[1,1.00512,.99488,1.01024];
for(let id=0;id<8;id++)assert(Math.abs(clock(id,0)-rate[id>>1])<1e-5);
const arpStart=[0,2,4,6].map(id=>clock(id,2));
const diff=()=>clock(3,1)-clock(1,1),a=diff();
run(44100*60);const b=diff();run(44100*60);const c=diff();
assert(b>a&&c>b);assert(Math.abs((c-b)-(b-a))<200,'relative phase accumulates at a stable rate');
const beats=(c-a)/(44100*60);
assert(beats>.97&&beats<1.00,'4-beat patterns shift one loop in about 8 minutes at Slip 40');
const counts=[0,2,4,6].map((id,i)=>clock(id,2)-arpStart[i]);assert(counts[3]>counts[0]&&counts[0]>counts[2],counts);
for(let id=0;id<8;id++)assert.equal(clock(id,9),0,'no second scheduler');
turn(e,6,-40);run(44100);const retained=diff();run(44100);assert(Math.abs(diff()-retained)<15,'zero stops drift without resetting phase');
assert(retained>0);assert.equal(e.web_dropped(),0);
console.log(JSON.stringify({pass:true,globalSlip:40,rate,beatsDriftInTwoMinutes:beats,arpEvents:counts}));
