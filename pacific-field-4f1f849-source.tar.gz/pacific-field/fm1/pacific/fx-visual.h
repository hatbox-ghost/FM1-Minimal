/* GPL-3.0-only. Firmware geometry; metered activity, illustrative wave/grain ages.
 * Effects run in parallel: visual overlap does not imply audio cross-feedback. */
static uint16_t fx_ink(int coral,float strength){int a=pf_clip((int)(strength*255),0,255);return coral?RGB(a,a*145/255,a*119/255):RGB(a*184/255,a*165/255,a*237/255);}
/* Several offset spiral arms leave negative space at the eye of the vortex. */
static void ui_fx_whorl(float phase,float size,float energy,int warm){
 for(int arm=0;arm<3;arm++){
  int px=0,py=0;
  uint16_t ink=fx_ink(warm,.27f+energy*.55f-arm*.04f);
  for(int i=0;i<=32;i++){
   float u=i/32.f;
   float angle=phase+u*.93f+arm/3.f;
   float radius=7+u*size;
   int x=120+(int)(us(angle+.25f)*radius);
   int y=107+(int)(us(angle)*radius*.54f);
   if(i&&i%11)ul(px,py,x,y,ink);
   px=x;py=y;
  }
 }
}
/* Rounded cloud contours face into the orbit, with a soft trail behind. */
static void ui_fx_delay_clouds(float time,float delay,float radius,float energy,float grain,int feedback){
 int repeats=3+feedback/15;
 float spin=time/(.85f+delay*3.f);
 for(int repeat=repeats-1;repeat>=0;repeat--){
  float age=repeat/(float)repeats;
  float angle=spin-age*.76f;
  float r=radius*(1-age*.67f);
  float size=5+grain*7+energy*4;
  float strength=(.43f+energy*.5f)*(1-age*(.80f-feedback*.005f));
  float tx=-us(angle),ty=us(angle+.25f);
  int x=120+(int)(ty*r),y=109+(int)(-tx*r*.50f);
  for(int trail=0;trail<7;trail++){
   float back=angle-(trail+1)*.012f;
   float sweep=r+trail*.6f;
   int xx=120+(int)(us(back+.25f)*sweep);
   int yy=109+(int)(us(back)*sweep*.50f);
   udot(xx,yy,trail<2?2:1,fx_ink(1,strength*(.58f-trail*.064f)));
  }
  int px=0,py=0;
  for(int i=0;i<=24;i++){
   float phase=i/24.f;
   float puff=size*(1+.18f*us(phase*3+.1f));
   float along=us(phase+.25f)*puff*1.25f,across=us(phase)*puff*.64f;
   int xx=x+(int)(tx*along+ty*across);
   int yy=y+(int)((ty*along-tx*across)*.70f);
   if(i)ul(px,py,xx,yy,fx_ink(1,strength));
   px=xx;py=yy;
  }
 }
}
static void ui_fx(float t){
 int p=pf_ui.page,main=p==6,clouds=p==37||p==38,m=pf_ui.mode;
 float revIn=pf_ui.fx[6]?0:pf_fx_meter(1),delIn=pf_ui.fx[14]?0:pf_fx_meter(0),revOut=pf_fx_meter(3),delOut=pf_fx_meter(2);
 float re=fm_clampf(fm_sqrtf((revIn+revOut)*12),0,1),de=fm_clampf(fm_sqrtf((delIn+delOut)*12),0,1);
 float size=pf_ui.fx[0]*.01f,decay=pf_ui.fx[1]*.01f,damp=pf_ui.fx[2]*.01f,mod=pf_ui.fx[4]*.01f;
 /* Below the activity floor, geometry stops moving. Freeze retains DSP playback,
  * not fictitious new recording. Actual output peaks govern continued activity. */
 float rt=revIn+revOut>.0001f?t:0,ct=delIn+delOut>.0001f?t:0;
 float delay=delay_sync_on()?pf_delay_sync_ms(pf_ui.seqBpm,pf_delay_div(pf_ui.seqReserved))*.001f:pf_ui.fx[8]*.001f;
 if(delay<.025f)delay=.025f;
 if(main||!clouds){
  float send=PF_PAR(pf_ui,m)[27]*.01f;int rings=3+(int)((1-damp)*3);
  ui_fx_whorl(rt*(.04f+mod*.035f),55+size*37,re,0);
  for(int j=rings-1;j>=0;j--){float age=rt/(.8f+decay*3.2f)+j/(float)rings;age-=fm_floorf(age);float radius=9+age*(38+size*42+send*8);float fade=(.15f+re*.58f)*(1-age*(1-decay*.55f));uint16_t c=fx_ink(0,fade);int px=0,py=0;
   for(int n=0;n<=32;n++){float a=n/40.f+age*.3f;float warp=rt?us(a*3+rt*(.01f+pf_ui.fx[5]*.0003f))*(1+mod*6)*re:0;int x=120+(int)(us(a+.25f)*(radius+warp)),y=109+(int)(us(a)*(radius*.51f+warp));if(n)ul(px,py,x,y,c);px=x;py=y;}
   if(damp<.6f&&re>.01f&&j%2==0)udot(120+(int)(us(age+.25f)*radius),109+(int)(us(age)*radius*.51f),1,fx_ink(0,fade*.7f));
  }
  if(!main){if(p==36)ut(8,48,fxRows[0]?"ALGO: PRIMARY / RETURN":"ALGO: HIGH PASS / MASTER",1,UI_DIM);if(pf_ui.fx[6])ut(8,161,"FREEZE / FIELD HELD",1,UI_LAVENDER);else ut(8,161,revIn+revOut>.0001f?"SHARED REVERB / ACTIVE":"SHARED REVERB / IDLE",1,UI_DIM);}
 }
 if(main||clouds){
  int mode=pf_ui.fx[9],feedback=pf_ui.fx[12];float send=PF_PAR(pf_ui,m)[24]*.01f,grain=pf_ui.fx[10]*.01f,spread=pf_ui.fx[17]*.01f;
  float pitch=fm_exp2f(pf_ui.fx[11]/24.f);float radius=(main?49+send*22:55+spread*32)*(.9f+.1f*pitch);
  if(!main)ui_fx_whorl(ct*.06f*pitch,radius,de,1);
  if(mode==0)ui_fx_delay_clouds(ct,delay,radius,de,grain,feedback);
  else{int count=12+pf_ui.fx[16]*36/100;for(int j=0;j<count;j++){float rate=mode==2?.007f:.025f;float arm=(j%3)/3.f, age=(j/3)/(float)((count+2)/3);float a=arm+age*.93f+ct*rate*pitch;float r=radius*(.18f+age*.87f);int x=120+(int)(us(a+.25f)*r),y=108+(int)(us(a)*r*(.42f+grain*.13f));uint16_t c=fx_ink(1,(.4f+de*.6f)*(.65f+(j%5)*.085f));int length=1+(int)(grain*(mode==2?11:4));if(mode==2)ul(x-length,y,x+length,y+(int)(pf_ui.fx[11]*.12f),c);else{ur(x,y,length,j%3?1:2,c);if(feedback>40)ur(x-3,y+2,1,1,fx_ink(1,de*feedback*.004f));}}}
  if(!main){if(p==38)ut(8,48,fxRows[1]?"ALGO: POSITION / RECORD":"ALGO: CLOUDS RETURN",1,UI_DIM);ut(8,161,pf_ui.fx[14]?"FROZEN / PLAYBACK":mode==0?"DELAY / REPEATS":mode==1?"GRANULAR / PARTICLES":"STRETCH / THREADS",1,UI_CORAL);if(!pf_ui.fx[14]&&delIn>.001f)udot(226,164,2,UI_CORAL);}
 }
 if(main){ut(8,161,pf_modes[m],1,UI_INK);ut(54,161,"SENDS / SHARED EFFECTS",1,UI_DIM);}
 if((p==6||p==38)&&pf_ui.fx[9]==0)ut(8,48,delay_sync_on()?"SYNC / GLOBAL+TIME: FREE":"FREE / GLOBAL+TIME: SYNC",1,UI_DIM);
}
