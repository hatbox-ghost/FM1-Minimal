> Historical implementation note. Page maps, memory numbers and build status describe that checkpoint. Current status: [root README](../../README.md) and [audit report](../../docs/audit-remediation/REPORT.md).

# Clock — fixed pitches, original mechanical motion

Automatic root travel, scale/interval stepping and Climb are removed from DSP and UI. PLAY’s Clock process now holds the fixed globally tuned root/fifth (voice slots 27/28); the third process voice is removed. Played/latched note centers are never retargeted by the mechanical clock. Arpeggiators, deliberate LFO pitch modulation and manual/global tuning still work normally.

Original reference: fm-drone-clock-braun-study.html supplied by the user. Adapted algorithms: secondMacroRaw = .5 - .5*cos(wheelPhase), remontoire charge decrement and sampled output .35+.65*raw, 5 Hz remontoire smoothing, original .35 raw/.65 remontoire blend at full amount, Evolve’s three FM-depth oscillator rates (.62+.2*operator), and second-hand changes to FM depth, operator cents detune and brightness. Original wheel range .0005–.12 Hz is exposed as MECH RATE. User controls now adjust remontoire amount and recharge interval rather than changing note selection.

Quartz is a clock-face label in the supplied original, not a separately implemented oscillator-drift algorithm. The Quartz page is a clearly new bounded extension: independent deterministic sample/hold noise, phase-continuous rate updates, slew, at most ±2 cents of common detune and at most ±100 ppm of wheel-rate variation. It does not choose or transpose notes. It uses no wall-clock timer or browser scheduling. Motion off disables this movement; REC freezes its phase/state. The original static per-operator DRIFT range is shown as 0–22 cents before the configuration’s operator detune weighting.

Pages: Voice (Shimmer/FM index, Osc Mix, Orbit, Drift); Envelope; EDIT Mechanics (Rate, Evolve, Remontoire, Rewind); ARP shortcut Quartz (Rate, Depth, Slew, Motion), then ARP Slip/Shape. Four universal LFOs remain independent. All rates run from sample frames; expensive detune/index coefficients are computed at the bounded control rate, not per sample.

Patch version 8 keeps the same data size. v2–7 musical data migrates; only the removed Clock process/movement controls 8–15 get the new safe defaults. TORT tone, mixer, effects, tuning, all LFOs and all arp/Slip settings retain their data. Existing stored Climb/Root Run can never reactivate the removed feature.

Validation: test-clock.mjs verifies stable manual and process pitch targets for three minutes with maximum wheel speed, eight controls changing rendered PCM, freeze, persistence and migration from a real v7 patch. Existing instrument, 48-control TORT, LFO, navigation and Slip regressions are required. Physical FM-1 CPU and audio performance remain unverified. The effects feasibility audit is still scoped to its earlier source checkpoint; this Clock update is not an effects port and does not open that hardware gate.

Final combined host/WASM stress: 30 rendered minutes with all three processes, arps/Slip and 12 LFOs; zero dropped commands/nonfinite samples; peak .79443. Aggregate pool diagnostic 257296 bytes (including 104 bytes ordinary BSS), patch 1004 bytes. Control/nav tests and browser knob/page checks passed. No FM-1 firmware build/device timing claim.
