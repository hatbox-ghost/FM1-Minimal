// Removing the editor must not change live keyboard/MIDI note ownership.
import assert from 'node:assert/strict';
import {boot,select,turn} from './test-slip-panel.mjs';
const e=await boot(),tick=()=>e.web_audio_render(128);
for(let m=0;m<4;m++){
 select(e,m);
 for(const page of [32,40,33]){
  e.web_open_page(page);turn(e,0,1);turn(e,1,1);
  assert.equal(e.web_page(),page);assert.equal(e.web_mode(),m);
  e.web_buttons(1<<9);e.web_keys(1<<7);tick();assert(e.web_layer_active(m)&(1<<7));
  e.web_keys(0);e.web_buttons(0);tick();assert.equal(e.web_layer_active(m),0);
  assert.equal(e.web_clip_event(m,0,-1,0),-1);
  for(const n of [36,60,64,84])e.web_midi(9|(0x90<<8)|(n<<16)|(100<<24));e.web_audio_render(128);
  assert.equal(e.web_seq_state(m,23),15);select(e,(m+1)%4);
  for(const n of [36,60,64,84])e.web_midi(8|(0x80<<8)|(n<<16));e.web_audio_render(128);
  assert.equal(e.web_seq_state(m,23),0);select(e,m);assert.equal(e.web_clip_event(m,0,-1,0),-1);
 }
}
assert.equal(e.web_dropped(),0);
console.log('PASS no manual edits, normal audition, and cross-layer MIDI note-off on all three pages.');
