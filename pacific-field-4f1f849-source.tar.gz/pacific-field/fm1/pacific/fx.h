/* SPDX-License-Identifier: GPL-3.0-only */
#pragma once
#include <stdint.h>
#include "delay-sync.h"
#ifdef EN_HOST
#define PF_FX_POOL
#else
#define PF_FX_POOL __attribute__((section(".pool")))
#endif
#ifdef __cplusplus
extern "C" {
#endif
extern int16_t pf_fx_settings[20];
extern int16_t pf_fx_delay_sync,pf_fx_delay_division,pf_fx_bpm;
void pf_fx_init(void);
void pf_fx_frame(float dl,float dr,float rl,float rr,float *outl,float *outr);
uint32_t pf_fx_bytes(void);
uint32_t pf_fx_faults(void);
float pf_fx_meter(int field); /* delay/reverb input, then delay/reverb output peaks */
void pf_clouds_init(void);
void pf_clouds_block(const float *in,float *out,const float *cfg);
uint32_t pf_clouds_bytes(void);
void pf_oliverb_init(void);
void pf_oliverb_block(const float *in,float *out,const float *cfg);
uint32_t pf_oliverb_bytes(void);
#ifdef __cplusplus
}
#endif
