#!/bin/sh
# SPDX-License-Identifier: GPL-3.0-only
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/gen build/emu
python3 tools/gen_font_noraqm.py tools/gen_font.py build/gen/felucca_font.h
python3 pacific/build-fx.py

cp web/emu/index.html web/emu/worklet.js build/emu/
