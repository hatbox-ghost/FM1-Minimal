> Historical implementation note. Page maps, memory numbers and build status describe that checkpoint. Current status: [root README](../../README.md) and [audit report](../../docs/audit-remediation/REPORT.md).

# SLOOP replacement

See [SLOOP-PORT.md](SLOOP-PORT.md) for controls, exact source reuse, tested behavior and remaining omissions. The previous custom sequencer is retired.
