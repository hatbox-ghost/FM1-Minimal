> Historical implementation note. Page maps, memory numbers and build status describe that checkpoint. Current status: [root README](../../README.md) and [audit report](../../docs/audit-remediation/REPORT.md).

# Voice Spread
Each layer stores a smoothed 0–100% Voice Spread setting. EDIT reaches its Voice Spread page (knob 1); Branch also exposes it in place of automatic AIR panning on Mechanics. Voice placement is deterministic, static and centered at zero; no background sweep or automatic keyboard-pan pattern remains. Manual per-note pan and assigned pan LFOs remain explicit overrides, layer pan stays separate, and stereo Slip retains its own deliberate separation.
Patch v9 appends three int16 spread settings. v2–8 migrate with spread zero; legacy factory per-key pan patterns are cleared while other manually set pan values are preserved. The two protected original folders remain unchanged. No effects port or device performance claim.
