import {modeDelta,legacyStep} from './test-panel-order.mjs';
import fs from 'node:fs';import assert from 'node:assert/strict';
export async function boot(path=process.argv[2]){const{instance:{exports:e}}=await WebAssembly.instantiate(fs.readFileSync(path),{wasi_snapshot_preview1:new Proxy({},{get:()=>()=>0}),env:new Proxy({},{get:()=>()=>0})});e._initialize();e.web_boot();return e;}
export function api(e){const run=(n=1024)=>{let energy=0;for(let i=0;i<n;i+=128){const count=Math.min(128,n-i);e.web_render(count);for(const p of[e.web_out_l(),e.web_out_r()])for(const x of new Float32Array(e.memory.buffer,p,count)){assert(Number.isFinite(x)&&Math.abs(x)<=.951);energy+=x*x;}}assert.equal(e.web_dropped(),0);assert.equal(e.web_fx_faults(),0);return energy;};const tap=b=>{e.web_buttons(1<<b);e.web_buttons(0);run();},turn=(r,d)=>{e.web_enc(r,d);run();},select=m=>turn(2,modeDelta(e,m)),combo=(a,b)=>{e.web_buttons(1<<a);e.web_buttons((1<<a)|(1<<b));e.web_buttons(1<<a);e.web_buttons(0);run();};return{run,tap,turn,select,combo};}
{const e=await boot(),a=api(e);a.run();for(let page=0;page<54;page++){e.web_open_page(page);a.tap(6);assert([7,49,50,51].includes(e.web_page()));for(let i=0;i<4;i++)a.turn(1,1);a.tap(5);assert.equal(e.web_page(),48);a.tap(4);assert.equal(e.web_page(),0);}}
{const e=await boot(),a=api(e);a.run();e.web_open_page(7);let levels=[0,1,2,3].map(m=>e.web_layer_level(m));for(let k=0;k<3;k++){a.turn(3+k,-7);assert.equal(e.web_layer_level([0,2,1][k]),levels[[0,2,1][k]]-7);}a.turn(6,-9);assert.equal(e.web_layer_level(3),levels[3]-9);assert.equal(e.web_master_gain(),100);a.turn(1,1);a.turn(6,18);assert.equal(e.web_layer_pan(3),18);a.combo(5,8);assert.equal(e.web_layer_mute(0),1);a.combo(5,9);assert.equal(e.web_layer_solo(0),1);a.tap(8);assert.equal(e.web_page(),8);a.tap(9);assert.equal(e.web_page(),32);assert.equal(e.web_save_project(),0);assert.equal(e.web_store_len(0),15772);e.web_boot();a.run();assert.equal(e.web_master_gain(),100);}
console.log('PASS: direct family entry, mixer cycle from all pages, four direct layer mappings, master persistence, independent mute/solo.');

{const e=await boot(),a=api(e);a.run();a.tap(5);assert.equal(e.web_page(),48);a.turn(3,24);assert.equal(e.web_seq_state(0,16),120);a.turn(4,1);assert.equal(e.web_metronome(),1);a.tap(10);a.run(44100*2);assert.equal(e.web_metronome_clicks(),5);a.tap(10);let n=e.web_metronome_clicks();a.run(44100);assert.equal(e.web_metronome_clicks(),n);a.tap(6);assert.equal(e.web_page(),7);for(let m=0;m<4;m++){a.select(m);let before=e.web_layer_level(m),column=[0,2,1,3].indexOf(m);a.turn(3+column,-1);assert.equal(e.web_layer_level(m),before-1);}}

console.log('PASS: four-engine dashboard macros, shared BPM, single master metronome follows project transport.');

// Physical MASTER fades the entire shared wet/dry output without resetting any voice.
{const e=await boot(),a=api(e);a.run();e.web_keys(1<<7);assert(a.run(30000)>0);e.web_master(0);e.web_render(1);let first=new Float32Array(e.memory.buffer,e.web_out_l(),1)[0];assert(Number.isFinite(first));a.run(10000);assert.equal(a.run(2048),0);assert.equal(e.web_layer_active(0),1<<7);e.web_master(2200);assert(a.run(10000)>0);assert.equal(e.web_layer_active(0),1<<7);}
console.log('PASS: physical MASTER smooths all dry/wet output to silence and back without releasing notes.');

// A near-zero physical MASTER at cold boot must not permanently reduce fixed-point FX resolution.
{const e=await boot(),f=await boot(),a=api(e),b=api(f);e.web_master(1);a.run(10000);b.run(10000);e.web_master(2200);a.run(10000);b.run(10000);e.web_keys(1<<7);f.web_keys(1<<7);for(let j=0;j<300;j++){e.web_render(128);f.web_render(128);for(const out of['web_out_l','web_out_r'])assert.deepEqual(new Float32Array(e.memory.buffer,e[out](),128),new Float32Array(f.memory.buffer,f[out](),128));}}
console.log('PASS: cold-boot MASTER position cannot change dry/FX resolution or the restored output.');

// SAVE recalls the performance and leaves transport stopped.
{
 const e=await boot(),a=api(e);a.run();
 legacyStep(e,0,0,[65]);a.run();
 e.web_open_page(5);a.turn(4,2);const root=e.web_param(21);
 const mix=[];
 for(let m=0;m<4;m++){
  a.select(m);e.web_open_page(7);a.turn(3+[0,2,1,3].indexOf(m),-30-m);
  e.web_open_page(6);a.turn(3,20+m);a.turn(6,30+m);
  a.combo(5,8);a.combo(5,9);
  mix.push([e.web_layer_level(m),e.web_param(24),e.web_param(27),e.web_layer_mute(m),e.web_layer_solo(m)]);
 }
 const keys=mask=>{e.web_keys(mask);a.run();};
 a.select(0);e.web_open_page(0);a.tap(1);a.tap(13);keys(1<<7);keys(0);a.tap(12);const bowlPitch=e.web_voice_frequency(0,7);
 a.select(1);e.web_open_page(8);a.turn(3,1);a.tap(1);keys(1<<7);keys(0);a.tap(13);keys(1<<7);keys(0);a.tap(12);
 a.select(2);e.web_open_page(10);a.turn(5,8);a.turn(4,75);
 const lfo=[e.web_lfo_setting(2,0,1),e.web_lfo_setting(2,0,3)];
 a.select(3);e.web_open_page(0);a.turn(6,28);const glide=e.web_param(3);
 keys(1<<11);a.tap(10);assert.equal(e.web_save_project(),0);keys(0);
 const saved=new Uint8Array(e.memory.buffer,e.web_store(0),e.web_store_len(0)).slice();
 assert.equal(saved.length,15772);assert.equal(new DataView(saved.buffer).getUint32(4,true),23);
 e.web_boot();a.run();assert.equal(e.web_transport(),0);
 for(let m=0;m<4;m++){
  a.select(m);
  assert.deepEqual([e.web_layer_level(m),e.web_param(24),e.web_param(27),e.web_layer_mute(m),e.web_layer_solo(m)],mix[m]);
  assert.equal(e.web_param(21),root);assert.equal(e.web_seq_state(m,3),0);
 }
 assert.equal(e.web_seq_step(0,0,0,0),65);
 assert.equal(e.web_param(3),glide);
 assert.deepEqual([e.web_lfo_setting(2,0,1),e.web_lfo_setting(2,0,3)],lfo);
 assert.equal(e.web_layer_active(0),1<<7);
 assert.equal(e.web_voice_frequency(0,7),bowlPitch);
 assert.equal(e.web_arp_note(1,-1),2);assert.equal(e.web_arp_note(1,0),60);assert.equal(e.web_arp_note(1,1),72);
 assert.equal(e.web_layer_active(3),0,'a physical key without HOLD must not be saved');
 assert.deepEqual(new Uint8Array(e.memory.buffer,e.web_store(0),e.web_store_len(0)),saved);
 assert.equal(e.web_dropped(),0);
}
console.log('PASS whole-performance SAVE, held chord and arp octaves, mix, modulation, clips and idle transport.');

// Recall the same mono priority when the last played key was the lowest.
{
 const e=await boot(),a=api(e);a.run();a.select(3);a.tap(1);
 for(const key of [14,11,7]){e.web_keys(1<<key);a.run();e.web_keys(0);a.run();}
 const pitch=e.web_lead_frequency();
 assert.equal(e.web_save_project(),0);e.web_boot();a.run();
 assert.equal(e.web_layer_active(3),(1<<14)|(1<<11)|(1<<7));
 assert.equal(e.web_lead_frequency(),pitch);
}

// The largest saved chords still fit alongside all boot-time parameter commands.
{
 const e=await boot(),a=api(e);a.run();
 const chord=(1<<27)-1;
 for(let m=0;m<4;m++){
  a.select(m);a.tap(1);e.web_keys(chord);a.run();e.web_keys(0);a.run();
 }
 assert.equal(e.web_save_project(),0);e.web_boot();a.run();
 assert.equal(e.web_dropped(),0);
 for(let m=0;m<4;m++)assert.equal(e.web_layer_active(m),chord);
}
