// Execute the actual browser worker assets with real WASM and transferable-buffer semantics.
import fs from'node:fs';import vm from'node:vm';import assert from'node:assert/strict';import{performance}from'node:perf_hooks';
let allocations=0,Processor,audio,display,frames=0,snapshots=0;
let releaseDisplayCompile;
const displayCompileGate=new Promise(resolve=>releaseDisplayCompile=resolve);
class PooledBuffer extends ArrayBuffer{constructor(n){super(n);allocations++;}}
const wasm=fs.readFileSync(process.argv[2]);const messages=[], projectReplies=[];
const transfer=(message,buffers=[])=>structuredClone(message,{transfer:buffers});
const displayContext=vm.createContext({WebAssembly:{instantiate:async(...args)=>{await displayCompileGate;return WebAssembly.instantiate(...args);}},ArrayBuffer:PooledBuffer,Uint8Array,Uint16Array,Uint32Array,DataView,Proxy,BigInt,Math,Date,Error,String,setTimeout,postMessage:(m,b)=>{
 const result=transfer(m,b);messages.push(result.type);
 if(result.type==='display-frame'){assert.equal(result.fb.length,57600);assert(result.fb.some(v=>v));frames++;audio.onMessage({type:'visual-buffer',buffer:result.snapshotBuffer});display.onmessage({data:{type:'pixel-buffer',buffer:result.fb.buffer}});}
 else if(result.type==='visual-buffer')audio.onMessage(result);
 else if(result.type==='display-error')throw Error(result.message);
}});display=displayContext;
vm.runInContext(fs.readFileSync(new URL('../web/emu/display-worker.js',import.meta.url),'utf8'),displayContext);
class FakeAudioProcessor {
 constructor(){
  this.port={postMessage:(m,b)=>{
   const result=transfer(m,b);
   if(result.type.startsWith('project-'))projectReplies.push(result);
   if(result.type==='frame'&&result.visual){snapshots++;display.onmessage({data:{type:'draw',visual:result.visual}});}
  }};
 }
}
const audioContext=vm.createContext({WebAssembly,ArrayBuffer:PooledBuffer,Uint8Array,Uint16Array,Float32Array,DataView,Proxy,BigInt,Math,Date,performance,currentTime:0,AudioWorkletProcessor:FakeAudioProcessor,registerProcessor:(name,type)=>Processor=type});
vm.runInContext(fs.readFileSync(new URL('../web/emu/worklet.js',import.meta.url),'utf8'),audioContext);audio=new Processor();
const displayLoading=display.onmessage({data:{type:'load',wasm}});
await audio.onMessage({type:'load',wasm,store:{},master:2200});
// A cold browser may compile the graphics instance after audio starts. More
// than three frames must survive this ordering without exhausting the pool.
for(let i=0;i<12;i++)audio.publish();
assert.equal(snapshots,12);assert.equal(audio.visualBuffers.length,3,'early snapshots returned while display compiles');
releaseDisplayCompile();await displayLoading;
assert.equal(allocations,5,'three snapshot and two pixel transfer buffers at startup');
const output=[[new Float32Array(128),new Float32Array(128)]];
// Force display backpressure first; audio continues while only the newest visual state survives.
for(let i=0;i<100;i++){audioContext.currentTime+=128/44100;assert(audio.process([],output));}await new Promise(r=>setTimeout(r,5));
for(let i=0;i<1000;i++){if(i===100)audio.onMessage({type:'page',page:0});if(i===200)audio.onMessage({type:'enc',role:3,n:7});audioContext.currentTime+=128/44100;audio.process([],output);if(i%18===0)await new Promise(r=>setTimeout(r,0));}
await new Promise(r=>setTimeout(r,10));assert(frames>20);assert(snapshots>=frames);assert.equal(allocations,5,'transfer buffers are reused after startup');assert.equal(audio.visualBuffers.length,3);assert.equal(vm.runInContext('pixels.length',displayContext),2);assert.equal(audio.ex.web_blits(),0);assert.equal(audio.ex.web_dropped(),0);assert.equal(audio.ex.web_fx_faults(),0);assert(messages.includes('display-ready'));console.log('PASS: actual browser AudioWorklet/graphics Worker load, publish, coalesce and recycle fixed transfer pools; audio keeps running with zero raster calls or dropped commands.');


// SAVE captures after queued controls, and LOAD replaces the running project in place.
const mask=(1<<7)|(1<<11);
await audio.onMessage({type:'page',page:0});
await audio.onMessage({type:'buttons',mask:1<<1});
await audio.onMessage({type:'buttons',mask:0});
await audio.onMessage({type:'keys',mask});
await audio.onMessage({type:'keys',mask:0});
await audio.onMessage({type:'save-project',id:1});
audio.process([],output);
const saved=projectReplies.pop();
assert.equal(saved.type,'project-saved');assert.equal(saved.id,1);assert.equal(saved.bytes.length,15772);
await audio.onMessage({type:'buttons',mask:1<<1});
await audio.onMessage({type:'buttons',mask:0});
audio.process([],output);
assert.equal(audio.ex.web_layer_active(0),0);
await audio.onMessage({type:'load-project',id:2,bytes:saved.bytes});
assert.equal(projectReplies.pop().ok,true);
audio.process([],output);
assert.equal(audio.ex.web_layer_active(0),mask);
assert.equal(audio.ex.web_seq_state(0,3),0);
await audio.onMessage({type:'load-project',id:3,bytes:new Uint8Array(10)});
assert.equal(projectReplies.pop().ok,false);
assert.equal(audio.ex.web_layer_active(0),mask);
console.log('PASS worklet snapshots and recalls a held set in place, and rejects an invalid payload.');
