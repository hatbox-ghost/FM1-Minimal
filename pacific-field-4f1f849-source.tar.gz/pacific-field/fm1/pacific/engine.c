/* SPDX-License-Identifier: GPL-3.0-only
 * Pacific Field: bounded, single-precision C DSP shared by browser and FM-1 adapter.
 * Original adaptations of the user's Branch, TORT and FM Drone Clock machines.
 */
#include "pacific.h"
#include "fx.h"
#include "branch-elements.h"
#include "../firmware/src/dsp/fastmath.h"
#include <string.h>
#define CL(x,a,b) fm_clampf((x),(a),(b))
#define DEL 16384
#define TAB 2048
#define BARRIER() __asm__ volatile("" ::: "memory")
#include "sine-table.h"
volatile uint32_t pf_active,pf_steps,pf_clock_step,pf_running,pf_frozen,pf_dropped;
volatile float pf_energy[8],pf_clock_phase,pf_peak;
volatile uint8_t en_load;
static const float ratios[5][12]={
 {1,1.059463094f,1.122462048f,1.189207115f,1.25992105f,1.334839854f,1.414213562f,1.498307077f,1.587401052f,1.681792831f,1.781797436f,1.887748625f},
 {1,16.f/15,9.f/8,6.f/5,5.f/4,4.f/3,45.f/32,3.f/2,8.f/5,5.f/3,9.f/5,15.f/8},
 {1,567.f/512,9.f/8,147.f/128,21.f/16,1323.f/1024,189.f/128,3.f/2,49.f/32,7.f/4,441.f/256,63.f/32},
 {1,16.f/15,9.f/8,6.f/5,5.f/4,4.f/3,64.f/45,3.f/2,8.f/5,5.f/3,16.f/9,15.f/8},
 {1,256.f/243,9.f/8,32.f/27,81.f/64,4.f/3,729.f/512,3.f/2,128.f/81,27.f/16,16.f/9,243.f/128}};
const char *const pf_modes[PF_LAYERS]={"BOWL","POLY","TEMPLE","LEAD"};
const char *const pf_pages[PF_PAGES]={"VOICE","ENVELOPE","MOTION","PROCESS","NOTE MIX","GLOBAL","SPACE","MIXER","ARP SLIP","ARP SHAPE","LFO 1","LFO 1 CONFIG","LFO 2","LFO 2 CONFIG","LFO 3","LFO 3 CONFIG","LFO 4","LFO 4 CONFIG","OSC A","OSC B","OSC INTERACTION","VOICE","FILTER","FILTER ENV","AMP ENV","FILTER MODEL","OSC SHAPE","NATIVE LFO","WHEEL SOURCE","MOD ROUTES","VOICE SPREAD","SLOOP NOTES","SLOOP PATTERN","SLOOP BANKS","SLOOP STEP","OLIVERB SPACE","OLIVERB MOTION","CLOUDS DELAY","CLOUDS TEXTURE","FX DETAIL","SLOOP REC SETUP","SEQ SLIP","LEAD OSC 1","LEAD OSC 2","LEAD OSC 3","LEAD FILTER ENV","LEAD NOISE","HOME","PROJECT CLOCK","MIX PAN","MIX ECHO","MIX ROOM","EXCITER","SYSTEM","LFO 1 ROUTES","LFO 2 ROUTES","LFO 3 ROUTES","LFO 4 ROUTES","FM CHARACTER","PAIR 1","PAIR 2","PAIR 3","OP SHAPE 1","OP SHAPE 2","OP SHAPE 3","TIMBRE ENV","OPERATOR ENV","QUARTZ DETAIL","LFO SETUP","OSC TUNING"};
const char *const pf_tunings[5]={"12 TET","5 LIMIT","WTP 7","RILEY 5","PYTHAG"};
const char *const pf_labels[PF_LAYERS][PF_NPAR]={
 {"BODY","RING","WIND","RAIN","ATTACK","RELEASE","BOW","LEVEL","BRIGHTNESS","DAMP","MOTION","BLOW","RAIN MS","STRIKE","POSITION","VARIATION","NOTE LVL","OCTAVE","PAN","FINE","TUNING","ROOT","ANCHOR","LATCH","ECHO","TIME MS","FEEDBACK","ROOM"},
 {"OSC MIX","CUTOFF","RESONANCE","MORPH","ATTACK","RELEASE","WIDTH 1","LEVEL","DRIVE","X-MOD","WIDTH 2","ENV AMOUNT","NOISE","LENGTH","ORDER","GATE","NOTE LVL","OCTAVE","PAN","FINE","TUNING","ROOT","ANCHOR","LATCH","ECHO","TIME MS","FEEDBACK","ROOM"},
 {"SHIMMER","OSC MIX","ORBIT","DRIFT","ATTACK","RELEASE","RATIO SET","LEVEL","MOTION RATE","EVOLUTION","TENSION","RECOVERY MS","DRIFT RATE","DRIFT DEPTH","DRIFT SLEW","DRIFT ON","NOTE LVL","OCTAVE","PAN","FINE","TUNING","ROOT","ANCHOR","LATCH","ECHO","TIME MS","FEEDBACK","ROOM"},
 {"CUTOFF","RESONANCE","CONTOUR","GLIDE","AMP ATTACK","AMP RELEASE","AMP SUSTAIN","LEVEL","FILTER ATK","FILTER DEC","FILTER SUS","AMP DECAY","LEGATO","KBD TRACK","BEND RANGE","MOD DEPTH","NOTE LVL","OCTAVE","PAN","FINE","TUNING","ROOT","ANCHOR","LATCH","DELAY","TIME MS","FEEDBACK","REVERB"}};
/* LFO definitions follow the sine helpers; runtime storage is fixed. */
#include "tort.h"
#include "lead.h"
typedef struct {float c[3],m[3],low,band,mal,excite,x,velocity,inc[3],mi[3];} VoiceDSP;
/* Branch's actual oscillator/resonator state is in branch-elements.cc. Only
 * these four controller/excitation values persist here for each of 60 slots. */
typedef struct {float mal,excite,x,velocity;} BranchDSP;
_Static_assert(sizeof(BranchDSP)==16 && sizeof(VoiceDSP)==72,"voice DSP storage sizes");
typedef struct {float freq,target,env,gate,pan,level,fine;int8_t key,oct;uint16_t minFrames;VoiceDSP *dsp;} Voice;
/* key=0..26, octave=-5..6 via MIDI (keyboard -2..2), minFrames=0..3528. */
_Static_assert(sizeof(void*)!=4 || sizeof(Voice)==36,"32-bit voice routing layout");
typedef struct {uint16_t op;int16_t a;int32_t b;} Cmd;
_Static_assert(sizeof(Cmd)==8,"command ring packing");
typedef struct {int16_t cfg[8];float phase,held,output;uint32_t random,cycles;} PFLfo;
#define PF_LFO_TYPE_DEFINED
typedef struct {uint8_t n,param[24];int16_t base[24],set[24];} PFSeqLocks;
static PFSeqLocks seqLockStates[PF_LAYERS];
static PFSeqPattern seqUndo[PF_LAYERS];
static uint8_t seqUndoBank[PF_LAYERS]; /* zero means no edit, otherwise bank + 1 */
static PFSeqLane seqPrograms[PF_LAYERS]; /* program banks live outside the realtime pool */
typedef struct {PFSeqLane *data;PFSeqLocks *lockState; uint64_t units; uint32_t events,last,frames; int active,queued,step,run,pendingSync,record,arm; uint32_t countin;
 uint32_t seq_abs,seq_off,pass,rskip_abs,rh_last_abs; uint16_t seq_idx;
 uint8_t seq_den,seq_notes[4],seq_n,seq_hold,seq_skip,slide_glide,seq_active,rat_done[4],rskip_n,rskip[4];
 uint8_t rh_n,rh_note[4],rh_start,rh_ties,rh_last,rh_end,rh_rs,rh_offn,rh_off[4]; PFSeqStep rh_bak,rh_put;
 int voiceBase;uint8_t slots[8]; uint32_t age[8],serial; int p[3];uint8_t fillHeld,fillArm,fillBar;uint32_t fillLastBar;uint32_t editRevision;int editResult;uint32_t countUnits;uint8_t countBeat;
} PFSeqRuntime;
/* Eight implemented timing sources, ordered by stable engine ID then ARP/SEQ.
 * No duplicate playheads: retain the original scheduler and note ownership. */
#define PHASE_ONE 16777216u
static uint32_t phaseRate[8],phaseFraction[8];
static uint8_t instrumentSlip[PF_LAYERS];
typedef struct {uint64_t next,off[8],launch,wrap;uint16_t owner[8];uint8_t scheduled,status,recordClip,recordEdited;uint32_t cycle;} PFEventRuntime;
static PFEventRuntime clipRuntime[PF_LAYERS];
static uint32_t phase_advance(int id,uint32_t bpm){uint32_t rate=phaseRate[id];if(rate==PHASE_ONE)return bpm;uint64_t x=(uint64_t)bpm*rate+phaseFraction[id];phaseFraction[id]=x&(PHASE_ONE-1);return x>>24;}
static int seqProjectBpm=96;
typedef struct {
 PFSeqRuntime seq;uint8_t midiNotes[4];uint32_t midiAge[4],midiSerial;
 uint8_t tort[56];PFLfo lfos[4];float lfoPitch,lfoPan,lfoAmp,baseSmooth[PF_NPAR];

 uint32_t seed,heldMask;
 struct {uint8_t note,key;} arpNotes[27];uint8_t arpCount,arpRelease[27];
 float arpPan[2][2];int arpConfig[8],arpCursor[2],arpSplit,arpWait;float arpGate[2],arpPeriod;uint32_t arpTicks,arpEvent[2],arpLast[2];
 float mechPhase,remCharge,remOutput,remSmooth,quartzTimer,quartzTarget,quartzSmooth,clockMacro,clockEvolve[3],clockDetune[3],clockIndex[3],clockBrightness;uint32_t quartzSeed;
 int spread;float spreadSmooth;int process,mixMute,mixSolo,mixPan;float mixGain,meter;
 int mode,par[PF_NPAR],arpOn,arpIndex,octave,smoothReady;
 float sampleClock,arpLeft,rainLeft;
 float smooth[PF_NPAR],masterRamp,dcL,dcR,lastL,lastR;
 Voice *v; Cmd *queue; volatile uint32_t qw,qr;
 volatile uint32_t active,steps,clock_step,running,frozen,dropped;
 volatile float energy[8],clock_phase,peak;
} Context;
static Context layers[PF_LAYERS] EN_POOL;
/* Command queues occupy ordinary RAM; audio voice/effect state stays in POOL. */
static Cmd commandQueues[PF_LAYERS][256];
static Voice routeVoices[PF_LAYERS][PF_NV] EN_POOL;
static BranchDSP branchDsp[PF_NV] EN_POOL;
static VoiceDSP templeDsp[PF_NV] EN_POOL;
/* TORT's oscillator/filter/envelopes live in tort_voices. Generic DSP writes
 * are inert routing scaffolding only.
 * Arp gains live per head in Context, independent of inert TORT DSP scratch.
 * Branch generic frequency writes also use this unread scratch. Its four
 * persistent fields use branchDsp; TEMPLE retains all per-note full DSP state. */
static VoiceDSP tortRoutingScratch EN_POOL;
static VoiceDSP leadRoutingScratch;
static Context *current;
static int projectTranspose,transposeReady;static float transposeRatio=1,transposeTarget=1;
static float projectMaster=1,projectMasterTarget=1,physicalGainReference;
static int projectMetronome,metroWasRunning;static uint32_t metroUnits,metroBeat;
static int editLayer,fxResetRequested;static float fxBuses[4][128] EN_POOL;static float fxReturnGain;




static uint8_t arpSyncMask;
static volatile int channelSwapResult;
int pf_channel_swap_result(void){return channelSwapResult;}

static int channel_busy(const Context *channel){
 if(channel->seq.run||channel->seq.record||channel->seq.arm||channel->seq.countUnits||
    channel->process||channel->heldMask)return 1;
 for(int v=48;v<52;v++)if(channel->v[v].gate)return 1;
 return 0;
}

static void channel_swap(int target){
 int source=current->mode;
 Context *other=&layers[target];
 if(channel_busy(current)||channel_busy(other)){channelSwapResult=-1;return;}

 // The program and lock pointers travel with the channel. Engine voices stay put.
 PFSeqRuntime seq=current->seq;
 current->seq=other->seq;
 other->seq=seq;
 PFEventRuntime clip=clipRuntime[source];
 clipRuntime[source]=clipRuntime[target];
 clipRuntime[target]=clip;
 current->seq.editRevision++;
 other->seq.editRevision++;
 for(int i=0;i<8;i++){
  int value=current->arpConfig[i];
  current->arpConfig[i]=other->arpConfig[i];
  other->arpConfig[i]=value;
 }
 current->arpOn=current->arpConfig[0];
 other->arpOn=other->arpConfig[0];
 current->arpLeft=other->arpLeft=0;
 current->arpCursor[0]=other->arpCursor[0]=0;
 unsigned differing=((arpSyncMask>>source)^(arpSyncMask>>target))&1u;
 arpSyncMask^=(differing<<source)|(differing<<target);
 for(int i=0;i<3;i++){
  int param=(int[]){7,24,27}[i],value=current->par[param];
  current->par[param]=other->par[param];
  other->par[param]=value;
 }
 int pan=current->mixPan,mute=current->mixMute,solo=current->mixSolo;
 current->mixPan=other->mixPan;current->mixMute=other->mixMute;current->mixSolo=other->mixSolo;
 other->mixPan=pan;other->mixMute=mute;other->mixSolo=solo;
 uint8_t *historyA=(uint8_t*)&seqUndo[source],*historyB=(uint8_t*)&seqUndo[target];
 for(unsigned i=0;i<sizeof(PFSeqPattern);i++){
  uint8_t value=historyA[i];historyA[i]=historyB[i];historyB[i]=value;
 }
 uint8_t history=seqUndoBank[source];seqUndoBank[source]=seqUndoBank[target];seqUndoBank[target]=history;
 channelSwapResult=1;
}
#define seed (current->seed)
#define heldMask (current->heldMask)
#define mode (current->mode)
#define par (current->par)
#define arpOn (current->arpOn)
#define arpIndex (current->arpIndex)
#define octave (current->octave)
#define smoothReady (current->smoothReady)
#define sampleClock (current->sampleClock)
#define arpLeft (current->arpLeft)
#define rainLeft (current->rainLeft)
#define smooth (current->smooth)
#define masterRamp (current->masterRamp)
#define dcL (current->dcL)
#define dcR (current->dcR)
#define lastL (current->lastL)
#define lastR (current->lastR)
#define v (current->v)
#define queue (current->queue)
#define qw (current->qw)
#define qr (current->qr)
#define pf_active (current->active)
#define pf_steps (current->steps)
#define pf_clock_step (current->clock_step)
#define pf_running (current->running)
#define pf_frozen (current->frozen)
#define pf_dropped (current->dropped)
#define pf_energy (current->energy)
#define pf_clock_phase (current->clock_phase)
#define pf_peak (current->peak)
static int single_post(int op,int a,int b){uint32_t w=qw;if(w-qr>=256){pf_dropped++;return 0;}queue[w&255]=(Cmd){op,a,b};BARRIER();qw=w+1;return 1;}
static float rnd(void){seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;return (float)(seed&65535)/32768.f-1.f;}
static float sn(float phase){phase-=fm_floorf(phase);float x=phase*TAB;int i=(int)x;return sine[i]+(sine[i+1]-sine[i])*(x-i);}
static float cycle(float x){return x-fm_floorf(x);}
#include "lfo.h"
#include "temple-fm.h"
static void lfo_key_reset(void){for(int slot=0;slot<4;slot++)if(current->lfos[slot].cfg[5])lfo_reset(&current->lfos[slot]);}
float pf_hz(int key,const int16_t *p,int oct,int fine){int tuning=p[20];if(tuning<0||tuning>4)tuning=0;int ref=tuning==2?3:tuning==3?1:0;int degree=(key+5-ref)%12,baseOct=(key+5-ref)/12;return p[22]*.1f*ratios[tuning][degree]*fm_exp2f((float)(oct+baseOct)+(float)p[21]/12.f+(float)fine/1200.f);}
static float freq(int key,int oct,int fine){int16_t p[PF_NPAR];for(int i=20;i<24;i++)p[i]=par[i];return pf_hz(key,p,oct,fine);}
static void setvoice(int i,int key,int oct,float level,int retrigger){Voice *a=&v[i];int fresh=!a->gate||retrigger;a->key=key;a->oct=oct;a->target=freq(key,oct,(int)a->fine);if(a->freq<1||a->env<.001f)a->freq=a->target;if(mode==PF_TORT&&(!a->gate||retrigger))tort_note(i,current->tort,a->target,level/fm_maxf(v[key].level,.001f));a->gate=1;a->level=level;if(mode==PF_LEAD){pf_lead_event(i);}if(retrigger){if(mode==PF_BRANCH){BranchDSP *s=&branchDsp[i];s->excite=.7f;s->mal=1;s->velocity+=.15f;}else{a->dsp->excite=.7f;a->dsp->mal=1;a->dsp->velocity+=.15f;}}if(mode==PF_CLOCK&&fresh)temple_note(i,a->dsp);}
static void arp_bank_clear(void){current->arpCount=0;memset(current->arpRelease,255,sizeof current->arpRelease);heldMask=0;}
static void arp_bank_mask(void){heldMask=0;for(int j=0;j<current->arpCount;j++)heldMask|=1u<<current->arpNotes[j].key;}
static void arp_bank_key(int key,int on,int noteOct){
 int note=53+key+12*noteOct;if(note<0||note>127)return;
 if(!on){note=current->arpRelease[key];current->arpRelease[key]=255;}
 int found=-1;for(int j=0;j<current->arpCount;j++)if(current->arpNotes[j].note==note)found=j;
 if(!on)for(int k=0;k<27;k++)if(current->arpRelease[k]==note){if(found>=0)current->arpNotes[found].key=k;arp_bank_mask();return;}
 if(!on||(on==2&&found>=0)){if(found>=0){for(int j=found+1;j<current->arpCount;j++)current->arpNotes[j-1]=current->arpNotes[j];current->arpCount--;}}
 else {if(found<0&&current->arpCount>=27)return;current->arpRelease[key]=(uint8_t)note;v[key].oct=noteOct;if(found<0&&current->arpCount<27){int j=current->arpCount++;while(j>0&&current->arpNotes[j-1].note>note){current->arpNotes[j]=current->arpNotes[j-1];j--;}current->arpNotes[j].note=note;current->arpNotes[j].key=key;}}
 arp_bank_mask();if(!current->arpCount)v[38].gate=v[39].gate=0;
}
static void silence(int hard){arp_bank_clear();pf_active=0;for(int i=0;i<PF_NV;i++){v[i].gate=0;if(mode==PF_BRANCH)branchDsp[i].excite=0;else if(mode!=PF_CLOCK)v[i].dsp->excite=0;if(hard){v[i].env=0;v[i].minFrames=0;if(mode==PF_BRANCH)branchDsp[i].mal=0;else v[i].dsp->mal=0;v[i].dsp->low=v[i].dsp->band=0;}}if(hard){masterRamp=0;if(mode==PF_TORT){memset(tort_voices,0,sizeof tort_voices);}}}
static void branch_seed(void){static const int notes[8]={7,11,14,18,19,23,26,30};for(int i=0;i<8;i++){int k=notes[i]+(int)(rnd()*2);if(k>26)k-=12;Voice *a=&v[30+i];a->fine=0;branchDsp[30+i].x=rnd()*.03f;branchDsp[30+i].velocity=0;a->pan=0;a->freq=0;setvoice(30+i,k,-1,.48f,1);}}
/* Stable anchor and fifth: no scale wheel, climb, root travel or interval stepping. */
/* Once the short stereo fade is silent, do not keep inaudible doubles running. */
static void slip_idle_voices(int first,int end){for(int i=first;i<end;i++){v[i].gate=0;v[i].env=0;v[i].minFrames=0;if(mode==PF_CLOCK)memset(&temple_eg[i],0,sizeof temple_eg[i]);else if(mode==PF_TORT)memset(&tort_voices[i],0,sizeof tort_voices[i]);}}
static void clock_notes(void){setvoice(27,7,-1,.75f,0);setvoice(28,14,-1,.55f,0);v[29].gate=0;pf_clock_step=0;}
static const float FMCONFIG[7][3][5];
static void clock_mechanics(float dt){
 if(pf_running&&!pf_frozen&&par[15]){
  current->quartzTimer+=dt*(.005f+smooth[12]*.00795f);
  if(current->quartzTimer>=1||!current->quartzSeed){uint32_t x=current->quartzSeed?current->quartzSeed:93817;x^=x<<13;x^=x>>17;x^=x<<5;current->quartzSeed=x;current->quartzTarget=(x&65535)/32768.f-1;current->quartzTimer=cycle(current->quartzTimer);}
  current->quartzSmooth+=(current->quartzTarget-current->quartzSmooth)*CL(dt/(.02f+smooth[14]*.04f),0,1);
  current->mechPhase=cycle(current->mechPhase+dt*smooth[8]*.0005f*(1+current->quartzSmooth*smooth[13]*.000001f));
  float raw=.5f-.5f*sn(current->mechPhase+.25f);
  current->remCharge-=dt/CL(smooth[11]*.001f,.08f,4);
  if(current->remCharge<=0){current->remCharge+=1;current->remOutput=.35f+.65f*raw;}
  current->remSmooth+=(current->remOutput-current->remSmooth)*CL(dt*5,0,1);
  current->clockMacro=CL(raw*(1-.65f*smooth[10]*.01f)+current->remSmooth*.65f*smooth[10]*.01f,0,1);
  float evolve=.002f+smooth[9]*.00118f;
  for(int j=0;j<3;j++)current->clockEvolve[j]=cycle(current->clockEvolve[j]+dt*evolve*(.62f+.2f*j)*(1+current->clockMacro*smooth[2]*.036f));
 }
 pf_clock_phase=current->mechPhase;
 float macro=par[15]?current->clockMacro:0;
 current->clockBrightness=CL(FM_TWO_PI*(2300+macro*smooth[2]*36)/PF_SR,.002f,.8f);
 int algorithm=par[6]%7;for(int j=0;j<3;j++){const float *cfg=FMCONFIG[algorithm][j];float orbit=smooth[2]*.01f,evolve=par[15]?sn(current->clockEvolve[j]):0;current->clockIndex[j]=smooth[0]*.055f*cfg[2]*(.78f+macro*orbit*.78f+evolve*(.11f+macro*.13f));float cents=cfg[4]*(smooth[3]*.22f+macro*orbit*7.5f)*(1+j*.12f)+(par[15]?current->quartzSmooth*smooth[13]*.02f:0);current->clockDetune[j]=fm_exp2f(cents/1200.f);}

}
static void start(void){if(mode==PF_LEAD){pf_running=1;current->process=0;return;}current->process=1;pf_running=1;arpLeft=0;rainLeft=0;if(mode==PF_BRANCH)branch_seed();if(mode==PF_CLOCK)clock_notes();}
#include "block_seq.h"
static int8_t tortRoutes[4][4];

static float oscillatorMod[PF_LAYERS][4]; /* three cents offsets and Slop amount, ordinary RAM */
static void drain(void){while(qr!=qw){Cmd c=queue[qr&255];qr++;switch(c.op){case PF_TEMPLE_PARAM:if(c.a>=0&&c.a<PF_TEMPLE_BYTES)temple_params[c.a]=(uint8_t)CL(c.b,0,temple_max(c.a));break;case PF_TORT_ROUTE:if(c.a>=0&&c.a<16)tortRoutes[c.a/4][c.a%4]=(int8_t)CL(c.b,c.a%2?-100:0,c.a%2?100:pf_lfo_count(PF_TORT)-1);break;case PF_GLOBAL:if(c.a==0)projectTranspose=(int)CL(c.b,-48,48);if(c.a==2)projectMetronome=!!c.b;if(c.a==3)for(int layer=0;layer<PF_LAYERS;layer++)instrumentSlip[layer]=(int)CL(c.b,0,100);if(c.a==4){if(c.b)arpSyncMask|=1u<<mode;else arpSyncMask&=~(1u<<mode);}break;case PF_LEAD_PARAM:pf_lead_patch(c.a,c.b);break;case PF_LEAD_BEND:if(c.a){pf_lead_wheel(c.b);}else{pf_lead_bend(c.b);}break;case PF_FX:if(c.a>=0&&c.a<20)pf_fx_settings[c.a]=c.b;else if(c.a==20)pf_fx_delay_sync=!!c.b;else if(c.a==21)pf_fx_delay_division=(int)CL(c.b,0,PF_DELAY_DIV_COUNT-1);break;case PF_SEQ:seq_command(c.a,c.b);break;case PF_CHANNEL_SWAP:channel_swap(c.a);break;case PF_MIDI:{int note=c.a,h=-1;if(note<0||note>127)break;for(int j=0;j<4;j++)if(current->midiNotes[j]==note&&v[48+j].gate){h=j;break;}if(!c.b){if(h>=0)v[48+h].gate=0;break;}if(h<0)for(int j=0;j<4;j++)if(!v[48+j].gate&&(h<0||current->midiAge[j]<current->midiAge[h]))h=j;if(h<0){h=0;for(int j=1;j<4;j++)if(current->midiAge[j]<current->midiAge[h])h=j;}int key=note-53,oct=0;while(key<0){key+=12;oct--;}while(key>26){key-=12;oct++;}v[48+h].fine=v[key].fine;v[48+h].pan=v[key].pan;v[48+h].env=0;v[48+h].freq=0;setvoice(48+h,key,oct,v[key].level*c.b/127.f,1);current->midiNotes[h]=note;current->midiAge[h]=++current->midiSerial;pf_running=1;break;}case PF_MODE:mode=(c.a%PF_LAYERS+PF_LAYERS)%PF_LAYERS;pf_running=0;pf_frozen=0;silence(1);arpIndex=0;pf_clock_step=0;pf_clock_phase=0;smoothReady=0;break;case PF_PARAM:if(c.a>=0&&c.a<PF_NPAR){par[c.a]=c.b;if(c.a>=20&&c.a<=22){for(int j=0;j<PF_NV;j++)if(v[j].target>1)v[j].target=freq(v[j].key,v[j].oct,(int)v[j].fine);}}break;case PF_TORT_PARAM:if(c.a>=0&&c.a<56)current->tort[c.a]=(uint8_t)CL(c.b,0,tort_max(c.a));break;case PF_LFO:if(c.a>=0&&c.a<32){int index=c.a%8;const int hi[8]={100,100,5,pf_lfo_count(mode)-1,1,1,359,100};current->lfos[c.a/8].cfg[index]=(int16_t)CL(c.b,0,hi[index]);}break;case PF_MIX:if(c.a==3)current->spread=(int)CL(c.b,0,100);else if(c.a==0)current->mixPan=c.b;else if(c.a==1)current->mixMute=c.b;else if(c.a==2)current->mixSolo=c.b;break;case PF_PLAY:if(c.a==2){if(!pf_running){arpLeft=0;current->arpWait=-1;}pf_running=1;}else if(c.a){start();}else{seq_command(10001,0);pf_running=0;silence(0);}break;case PF_PANIC:fxResetRequested=1;seq_command(10001,0);current->process=0;pf_running=0;silence(1);break;case PF_FREEZE:pf_frozen=c.a;break;case PF_ARP:if(c.a==8){arp_bank_clear();v[38].gate=v[39].gate=0;for(int k=0;k<27;k++)if(c.b&(1u<<k))arp_bank_key(k,1,v[k].oct);}if(c.a>=0&&c.a<8){current->arpConfig[c.a]=c.b;if(c.a==0){int previous=arpOn;arpOn=!!c.b;if(arpOn&&!previous){current->arpCount=0;for(int k=0;k<27;k++)if(heldMask&(1u<<k)){int j=current->arpCount++;current->arpNotes[j].key=k;current->arpNotes[j].note=53+k+12*v[k].oct;current->arpRelease[k]=current->arpNotes[j].note;}for(int i=1;i<current->arpCount;i++)for(int j=i;j>0&&current->arpNotes[j-1].note>current->arpNotes[j].note;j--){uint8_t n=current->arpNotes[j].note,k=current->arpNotes[j].key;current->arpNotes[j]=current->arpNotes[j-1];current->arpNotes[j-1].note=n;current->arpNotes[j-1].key=k;}arpLeft=0;current->arpCursor[0]=current->arpCursor[1]=0;current->arpWait=-1;current->arpSplit=0;for(int k=0;k<27;k++){v[k].gate=0;v[k].minFrames=0;}}if(!arpOn){v[38].gate=v[39].gate=0;current->arpWait=-1;for(int k=0;k<27;k++)if(heldMask&(1u<<k))setvoice(k,k,v[k].oct,v[k].level,0);}}}break;case PF_KEY:case PF_RECALL_KEY:{
 int k=c.a,keyOct=c.op==PF_RECALL_KEY?c.b:octave,on=c.op==PF_RECALL_KEY?1:c.b;
 if(c.op==PF_RECALL_KEY)pf_running=1;if(k<0||k>26)break;if(arpOn){if(on&&!current->arpCount)lfo_key_reset();arp_bank_key(k,on,keyOct);break;}if(on){if(!heldMask)lfo_key_reset();heldMask|=1u<<k;if(!arpOn){setvoice(k,k,keyOct,v[k].level,mode==PF_BRANCH);/* A new keyboard note starts at its played pitch even over a release tail. */v[k].freq=v[k].target;for(int j=0;j<3;j++){v[k].dsp->inc[j]=v[k].freq*transposeRatio/PF_SR;if(mode!=PF_CLOCK)v[k].dsp->mi[j]=v[k].dsp->inc[j];}v[k].minFrames=3528;}}else{heldMask&=~(1u<<k);v[k].gate=0;}break;}case PF_NOTE:if(c.a==1){octave=c.b;}else if(c.a>=100&&c.a<127){int k=c.a-100;v[k].level=c.b*.01f;}else if(c.a>=200&&c.a<227){v[c.a-200].pan=c.b*.01f;}else if(c.a>=300&&c.a<327){int k=c.a-300;v[k].fine=c.b;v[k].target=freq(k,v[k].oct,c.b);}break;case PF_ACTION:if(mode==PF_BRANCH){if(c.a)branch_seed();else for(int i=30;i<38;i++){branchDsp[i].mal=1;branchDsp[i].excite=.6f;branchDsp[i].velocity+=.2f;}}else if(mode==PF_CLOCK){/* No automatic note-shifting action. */}else{arpIndex++;arpLeft=0;}break;}}}
static void single_init(void){memset(par,0,sizeof par);silence(1);qw=qr=0;pf_running=pf_frozen=pf_dropped=0;sampleClock=0;mode=0;arpOn=0;octave=0;smoothReady=0;for(int i=0;i<27;i++){v[i].level=.65f;v[i].pan=0;}}
static void controls(uint32_t n){float dt=n/PF_SR;sampleClock+=dt;current->spreadSmooth+=(current->spread*.01f-current->spreadSmooth)*.075f;for(int i=0;i<PF_NPAR;i++){if(!smoothReady)current->baseSmooth[i]=par[i];else current->baseSmooth[i]+=(par[i]-current->baseSmooth[i])*.075f;smooth[i]=current->baseSmooth[i];}smoothReady=1;
 float sums[PF_NPAR]={0};float pitch=0,pan=0,amp=0,allPitch=0;memset(oscillatorMod[mode],0,sizeof oscillatorMod[mode]);int anyAmp=0;
 for(int slot=0;slot<4;slot++){PFLfo *a=&current->lfos[slot];lfo_tick(a,dt,current->arpConfig[1]>=30?current->arpConfig[1]:96);int d=a->cfg[3];if(d<=0||d>=pf_lfo_count(mode)||!a->cfg[1])continue;const PFDestination *dest=&destinations[mode][d];float amount=a->cfg[1]*.01f*a->output*dest->range;if(dest->parameter>=0)sums[dest->parameter]+=amount;else if(dest->parameter==-5)allPitch+=amount;else if(dest->parameter<=-6&&dest->parameter>=-8)oscillatorMod[mode][-dest->parameter-6]+=amount;else if(dest->parameter==-9)oscillatorMod[mode][3]+=amount;else if(dest->parameter==-2)pitch+=amount;else if(dest->parameter==-3)pan+=amount;else if(dest->parameter==-4){amp+=amount;anyAmp=1;}}
 if(mode==PF_TORT)for(int slot=0;slot<4;slot++)for(int route=0;route<2;route++){int d=tortRoutes[slot][route*2],depth=tortRoutes[slot][route*2+1];if(d<=0||d>=pf_lfo_count(PF_TORT)||!depth)continue;const PFDestination *dest=&destinations[mode][d];float amount=current->lfos[slot].output*depth*.01f*dest->range;if(dest->parameter>=0)sums[dest->parameter]+=amount;else if(dest->parameter==-5)allPitch+=amount;else if(dest->parameter<=-6&&dest->parameter>=-8)oscillatorMod[mode][-dest->parameter-6]+=amount;else if(dest->parameter==-9)oscillatorMod[mode][3]+=amount;else if(dest->parameter==-2)pitch+=amount;else if(dest->parameter==-3)pan+=amount;else if(dest->parameter==-4){amp+=amount;anyAmp=1;}}
 if(mode==PF_TORT)for(int d=1;d<pf_lfo_count(PF_TORT);d++){const PFDestination *dest=&destinations[mode][d];if(dest->parameter>=0)smooth[dest->parameter]=current->baseSmooth[dest->parameter]+sums[dest->parameter];}
 if(mode!=PF_TORT)for(int slot=0;slot<4;slot++){PFLfo *a=&current->lfos[slot];int d=a->cfg[3];if(d>0&&d<pf_lfo_count(mode)&&a->cfg[1]){const PFDestination *dest=&destinations[mode][d];if(dest->parameter>=0)smooth[dest->parameter]=CL(current->baseSmooth[dest->parameter]+sums[dest->parameter],dest->low,dest->high);}}
 current->lfoPitch=fm_exp2f((CL(pitch,-100,100)+CL(allPitch,-2400,2400))/1200.f);current->lfoPan=CL(pan,-1,1);current->lfoAmp=anyAmp?CL(1+amp,0,1):1;
 if(pf_running&&!pf_frozen){if(mode==PF_BRANCH&&current->process){rainLeft-=dt;float spring=.3f+smooth[8]*.08f,damp=.4f+smooth[9]*.045f;for(int i=30;i<38;i++){BranchDSP *s=&branchDsp[i];float wind=sn(sampleClock*(.025f+i*.0007f)+i*.13f)*smooth[2]*.003f;float coupled=i>30?branchDsp[i-1].x*smooth[10]*.003f:0;s->velocity+=(-s->x*spring-s->velocity*damp+wind+coupled)*dt;s->x+=s->velocity*dt;s->excite*=fm_expf(-dt/(.4f+smooth[1]*.09f));pf_energy[i-30]=CL(s->excite+fm_fabsf(s->velocity)*5,0,1);}if(rainLeft<=0&&smooth[3]>0){int center=par[14]*7/100;int width=par[15]*7/100;int index=center+(int)(rnd()*(width+.5f));if(index<0)index=0;if(index>7)index=7;float hit=CL(smooth[13]*.01f*(1+rnd()*smooth[15]*.008f),0,1.5f);branchDsp[30+index].excite=hit;branchDsp[30+index].mal=hit;branchDsp[30+index].velocity+=.06f;rainLeft=(smooth[12]*.001f)*(1+rnd()*.35f)*(1.05f-smooth[3]*.0095f);}}

 }
 if(mode==PF_CLOCK){clock_mechanics(dt);temple_prepare();}
 if(arpOn){for(int k=0;k<27;k++){v[k].gate=0;v[k].minFrames=0;}}
 else if(pf_running)for(int k=0;k<27;k++)v[k].gate=(heldMask>>k)&1;

 pf_active=heldMask;
 for(int i=0;i<PF_NV;i++){Voice *a=&v[i];if(a->target<1)continue;float glide=.07f;a->freq+=(a->target-a->freq)*CL(dt/glide,0,1);float drift=mode==PF_TORT?smooth[3]*.00006f*sn(sampleClock*.03f+i*.21f):0;float f=a->freq*(1+drift)*current->lfoPitch*transposeRatio;for(int j=0;j<3;j++){a->dsp->inc[j]=f/PF_SR;if(mode!=PF_CLOCK)a->dsp->mi[j]=f/PF_SR;}}}
static float arp_interval(void){static const float division[6]={4,2,1,.5f,.25f,.125f};int d=current->arpConfig[2];if(d<0||d>5)d=2;return fm_maxf(.024f,60.f/CL((arpSyncMask&(1u<<mode))?seqProjectBpm:current->arpConfig[1],30,240)*division[d]);}
static void arp_fire(int head){int count=current->arpCount;int length=current->arpConfig[4];if(length<count)count=length;if(count<=0)return;int index=current->arpCursor[head]++,order=current->arpConfig[5];int slot=index%count;if(order==1)slot=count-1-slot;if(order==2){int span=count>1?count*2-2:1;slot=index%span;if(slot>=count)slot=span-slot;}if(order==3){float random=rnd();slot=(int)((random+1)*.499f*count);}if(slot>=count)slot=count-1;int key=current->arpNotes[slot].key,note=current->arpNotes[slot].note,playKey=note-53,playOct=0;while(playKey<0){playKey+=12;playOct--;}while(playKey>26){playKey-=12;playOct++;}int voice=38+head;setvoice(voice,playKey,playOct,v[key].level*current->arpConfig[7]*.01f,1);v[voice].fine=v[key].fine;v[voice].target=freq(playKey,playOct,(int)v[key].fine);v[voice].freq=v[voice].target;for(int j=0;j<3;j++){v[voice].dsp->inc[j]=v[voice].freq*transposeRatio/PF_SR;if(mode!=PF_CLOCK)v[voice].dsp->mi[j]=v[voice].dsp->inc[j];}v[voice].pan=v[key].pan;current->arpPan[head][0]=fm_sqrtf((1-v[voice].pan)*.5f)*.70710678f;current->arpPan[head][1]=fm_sqrtf((1+v[voice].pan)*.5f)*.70710678f;current->arpGate[head]=(int)(current->arpPeriod*CL(current->arpConfig[6]*.01f,.02f,.95f));pf_steps=key;current->arpEvent[head]++;current->arpLast[head]=current->arpTicks;}
static void arp_sample(void){
 if(!arpOn||!pf_running){v[39].gate=0;current->arpSplit=0;return;}if(pf_frozen)return;current->arpTicks++;float period=arp_interval()*PF_SR;
 if(current->arpPeriod>0&&fm_fabsf(period-current->arpPeriod)>.01f)arpLeft*=period/current->arpPeriod;current->arpPeriod=period;
 if(arpLeft<=0){arp_fire(0);arpLeft+=period;}uint32_t adv=phase_advance(2*mode,1);arpLeft-=adv;
 if(current->arpGate[0]>0){current->arpGate[0]-=adv;if(current->arpGate[0]<=0)v[38].gate=0;}
}

static float morph(Voice *a,float wave,float shape){float p=a->dsp->c[0],s=sn(p),tri=sn(p)-sn(p*3)/9.f+sn(p*5)/25.f;float saw=s-sn(p*2)*.5f+sn(p*3)/3.f-sn(p*4)*.25f+sn(p*5)*.2f;float pulse=s+sn(p*3)/3.f+sn(p*5)/5.f;float x=wave*.03f;float out=x<1?s+(tri-s)*x:x<2?tri+(saw-tri)*(x-1):saw+(pulse-saw)*(x-2);a->dsp->c[0]=cycle(p+a->dsp->inc[0]);return out*(1-shape*.002f)+sn(p*2)*shape*.0015f;}
static const float FMCONFIG[7][3][5]={{{1.0f,1.0f,0.26f,0.31f,-1.0f},{1.0f,2.0f,0.24f,0.18f,0.0f},{0.5f,1.5f,0.18f,0.2f,1.0f}},{{1.0f,2.0f,0.34f,0.28f,-1.0f},{1.0f,3.0f,0.3f,0.19f,0.0f},{0.5f,2.5f,0.2f,0.17f,1.0f}},{{1.0f,1.414f,0.38f,0.24f,-1.0f},{1.0f,2.71f,0.34f,0.17f,0.0f},{0.5f,3.5f,0.24f,0.14f,1.0f}},{{1.0f,2.0f,0.115f,0.33f,-1.7f},{1.5f,3.0f,0.09f,0.25f,0.8f},{2.0f,4.0f,0.065f,0.18f,2.2f}},{{1.0f,1.0f,0.18f,0.3f,-1.0f},{2.0f,2.0f,0.1f,0.16f,0.0f},{0.5f,0.5f,0.12f,0.2f,1.0f}},{{1.0f,1.0f,0.34f,0.3f,-1.0f},{1.0f,4.0f,0.28f,0.18f,0.0f},{2.0f,3.0f,0.18f,0.12f,1.0f}},{{1.0f,1.0f,0.44f,0.3f,-1.0f},{1.0f,3.0f,0.34f,0.16f,0.0f},{0.5f,5.0f,0.22f,0.12f,1.0f}}};
static void lead_render(float *l,float *r,uint32_t n,float gain){
 float pitches[PF_NV],levels[PF_NV];
 uint8_t gates[PF_NV];
 for(uint32_t k=0;k<n;k++){
  seq_sample(k);arp_sample();
  for(int j=0;j<PF_NV;j++){
   pitches[j]=v[j].target;
   levels[j]=v[j].level;
   gates[j]=(uint8_t)(v[j].gate&&j!=39&&j<52);
   if(v[j].minFrames>0)v[j].minFrames--;
   v[j].env=v[j].gate?1:v[j].env*.999f;
  }
  int slot=pf_lead_slot();
  float x=pf_lead_sample(pitches,levels,gates,smooth,current->lfoPitch,current->lfoAmp,
                         current->lfos[0].output,transposeRatio,oscillatorMod[mode]);
  float pan=CL((slot>=0?v[slot].pan:0)+current->lfoPan,-1,1);
  float L=x*(.5f-pan*.45f),R=x*(.5f+pan*.45f);
 float outL=L-lastL+.995f*dcL,outR=R-lastR+.995f*dcR;lastL=L;lastR=R;dcL=outL;dcR=outR;float g=gain*smooth[7]*.01f;l[k]=CL(outL*g,-.92f,.92f);r[k]=CL(outR*g,-.92f,.92f);}}
static void single_render(float *l,float *r,uint32_t n,float gain){drain();controls(n);if(mode==PF_LEAD){lead_render(l,r,n,gain);return;}if(mode==PF_TORT)tort_prepare(current->tort,smooth,par,oscillatorMod[mode]);float aa=smooth[4]*.01f;float attack=1.f/(PF_SR*(.005f+7.f*aa*aa*aa)),release=1.f/(PF_SR*(.02f+9.f*(smooth[5]*.01f)*(smooth[5]*.01f)*(smooth[5]*.01f)));float morphWave=smooth[0],cut=mode==PF_TORT?smooth[1]:mode==PF_BRANCH?smooth[0]:70;float cutoff=100+cut*cut*.65f;float filterCoeff=CL(FM_TWO_PI*cutoff/PF_SR,0,.65f);int len=(int)(smooth[25]*PF_SR*.001f);if(len<1)len=1;if(len>=DEL)len=DEL-1;float fb=CL(smooth[26]*.01f,0,.78f),send=smooth[24]*.01f,room=smooth[27]*.01f,level=smooth[7]*.01f;float peak=0;
 /* The shared field rings at the global tonic, independent of temperament. */
 float bowlRoot=mode==PF_BRANCH?65.4064f*(par[22]/1308.f)*fm_exp2f(par[21]/12.f):0;
 for(uint32_t k=0;k<n;k++){seq_sample(k);arp_sample();if(mode==PF_TORT)tort_wheel_sample();if(mode==PF_BRANCH)pf_branch_field(smooth,current->process?smooth[2]*.01f:0,v[30].freq>1?v[30].freq*transposeRatio:bowlRoot*transposeRatio);float L=0,R=0;masterRamp+=(pf_running?1.f:0.f)-masterRamp>0?(.0004f*(1-masterRamp)):(-.0004f*masterRamp);for(int i=0;i<PF_NV;i++){Voice *a=&v[i];float target=(a->gate||a->minFrames>0)?1:0;if(a->minFrames>0)a->minFrames--;float atk=(i==38||i==39)?1.f/(PF_SR*.003f):attack,rel=(i==38||i==39)?1.f/(PF_SR*.08f):release;if(mode==PF_CLOCK)temple_envelopes(i,a,target>0,atk,rel);else a->env+=(target-a->env)*(target>a->env?atk:rel);if(a->env<.000001f&&(mode!=PF_TORT||tort_voices[i].amp.stage==0)){a->env=0;continue;}float x=0;float position=i>=40?((i&1)?1.f:-1.f):i<27?((i%7)-3)/3.f:i<30?(i==27?-.75f:.75f):(i-33.5f)/3.5f;float pan=CL(a->pan+position*current->spreadSmooth+current->lfoPan,-1,1);
 if(mode==PF_CLOCK){int algo=par[6]%7;if(algo<0)algo=0;x=temple_sample(i,a,FMCONFIG[algo]);}
 else if(mode==PF_TORT){x=tort_sample(i,a->target*current->lfoPitch,target>0,transposeRatio);}
 else{BranchDSP *s=&branchDsp[i];x=pf_branch_sample(i,a->freq*transposeRatio*current->lfoPitch,target,s->excite+s->mal,s->x,smooth);s->mal*=.995f;}

 float amp=(mode==PF_TORT?1:a->env)*a->level*.36f*current->lfoAmp;
 if(i==38){
  L+=x*amp*(current->arpPan[0][0]*(1-fm_maxf(current->lfoPan,0)));
  R+=x*amp*(current->arpPan[0][1]*(1+fm_minf(current->lfoPan,0)));
 }else{
  L+=x*amp*(.5f-pan*.45f);
  R+=x*amp*(.5f+pan*.45f);
 }
 }

 float outL=L-lastL+.995f*dcL,outR=R-lastR+.995f*dcR;lastL=L;lastR=R;dcL=outL;dcR=outR;float g=gain*masterRamp*level;outL=CL(outL*g,-.92f,.92f);outR=CL(outR*g,-.92f,.92f);l[k]=outL;r[k]=outR;float pk=fm_maxf(fm_fabsf(outL),fm_fabsf(outR));if(pk>peak)peak=pk;}
 pf_peak=peak;}

#undef echoL
#undef echoR
#undef roomL
#undef roomR
#undef seed
#undef heldMask
#undef mode
#undef par
#undef arpOn
#undef arpIndex
#undef octave
#undef smoothReady
#undef sampleClock
#undef arpLeft
#undef rainLeft
#undef smooth
#undef masterRamp
#undef dcL
#undef dcR
#undef lastL
#undef lastR
#undef v
#undef queue
#undef qw
#undef qr
#undef pf_active
#undef pf_steps
#undef pf_clock_step
#undef pf_running
#undef pf_frozen
#undef pf_dropped
#undef pf_energy
#undef pf_clock_phase
#undef pf_peak

/* Global Slip offsets the primary clocks with a quadratic curve and Q24 carry. */
static void phase_prepare(uint32_t frames){float slew=CL(frames/(PF_SR*.05f),0,1);static const int weight[4]={0,1,-1,2};uint32_t amount=instrumentSlip[0];
 for(int m=0;m<PF_LAYERS;m++){uint32_t depth=(uint64_t)PHASE_ONE*amount*amount*32/10000000ull;uint32_t target=PHASE_ONE+(int32_t)depth*weight[m];for(int h=0;h<2;h++){unsigned i=2*m+h;int32_t diff=(int32_t)target-(int32_t)phaseRate[i],delta=(int32_t)(diff*slew);if(!delta&&diff)delta=diff>0?1:-1;phaseRate[i]+=delta;}}
}

static void snapshot(void){Context *a=&layers[editLayer];pf_active=a->active;pf_steps=a->steps;pf_clock_step=a->clock_step;pf_running=a->running;pf_frozen=a->frozen;pf_clock_phase=a->clock_phase;pf_dropped=layers[0].dropped+layers[1].dropped+layers[2].dropped+layers[3].dropped;for(int k=0;k<8;k++)pf_energy[k]=layers[0].energy[k];}
void pf_init(void){memset(seqUndoBank,0,sizeof seqUndoBank);channelSwapResult=0;arpSyncMask=0;memset(instrumentSlip,0,sizeof instrumentSlip);memset(clipRuntime,0,sizeof clipRuntime);memset(phaseFraction,0,sizeof phaseFraction);for(int i=0;i<8;i++)phaseRate[i]=PHASE_ONE;memset(temple_eg,0,sizeof temple_eg);temple_defaults(temple_params);memset(tortRoutes,0,sizeof tortRoutes);pf_fx_delay_sync=pf_fx_delay_division=0;pf_fx_bpm=96;projectTranspose=transposeReady=0;transposeRatio=transposeTarget=1;projectMaster=projectMasterTarget=1;physicalGainReference=0;projectMetronome=metroWasRunning=metroUnits=metroBeat=click_n=0;ft_on=ft_t=ft_n=ft_frames=ft_closed=ft_bars=0;memset(ft_ev,0,sizeof ft_ev);recQuant=3;memset(&click,0,sizeof click);seqRecTempo=seqRecCount=rec_quant_off=0;tort_slop_clock=0;tort_slop_scale=tort_slop_gain=0;memset(oscillatorMod,0,sizeof oscillatorMod);memset(tort_voices,0,sizeof tort_voices);memset(&tort_block,0,sizeof tort_block);memset(layers,0,sizeof layers);memset(routeVoices,0,sizeof routeVoices);memset(branchDsp,0,sizeof branchDsp);memset(templeDsp,0,sizeof templeDsp);memset(&tortRoutingScratch,0,sizeof tortRoutingScratch);memset(&leadRoutingScratch,0,sizeof leadRoutingScratch);for(int m=0;m<PF_LAYERS;m++){current=&layers[m];layers[m].queue=commandQueues[m];layers[m].v=routeVoices[m];for(int j=0;j<PF_NV;j++)routeVoices[m][j].dsp=m==PF_CLOCK?&templeDsp[j]:m==PF_LEAD?&leadRoutingScratch:&tortRoutingScratch;single_init();layers[m].mode=m;layers[m].seed=311+m*179;for(int j=0;j<4;j++){layers[m].lfos[j].random=1777+m*73+j*139;layers[m].lfos[j].held=lfo_random(&layers[m].lfos[j]);}}editLayer=0;current=&layers[0];pf_lead_init();pf_fx_init();pf_branch_init();fxReturnGain=0;fxResetRequested=0;snapshot();}
int pf_post(int op,int x,int y){if(op==PF_MODE){editLayer=(x%PF_LAYERS+PF_LAYERS)%PF_LAYERS;snapshot();return 1;}if(op==PF_CHANNEL_SWAP){if(x<0||x>=PF_LAYERS||x==editLayer)return 0;channelSwapResult=0;}Context *a=&layers[editLayer];if(x < -32768 || x > 32767){a->dropped++;return 0;}uint32_t w=a->qw;if(w-a->qr>=256){a->dropped++;return 0;}a->queue[w&255]=(Cmd){op,x,y};BARRIER();a->qw=w+1;return 1;}
void pf_render(float *l,float *r,uint32_t n,float gain){if(!physicalGainReference){physicalGainReference=(2200.f/4096.f)*1.8f;/* Fixed nominal DSP level: cold-boot knob position must not alter FX resolution. */projectMaster=gain/physicalGainReference;}projectMasterTarget=gain/physicalGainReference;gain=physicalGainReference;/* Layer samples are consumed into buses before click rendering starts.
 * Reuse that dead scratch for click PCM; persistent engines never alias. */
union {float layer[2][128];int32_t click[2][128];} blockScratch;
float *tl=blockScratch.layer[0],*tr=blockScratch.layer[1];pf_peak=0;for(int m=0;m<PF_LAYERS;m++){current=&layers[m];drain();}pf_fx_bpm=seqProjectBpm;if(fxResetRequested){pf_fx_init();fxResetRequested=0;}int16_t tuning[PF_NPAR]={0};for(int j=20;j<=22;j++)tuning[j]=layers[0].par[j];int key=7+projectTranspose,oct=0;while(key<0){key+=12;oct--;}while(key>26){key-=12;oct++;}transposeTarget=pf_hz(key,tuning,oct,0)/pf_hz(7,tuning,0,0);if(!transposeReady){transposeRatio=transposeTarget;transposeReady=1;}int anySolo=layers[0].mixSolo||layers[1].mixSolo||layers[2].mixSolo||layers[3].mixSolo;for(uint32_t offset=0;offset<n;offset+=128){uint32_t count=n-offset>128?128:n-offset;transposeRatio+=(transposeTarget-transposeRatio)*CL(count/(PF_SR*.02f),0,1);if(fm_fabsf(transposeRatio-transposeTarget)<.000001f)transposeRatio=transposeTarget;phase_prepare(count);memset(fxBuses,0,sizeof fxBuses);for(uint32_t i=0;i<count;i++)l[offset+i]=r[offset+i]=0;for(int m=0;m<PF_LAYERS;m++){current=&layers[m];single_render(tl,tr,count,gain);float audible=!layers[m].mixMute&&(!anySolo||layers[m].mixSolo);float pan=layers[m].mixPan*.01f,peak=0;for(uint32_t i=0;i<count;i++){layers[m].mixGain+=(audible-layers[m].mixGain)*.004f;if(fm_fabsf(layers[m].mixGain-audible)<.000001f)layers[m].mixGain=audible;float L=tl[i]*layers[m].mixGain*(pan>0?1-pan:1)*.65f,R=tr[i]*layers[m].mixGain*(pan<0?1+pan:1)*.65f;l[offset+i]+=L;r[offset+i]+=R;fxBuses[0][i]+=L*layers[m].smooth[24]*.01f;fxBuses[1][i]+=R*layers[m].smooth[24]*.01f;fxBuses[2][i]+=L*layers[m].smooth[27]*.01f;fxBuses[3][i]+=R*layers[m].smooth[27]*.01f;peak=fm_maxf(peak,fm_maxf(fm_fabsf(L),fm_fabsf(R)));}layers[m].meter=fm_maxf(peak,layers[m].meter*.975f);}int wetCount=0;float wetPan=0;for(int m=0;m<PF_LAYERS;m++)if(layers[m].running&&!layers[m].mixMute&&(!anySolo||layers[m].mixSolo)&&layers[m].par[7]>0){wetCount++;wetPan=layers[m].mixPan*.01f;}if(wetCount!=1)wetPan=0;int32_t *clickL=blockScratch.click[0],*clickR=blockScratch.click[1];memset(&blockScratch,0,sizeof blockScratch);if(projectMetronome){int running=0,counting=0;for(int m=0;m<PF_LAYERS;m++){running|=layers[m].seq.run||layers[m].process;counting|=layers[m].seq.countBeat;}if(running&&!metroWasRunning){metroUnits=metroBeat=0;if(!counting)click_on(1);}for(uint32_t i=0;i<count;i++){if(running&&!counting){metroUnits+=seqProjectBpm;if(metroUnits>=BEAT_U){metroUnits-=BEAT_U;metroBeat++;click_on((metroBeat%4)==0);}}click_render(clickL+i,clickR+i,1);}metroWasRunning=running;}else{metroWasRunning=0;click_render(clickL,clickR,count);}for(uint32_t i=0;i<count;i++){l[offset+i]+=clickL[i]/32768.f*gain*.2f;r[offset+i]+=clickR[i]/32768.f*gain*.2f;float wl,wr;pf_fx_frame(fxBuses[0][i],fxBuses[1][i],fxBuses[2][i],fxBuses[3][i],&wl,&wr);fxReturnGain+=((wetCount?1.f:0.f)-fxReturnGain)*.004f;if(fxReturnGain<.000001f)fxReturnGain=0;l[offset+i]+=wl*fxReturnGain*(wetPan>0?1-wetPan:1);r[offset+i]+=wr*fxReturnGain*(wetPan<0?1+wetPan:1);projectMaster+=(projectMasterTarget-projectMaster)*.00226757f;if(fm_fabsf(projectMaster-projectMasterTarget)<.00002f)projectMaster=projectMasterTarget;l[offset+i]=CL(l[offset+i]*projectMaster,-.95f,.95f);r[offset+i]=CL(r[offset+i]*projectMaster,-.95f,.95f);float peak=fm_maxf(fm_fabsf(l[offset+i]),fm_fabsf(r[offset+i]));if(peak>pf_peak)pf_peak=peak;}}snapshot();}
float pf_layer_meter(int m){return m>=0&&m<PF_LAYERS?layers[m].meter:0;}
float pf_voice_frequency(int m,int key){return m>=0&&m<PF_LAYERS&&key>=0&&key<27?layers[m].v[key].target*transposeTarget:0;}

uint32_t pf_layer_active(int m){return m>=0&&m<PF_LAYERS?layers[m].active:0;}
uint32_t pf_layer_running(int m){return m>=0&&m<PF_LAYERS?layers[m].running:0;}
uint32_t pf_layer_lit(int m){
 if(m<0||m>=PF_LAYERS||!layers[m].running)return 0;Context *ctx=&layers[m];uint32_t mask=0;
 if(ctx->arpOn)for(int i=0;i<ctx->arpCount;i++){int k=ctx->arpNotes[i].note-53-12*ctx->octave;if(k>=0&&k<27)mask|=1u<<k;}
 for(int i=0;i<PF_NV;i++){Voice *a=&ctx->v[i];int k=a->key;if(ctx->arpOn)k+=12*(a->oct-ctx->octave);if(k>=0&&k<27&&a->env>.001f&&a->level>.001f)mask|=1u<<k;}return mask;
}
uint32_t pf_pool_bytes(void){return sizeof layers+sizeof routeVoices+sizeof branchDsp+sizeof templeDsp+sizeof tortRoutingScratch+sizeof tort_voices+sizeof fxBuses+pf_fx_bytes()+pf_lead_pool_bytes()+pf_branch_bytes();}

uint32_t pf_arp_events(int m,int h){return m>=0&&m<PF_LAYERS&&h>=0&&h<2?layers[m].arpEvent[h]:0;}
uint32_t pf_arp_last(int m,int h){return m>=0&&m<PF_LAYERS&&h>=0&&h<2?layers[m].arpLast[h]:0;}

float pf_lfo_phase(int m,int slot){return m>=0&&m<PF_LAYERS&&slot>=0&&slot<4?layers[m].lfos[slot].phase:0;}
float pf_lfo_output(int m,int slot){return m>=0&&m<PF_LAYERS&&slot>=0&&slot<4?layers[m].lfos[slot].output:0;}

float pf_lfo_sample(int shape,float phase,float held){return lfo_wave(shape,cycle(phase),held);}
float pf_lfo_effective(int m,int parameter){return m>=0&&m<PF_LAYERS&&parameter>=0&&parameter<PF_NPAR?layers[m].smooth[parameter]:0;}
uint32_t pf_lfo_cycles(int m,int slot){return m>=0&&m<PF_LAYERS&&slot>=0&&slot<4?layers[m].lfos[slot].cycles:0;}

int pf_lfo_config(int m,int slot,int field){return m>=0&&m<PF_LAYERS&&slot>=0&&slot<4&&field>=0&&field<8?layers[m].lfos[slot].cfg[field]:0;}

float pf_visual_cutoff(int m){
 return m==PF_TORT?tort_effective[P_CUTOFF]/127.f:layers[PF_LEAD].smooth[0]*.01f;
}
float pf_clock_macro(void){return layers[PF_CLOCK].clockMacro;}
float pf_clock_quartz(void){return layers[PF_CLOCK].quartzSmooth;}

float pf_clock_frequency(int voice){return voice>=0&&voice<2?layers[PF_CLOCK].v[27+voice].target*transposeTarget:0;}

void pf_seq_load(int m,const PFSeqLane *lane,int bpm){if(m<0||m>=PF_LAYERS)return;seqUndoBank[m]=0;memset(&layers[m].seq,0,sizeof layers[m].seq);seqPrograms[m]=*lane;layers[m].seq.data=&seqPrograms[m];layers[m].seq.voiceBase=40;phaseFraction[2*m+1]=0;memset(&clipRuntime[m],0,sizeof clipRuntime[m]);memset(&seqLockStates[m],0,sizeof seqLockStates[m]);layers[m].seq.lockState=&seqLockStates[m];layers[m].seq.active=lane->active;layers[m].seq.queued=-1;layers[m].seq.step=-1;layers[m].seq.seq_abs=0xffffffffu;seqProjectBpm=bpm;}
void pf_seq_read(int m,PFSeqLane *lane){if(m>=0&&m<PF_LAYERS)*lane=*layers[m].seq.data;}
static int midi_gate_mask(int m){int mask=0;for(int j=0;j<4;j++)if(layers[m].v[48+j].gate)mask|=1<<j;return mask;}
static int seq_gate_mask(int m){int mask=0;for(int j=0;j<8;j++)if(layers[m].v[40+j].gate)mask|=1<<j;return mask;}
int pf_seq_state(int m,int f){if(m<0||m>=PF_LAYERS)return 0;PFSeqRuntime *s=&layers[m].seq;return f==0?s->active:f==1?s->queued:f==2?s->step:f==3?s->run:f==4?s->data->enabled:f==5?s->data->sync:f==6?s->seq_n:f==7?pf_clip_length(&s->data->pattern[s->active]):f==8?(s->record||(ft_on&&ft_trk==m)):f==9?s->arm:f==10?s->serial:f==12?seqRecTempo:f==13?seqRecCount:f==14?rec_quant_off:f==15?s->countBeat:f==16?seqProjectBpm:f==17?ft_closed:f==18?layers[m].par[0]:f==19?s->lockState->n:f==20?ft_bars:f==21?s->editResult:f==22?s->editRevision:f==23?midi_gate_mask(m):f==24?clipRuntime[m].status:f==25?(int)((s->units%clip_units(s))*1000/clip_units(s)):f==26?recQuant:f==11?seq_gate_mask(m):0;}
uint32_t pf_seq_events(int m){return m>=0&&m<PF_LAYERS?layers[m].seq.events:0;}
uint32_t pf_seq_last(int m){return m>=0&&m<PF_LAYERS?layers[m].seq.last:0;}

int pf_seq_span(int m,int step,int note,int delta){if(m<0||m>=PF_LAYERS||step<0||step>255||note<0||note>3)return 1;track_t copy=layers[m].seq;track_t *t=&copy;int active=t->active;t->active=step/64;if(pf_clip_events(&t->data->pattern[t->active]))return 1;step%=64;step_t *st=&t->data->pattern[t->active].steps[step];uint32_t length=1;if(note<st->n){uint8_t key=st->note[note];length=span_len(t,step,&key,1);}t->active=active;return length;}

int pf_seq_slip_state(int m,int field){return m>=0&&m<PF_LAYERS&&field==0?instrumentSlip[m]:0;}

float pf_voice_current_frequency(int m,int key){return m>=0&&m<PF_LAYERS&&key>=0&&key<27?layers[m].v[key].freq*transposeRatio:0;}

uint32_t pf_metronome_clicks(void){return click_n;}

float pf_transpose_ratio(void){return transposeRatio;}

/* Read-only arp ownership diagnostics; no UI/audio mutation. */
/* The packed key preserves its original keyboard calibration and octave. */
int pf_commands_pending(void){
 for(int m=0;m<PF_LAYERS;m++)if(layers[m].qw!=layers[m].qr)return 1;
 return 0;
}
int pf_held_key(int m,int index,int arp){
 Context *layer=&layers[m];
 if(arp){
  if(index>=layer->arpCount)return 0;
  int key=layer->arpNotes[index].key;
  int octave=(layer->arpNotes[index].note-53-key)/12;
  return 1+key+27*(octave+2);
 }
 return 1+index+27*(layer->v[index].oct+2);
}
int pf_arp_note(int m,int index){if(m<0||m>=PF_LAYERS)return -1;if(index<0)return layers[m].arpCount;return index<layers[m].arpCount?layers[m].arpNotes[index].note:-1;}
float pf_arp_frequency(int m,int head){return m>=0&&m<PF_LAYERS&&head>=0&&head<2?layers[m].v[38+head].target*transposeRatio:0;}

#ifdef EN_HOST
uint32_t pf_tort_voice_bytes(void){return sizeof(ov_voice_t);}
int pf_tort_voice_state(int i,int field){if(i<0||i>=PF_NV)return 0;const ov_voice_t *v=&tort_voices[i];switch(field){case 0:return v->gate;case 1:return v->amp.stage;case 2:return v->fe.level;case 3:return v->amp.level;case 4:return v->inc1;default:return v->inc2;}}
#endif
#ifdef EN_HOST
int pf_temple_runtime(int i){return i>=0&&i<PF_TEMPLE_BYTES?temple_params[i]:0;}
#endif

#ifdef EN_HOST
float pf_temple_env(int slot,int field){if(slot<0||slot>=PF_NV)return 0;return field==0?layers[PF_CLOCK].v[slot].env:field==1?temple_eg[slot].tone:field==2?temple_eg[slot].amp:temple_eg[slot].stage;}
#endif

#ifdef EN_HOST
float pf_temple_operator_env(int slot,int op,int field){if(slot<0||slot>=PF_NV||op<0||op>=6)return 0;return field?temple_eg[slot].op[op]:*temple_env(layers[PF_CLOCK].v[slot].dsp,op);}
#endif

#ifdef EN_HOST
/* Test-only long-duration clock runner. Uses production timing and note owners,
 * skipping oscillator/FX work; never called by the workstation render path. */
void pf_phase_test_run(uint32_t frames){for(int m=0;m<PF_LAYERS;m++){current=&layers[m];drain();}for(uint32_t at=0;at<frames;at+=128){uint32_t n=frames-at>128?128:frames-at;phase_prepare(n);for(int m=0;m<PF_LAYERS;m++){current=&layers[m];for(uint32_t i=0;i<n;i++){seq_sample(i);arp_sample();}}}snapshot();}
double pf_phase_test_state(int id,int field){if(id<0||id>=8)return 0;Context *c=&layers[id/2];if(field==12){int bits=0;for(int j=0;j<((id&1)?8:1);j++)if(c->v[((id&1)?52:39)+j].env>.000001f)bits|=1<<j;return bits;}if(field>=8&&field<=10)return 0;if(field==11){int bits=0;for(int j=0;j<((id&1)?8:1);j++)if(c->v[((id&1)?52:39)+j].gate)bits|=1<<j;return bits;}if(field==0)return phaseRate[id]*(1.0/PHASE_ONE);if(field==1)return (id&1)?(double)c->seq.units:(double)c->arpLeft;if(field==2)return (id&1)?c->seq.events:c->arpEvent[0];if(field==3)return (id&1)?c->seq.last:c->arpLast[0];if(field==4)return (id&1)?c->seq.seq_off:c->arpGate[0];if(field==5)return (id&1)?c->seq.serial:c->arpCursor[0];if(field==6){int bits=0;for(int j=0;j<((id&1)?8:1);j++)if(c->v[((id&1)?40:38)+j].gate)bits|=1<<j;return bits;}return 0;}
#endif

int pf_clip_event_state(int m,int bank,int index,int field){if(m<0||m>=4||bank<0||bank>3)return -1;PFSeqPattern*p=&layers[m].seq.data->pattern[bank];if(index<0)return pf_clip_events(p)?pf_clip_count(p):-1;PFClipEvent e=pf_clip_event(p,index);return field==0?(e.time&16383):field==1?pf_clip_duration(e.duration):field==2?(e.note&127):field==3?(e.velocity&127):0;}
