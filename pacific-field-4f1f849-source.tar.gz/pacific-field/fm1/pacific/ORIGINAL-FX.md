# Original Oliverb and Clouds implementation

One `clouds::GranularProcessor` from Mutable Instruments and one `clouds::Oliverb` from Clouds Parasites are integrated in the workstation. This replaces the three per-layer generic echo/room buffers. The instrument DSP, tuning, four-LFO banks, arps/Slip, note owners and existing sequencer code remain separate.

## Provenance and licenses

- Clouds: eurorack `f4cfa7697095a28d292bff758beb51deb49b5a86`; stmlib `e3bd7c9cc00e4364166f9905c0509b6ffd0535ec`.
- Oliverb: Parasites `32fa66f5acce1bff2f0a7bdd041e29bad3222557`; stmlib `8ab2aaee77cbacb47b646d46d22ee5d358effe2d`.
- Production contains only the 43-file Clouds and 11-file Oliverb compiler-derived dependency closures under `pacific/upstream/`, not whole firmware repositories. Complete reference clones remain outside the workstation in `References/`.
- Original MIT notices remain in every selected source file, including Emilie Gillet and Matthias Puech notices. The combined workstation is GPL-3.0-only. Manifest hashes and actual modification hashes are in `upstream/manifest.json`.
- Both upstreams define different `clouds`/`stmlib` namespaces and similar header guards. Separate translation units and compile-time namespace renaming isolate them. No Parasites FxEngine is substituted into original Clouds.

## Actual DSP and adaptations

`clouds-port.cc` calls original GranularProcessor::Init/Prepare/Process in stereo16-bit at32kHz, maximum32-frame blocks. It exposes original looping delay, granular and WSOLA stretch modes, pitch, texture, density, stereo spread, feedback and freeze. Spectral, mono/lo-fi and memory-save firmware modes are not exposed. Original Clouds diffusion, feedback filtering, limiter and internal freeze-dependent reverb behavior are retained as part of its DSP, not another parallel external engine.

`oliverb-port.cc` calls original Oliverb::Init/Process at32kHz. Its original delay/allpass/modulation/filter topology and lookup tables are used. Pitch-shift feedback is disabled with ratio1 and pitch-shift amount0; no substitute shimmer. Freeze smoothly fades input gain to0, decay toward1 and damping open. Normal decay is bounded below unity; independent return/master controls retain output protection.

Only one upstream code correction was needed: Clouds `dsp/window.h`, Window::Start now clears done_ and half_. Init sets done_=true, while the unmodified Start did not arm the window; OverlapAdd therefore returned without ever rendering WSOLA. The reproduced silent-mode test and working post-fix test motivated this two-field state correction. No synthesis, interpolation, grain, correlation, envelope or reverb topology was replaced. All other selected upstream file bytes are unchanged; namespaces are isolated by build flags.

The adapter removes4096 bytes of unused Clouds workspace padding: large buffer114688, small buffer65408. The two stereo recording channels are still65408 bytes each, preserving ~1.022s at32kHz. Workspace49280 bytes covers8192-byte diffuser +32768-byte internal reverb +8192-byte pitch-shifter/correlator alias, with128 spare. This alias high-water bound is statically asserted; using only the correlator's1560-byte allocation would underestimate it. Full-allocation118784/65408 reference builds produce sample-identical tested outputs across delay/granular/WSOLA, pitch and freeze. No sample arena was replaced by a smaller generic delay.

`fx.c` bridges44100Hz instrument audio and32000Hz effects with bounded rational clocks and32-tap/64-phase Blackman-windowed sinc filters in both directions. Coefficients are read-only; processing uses fixed arrays, no heap or I/O in the audio path. Wet-only latency is a few milliseconds; dry remains direct. Each32-frame native block runs both actual processors. The browser's TEST branches select portable stmlib math; that is not an assertion of PI32v2 compatibility. Nonfinite wet samples increment a test-visible fault counter before being suppressed.

## Routing and mixer semantics

Each single_render produces its own dry stereo signal after its normal instrument envelope/DC/gain stage. Before summing the final master, pf_render applies that layer's gain ramp, pan and mute/solo mask and independently accumulates:

- `par[24]` → Clouds stereo send.
- `par[27]` → Oliverb stereo send.

Both shared buses are processed once; returns join dry before the existing final protection clamp. Master gain is included in send inputs; sends are post-fader. Shared processors continue with zero new input after manual note release. Existing per-layer buffers are removed rather than duplicated.

A shared tail cannot be separated back into its source layers. Muting a layer stops new input from it while existing shared tails continue if another eligible layer remains. If all eligible running strips are muted/zero/unsoloed, a smoothed global wet gate closes; with one eligible strip, its pan also applies to returns. Mixer meters remain per-layer dry/send-stage meters, not fabricated per-layer ownership of shared tails. Explicit global panic clears the shared state; ordinary key release and lane-only sequencer stop do not.

## Controls and persistence

FX cycles6 pages: original sends page → Oliverb Space → Oliverb Motion → Clouds Delay → Clouds Texture → detail. Four knobs follow the actual on-screen labels. Mixer knobs3/4 are DELAY/REVERB sends for the selected instrument. FX sends page knobs2/3 edit shared time/feedback. Other pages expose size/decay/damping/diffusion; reverb modulation/freeze/return; Clouds time-position/mode/size/pitch; feedback/texture/freeze/return; density/stereo/high-pass/master wet. All shared controls smooth except discrete mode/freeze selection; original freeze smoothing remains active internally.

Patch v11 is2244 bytes of3840. The entire v10 prefix (including programs and sends) is retained;20 shared int16 controls append at2204. Versions2–10 load through existing migration, retaining sends. Shared time/feedback inherit the formerly selected layer's old time/feedback. Other effect settings start at musical defaults. Reboot restores settings silently, never live buffers or notes. The old approximation's sound is intentionally replaced, not represented as sample-identical wet audio.

## Build and checks

With emsdk active: `sh pacific/build-web.sh` builds the shared C + original C++ DSP. `python3 pacific/check-fx.py` compiles and runs workstation and effect regressions; EMCC/EMXX/NODE may be set explicitly. For the full-memory reference use PF_CLOUDS_FULL_BUFFER=1 and PF_WASM_OUTPUT=<reference.wasm>, then run test-fx-reference.mjs against normal/reference outputs.

Tests cover audible impulse responses, actual delay/granular/WSOLA and freeze, all six independent sends, page navigation, v10→v11 prefix preservation, shared persistence/silent boot, exact dry-patch PCM identity, note ownership and existing instrument/arp/LFO/tuning/mixer controls. The known sequencer recording-onset bug is not repaired or newly claimed verified by this effects change.

Reported DSP/storage allocation264132 plus conservative canvas69120 =333252 bytes against344064;10812 bytes remain, including8192 reserve. This is source/WASM accounting, not a native map. C++ runtime, ordinary BSS/stack and native flash still require a real target link.

## Hardware secondary milestone

SDK tagAC79NN_SDK_V1.2.1_2023-12-13 and official JieLi tools were downloaded and checksummed in the separate permanent Build Tools folder. Baseline native build did not complete: this macOS13 machine needed alternate Linux emulation and a RAQM-capable font generator. Per the user's direction, environment work was paused and the VM stopped. No firmware was flashed.

The browser integration is functional. Native build.py still needs C++ source/link integration, targeted non-ARM stmlib portability guards (not a blanket device TEST define), a complete RAM/stack/flash map and actual FM-1 CPU/audio validation. No hardware-ready binary or device performance claim is made here.

Measured ten-minute full-workstation run:600s audio in61.27s host time, all3 sequencers/processes/arps with Slip and all12 LFOs active, zero dropped commands and zero DSP nonfinite faults. Output stayed within the existing0.95 protection bound. This is host throughput, not FM-1 CPU headroom.

Additional extreme-control run:120s audio in12.29s host time at Clouds feedback95%, Oliverb decay96%, high modulation and both returns100%, cycling all3 Clouds modes and both freezes while the workstation played. Zero dropped commands and zero nonfinite-DSP faults; output remained protected at0.95. Normal/full-memory reference output comparison was bit-exact across the tested modes, pitch and freeze. No device-performance inference is made.
