// Legacy SLOOP patterns still play without converting or needing the removed editor.
import assert from 'node:assert/strict';
import {boot,turn} from './test-slip-panel.mjs';
import {legacyStep} from './test-panel-order.mjs';
const tick=(e,n=1)=>e.web_phase_test_run(n);
for(const swing of [0,100]){
 const e=await boot();e.web_open_page(32);turn(e,5,swing);
 e.web_seq_post(0,10002,120);e.web_seq_post(0,10001,1);
 const at=[];let last=0;for(let f=0;f<12000;f++){tick(e);const n=e.web_seq_events(0);if(n!==last){at.push(f);last=n;}}
 assert.deepEqual(at.slice(0,3),swing?[0,8269,11025]:[0,5513,11025]);
}
{
 const e=await boot();legacyStep(e,0,0,[60,64,67,72]);legacyStep(e,0,1,[],{type:1});legacyStep(e,0,2,[],{type:2});
 e.web_seq_post(0,30000,(70<<16));e.web_seq_post(0,10001,1);tick(e);
 assert.equal(e.web_seq_state(0,11),15);assert.equal(e.web_seq_state(0,18),70);
 tick(e,6891);assert.equal(e.web_seq_state(0,11),15);assert.equal(e.web_seq_state(0,19),0);
 tick(e,6891);assert.equal(e.web_seq_state(0,11),0);assert.equal(e.web_clip_event(0,0,-1,0),-1);
 e.web_seq_post(0,10001,0);tick(e);assert.equal(e.web_seq_state(0,19),0);
}
{
 const e=await boot();legacyStep(e,0,0,[60],{ratchet:3});
 e.web_seq_post(0,10001,1);tick(e,6800);assert.equal(e.web_seq_state(0,10),4);
 e.web_seq_post(0,10001,0);tick(e);legacyStep(e,0,0,[60],{micro:16});
 e.web_seq_post(0,10001,1);tick(e);assert.equal(e.web_seq_state(0,11),0);
 tick(e,2100);assert(e.web_seq_state(0,11)>0);
}
{
 const e=await boot();legacyStep(e,0,0,[60]);e.web_seq_post(0,0,1);e.web_seq_post(0,10015,1<<8);
 e.web_seq_post(0,10001,1);tick(e,10000);assert.equal(e.web_seq_state(0,10),0);
 e.web_buttons(1<<9);e.web_buttons((1<<9)|(1<<5));e.web_keys(1<<14);tick(e,10000);
 const hits=e.web_seq_state(0,10);assert(hits>0);
 e.web_keys(0);e.web_buttons(0);tick(e,10000);assert.equal(e.web_seq_state(0,10),hits);
}
console.log('PASS legacy straight/swing deadlines, chords, ties, rests, ratchets, nudge, locks and live fill.');
