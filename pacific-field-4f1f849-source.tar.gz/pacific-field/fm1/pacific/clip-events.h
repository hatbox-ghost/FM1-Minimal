/* SPDX-License-Identifier: GPL-3.0-only
 * Bounded recorder / event-clip adapter. Uses SLOOP voices, clocks and programs.
 * The retired free-take buffer supplies 32 held records and conversion scratch. */
_Static_assert(sizeof(ft_ev)>=PF_LAYERS*8*12+PF_CLIP_MAX_EVENTS*6,"recorder scratch fits retired free-take buffer");
static unsigned recQuant=3;
static uint64_t clip_step_units(const track_t*t){return (uint64_t)BEAT_U*seqDenominator[trk_div(t)]/seqNumerator[trk_div(t)];}
static uint64_t clip_units(const track_t*t){return clip_step_units(t)*trk_len(t);}
static uint8_t *clip_hold(int m,int h){return (uint8_t*)ft_ev+(m*8+h)*12;}
static void clip_hold_clear(int m){memset(clip_hold(m,0),0,8*12);}
static PFEventRuntime *clip_rt(track_t*t){return &clipRuntime[seq_track_index(t)];}
static void clip_cache_dirty(track_t*t){clip_rt(t)->scheduled=0;}
static void clip_voices_clear(track_t*t){seq_release(t);PFEventRuntime*r=clip_rt(t);memset(r->off,0,sizeof r->off);memset(r->owner,0,sizeof r->owner);r->scheduled=0;}
static void clip_save_undo(track_t *t){
 int layer=seq_track_index(t);
 seqUndo[layer]=t->data->pattern[t->active];
 seqUndoBank[layer]=t->active+1;
}
static uint64_t clip_grid_start(track_t*t,int i){uint64_t u=clip_step_units(t);return i*u+((i&1)&&trk_div(t)<4?swing_units(t->data->swing,u):0);}
/* Conversion is bounded and transactional. Original fill/locks remain intact.
 * Each audible onset is flattened; ties/continuations become durations. */
static int clip_convert(track_t*t){PFSeqPattern*p=&t->data->pattern[t->active];if(pf_clip_events(p))return 1;
 uint8_t *events=(uint8_t*)(ft_ev+64);unsigned count=0,len=trk_len(t);uint64_t loop=clip_units(t);
 for(unsigned i=0;i<len;i++){step_t*st=&p->steps[i];if(st->time!=ST_NOTE)continue;uint32_t into,span;track_t copy=*t;copy.units=clip_grid_start(t,i);trk_grid(&copy,&into,&span);
  for(unsigned n=0;n<st->n&&n<4;n++){if(st->flags&SF_CONT(n))continue;unsigned hits=1+((st->rat>>(n*2))&3);
   for(unsigned hit=0;hit<hits;hit++){if(count>=PF_CLIP_MAX_EVENTS-1)return 0;int64_t start=(int64_t)clip_grid_start(t,i)+(int64_t)span*st->micro/64+(uint64_t)span*hit/hits;
    uint64_t duration=(uint64_t)span*t->data->gate/(128*hits);
    if(hits==1){unsigned k=1;for(;k<len;k++){step_t*next=&p->steps[(i+k)%len];int cont=next->time==ST_TIE;for(unsigned j=0;j<next->n&&j<4;j++)if(next->note[j]==st->note[n]&&(next->flags&SF_CONT(j)))cont=1;if(!cont)break;}
     if(k>1){uint64_t last=clip_grid_start(t,i+k-1),end=clip_grid_start(t,i+k);uint64_t tail=(end-last)*t->data->gate/128+(end-last)/2;if(tail>end-last)tail=end-last;duration=last+tail-start;}}
    int64_t wrapped=start%(int64_t)loop;if(wrapped<0)wrapped+=loop;unsigned cond=(p->fill[i/4]>>(2*(i%4)))&3;
    uint16_t d=pf_clip_duration_pack((duration*PF_CLIP_TICKS+loop/2)/loop);PFClipEvent event={(uint16_t)(((uint64_t)wrapped*PF_CLIP_TICKS/loop)|(cond<<14)),d,(uint8_t)(st->note[n]|((st->flags&SF_LEG)?128:0)),step_vel(st,n)};memcpy(events+6*count++,&event,6);
   }
  }
 }
 clip_save_undo(t);
 pf_clip_init(p,len);uint8_t*header=(uint8_t*)p->steps;header[2]=t->data->gate;header[3]=t->data->swing;header[4]=count;memcpy(header+6,events,count*6);t->editRevision++;return 1;
}
static void clip_snap(track_t *t,unsigned quant){
 PFSeqPattern *p=&t->data->pattern[t->active];
 if(!quant||quant>5||t->run||t->record||t->arm||!pf_clip_events(p))return;
 uint64_t loop=clip_units(t),grid=BEAT_U/(1u<<(quant-1));
 int changed=0;
 for(unsigned i=0;i<pf_clip_count(p);i++){
  PFClipEvent e=pf_clip_event(p,i);
  uint64_t pos=(e.time&16383)*loop/PF_CLIP_TICKS;
  uint64_t left=pos/grid*grid,right=left+grid;
  if(right>loop)right=loop;
  uint64_t snapped=pos-left<right-pos?left:right;
  unsigned tick=((snapped%loop)*PF_CLIP_TICKS+loop/2)/loop;
  unsigned time=(e.time&0xc000)|(tick&16383);
  if(e.time==time)continue;
  if(!changed){clip_save_undo(t);changed=1;}
  e.time=time;
  pf_clip_event_set(p,i,e);
 }
 if(changed){t->editRevision++;clip_cache_dirty(t);}
}
static void clip_record_off(track_t*t,unsigned note,int force){int m=seq_track_index(t);PFSeqPattern*p=&t->data->pattern[clip_rt(t)->recordClip];uint64_t loop=clip_units(t);
 for(int h=0;h<8;h++){uint8_t*hold=clip_hold(m,h);if(!hold[9]||hold[8]!=note)continue;if(!force&&hold[10]>1){hold[10]--;continue;}uint64_t start;memcpy(&start,hold,8);PFClipEvent e=pf_clip_event(p,hold[9]-1);uint64_t duration=((t->units-start)*PF_CLIP_TICKS+loop/2)/loop;e.duration=pf_clip_duration_pack(duration);pf_clip_event_set(p,hold[9]-1,e);hold[9]=0;t->editRevision++;clip_cache_dirty(t);}
}
static void clip_record_finish(track_t*t){int m=seq_track_index(t);for(int h=0;h<8;h++){uint8_t*p=clip_hold(m,h);if(p[9]&&p[9]!=255)clip_record_off(t,p[8],1);}clip_hold_clear(m);t->record=t->arm=0;t->countUnits=t->countBeat=0;t->editRevision++;}
static void clip_undo(track_t *t){
 int layer=seq_track_index(t),bank=seqUndoBank[layer]-1;
 if(bank<0)return;
 if(bank==t->active){
  clip_record_finish(t);
  clip_voices_clear(t);
  locks_restore(t);
  t->seq_abs=SEQ_NONE;
 }
 PFSeqPattern *p=&t->data->pattern[bank];
 int length=pf_clip_length(p);
 *p=seqUndo[layer];
 pf_clip_length_set(p,length);
 seqUndoBank[layer]=0;
 t->editRevision++;
}
static void clip_adopt_event_voices(track_t *t){
 PFEventRuntime *r=clip_rt(t);
 PFSeqPattern *p=&t->data->pattern[t->active];
 uint64_t loop=clip_units(t);
 for(int h=0;h<8;h++)if(v[t->voiceBase+h].gate){r->owner[h]=65535;r->off[h]=t->units+(t->seq_off?t->seq_off:1);uint64_t best=0;for(unsigned i=0;i<pf_clip_count(p);i++){PFClipEvent e=pf_clip_event(p,i);if((e.note&127)!=t->slots[h])continue;int64_t start=(uint64_t)r->cycle*loop+(e.time&16383)*loop/PF_CLIP_TICKS;if(start>(int64_t)t->units)start-=loop;int64_t end=start+(uint64_t)pf_clip_duration(e.duration)*loop/PF_CLIP_TICKS;if(end>(int64_t)t->units&&(uint64_t)end>best){best=end;r->owner[h]=i+1;r->off[h]=end;}}}
}
static int clip_record_begin(track_t *t){
 PFEventRuntime *r=clip_rt(t);
 uint64_t loop=clip_units(t);
 r->cycle=t->units/loop;r->wrap=(r->cycle+1ull)*loop;
 r->recordClip=t->active;r->recordEdited=0;r->status=0;t->record=1;t->arm=0;
 clip_hold_clear(seq_track_index(t));clip_cache_dirty(t);return 1;
}
static void clip_record_on(track_t*t,unsigned note,unsigned velocity){
 if(!t->record)return;
 PFSeqPattern*p=&t->data->pattern[t->active];
 PFEventRuntime*r=clip_rt(t);
 int converted=!pf_clip_events(p);
 if(converted){
  if(!clip_convert(t)){r->status=1;return;}
  clip_adopt_event_voices(t);
 }
 unsigned count=pf_clip_count(p);
 int slot=-1,m=seq_track_index(t);
 for(int h=0;h<8;h++){uint8_t*x=clip_hold(m,h);if(x[9]&&x[8]==note){if(x[10]<255)x[10]++;return;}if(!x[9]&&slot<0)slot=h;}
 if(slot<0||count>=PF_CLIP_MAX_EVENTS){r->status=1;return;}
 if(!r->recordEdited){if(!converted)clip_save_undo(t);r->recordEdited=1;}
 uint64_t start=t->units,quantized=start,loop=clip_units(t);if(recQuant){uint64_t grid=BEAT_U/(1u<<(recQuant-1));quantized=(start+grid/2)/grid*grid;}
 PFClipEvent e={(quantized%loop)*PF_CLIP_TICKS/loop,0,note,(velocity&127)|128};pf_clip_event_set(p,count,e);((uint8_t*)p->steps)[4]=count+1;
 uint8_t*hold=clip_hold(m,slot);memcpy(hold,&start,8);hold[8]=note;hold[9]=count+1;hold[10]=1;t->editRevision++;clip_cache_dirty(t);
}
static void clip_clear_fresh(track_t*t){PFSeqPattern*p=&t->data->pattern[t->active];if(pf_clip_events(p))for(unsigned i=0;i<pf_clip_count(p);i++){PFClipEvent e=pf_clip_event(p,i);if(e.velocity&128){e.velocity&=127;pf_clip_event_set(p,i,e);clip_cache_dirty(t);}}}
static void clip_start_local(track_t*t){clip_clear_fresh(t);clip_rt(t)->cycle=0;clip_rt(t)->wrap=clip_units(t);t->run=1;pf_running=1;t->data->enabled=1;t->units=0;t->seq_abs=SEQ_NONE;t->step=-1;t->events=0;clip_cache_dirty(t);}
static void clip_rec_toggle(track_t*t){if(t->record||t->arm||t->countBeat){clip_record_finish(t);return;}
 if(seqRecCount){t->arm=1;t->countUnits=1;t->countBeat=4;click_on(1);return;}if(t->run){clip_record_begin(t);return;}t->arm=1;}
/* Pending physical input during count-in; latch/arp notes are not takes. */
static void clip_count_input(track_t*t,unsigned note,unsigned velocity){
 int m=seq_track_index(t);uint8_t*free=0;
 for(int h=0;h<8;h++){uint8_t*x=clip_hold(m,h);if(x[9]==255&&x[8]==note){
  if(!velocity){if(x[10]&&!--x[10])x[9]=0;}else if(x[10]<255)x[10]++;
  return;
 }if(!x[9]&&!free)free=x;}
 if(velocity&&free){free[8]=note;free[9]=255;free[10]=1;free[11]=velocity;}
}
static void clip_count_complete(track_t*t){
 uint8_t notes[8],velocities[8],refs[8];int m=seq_track_index(t);
 for(int h=0;h<8;h++){uint8_t*x=clip_hold(m,h);notes[h]=x[8];velocities[h]=x[9]==255?x[11]:0;refs[h]=x[10];}
 if(!t->run)clip_start_local(t);
 if(clip_record_begin(t))for(int h=0;h<8;h++)if(velocities[h])for(unsigned n=0;n<refs[h];n++)clip_record_on(t,notes[h],velocities[h]);
}
static uint64_t clip_event_position(track_t*t,PFSeqPattern*p,PFClipEvent e,uint64_t loop){uint64_t pos=(e.time&16383)*loop/PF_CLIP_TICKS;int change=(int)t->data->swing-((uint8_t*)p->steps)[3];if(!change||trk_div(t)>=4)return pos;int64_t u=clip_step_units(t),step=pos/u,part=pos%u;int64_t delta=(step&1)?u-part:step+1<(int64_t)trk_len(t)?part:0;int64_t swung=(int64_t)pos+delta*change/200;return swung<0?0:(uint64_t)swung>=loop?loop-1:swung;}
static void clip_schedule(track_t*t,uint64_t from,uint64_t loop){PFEventRuntime*r=clip_rt(t);PFSeqPattern*p=&t->data->pattern[t->active];uint64_t cycle=from/loop,best=~(uint64_t)0;
 for(unsigned i=0;i<pf_clip_count(p);i++){PFClipEvent e=pf_clip_event(p,i);if(!e.duration||(e.velocity&128))continue;uint64_t at=cycle*loop+clip_event_position(t,p,e,loop);if(at<from)at+=loop;if(at<best)best=at;}
 r->next=best;r->scheduled=1;
}
static void clip_event_fire(track_t*t,unsigned index,uint64_t at){PFEventRuntime*r=clip_rt(t);PFSeqPattern*p=&t->data->pattern[t->active];PFClipEvent e=pf_clip_event(p,index);unsigned cond=e.time>>14;int fill=t->fillHeld||t->fillBar;
 if((cond==1&&!fill)||(cond==2&&fill))return;
 int note=e.note&127;
 for(int k=0;k<27;k++)if(!arpOn&&(heldMask&(1u<<k))&&53+k+12*v[k].oct==note)return;
 if(arpOn)for(int k=0;k<current->arpCount;k++)if(current->arpNotes[k].note==note)return;
 for(int h=0;h<4;h++)if(v[48+h].gate&&current->midiNotes[h]==note)return;
 for(int h=0;h<8;h++)if(r->owner[h]==index+1&&v[t->voiceBase+h].gate)return;
 t->slide_glide=!!(e.note&128);trk_note_on(t,e.note&127,e.velocity&127);for(int h=0;h<8;h++)if(t->slots[h]==(e.note&127)){r->owner[h]=index+1;r->off[h]=at+(uint64_t)pf_clip_duration(e.duration)*clip_units(t)/PF_CLIP_TICKS*t->data->gate/pf_clip_base_gate(p);break;}t->slide_glide=0;
}
static void clip_event_due(track_t*t,uint64_t through,uint64_t loop){
 PFEventRuntime*r=clip_rt(t);PFSeqPattern*p=&t->data->pattern[t->active];
 while(r->next<=through){uint64_t at=r->next,pos=at%loop;
  for(unsigned i=0;i<pf_clip_count(p);i++){PFClipEvent e=pf_clip_event(p,i);if(e.duration&&!(e.velocity&128)&&pos==clip_event_position(t,p,e,loop))clip_event_fire(t,i,at);}
  clip_schedule(t,at+1,loop);
 }
}
static void clip_event_tick(track_t*t,uint32_t adv){
 PFEventRuntime*r=clip_rt(t);uint64_t loop=clip_units(t),from=t->units;
 if(t->seq_n)for(int h=0;h<8;h++)if(r->owner[h]&&t->units>=r->off[h]){v[t->voiceBase+h].gate=0;t->slots[h]=255;r->owner[h]=0;}
 if(t->units>=r->wrap){
  uint64_t boundary=r->wrap;
  if(boundary&&r->scheduled)clip_event_due(t,boundary-1,loop);
  r->cycle=t->units/loop;r->wrap=(r->cycle+1ull)*loop;clip_clear_fresh(t);
  // The clock may cross the loop by a fraction of a sample. Include tick zero.
  if(boundary)from=boundary;
 }
 if(!r->scheduled)clip_schedule(t,from,loop);
 clip_event_due(t,t->units,loop);
 t->seq_n=0;for(int h=0;h<8;h++)if(v[t->voiceBase+h].gate)t->seq_n++;
 t->units+=adv;
}
