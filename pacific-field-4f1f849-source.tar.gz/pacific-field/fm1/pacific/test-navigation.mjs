import fs from 'node:fs';import assert from 'node:assert/strict';import crypto from 'node:crypto';import{modeDelta}from'./test-panel-order.mjs';
const bytes=fs.readFileSync(process.argv[2]);async function boot(){const{instance:{exports:e}}=await WebAssembly.instantiate(bytes,{wasi_snapshot_preview1:new Proxy({},{get:()=>()=>0}),env:new Proxy({},{get:()=>()=>0})});e._initialize();e.web_audio_boot();return e;}
const orders=[[0,2,3,30,4],[22,18,19,69,20,21,25,30,4],[0,58,3],[0,42,43,44,69,46,3,30,4]];
function api(e){const run=()=>{e.web_audio_render(128);assert.equal(e.web_dropped(),0);assert.equal(e.web_fx_faults(),0);},tap=b=>{e.web_buttons(1<<b);e.web_buttons(0);run();},turn=(r,d)=>{e.web_enc(r,d);run();},select=m=>turn(2,modeDelta(e,m));return{run,tap,turn,select};}
for(let m=0;m<4;m++){
 const e=await boot(),a=api(e);a.run();a.select(m);const primary=orders[m][0];
 for(const source of[7,49,50,51,48,5,53,1,10,11,6,35,31,41,8]){e.web_open_page(source);a.tap(4);assert.equal(e.web_page(),primary,`mode ${m} entry from ${source}`);assert.equal(e.web_mode(),m);assert.equal(e.web_page_position(),1);}
 a.tap(6);for(let n=0;n<orders[m].length*2;n++){a.tap(4);assert.equal(e.web_page(),orders[m][n%orders[m].length]);assert.equal(e.web_page_position(),n%orders[m].length+1);assert.equal(e.web_page_count(),orders[m].length);}
 for(const page of orders[m]){e.web_open_page(page);a.tap(6);assert.equal(e.web_page(),7);for(const layer of[49,50,51,7]){a.tap(6);assert.equal(e.web_page(),layer);}a.tap(5);assert.equal(e.web_page(),48);a.tap(5);assert.equal(e.web_page(),5);a.tap(5);assert.equal(e.web_page(),53);a.tap(5);assert.equal(e.web_page(),48);a.turn(0,1);assert.equal(e.web_page(),5);a.tap(4);assert.equal(e.web_page(),orders[m][0]);assert.equal(e.web_mode(),m);}
 // Layer switching never touches a timbre parameter, even if ALGORITHM has a voice meaning elsewhere.
 e.web_open_page(7);let params=Array.from({length:28},(_,i)=>e.web_param(i));for(const page of[49,50,51,7]){a.turn(1,1);assert.equal(e.web_page(),page);assert.deepEqual(Array.from({length:28},(_,i)=>e.web_param(i)),params);}
 a.tap(2);const env=m===1?[23,24]:m===3?[1,45]:m===2?[1,65]:[1];for(let i=0;i<env.length*2;i++){assert.equal(e.web_page(),env[i%env.length]);a.tap(2);}a.tap(4);assert.equal(e.web_page(),primary);
 a.tap(3);const lfos=[10,12,14,16,68];for(let i=0;i<lfos.length*2;i++){assert.equal(e.web_page(),lfos[i%lfos.length]);assert.equal(e.web_page_position(),i%lfos.length+1);a.tap(3);}a.tap(4);assert.equal(e.web_page(),primary);
 for(const page of[0,7,48,5,53,10,31,35]){e.web_open_page(page);a.tap(6);assert.equal(e.web_lit_buttons()&(1<<6),1<<6);a.tap(5);assert.equal(e.web_lit_buttons()&(1<<5),1<<5);a.tap(4);assert.equal(e.web_lit_buttons()&(1<<4),1<<4);assert.equal(e.web_mode(),m);}
 assert.equal(e.web_patch_bytes(),15664);assert.equal(e.web_nav_bytes(),9);
}
// Compare identical audio runs with/without hundreds of navigation transitions.
// All four latched engines, original effects, all four sequencers and Slip stay live.
async function capture(navigate){const e=await boot(),a=api(e);a.run();for(let m=0;m<4;m++){a.select(m);e.web_open_page(31);e.web_keys((1<<7)|(1<<11));a.run();e.web_keys(0);a.run();e.web_open_page(41);a.turn(3,20);e.web_open_page(0);a.tap(1);e.web_keys((1<<7)|(1<<14));a.run();e.web_keys(0);a.run();}a.tap(10);const params=Array.from({length:28},(_,i)=>e.web_param(i)),h=crypto.createHash('sha256');const buttons=[6,5,4,4,2,4,3,4,0,4,9,4];for(let i=0;i<1200;i++){if(navigate&&i%4===0){const b=buttons[(i/4)%buttons.length];e.web_buttons(1<<b);e.web_buttons(0);}a.run();for(const out of[e.web_out_l(),e.web_out_r()])h.update(new Uint8Array(e.memory.buffer,out,512));}assert.deepEqual(Array.from({length:28},(_,i)=>e.web_param(i)),params);for(let m=0;m<4;m++){assert(e.web_seq_events(m)>0);assert.equal(e.web_layer_active(m),(1<<7)|(1<<14));}return h.digest('hex');}
assert.equal(await capture(true),await capture(false),'navigation must not change ongoing PCM');
console.log('PASS: all required transitions for all four instruments, global submenus, family counters/LEDs, preserved active instrument, mixer layers, dedicated ENV/LFO, unchanged patch size, exact ongoing four-engine/effects/sequence/Slip PCM.');

// Regression: HOME must retain the usable Volume / Pan / Sends workflow.
{const e=await boot(),a=api(e);a.run();e.web_open_page(0);a.tap(6);assert.equal(e.web_page(),7);const order=[0,2,1,3];
for(let k=0;k<4;k++){const before=e.web_layer_level(order[k]);a.turn(3+k,-2);assert.equal(e.web_layer_level(order[k]),before-2);}
a.tap(6);assert.equal(e.web_page(),49);for(let k=0;k<4;k++){const before=e.web_layer_pan(order[k]);a.turn(3+k,7);assert.equal(e.web_layer_pan(order[k]),before+7);}
for(const [page,param]of[[50,27],[51,24]]){a.tap(6);assert.equal(e.web_page(),page);for(let k=0;k<4;k++){a.select(order[k]);const before=e.web_param(param);a.turn(3+k,4);assert.equal(e.web_param(param),before+4);}}
a.tap(6);assert.equal(e.web_page(),7);}
console.log('PASS: HOME cycles VOL/PAN/FX1/FX2; all four physical knobs change the corresponding real four-engine faders, pan and both sends.');
