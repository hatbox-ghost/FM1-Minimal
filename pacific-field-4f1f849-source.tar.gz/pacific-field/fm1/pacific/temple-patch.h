/* SPDX-License-Identifier: GPL-3.0-only. TEMPLE's existing six oscillators, expanded. */
#pragma once
#define PF_TEMPLE_BYTES 64
static void temple_envelope_defaults(uint8_t *p){const uint8_t e[8]={40,100,0,45,0,40,100,0};memcpy(p+32,e,8);for(int op=0;op<6;op++){p[40+op*4]=0;p[41+op*4]=40;p[42+op*4]=100;p[43+op*4]=40;}}
static void temple_defaults(uint8_t *p){memset(p,0,PF_TEMPLE_BYTES);for(int i=10;i<16;i++)p[i]=100;p[28]=4;temple_envelope_defaults(p);}
static const uint8_t temple_controls[7][4]={{0,1,28,2},{4,5,10,11},{6,7,12,13},{8,9,14,15},{16,17,22,23},{18,19,24,25},{20,21,26,27}};
static const char *const temple_labels[7][4]={{"BODY DECAY","STRIKE DECAY","ROUTING","FEEDBACK"},{"OP1 RATIO","OP2 RATIO","OP1 LEVEL","OP2 LEVEL"},{"OP3 RATIO","OP4 RATIO","OP3 LEVEL","OP4 LEVEL"},{"OP5 RATIO","OP6 RATIO","OP5 LEVEL","OP6 LEVEL"},{"OP1 DECAY","OP2 DECAY","OP1 WAVE","OP2 WAVE"},{"OP3 DECAY","OP4 DECAY","OP3 WAVE","OP4 WAVE"},{"OP5 DECAY","OP6 DECAY","OP5 WAVE","OP6 WAVE"}};
static int temple_max(int i){return i==3?63:i>=40&&i<64?100:i==38?200:i==39?3:i>=32&&i<38?100:i==28?31:i>=22&&i<28?7:i>=4&&i<10?124:i==0||i==1||i==2||(i>=10&&i<22)?100:0;}
