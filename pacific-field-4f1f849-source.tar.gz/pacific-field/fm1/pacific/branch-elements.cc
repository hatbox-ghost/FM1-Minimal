/* GPL-3.0-only adapter; original MIT Elements algorithms retain their notices.
 * Four independent modal partials per note; shared bowed atmospheric body.
 * Template capacities and 44.1kHz constants are explicit platform adaptations. */
#include "branch-elements.h"
#include "fx.h"
#include "elements/dsp/resonator.h"
#include "elements/dsp/resonator.cc"
#include "elements/dsp/exciter.h"
#include <cstring>
#include <cmath>
using namespace pf_elements;
struct Note { Resonator<4,0,2> body;float prior,energy; };
static Note notes[60] PF_FX_POOL;
static Resonator<8,1,256> atmosphere PF_FX_POOL;
static Exciter breath,bow,mallet;
static float air,friction,shared,pink,gust;static unsigned tick;
extern "C" void pf_branch_init(){memset(notes,0,sizeof notes);memset(&atmosphere,0,sizeof atmosphere);for(auto &n:notes)n.body.Init();atmosphere.Init();breath.Init();breath.set_model(EXCITER_MODEL_GRANULAR_SAMPLE_PLAYER);bow.Init();bow.set_model(EXCITER_MODEL_FLOW);mallet.Init();mallet.set_model(EXCITER_MODEL_MALLET);tick=0;air=friction=shared=pink=gust=0;}
extern "C" void pf_branch_field(const float *p,float wind,float hz){
 gust=wind;breath.set_parameter(.35f);breath.set_timbre(.25f+p[8]*.005f);breath.set_signature(.3f);breath.Process(EXCITER_FLAG_GATE,&air,1);
 bow.set_parameter(.7f);bow.set_timbre(.4f);bow.Process(EXCITER_FLAG_GATE,&friction,1);
 pink+=(air-pink)*.035f;air=air*.35f+pink*1.8f;
 atmosphere.set_frequency(hz/44100.f);atmosphere.set_geometry(p[0]*.0095f);atmosphere.set_brightness(.2f+p[8]*.007f);atmosphere.set_damping(p[1]*.009f);atmosphere.set_position(.15f+p[14]*.007f);atmosphere.set_modulation_frequency(0);atmosphere.set_modulation_offset(.3f);
 float strength=p[6]*.008f,in=air*wind*.015f+friction*strength*.03f,c,s;atmosphere.Process(&strength,&in,&c,&s,1);shared=c*strength*.3f;tick++;
}
extern "C" float pf_branch_sample(int slot,float hz,float gate,float impulse,float motion,const float *p){
 Note &n=notes[slot];float rise=gate>0&&n.prior<=0;n.prior=gate;
 float strike=0;mallet.set_timbre(.15f+p[8]*.008f);mallet.set_parameter(.5f);mallet.Process((rise||impulse>n.energy+.02f?EXCITER_FLAG_RISING_EDGE:0)|(gate>0?EXCITER_FLAG_GATE:0),&strike,1);n.energy=impulse;
 auto &r=n.body;r.set_frequency(hz/44100.f);r.set_geometry(fminf(.99f,fmaxf(0,p[0]*.0095f+motion*p[10]*.004f+((slot*37%101)-50)*p[15]*.00002f)));r.set_damping(fminf(.99f,p[1]*.009f));r.set_brightness(.1f+p[8]*.008f);r.set_position(.1f+p[14]*.008f);r.set_modulation_frequency(0);r.set_modulation_offset(.3f);
 float input=air*gust*(slot>=30&&slot<38?.04f:0)+friction*p[6]*.0025f*(gate>0?1:0)+air*(p[11]*.0009f)*(gate>0?.7f:0)+strike*p[13]*.012f,zero=0,c,s;r.Process(&zero,&input,&c,&s,1);
 return c*2.f+shared*(gate>0?.3f:0);
}
extern "C" uint32_t pf_branch_bytes(){return sizeof notes+sizeof atmosphere+sizeof breath+sizeof bow+sizeof mallet+sizeof air+sizeof friction+sizeof shared+sizeof pink+sizeof gust+sizeof tick;}
