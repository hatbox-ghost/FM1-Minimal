/* SPDX-License-Identifier: GPL-3.0-only
 * Original pixel illustrations, drawn with the FM-1 strip renderer.
 * Coordinates are constrained to the screen's upper 120 rows.
 */
#include "../firmware/src/dsp/fastmath.h"
static uint16_t SC_INK,SC_LEAF,SC_GOLD,SC_FOG,SC_ROSE,SC_ROSE;
static int sc_wave(float t,int amp){return (int)(fm_sinf(t)*(float)amp);}
static void sc_oval(int x,int y,int rx,int ry,uint16_t c){for(int j=-ry;j<=ry;j++){float a=1.f-(float)(j*j)/(float)(ry*ry);int w=(int)(rx*fm_sqrtf(a<0?0:a));cv_rect(x-w,y+j,2*w+1,1,c);}}
static void sc_star(int x,int y,uint16_t c){cv_rect(x-2,y,5,1,c);cv_rect(x,y-2,1,5,c);}
static void sc_mist(float t,int y,uint16_t c){for(int j=0;j<3;j++){int x=(int)(t*5+j*83)%290-35;cv_line(x,y+j*4,x+49,y+j*4,c);cv_line(x+5,y+j*4+1,x+42,y+j*4+1,c);}}
static void sc_redwood(float t,uint32_t notes){
 cv_rect(0,22,240,98,RGB(13,29,27));
 for(int i=0;i<9;i++){int x=8+i*29;uint16_t col=i%2?RGB(26,49,42):RGB(34,57,43);cv_rect(x,23,5+i%3,88,col);for(int k=0;k<5;k++){int yy=35+k*12;cv_line(x,yy,x-14,yy+8,col);cv_line(x+4,yy+2,x+18,yy+8,col);}}
 cv_rect(95,20,18,95,RGB(84,48,38));cv_rect(101,20,4,95,RGB(125,68,43));cv_line(97,49,70,33,SC_GOLD);cv_line(111,67,146,48,SC_GOLD);cv_line(97,83,67,66,SC_LEAF);
 for(int j=0;j<7;j++){int x=47+j*23+sc_wave(t*.5f+j,2),yy=41+(j%3)*16;sc_oval(x,yy,10,4,RGB(41,83,54));cv_line(x-7,yy,x+7,yy,SC_LEAF);}
 cv_line(0,112,240,112,RGB(63,87,49));for(int j=0;j<10;j++){int x=j*25;cv_line(x,115,x+4,105,SC_LEAF);cv_line(x+4,105,x+8,112,SC_LEAF);}
 sc_mist(t,94,RGB(61,85,72));
 for(int k=0;k<27;k++)if(notes&(1u<<k)){int x=19+(k*31)%207,y=37+(k*13)%59;sc_star(x,y,SC_GOLD);}
 for(int j=0;j<8;j++){int energy=(int)(pf_energy[j]*10);if(energy>1){int x=35+j*25;cv_rect(x,44+j%3*17,2,energy,SC_GOLD);}}
}
static void sc_tortoise(float t,uint32_t notes){
 cv_rect(0,22,240,98,RGB(23,31,38));sc_oval(192,40,12,12,RGB(215,196,126));sc_oval(197,36,11,11,RGB(23,31,38));
 for(int i=0;i<8;i++)cv_rect(17+i*27,33+(i*7)%31,1,1,SC_FOG);
 cv_line(0,102,65,91,RGB(48,71,68));cv_line(65,91,146,104,RGB(48,71,68));cv_line(146,104,239,89,RGB(48,71,68));
 int step=notes?sc_wave(t*1.2f,2):0;sc_oval(83-step,103,11,5,SC_LEAF);sc_oval(142+step,104,12,5,SC_LEAF);cv_line(67,91,52,97,SC_LEAF);
 sc_oval(111,83,47,24,SC_INK);sc_oval(111,80,43,23,RGB(79,114,83));
 cv_line(71,85,92,69,SC_GOLD);cv_line(92,69,112,61,SC_GOLD);cv_line(112,61,133,72,SC_GOLD);cv_line(133,72,151,86,SC_GOLD);
 cv_line(70,86,91,91,SC_GOLD);cv_line(91,91,114,96,SC_GOLD);cv_line(114,96,134,91,SC_GOLD);cv_line(134,91,152,85,SC_GOLD);
 cv_line(92,69,91,91,SC_GOLD);cv_line(112,61,114,96,SC_GOLD);cv_line(133,72,134,91,SC_GOLD);cv_line(91,79,134,79,SC_GOLD);
 sc_oval(165,87+step,18,11,SC_LEAF);sc_oval(178,91+step,8,5,SC_LEAF);cv_rect(172,83+step,3,(int)t%11==0?1:3,SC_INK);cv_line(179,94+step,185,93+step,SC_INK);
 for(int k=0;k<27;k++)if(notes&(1u<<k)){int x=82+k%6*11,y=71+k/6*5;cv_rect(x,y,3,3,SC_GOLD);}
 sc_mist(t*.5f,111,RGB(70,87,85));
}
static void sc_lotus(int x,int y,int size){sc_oval(x-size,y-2,size,3,SC_ROSE);sc_oval(x+size,y-2,size,3,SC_ROSE);sc_oval(x,y-5,4,7,SC_ROSE);cv_line(x-size*2,y+2,x+size*2,y+2,SC_GOLD);}
static void sc_saraswati(float t,uint32_t notes){
 cv_rect(0,22,240,98,RGB(26,29,48));
 for(int j=0;j<3;j++){int yy=97+j*7;for(int x=0;x<240;x+=4)cv_line(x,yy+sc_wave(x*.06f+t*.4f,2),x+3,yy+sc_wave((x+3)*.06f+t*.4f,2),RGB(75,108,124));}
 // A seated, four-armed Saraswati holding a veena, book and prayer beads.
 sc_oval(119,53,24,24,RGB(111,87,56));sc_oval(119,53,21,21,RGB(52,50,59));
 cv_rect(111,40,17,17,RGB(55,44,44));sc_oval(119,49,8,10,RGB(221,185,143));
 cv_rect(112,38,15,4,SC_GOLD);cv_rect(115,33,9,6,SC_GOLD);cv_rect(118,30,3,4,SC_GOLD);
 cv_rect(115,48,2,1,SC_INK);cv_rect(122,48,2,1,SC_INK);cv_rect(119,44,1,2,SC_ROSE);cv_line(117,54,121,54,RGB(142,85,77));
 cv_rect(116,59,7,5,RGB(221,185,143));sc_oval(119,78,15,20,RGB(222,222,198));
 cv_line(113,65,105,87,SC_GOLD);cv_line(126,66,132,90,SC_GOLD);
 // Upper arms: book at left, mala at right.
 cv_line(108,67,94,57,RGB(221,185,143));cv_line(94,57,88,47,RGB(221,185,143));cv_rect(78,40,17,10,RGB(226,215,170));cv_line(86,41,86,49,SC_GOLD);
 cv_line(131,66,144,55,RGB(221,185,143));cv_line(144,55,151,43,RGB(221,185,143));for(int j=0;j<5;j++)sc_oval(155,43+j*4,1,1,SC_GOLD);
 // Lower arms meet the veena; the instrument crosses her lap.
 cv_line(108,71,91,82,RGB(221,185,143));cv_line(91,82,105,88,RGB(221,185,143));cv_line(130,71,140,79,RGB(221,185,143));cv_line(140,79,132,84,RGB(221,185,143));
 sc_oval(109,98,23,6,RGB(222,222,198));sc_oval(135,98,22,6,RGB(222,222,198));
 sc_oval(95,91,11,9,RGB(146,91,45));sc_oval(143,77,7,6,RGB(146,91,45));
 for(int j=0;j<3;j++)cv_line(95,90+j,153,73+j,notes?SC_GOLD:RGB(172,133,79));
 for(int k=0;k<5;k++)cv_line(109+k*8,86-k*2,109+k*8,90-k*2,SC_INK);
 sc_lotus(120,111,15);sc_lotus(35,105,5);sc_lotus(203,108,5);
 // Swan beside the river, with an unanimated sacred figure.
 sc_oval(182,94,10,5,SC_FOG);cv_line(188,93,190,82,SC_FOG);sc_oval(190,81,3,3,SC_FOG);cv_line(193,82,197,83,SC_GOLD);
 if(notes)for(int j=0;j<4;j++){int x=58+j*44,y=52+sc_wave(t+j,5);sc_star(x,y,SC_GOLD);}
}
static void sc_coast(float t,uint32_t notes){
 (void)notes;cv_rect(0,22,240,98,RGB(23,40,49));sc_oval(183,44,10,10,RGB(211,182,116));
 for(int j=0;j<4;j++){uint16_t c=j%2?RGB(65,102,110):RGB(42,77,88);for(int x=0;x<240;x+=3){int y=69+j*13+sc_wave(t*.5f+x*.035f+j,3);cv_rect(x,y,3,3,c);}}
 for(int y=53;y<120;y++){int width=(y-45)*2;cv_rect(0,y,width/2,1,RGB(40,61,48));}cv_line(4,56,46,77,SC_LEAF);cv_line(46,77,62,107,SC_LEAF);
 sc_mist(t,58,RGB(95,118,120));
 for(int m=0;m<PF_LAYERS;m++){int h=PF_PAR(pf_ui,m)[7]*18/100;cv_rect(166+m*20,116-h,7,h,(const uint16_t[]){SC_LEAF,SC_GOLD,SC_FOG,SC_ROSE}[m]);}
}
static void pf_scene(int layer,int page){float time=plat_ms()*.001f;uint32_t notes=pf_layer_lit(layer);SC_INK=RGB(18,29,29);SC_LEAF=RGB(145,178,126);SC_GOLD=RGB(228,187,108);SC_FOG=RGB(190,211,204);SC_ROSE=RGB(193,128,146);
 if(page==6||page==7)sc_coast(time,notes);else if(layer==0)sc_redwood(time,notes);else if(layer==1)sc_tortoise(time,notes);else if(layer==PF_CLOCK)sc_saraswati(time,notes);else sc_coast(time,notes);
}
