#pragma once
/* GPL-3.0-only. TORT control adapter for pinned OberVave DSP. */
#include "upstream/obervave/obv_params.h"
static void tort_defaults(uint8_t *v){memset(v,0,56);for(int i=0;i<=P_FMORPH;i++)v[i]=PDEF[i].def;v[P_FTYPE]=F_SEM;v[P_FMORPH]=0;v[P_FENV_AMT]=80;v[P_LFO_PITCH]=v[P_LFO_PWM]=v[P_LFO_FLT]=v[P_LFO_AMP]=v[P_MOD_DEPTH]=0;v[P_GLIDE]=0;v[P_VOLUME]=127;}
static const uint8_t tort_controls[12][4]={
 {P_O1_WAVE,P_O1_PW,P_O1_LVL,P_NOISE},{P_O2_WAVE,P_O2_PW,P_O2_SEMI,P_O2_FINE},
 {P_SYNC,P_XMOD,P_ENV_O2,P_O2_LVL},{P_GLIDE,P_KEYTRK,P_VINTAGE,P_VEL_AMP},
 {P_CUTOFF,P_RESO,P_FMORPH,P_FENV_AMT},{P_FA,P_FD,P_FS,P_FR},
 {P_AA,P_AD,P_AS,P_AR},{P_FTYPE,P_DRIVE,P_VEL_FLT,P_KEYTRK},
 {P_O1_PW,P_O2_PW,P_XMOD,P_ENV_O2},{P_LFO_RATE,P_LFO_SHAPE,P_LFO_DELAY,P_LFO_PHASE},
 {P_LFO_PITCH,P_LFO_PWM,P_LFO_FLT,P_LFO_AMP},{P_LFO_PITCH_TO,P_LFO_PWM_TO,P_MOD_DEPTH,P_FMORPH}};
static const char *const tort_labels[12][4]={
 {"WAVE 1","WIDTH 1","OSC 1","NOISE"},{"WAVE 2","WIDTH 2","SEMITONE","DETUNE"},
 {"HARD SYNC","X-MOD","ENV > OSC2","OSC 2"},{"GLIDE","KEY TRACK","VINTAGE","VEL > AMP"},
 {"CUTOFF","RESONANCE","MORPH","ENV AMOUNT"},{"FLT ATTACK","FLT DECAY","FLT SUSTAIN","FLT RELEASE"},
 {"AMP ATTACK","AMP DECAY","AMP SUSTAIN","AMP RELEASE"},{"FILTER TYPE","DRIVE","VEL > FLT","KEY TRACK"},
 {"WIDTH 1","WIDTH 2","X-MOD","ENV > OSC2"},{"RATE","SHAPE","DELAY","PHASE"},
 {"PITCH","PWM","FILTER","AMP"},{"PITCH TO","PWM TO","MOD DEPTH","MORPH"}};
enum {PF_TORT_SLOP=52,PF_TORT_FINE1=53,PF_TORT_FINE2=54};
static int tort_max(int i){if(i==52)return 100;if(i==53||i==54)return 127;return i>=0&&i<=P_FMORPH?PDEF[i].max:0;}
