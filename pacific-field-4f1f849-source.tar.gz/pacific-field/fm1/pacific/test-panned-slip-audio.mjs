// Slip changes time only; it must not override the instrument's mixer pan.
import {boot,turn} from './test-slip-panel.mjs';
import {legacyStep} from './test-panel-order.mjs';
import assert from 'node:assert/strict';
for(const pan of [-100,100]){
 const e=await boot();e.web_open_page(49);turn(e,3,pan);
 e.web_open_page(32);turn(e,6,100);legacyStep(e,0,0,[60]);legacyStep(e,0,1,[64]);
 e.web_seq_post(0,0,2);e.web_seq_post(0,10001,1);
 const energies=[0,0];
 for(let j=0;j<700;j++){e.web_audio_render(128);for(const [i,p] of [e.web_out_l(),e.web_out_r()].entries())for(const x of new Float32Array(e.memory.buffer,p,128)){assert(Number.isFinite(x));energies[i]+=x*x;}}
 assert(energies[pan>0?1:0]>1e-8);assert.equal(energies[pan>0?0:1],0);
 assert.equal(e.web_phase_state(1,9),0);assert.equal(e.web_dropped(),0);assert.equal(e.web_fx_faults(),0);
}
console.log('PASS no auto-panning or duplicate gate with Slip enabled.');
