#pragma once
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
void pf_branch_init(void);
void pf_branch_field(const float *p,float wind,float hz);
float pf_branch_sample(int slot,float hz,float gate,float impulse,float motion,const float *p);
uint32_t pf_branch_bytes(void);
#ifdef __cplusplus
}
#endif
