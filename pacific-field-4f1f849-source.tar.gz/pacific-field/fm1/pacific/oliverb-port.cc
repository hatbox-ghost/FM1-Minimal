/* SPDX-License-Identifier: GPL-3.0-only
 * Pacific adapter around unchanged MIT Parasites Oliverb. */
#include "fx.h"
#include "clouds/dsp/frame.h"
#include "clouds/dsp/fx/oliverb.h"
#include <cstring>
static clouds::Oliverb processor PF_FX_POOL;
static uint16_t delay_buffer[16384] PF_FX_POOL;
extern "C" void pf_oliverb_init(){memset(static_cast<void*>(&processor),0,sizeof processor);memset(delay_buffer,0,sizeof delay_buffer);processor.Init(delay_buffer);processor.set_pitch_shift_amount(0.f);processor.set_ratio(1.f);}
extern "C" void pf_oliverb_block(const float *in,float *out,const float *c){clouds::FloatFrame frames[32];for(int i=0;i<32;i++){frames[i].l=in[i*2];frames[i].r=in[i*2+1];}
 float freeze=c[6];processor.set_size(.05f+c[0]*.0095f);processor.set_diffusion(c[3]*.009f);processor.set_decay((.2f+.799f*c[1]*.01f)*(1-freeze)+freeze);float lp=.02f+.97f*(1-c[2]*.01f)*(1-c[2]*.01f);processor.set_lp(lp*(1-freeze)+freeze);processor.set_hp(c[18]*.001f*(1-freeze));processor.set_input_gain(.2f*(1-freeze));processor.set_mod_amount(c[4]*.6f);processor.set_mod_rate(.05f+c[5]*.0095f);processor.Process(frames,32);for(int i=0;i<32;i++){out[i*2]=frames[i].l;out[i*2+1]=frames[i].r;}}
extern "C" uint32_t pf_oliverb_bytes(){return sizeof processor+sizeof delay_buffer;}
