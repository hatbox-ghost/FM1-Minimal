import {modeDelta} from './test-panel-order.mjs';
import fs from 'node:fs';import assert from 'node:assert/strict';
for(let m=0;m<3;m++){
 const {instance:{exports:e}}=await WebAssembly.instantiate(fs.readFileSync(process.argv[2]),{wasi_snapshot_preview1:new Proxy({},{get:()=>()=>0}),env:new Proxy({},{get:()=>()=>0})});e._initialize();e.web_boot();const render=(n=128)=>e.web_render(n),tap=b=>{e.web_buttons(1<<b);e.web_buttons(0);render();};render();e.web_enc(2,modeDelta(e,m));render();e.web_open_page(0);
 e.web_keys(1<<7);render();const base=e.web_voice_current_frequency(m,7);e.web_keys(0);render();
 // Still-ringing voices previously retained their old pitch and glided for 70ms.
 tap(12);e.web_keys(1<<7);render(1);assert(Math.abs(e.web_voice_current_frequency(m,7)-base/2)<.001,'new lower-octave note must start at pitch');e.web_keys(0);render();
 tap(13);e.web_keys(1<<7);render(1);assert(Math.abs(e.web_voice_current_frequency(m,7)-base)<.001,'new upper-octave note must start at pitch');e.web_keys(0);render();
 assert.equal(e.web_dropped(),0);
}
console.log('PASS: octave down/up starts new keyboard notes immediately at the correct pitch on all three instruments, including over release tails.');
