/* SPDX-License-Identifier: GPL-3.0-only
 * Shared stereo buses; rational 44100/32000 adapter around original DSP. */
#include "fx.h"
#include "../firmware/src/app/plat.h"
#include <string.h>
#include "fx-src.h"
int16_t pf_fx_settings[20];
int16_t pf_fx_delay_sync,pf_fx_delay_division,pf_fx_bpm=96;
typedef struct {float input[4][32],output[4][128],inBlock[2][64],outBlock[2][64],cfg[20];uint32_t head,phase,native,fill,faults;int ready;} FxState;
static FxState state EN_POOL;
static volatile float activity[4];
float pf_fx_meter(int i){return i>=0&&i<4?activity[i]:0;}
void pf_fx_init(void){memset(&state,0,sizeof state);for(int i=0;i<4;i++)activity[i]=0;pf_clouds_init();pf_oliverb_init();}
void pf_fx_frame(float dl,float dr,float rl,float rr,float *L,float *R){FxState *s=&state;float values[4]={dl,dr,rl,rr};for(int c=0;c<4;c++)s->input[c][s->head&31]=values[c];s->phase+=32000;
 if(s->phase>=44100){s->phase-=44100;int phase=(int)(s->phase*63u/32000u);for(int c=0;c<4;c++){float v=0;for(int t=0;t<32;t++)v+=s->input[c][(s->head-t)&31]*fxDown[phase][t];s->inBlock[c/2][s->fill*2+c%2]=v;}
 s->fill++;s->native++;if(s->fill==32){for(int i=0;i<20;i++){float target=pf_fx_settings[i];if(!s->ready||i==9||i==14)s->cfg[i]=target;else s->cfg[i]+=.04f*(target-s->cfg[i]);}s->ready=1;pf_clouds_block(s->inBlock[0],s->outBlock[0],s->cfg);pf_oliverb_block(s->inBlock[1],s->outBlock[1],s->cfg);float peaks[4]={0};for(int j=0;j<32;j++)for(int c=0;c<4;c++){float input=s->inBlock[c/2][j*2+c%2];if(input<0)input=-input;if(input>peaks[c/2])peaks[c/2]=input;float v=s->outBlock[c/2][j*2+c%2];if(!__builtin_isfinite(v)){s->faults++;v=0;}s->output[c][(s->native-32+j)&127]=v;float peak=v<0?-v:v;if(peak>peaks[2+c/2])peaks[2+c/2]=peak;}for(int i=0;i<4;i++)activity[i]=peaks[i]>activity[i]*.995f?peaks[i]:activity[i]*.995f;s->fill=0;}}
 s->head++;float out[4]={0};int ph=63-(int)(s->phase*63u/44100u);for(int c=0;c<4;c++)for(int t=0;t<32;t++){int64_t at=(int64_t)s->native-63-t;if(at>=0)out[c]+=s->output[c][at&127]*fxUp[ph][t];}/* Raise both current wet returns by another 30% (1.3 * 1.3 = 1.69).
 * Sends, feedback, dry signal and the original algorithms remain unchanged. */float master=s->cfg[19]*.0169f;*L=(out[0]*s->cfg[15]*.01f+out[2]*s->cfg[7]*.01f)*master;*R=(out[1]*s->cfg[15]*.01f+out[3]*s->cfg[7]*.01f)*master;}
uint32_t pf_fx_bytes(void){return sizeof state+pf_clouds_bytes()+pf_oliverb_bytes();}

uint32_t pf_fx_faults(void){return state.faults;}
