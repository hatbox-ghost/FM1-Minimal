import {modeDelta} from './test-panel-order.mjs';
import fs from 'node:fs';import assert from 'node:assert/strict';
const wasm=fs.readFileSync(process.argv[2]);
async function boot(bytes=wasm){const {instance:{exports:e}}=await WebAssembly.instantiate(bytes,{wasi_snapshot_preview1:new Proxy({},{get:()=>()=>0}),env:new Proxy({},{get:()=>()=>0})});e._initialize?.();e.web_boot();return e;}
const e=await boot();const run=(seconds=.03,check=false)=>{for(let i=0;i<Math.ceil(seconds*44100/128);i++){e.web_render(128);if(check)for(const ptr of [e.web_out_l(),e.web_out_r()])for(const x of new Float32Array(e.memory.buffer,ptr,128))assert(Number.isFinite(x)&&Math.abs(x)<=.951);}};
const tap=b=>{e.web_buttons(1<<b);e.web_buttons(0);run();};const turn=(k,d)=>{e.web_enc(3+k,d);run();};const select=m=>{e.web_enc(2,modeDelta(e,m));run();};
function set(m,slot,field,value){select(m);e.web_open_page(10+slot*2+(field>=4?1:0));turn(field<4?[0,1,3,2][field]:field%4,value-e.web_lfo_setting(m,slot,field));assert.equal(e.web_lfo_setting(m,slot,field),value);}
run();assert(e.web_patch_bytes()<=e.web_store_max());assert(e.web_pool_bytes()+240*144*2<0x54000);
for(let m=0;m<3;m++){select(m);tap(6);for(let n=0;n<5;n++){tap(3);assert.equal(e.web_page(),[10,12,14,16,68][n]);assert.equal(e.web_mode(),m);assert.equal(e.web_layer_running(m),0);}for(let slot=0;slot<4;slot++){assert.equal(e.web_lfo_setting(m,slot,1),0);set(m,slot,0,52+slot*5);set(m,slot,1,35+slot);set(m,slot,2,slot);set(m,slot,3,slot+1);set(m,slot,4,slot%2);set(m,slot,6,slot*45);}tap(1);e.web_keys((1<<7)|(1<<11)|(1<<14));e.web_keys(0);run(.3,true);assert.equal(e.web_layer_active(m),(1<<7)|(1<<11)|(1<<14));}
const base=Array.from({length:28},(_,i)=>e.web_param(i));const phases=Array.from({length:3},(_,m)=>e.web_lfo_phase(m,0));run(1,true);assert.deepEqual(Array.from({length:28},(_,i)=>e.web_param(i)),base);for(let m=0;m<3;m++)assert.notEqual(e.web_lfo_phase(m,0),phases[m]);
// Page changes don't restart phase. Very slow LFO provides an unambiguous check.
set(0,0,0,1);set(0,0,4,0);const phase=e.web_lfo_phase(0,0);for(let n=0;n<30;n++)tap(3);assert(e.web_lfo_phase(0,0)>phase);assert.equal(e.web_mode(),0);
// First-key reset only, chord additions and arp events do not restart the bank.
set(0,0,5,1);tap(1);e.web_keys(0);run(.2);e.web_keys(1<<5);run(.03);assert(e.web_lfo_phase(0,0)<.002);run(1);const before=e.web_lfo_phase(0,0);e.web_keys((1<<5)|(1<<9));run(.03);assert(e.web_lfo_phase(0,0)>before);e.web_keys(0);
// Tempo sync follows BPM even with transport stopped and no phase reset.
set(0,0,4,1);set(0,0,0,63);set(0,0,5,0);e.web_open_page(8);if(e.web_arp_sync?.(0)){e.web_buttons(1<<5);e.web_enc(4,1);e.web_buttons(1<<5);e.web_buttons(0);}turn(1,120-e.web_arp_setting(0,1));let a=e.web_lfo_phase(0,0);run(.1);let b=e.web_lfo_phase(0,0);assert(Math.abs(((b-a+1)%1)-.2)<.01);turn(1,60);a=e.web_lfo_phase(0,0);run(.1);b=e.web_lfo_phase(0,0);assert(Math.abs(((b-a+1)%1)-.3)<.012);
// All fields persist for every bank and the sequencer stays stopped.
assert.equal(e.web_save_project(),0);const settings=Array.from({length:3},(_,m)=>Array.from({length:4},(_,slot)=>Array.from({length:8},(_,field)=>e.web_lfo_setting(m,slot,field))));e.web_boot();run();for(let m=0;m<3;m++){for(let slot=0;slot<4;slot++)for(let field=0;field<8;field++)assert.equal(e.web_lfo_setting(m,slot,field),settings[m][slot][field]);assert.equal(e.web_seq_state(m,3),0);}
// v5 migration preserves original bytes and seeds inactive LFOs.
if(process.argv[3]){
const legacy=await boot(fs.readFileSync(process.argv[3]));legacy.web_enc(3,13);legacy.web_render(128);legacy.web_buttons(1<<7);legacy.web_buttons(0);legacy.web_render(128);const n=legacy.web_store_len(0),saved=new Uint8Array(legacy.memory.buffer,legacy.web_store(0),n).slice();new Uint8Array(e.memory.buffer,e.web_store(0),n).set(saved);e.web_store_set_len(0,n);e.web_boot();run();assert.equal(e.web_layer_level(0),legacy.web_layer_level(0));for(let m=0;m<3;m++)for(let slot=0;slot<4;slot++)assert.equal(e.web_lfo_setting(m,slot,1),0);
// Depth-zero output is identical to the shipped pre-LFO DSP, sample for sample.
const old=await boot(fs.readFileSync(process.argv[3])),fresh=await boot();for(const x of [old,fresh]){x.web_keys(1<<7);}
for(let i=0;i<100;i++){old.web_render(128);fresh.web_render(128);for(const channel of ['web_out_l','web_out_r'])assert.deepEqual(new Float32Array(fresh.memory.buffer,fresh[channel](),128),new Float32Array(old.memory.buffer,old[channel](),128));}
}
console.log('PASS: 12 independent LFOs, slot navigation, phase continuity, zero-depth sample identity, safe audio, unmodified base patch, key sync, tempo changes, v5 migration, all-bank persistence, idle transport and storage/RAM bounds.');

// Pure waveform reference points and deterministic same-destination addition.
select(1);if(e.web_param(23))tap(1);
for(let i=0;i<1000;i++){const phase=i/1000;const expected=[Math.sin(phase*2*Math.PI),1-4*Math.abs(phase-.5),2*phase-1,1-2*phase,phase<.5?1:-1,.314];for(let shape=0;shape<6;shape++)assert(Math.abs(e.web_lfo_sample(shape,phase,.314)-expected[shape])<.00002);}
for(let slot=0;slot<4;slot++){set(1,slot,0,0);set(1,slot,1,0);set(1,slot,4,0);set(1,slot,6,0);set(1,slot,2,4);set(1,slot,3,1);set(1,slot,5,1);}set(1,0,1,20);set(1,1,1,20);e.web_keys(1<<7);e.web_keys(0);run(1);assert(Math.abs(e.web_lfo_effective(1,1)-Math.min(100,e.web_param(1)+18))<.01);
set(1,0,0,100);set(1,0,2,5);set(1,0,1,80);let cycles=e.web_lfo_cycles(1,0),observed=0;for(let i=0;i<1000;i++){e.web_render(128);const next=e.web_lfo_cycles(1,0);assert(next-cycles<=1);observed+=next-cycles;cycles=next;}assert(observed>=34&&observed<=35);
console.log('PASS: six waveform numerical references, summed destinations clamp once, S&H once-per-cycle at 12 Hz.');
