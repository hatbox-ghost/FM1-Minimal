> Historical implementation note. Page maps, memory numbers and build status describe that checkpoint. Current status: [root README](../../README.md) and [audit report](../../docs/audit-remediation/REPORT.md).

# Four-LFO audit and implementation

The supplied document is a design reference; the user's request authorizes implementation. The original UI has no encoder click. EDIT already advances pages. LFO selects a slot; EDIT from its main page opens configuration and continues through the other slots. Direct buttons remain escape shortcuts. Layer changes retain slot and all phases.

Files: pacific.h appends 192 bytes of saved configs in version 6. app.c migrates v2–5 with zero depth, adds main/config pages, and retains all old controls on EDIT. engine.c and lfo.h hold four fixed states per context, a supported-destination registry, normalized phase and a private PRNG. web.c exposes diagnostics and direct page navigation; the emulator mirrors native controls. Existing build manifests already compile engine.c, so lfo.h is included on both targets.

Original Albion's actual source includes 8 bars, despite the supplied prose mentioning 4 bars. All nine original divisions are preserved; free rate is exactly 0 (control zero), otherwise .02*600^control up to 12 Hz. The legacy Albion filter motion remains separately available so old patches retain their sound. SEQ is deferred, not presented as a waveform. No audio-rate or extended slow range.

Modulation is global per instrument. Key sync resets on the first live keyboard/MIDI note when the held bank was empty, not every chord note, arp event or process note. Transport never resets phase. Tempo follows that layer's existing ARP BPM even when stopped. Phase offset affects evaluation, not the running accumulator. S&H changes once at each cycle boundary; slew is 3–503 ms. Same destinations sum before clamping; pitch is cents, pan bipolar, amplitude attenuates from unity. Numeric parameters use their existing perceptual DSP mapping. No base values are mutated.

Hardware: OBJ_PROJ capacity is 3840 bytes. The patch remains below that capacity; the runtime pool plus graphics strip must remain below 0x54000 bytes. Browser tests check these bounds. Device compiler, CPU/xruns and physical FM-1 remain unmeasured; browser performance is not device proof. Future block sequencing is out of scope.

Measured browser WASM stress: 30 minutes of sample-frame audio, all three processes, three Slip arps and 12 routed LFOs, nine latched notes. Peak .7294; zero dropped commands / nonfinite samples, normalized phases. Render completed in 48.66 seconds on this computer. Engine pool 252180 bytes; with 69120-byte graphics strip: 321300 < 344064 bytes. Patch 948 < 3840 bytes. This is not a hardware timing measurement. Tests: test-lfo.mjs <wasm> [pre-LFO-baseline-wasm] includes optional sample-identity and v5 compatibility comparisons; test-lfo-long.mjs performs full 30-minute audio render.
