/* SPDX-License-Identifier: GPL-3.0-only */
static void project_recall(void){fm1_reboot();}
#include "app.c"
int project_load(void){return pf_load();}
void project_apply(void){pf_apply();}
void ui_init(void){pf_app_init();}
void ui_frame(void){pf_app_frame();}
void ui_input_only(void){pf_app_input();}
void ui_splash(int f){(void)f;palette_set(0);pf_draw();}
void ui_say(const char *a,const char *b){draw_text_box(0,100,240,&FONT_S,a,C_HI,1);if(b)draw_text_box(0,125,240,&FONT_S,b,C_GRAY,1);}
