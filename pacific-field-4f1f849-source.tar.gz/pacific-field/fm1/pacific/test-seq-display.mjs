import assert from 'node:assert/strict';
import {legacyStep} from './test-panel-order.mjs';
import {boot,turn} from './test-slip-panel.mjs';
const e=await boot(),display=await boot(),run=()=>e.web_render(128),tap=b=>{e.web_buttons(1<<b);e.web_buttons(0);run();};
const value=k=>{const data=new Uint8Array(e.memory.buffer,e.web_value(k),32);return new TextDecoder().decode(data.slice(0,data.indexOf(0)));};
function pixel(x,y){
 const size=e.web_visual_size(),packet=new Uint8Array(e.memory.buffer,e.web_visual_snapshot(),size);
 new Uint8Array(display.memory.buffer,display.web_visual_buffer(),size).set(packet);
 assert(display.web_visual_draw(size));
 return new Uint16Array(display.memory.buffer,display.web_fb(),240*240)[y*240+x];
}
e.web_open_page(33);turn(e,4,1);run();assert.equal(value(1),'SELECTED');assert.equal(value(0),'EMPTY');
tap(11);e.web_keys(1<<7);run();e.web_keys(0);run();tap(11);assert.equal(value(1),'PLAY');
const fill=pixel(71,60);assert.notEqual(fill,pixel(15,60));
turn(e,3,1);run();assert.equal(value(0),'QUEUED');assert.equal(value(1),'PLAY');
assert.notEqual(pixel(10,58),pixel(15,61),'queued border drawn');
assert.equal(e.web_save_project(),0);e.web_boot();run();assert.equal(e.web_seq_state(0,0),1);assert.equal(e.web_clip_event(0,1,-1,0),1);
e.web_open_page(33);assert.equal(value(1),'SELECTED');assert.equal(value(0),'EMPTY');
console.log('PASS selected, playing, queued and empty clip presentation; saved clip and notes restored.');


// The first SEQ page displays recorded notes and legacy step chords.
e.web_open_page(32);
assert.notEqual(pixel(10,108),0,'recorded middle note starts at the left edge of the roll');
turn(e,2,1);run(); // inspect a different instrument without changing either clip
legacyStep(e,e.web_mode(),0,[60,72]);run();run();
assert.notEqual(pixel(10,68),0,'upper note of the legacy chord is visible');
assert.notEqual(pixel(10,147),0,'lower note of the legacy chord is visible');
tap(10);run();
assert.notEqual(pixel(9,59),0,'running playhead appears above the roll');
assert.equal(e.web_page(),32);
console.log('PASS TIMING shows event and legacy pitches with a playback marker.');
