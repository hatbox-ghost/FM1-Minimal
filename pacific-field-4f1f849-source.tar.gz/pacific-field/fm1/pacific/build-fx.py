#!/usr/bin/env python3
"""Build shared C workstation + original isolated MIT C++ DSP for the emulator."""
import os,pathlib,shutil,subprocess,json
root=pathlib.Path(__file__).resolve().parents[1];out=root/'build/fx';out.mkdir(parents=True,exist_ok=True)
(root/'build/emu').mkdir(parents=True,exist_ok=True)
emcc=os.environ.get('EMCC') or shutil.which('emcc');assert emcc,'Set EMCC or activate emsdk'
emxx=os.environ.get('EMXX') or str(pathlib.Path(emcc).with_name('em++'))
base=['-O2','-ffp-contract=off','-DEN_HOST'];objects=[]
audit=os.environ.get('PF_MEMORY_AUDIT')
if audit:
 pathlib.Path(audit).mkdir(parents=True,exist_ok=True)
 base+=['-fstack-usage']
def unit(src,flags,compiler):
 obj=out/(str(src.relative_to(root)).replace('/','_')+'.o');subprocess.run([compiler,*base,*flags,'-c',str(src),'-o',str(obj)],check=True);objects.append(str(obj))
for name in ['web.c','engine.c','fx.c','lead.c']:unit(root/'pacific'/name,['-I'+str(root/'build/gen')],emcc)
for name in ['clouds','oliverb']:
 vendor=root/'pacific/upstream'/name
 flags=['-std=c++11','-fno-exceptions','-fno-rtti','-fno-threadsafe-statics','-DTEST','-DPF_SHARED_FX_WINDOW','-Dclouds=pf_'+name,'-Dstmlib=pf_'+name+'_stmlib','-I'+str(vendor)]
 
 if name=='clouds' and os.environ.get('PF_CLOUDS_FULL_BUFFER'):flags.append('-DPF_CLOUDS_FULL_BUFFER')
 unit(root/'pacific'/(name+'-port.cc'),flags,emxx)
 for src in sorted(vendor.rglob('*.cc')):unit(src,flags,emxx)
vendor=root/'pacific/upstream/elements'
flags=['-std=c++11','-fno-exceptions','-fno-rtti','-DTEST','-Delements=pf_elements','-Dstmlib=pf_elements_stmlib','-I'+str(vendor)]
unit(root/'pacific/branch-elements.cc',flags,emxx)
for name in ['elements/dsp/exciter.cc','elements/resources.cc','stmlib/utils/random.cc','stmlib/dsp/units.cc']:
 unit(vendor/name,flags,emxx)
linkflags=['-Wl,-Map='+str(pathlib.Path(audit)/'workstation.map')] if audit else []
subprocess.run([emxx,*objects,*linkflags,'--no-entry','-sSTANDALONE_WASM','-sSTACK_SIZE=131072','-sINITIAL_MEMORY=4194304','-sFILESYSTEM=0','-o',os.environ.get('PF_WASM_OUTPUT',str(root/'build/emu/amb.wasm'))],check=True)
print(os.environ.get('PF_WASM_OUTPUT',str(root/'build/emu/amb.wasm')))
