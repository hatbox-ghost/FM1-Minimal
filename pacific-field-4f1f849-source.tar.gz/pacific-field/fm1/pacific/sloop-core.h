/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments.
 * SLOOP modifications: isod89. Port pinned at 91f30182d9095e0ecdb43396554f2ce5a67df179.
 * Original synth seq_step, ratchets, span and polyphonic recording routines below.
 * Pacific replaces hardware clock, track/voice access, storage and MIDI-out hooks.
 */
#define UI_SMALL
#define NSTEP 64u
#define BEAT_U (44100u*60u)
#define SEQ_NONE 0xffffffffu
#define ST_NOTE 0
#define ST_TIE 1
#define ST_REST 2
#define SF_ACCENT 1u
#define SF_SLIDE 2u
#define SF_CONT0 8u
#define SF_CONT(k) (SF_CONT0<<(k))
#define SF_CONT_ALL (15u*SF_CONT0)
#define SF_LEG 128u
#define V_POLY 0
#define P_VOICE 0
#define MICRO_MIN -32
#define MICRO_MAX 31
#define UNDO_REC(t) 0
#define clamp(x,a,b) ((x)<(a)?(a):(x)>(b)?(b):(x))
typedef PFSeqRuntime track_t;
typedef PFSeqStep step_t;
/* Upstream stores nudge separately: clearing a note must keep its nudge here too. */
static void sloop_zero(void *dst,int value,size_t bytes){int8_t micro=0;if(bytes==sizeof(step_t))micro=((step_t*)dst)->micro;memset(dst,value,bytes);if(bytes==sizeof(step_t))((step_t*)dst)->micro=micro;}
static const int seqNumerator[9]={1,2,4,8,3,6,1,1,1},seqDenominator[9]={1,1,1,1,1,1,2,4,8};
static int seq_bpm(const track_t *t){return t->data->sync?seqProjectBpm:clamp(t->data->bpm,30,240);}
static uint32_t trk_len(const track_t *t){return clamp(pf_clip_length(&t->data->pattern[t->active]),1,64);}
static uint32_t trk_div(const track_t *t){return t->data->division%9;}
static uint32_t lvl_vel(uint32_t level,uint32_t base){return level==1?base*40/100:level==2?base*70/100:level==3?127:base;}
static uint32_t vel_lvl(uint32_t value){return value<50?1:value<85?2:value>115?3:0;}
static void undo_mark(track_t *t,uint32_t sess){(void)t;(void)sess;}
static int is_drum(const track_t *t){return 0;}
static int roll_has(const track_t *t,uint32_t n){return 0;}
static void seq_out_on(const track_t *t,uint32_t n,uint32_t vel){}
static void seq_out_off(const track_t *t,uint32_t n){}
static void seq_out_track_off(const track_t *t){}
static int live_has(const track_t *t,uint32_t note){if(t->voiceBase==52)return 0;int k=(int)note-53-12*octave;if(k>=0&&k<27&&(heldMask&(1u<<k)))return 1;for(int h=0;h<4;h++)if(v[48+h].gate&&current->midiNotes[h]==note)return 1;return 0;}

static void trk_note_off(track_t *t,uint32_t note){for(int h=0;h<8;h++)if(t->slots[h]==note){v[t->voiceBase+h].gate=0;t->slots[h]=255;}}
static void trk_note_on(track_t *t,uint32_t note,uint32_t vel){int h=-1;for(int j=0;j<8;j++)if(t->slots[j]==note){h=j;break;}if(h<0)for(int j=0;j<8;j++)if(!v[t->voiceBase+j].gate&&(h<0||t->age[j]<t->age[h]))h=j;if(h<0){h=0;for(int j=1;j<8;j++)if(t->age[j]<t->age[h])h=j;}
 int key=(int)note-53,oct=0;while(key<0){key+=12;oct--;}while(key>26){key-=12;oct++;}Voice *a=&v[t->voiceBase+h];int was=a->gate;a->fine=v[key].fine;a->pan=v[key].pan;if(!t->slide_glide||!was){a->freq=0;a->env=0;}setvoice(t->voiceBase+h,key,oct,v[key].level*vel/127.f,!t->slide_glide);if(!t->slide_glide||!was)a->freq=a->target;for(int j=0;j<3;j++){a->dsp->inc[j]=a->freq*transposeRatio/PF_SR;if(mode!=PF_CLOCK)a->dsp->mi[j]=a->dsp->inc[j];}t->slots[h]=note;t->age[h]=++t->serial;}
static void trk_note_chord(track_t *t,const uint8_t *notes,uint32_t n,uint32_t i,uint32_t vel){trk_note_on(t,notes[i],vel);}
static void seq_release(track_t *t){for(int h=0;h<8;h++){v[t->voiceBase+h].gate=0;t->slots[h]=255;}t->seq_n=0;t->seq_hold=0;t->slide_glide=0;}
static uint32_t swing_units(int32_t pct, uint32_t u)
{
    return (uint32_t)clamp(pct, 0, 100) * u / 200u;
}
/* a position on a grid of steps u units long, odd steps sw late: the step, units into it, its length */
static uint32_t grid_swing(uint32_t abs, uint32_t frac, uint32_t u, uint32_t sw, uint32_t *into, uint32_t *len)
{
    if (abs & 1u) {                                      /* an odd step: sw late */
        if (frac < sw) {
            abs--;
            frac += u;
            *len = u + sw;
        } else {
            frac -= sw;
            *len = u - sw;
        }
    } else {
        *len = u + sw;
    }
    *into = frac;
    return abs;
}

static uint32_t trk_grid(const track_t *t,uint32_t *into,uint32_t *len){uint32_t d=trk_div(t),u=BEAT_U*seqDenominator[d]/seqNumerator[d];return grid_swing(t->units/u,t->units%u,u,d<4?swing_units(t->data->swing,u):0,into,len);}
#define REC_LAT 0u /* browser/panel commands carry no fixed hardware scan delay */
static int8_t rec_m;                     /* (2.7) the last rec_target's note off the grid, as a nudge (rec_micro_set) */
static uint32_t rec_target(const track_t *t, uint32_t *later)
{
    uint32_t into, slen, abs = trk_grid(t, &into, &slen), half = slen / 2u, lat = REC_LAT * (uint32_t)seq_bpm(t);
    int32_t off = (int32_t)into - (int32_t)lat, m;  /* where it was heard, from the start of the playing step */
    if (into > half + (lat < half ? lat : half)) {  /* (32 bits: a step is 8 beats at most, 8 x FS x 60 x 64 < 2^31) */
        abs++;
        off -= (int32_t)slen;                       /* (before the next one: early) */
    }
    if (off < -(int32_t)slen)
        off = -(int32_t)slen;
    m = slen ? (off * 64 + (off >= 0 ? (int32_t)(slen / 2u) : -(int32_t)(slen / 2u))) / (int32_t)slen : 0;
    rec_m = (int8_t)(m < MICRO_MIN ? MICRO_MIN : m > MICRO_MAX ? MICRO_MAX : m);
    *later = abs != t->seq_abs;
    return abs;
}
/* SLOOP 2.7, REC screen QUANT OFF (rec_quant_off, panel.c lights_word bit 31): a note played by hand keeps its timing.
 * It goes into the nearest step as ever, and how far off the grid it was becomes that step's nudge (1/64 of a step:
 * at 120 BPM in 1/16, about 2 ms), when the step held nothing before: a step has one nudge, so a chord's later
 * notes and a second drum sound on a step take the first one's. The arp's notes and the rolls stay on their grid. */
static uint8_t rec_quant_off;
static void rec_micro_set(track_t *t, uint32_t idx, int was_empty)
{
    if (rec_quant_off && was_empty && idx < NSTEP)
        t->data->pattern[t->active].steps[idx].micro = rec_m;
}

static void step_add(track_t *t, uint32_t idx, uint32_t note, uint32_t vel, uint32_t lvl, uint32_t rat)
{
    step_t *s = &t->data->pattern[t->active].steps[idx];
    uint32_t k;
    if (s->time != ST_NOTE || !s->n || t->p[P_VOICE] != V_POLY) {
        s->n = 0;                                   /* a fresh step */
        s->flags = 0;
        s->vel = 0;
        s->lvl = 0;
        s->rat = 0;
    }
    for (k = 0; k < s->n && s->note[k] != note; k++)
        ;
    if (k == s->n) {
        if (s->n < 4u)
            s->n++;
        k = s->n - 1u;
        s->note[k] = (uint8_t)note;
    }
    s->lvl = (uint8_t)((s->lvl & ~(3u << (2u * k))) | (lvl & 3u) << (2u * k));
    s->rat = (uint8_t)((s->rat & ~(3u << (2u * k))) | (rat & 3u) << (2u * k));
    s->time = ST_NOTE;
    if (vel > s->vel)
        s->vel = (uint8_t)vel;
}

#ifndef UI_SMALL
#define UI_SMALL                         /* (gfx.c: minsize; the host tests: nothing) */
#endif
/* ---- SLOOP 2.7: overdub over held notes ----
 * A pattern holds its notes with TIE steps (the notes of the NOTE step before them go on). A note recorded into a TIE
 * used to make that step a NOTE of its own, which ends the held notes there. Now (POLY parts) the step becomes a NOTE
 * with the held notes marked as going on (SF_CONT: not played again, not released) and the new note, up to 4 (the
 * oldest held one makes room); the step after it, when a TIE, becomes the new note's end: a NOTE of the held notes
 * only, all going on (step_pure_cont). While the new note is held, rec_hold moves that end along. Step entry (SEQ +
 * key) still replaces what plays. */
UI_SMALL static uint32_t chain_notes(const track_t *t, uint32_t idx, uint8_t *out)   /* what goes on into TIE step idx */
{
    uint32_t len = trk_len(t), k;
    for (k = 1; k < len; k++) {
        const step_t *s = &t->data->pattern[t->active].steps[(idx + len - k) % len];
        if (s->time == ST_TIE)
            continue;
        if (s->time == ST_NOTE && s->n && s->n <= 4u) {
            memcpy(out, s->note, s->n);
            return s->n;
        }
        return 0;
    }
    return 0;
}
UI_SMALL static int step_pure_cont(const step_t *s)      /* a NOTE whose notes all go on: the end of an overdubbed note */
{
    return s->time == ST_NOTE && s->n && s->n <= 4u && ((s->flags & SF_CONT_ALL) / SF_CONT0) == (1u << s->n) - 1u;
}
UI_SMALL static void chain_end(track_t *t, uint32_t j, const uint8_t *keep, uint32_t n)   /* TIE j: only keep goes on */
{
    step_t *s = &t->data->pattern[t->active].steps[j % NSTEP];
    uint32_t i;
    if (s->time != ST_TIE || !n)
        return;
    sloop_zero(s, 0, sizeof *s);
    for (i = 0; i < n && i < 4u; i++) {
        s->note[i] = keep[i];
        s->flags |= (uint8_t)SF_CONT(i);
    }
    s->n = (uint8_t)i;
    s->time = ST_NOTE;
}
UI_SMALL static uint32_t cont_notes(const step_t *s, uint32_t except, uint8_t *out)   /* its notes going on, but except */
{
    uint32_t i, n = 0;
    for (i = 0; i < s->n && i < 4u; i++)
        if ((s->flags & SF_CONT(i)) && s->note[i] != except)
            out[n++] = s->note[i];
    return n;
}

/* ---- (2.8.3) a note's length under later notes (SEQ > NOTES LEN: ui.c note_span_set; a free take: ft_close) ----
 * POLY: a note's LEN runs on under the notes after it: it joins their steps as a note going on (SF_CONT, as a
 * recording over held notes writes it, seq.c rec_hold), 4 notes a step at most; after them, a NOTE of its notes only,
 * all going on, carries it (the others end there). A long bass under a melody, programmed. MONO / LEGATO parts play one
 * note at a time: it stops there and says so. The step format is 2.7's: a project of 2.8.3 opens in 2.7 and later.
 * span_why: why the last note_span_set stopped short (0 a note ahead, 1 the step is full, 2 a MONO sound, 3 the end) */
static uint8_t span_why;
static int sp_on(const step_t *st) { return st->time == ST_NOTE && st->n; }
UI_SMALL static uint32_t span_notes(const step_t *st, uint8_t *s)   /* the notes step st starts (not ones going on) */
{
    uint32_t k, n = 0;
    for (k = 0; k < st->n && k < 4u; k++)
        if (!(st->flags & SF_CONT(k)))
            s[n++] = st->note[k];
    return n;
}
UI_SMALL static int span_in(const uint8_t *c, uint32_t nc, uint32_t note)
{
    uint32_t i;
    for (i = 0; i < nc; i++)
        if (c[i] == note)
            return 1;
    return 0;
}
/* the chain going into step j: 1 it carries all of s, and *other: notes not in s too */
UI_SMALL static int span_chain(const track_t *t, uint32_t j, const uint8_t *s, uint32_t ns, int *other, uint8_t *oc, uint32_t *no)
{
    uint8_t c[4];
    uint32_t n = chain_notes(t, j, c), i, all = 1;
    *other = 0;
    if (no)
        *no = 0;
    for (i = 0; i < ns; i++)
        all &= (uint32_t)span_in(c, n, s[i]);
    for (i = 0; i < n; i++)
        if (!span_in(s, ns, c[i])) {
            *other = 1;
            if (oc)
                oc[(*no)++] = c[i];
        }
    return n && all;
}
UI_SMALL static int span_cont_all(const step_t *st, const uint8_t *s, uint32_t ns)   /* all of s go on in st */
{
    uint32_t i, k;
    if (!sp_on(st))
        return 0;
    for (i = 0; i < ns; i++) {
        for (k = 0; k < st->n && !(st->note[k] == s[i] && (st->flags & SF_CONT(k))); k++)
            ;
        if (k == st->n)
            return 0;
    }
    return 1;
}
UI_SMALL static uint32_t span_len(const track_t *t, uint32_t i, const uint8_t *s, uint32_t ns)   /* the steps s sounds from i */
{
    uint32_t len = (uint32_t)clamp(trk_len(t), 1, NSTEP), n = 1;
    int other;
    while (i + n < len) {
        const step_t *st = &t->data->pattern[t->active].steps[i + n];
        if (st->time == ST_TIE ? !span_chain(t, i + n, s, ns, &other, 0, 0) : !span_cont_all(st, s, ns))
            break;
        n++;
    }
    return n;
}
UI_SMALL static void span_drop(step_t *st, const uint8_t *s, uint32_t ns)   /* s's notes going on in st: out */
{
    uint32_t k = 0;
    while (k < st->n) {
        if ((st->flags & SF_CONT(k)) && span_in(s, ns, st->note[k])) {
            uint32_t j, c;
            for (j = k; j + 1u < st->n; j++)
                st->note[j] = st->note[j + 1u];
            st->lvl = (uint8_t)((st->lvl & ((1u << (2u * k)) - 1u)) | ((st->lvl >> (2u * k + 2u)) << (2u * k)));
            st->rat = (uint8_t)((st->rat & ((1u << (2u * k)) - 1u)) | ((st->rat >> (2u * k + 2u)) << (2u * k)));
            c = (st->flags & SF_CONT_ALL) / SF_CONT0;
            c = (c & ((1u << k) - 1u)) | ((c >> (k + 1u)) << k);
            st->flags = (uint8_t)((st->flags & ~SF_CONT_ALL) | c * SF_CONT0);
            st->n--;
        } else {
            k++;
        }
    }
    if (!st->n) {
        sloop_zero(st, 0, sizeof *st);
        st->time = ST_REST;
    }
}
/* the notes s (started at step i) sound want steps; returns the steps they got (span_why: why fewer) */
UI_SMALL static uint32_t span_set(track_t *t, uint32_t i, const uint8_t *s, uint32_t ns, uint32_t want)
{
    uint32_t len = (uint32_t)clamp(trk_len(t), 1, NSTEP), cur, j, n, no, k;
    uint8_t oc[4];
    int other;
    span_why = 3;
    cur = span_len(t, i, s, ns);
    if (want == cur)
        return cur;
    /* 1. back to one step: what carried its notes after it goes. Read first (the chains as they are), then written: a
     * TIE of its notes only goes (a REST), its notes going on in later steps go; the melody's TIEs stay (theirs again) */
    {
        uint8_t act[NSTEP];
        for (j = i + 1u; j < i + cur; j++)
            act[j] = t->data->pattern[t->active].steps[j].time == ST_TIE ? (uint8_t)(span_chain(t, j, s, ns, &other, 0, 0) && !other) : 2u;
        for (j = i + 1u; j < i + cur; j++) {
            step_t *st = &t->data->pattern[t->active].steps[j];
            if (act[j] == 1u) {
                if (!st->n)
                    sloop_zero(st, 0, sizeof *st);
                st->time = ST_REST;                     /* (a TIE holding notes (an older SLOOP) keeps them) */
            } else if (act[j] == 2u) {
                span_drop(st, s, ns);
            }
        }
        for (j = i + 1u; j <= i + cur && j < len; j++) {   /* an end it left in a melody's note (step 3 below): a TIE again */
            step_t *st = &t->data->pattern[t->active].steps[j];
            uint8_t c[4];
            uint32_t nc, m, same;
            if (!step_pure_cont(st) || j == i)
                continue;
            nc = chain_notes(t, j, c);
            same = nc == st->n;
            for (m = 0; m < st->n && same; m++)
                same = (uint32_t)span_in(c, nc, st->note[m]);
            if (same) {
                sloop_zero(st, 0, sizeof *st);
                st->time = ST_TIE;
            }
        }
    }
    /* 2. on to want */
    for (n = 1, j = i + 1u; n < want && j < len; n++, j++) {
        step_t *st = &t->data->pattern[t->active].steps[j];
        if (st->time == ST_TIE) {
            if (!span_chain(t, j, s, ns, &other, 0, 0)) {
                span_why = 0;
                break;
            }
            continue;
        }
        if (sp_on(st)) {
            uint32_t add = 0;
            if (t->p[P_VOICE] != V_POLY) {
                span_why = 2;
                break;
            }
            for (k = 0; k < ns; k++)
                add += !span_in(st->note, st->n, s[k]);
            if (add < ns || st->rat || (st->flags & SF_SLIDE)) {   /* (the same pitch played there, ratchets, a slide) */
                span_why = 0;
                break;
            }
            if (st->n + add > 4u) {
                span_why = 1;
                break;
            }
            for (k = 0; k < ns; k++) {
                st->flags |= (uint8_t)SF_CONT(st->n);
                st->note[st->n++] = s[k];
            }
            continue;
        }
        span_chain(t, j, s, ns, &other, 0, 0);
        sloop_zero(st, 0, sizeof *st);
        if (other) {                                    /* after a melody's note: its notes only, going on */
            for (k = 0; k < ns; k++) {
                st->note[k] = s[k];
                st->flags |= (uint8_t)SF_CONT(k);
            }
            st->n = (uint8_t)ns;
            st->time = ST_NOTE;
        } else {
            st->time = ST_TIE;
        }
    }
    /* 3. it ends inside a melody's note: from there, the melody's only */
    if (j < len && t->data->pattern[t->active].steps[j].time == ST_TIE && span_chain(t, j, s, ns, &other, oc, &no) && other)
        chain_end(t, j, oc, no);
    return n;
}

/* (2.7.1) several notes held while recording (POLY): each goes on until its own key is let go. A note recorded over a
 * held one makes its step a NOTE of the held ones going on + the new one (as over a pattern's held notes, above); one let
 * go while others are held ends there: the step it ends on becomes a NOTE of the others only, all going on (hold_restart),
 * and TIEs carry them on. Before, the hold followed the newest note only and the others ended with it */
UI_SMALL static int rh_has(const track_t *t, uint32_t note)      /* a note of this hold: held, or let go since its last NOTE */
{
    uint32_t i;
    for (i = 0; i < t->rh_n; i++)
        if (t->rh_note[i] == note)
            return 1;
    for (i = 0; i < t->rh_offn; i++)
        if (t->rh_off[i] == note)
            return 1;
    return 0;
}
UI_SMALL static int rh_held(const track_t *t, uint32_t note)
{
    uint32_t i;
    for (i = 0; i < t->rh_n; i++)
        if (t->rh_note[i] == note)
            return 1;
    return 0;
}
UI_SMALL static void hold_marker_clear(track_t *t, uint32_t j, uint32_t also)   /* an end marker of only this hold's notes: gone */
{
    step_t *s = &t->data->pattern[t->active].steps[j % NSTEP];
    uint32_t i;
    if (!step_pure_cont(s))
        return;
    for (i = 0; i < s->n; i++)
        if (!rh_has(t, s->note[i]) && s->note[i] != also)
            return;
    sloop_zero(s, 0, sizeof *s);
    s->time = ST_REST;
}
UI_SMALL static void hold_restart(track_t *t, uint32_t j, uint32_t len, uint32_t abs)   /* step j: only the notes still held go on */
{
    step_t *s = &t->data->pattern[t->active].steps[j % NSTEP];
    uint8_t c[4];
    uint32_t n = chain_notes(t, j, c), i, k, m = 0;
    for (i = 0; i < n; i++) {                       /* (what sounded into j, but the ones let go) */
        for (k = 0; k < t->rh_offn && t->rh_off[k] != c[i]; k++)
            ;
        if (k == t->rh_offn)
            c[m++] = c[i];
    }
    hold_marker_clear(t, (j + 1u) % len, 0x100u);
    sloop_zero(s, 0, sizeof *s);
    for (i = 0; i < m; i++) {
        s->note[i] = c[i];
        s->flags |= (uint8_t)SF_CONT(i);
    }
    s->n = (uint8_t)m;
    s->time = m ? ST_NOTE : ST_REST;
    t->rh_start = (uint8_t)j;
    t->rh_last = (uint8_t)j;
    t->rh_last_abs = abs;
    t->rh_ties = 0;
    t->rh_rs = 1;
    t->rh_end = 0;
    t->rh_offn = 0;
}

/* live recording into a synth part: the nearest step (rec_target). Held on: each further step the
 * sequencer enters while the note is held becomes a TIE (rec_hold), up to the pattern length and
 * never over a step with notes (overdub keeps them); a release before the middle of the last one
 * puts that step back (rec_release), so a short note stays one step. A note recorded into another
 * step ends the hold before (the step model ties the notes of one step only). */
UI_SMALL static void rec_note(track_t *t, uint32_t note, uint32_t vel, uint32_t rat, int hold)
{
    uint32_t len = trk_len(t), later, abs = rec_target(t, &later), idx = abs % len, k;
    int was_empty = !(t->data->pattern[t->active].steps[idx % NSTEP].time == ST_NOTE && t->data->pattern[t->active].steps[idx % NSTEP].n);
    step_t *st = &t->data->pattern[t->active].steps[idx % NSTEP];
    uint8_t ch[4], keep[4];
    uint32_t nc = 0, nk = 0, merged = 0;
    undo_mark(t, UNDO_REC(t));
    if (t->p[P_VOICE] == V_POLY && !rat && hold && t->rh_n && st->time != ST_TIE && !(st->time == ST_NOTE && st->n) &&
        idx == ((t->rh_ties || t->rh_rs ? t->rh_last : t->rh_start) + 1u) % len) {
        nc = t->rh_n;                               /* (2.7.1) the step the hold goes on into, not tied yet: as a TIE */
        memcpy(ch, t->rh_note, nc);
        st->time = ST_TIE;
    } else if (t->p[P_VOICE] == V_POLY && !rat && st->time == ST_TIE) {
        nc = chain_notes(t, idx, ch);
    }
    if (nc) {
        merged = hold != 0;
        for (k = 0; k < nc; k++)                    /* (2.7) over held notes: they go on, this one starts */
            if (ch[k] != note && !(t->rh_n && rh_has(t, ch[k]) && !rh_held(t, ch[k])))   /* (2.7.1: not one let go) */
                keep[nk++] = ch[k];
        while (nk > 3u) {                           /* (four at most: the oldest one ends here) */
            for (k = 0; k + 1u < nk; k++)
                keep[k] = keep[k + 1u];
            nk--;
        }
        sloop_zero(st, 0, sizeof *st);
        for (k = 0; k < nk; k++) {
            st->note[k] = keep[k];
            st->flags |= (uint8_t)SF_CONT(k);
        }
        st->note[nk] = (uint8_t)note;
        st->n = (uint8_t)(nk + 1u);
        st->time = ST_NOTE;
        st->vel = (uint8_t)vel;
        st->lvl = (uint8_t)((vel_lvl(vel) & 3u) << (2u * nk));
        if ((idx + 1u) % len != idx)
            chain_end(t, (idx + 1u) % len, keep, nk);
    } else {
        uint32_t last = t->rh_ties || t->rh_rs ? t->rh_last : t->rh_start;
        int leg = t->p[P_VOICE] != V_POLY && !rat && hold && t->rh_n && !(t->rh_n == 1u && t->rh_note[0] == note) &&
                  idx != t->rh_start && (idx == (last + 1u) % len || (t->rh_ties && idx == last && st->time == ST_TIE));
        step_add(t, idx, note, vel, vel_lvl(vel), rat);
        if (leg)                                    /* (2.7.2) MONO / LEGATO: played over the note before, still held
                                                     * into this step (or to it): legato, as it sounded */
            st->flags |= (uint8_t)SF_LEG;
        for (k = 0; k < st->n; k++)                 /* (2.7) played again: it starts here */
            if (st->note[k] == note)
                st->flags &= (uint8_t)~SF_CONT(k);
        if ((st->flags & SF_CONT_ALL) && (nk = cont_notes(st, note, keep)) != 0 && (idx + 1u) % len != idx)
            chain_end(t, (idx + 1u) % len, keep, nk);   /* (into an end: the held ones go on past it) */
    }
    if (hold)                                       /* (a note played: hold; the arp's and a roll's: not) */
        rec_micro_set(t, idx, was_empty);
    t->seq_active = 1;
    if (later) {                                    /* it sounds now: the step must not trigger it again */
        if (t->rskip_abs != abs)
            t->rskip_n = 0;
        t->rskip_abs = abs;
        if (t->rskip_n < 4u)
            t->rskip[t->rskip_n++] = (uint8_t)note;
    }
    if (!hold)
        return;
    if (merged) {                                   /* (2.7.1) over held ones: they stay held, from this step on */
        t->rh_start = (uint8_t)idx;
        t->rh_ties = 0;
        t->rh_rs = t->rh_end = t->rh_offn = 0;
    } else if (!t->rh_n || t->rh_start != idx) {    /* a new hold (one in another step ends) */
        t->rh_n = 0;
        t->rh_start = (uint8_t)idx;
        t->rh_ties = 0;
        t->rh_rs = t->rh_end = t->rh_offn = 0;
    }
    for (k = 0; k < t->rh_n && t->rh_note[k] != note; k++)
        ;
    if (k == t->rh_n && t->rh_n < 4u)
        t->rh_note[t->rh_n++] = (uint8_t)note;      /* a chord: held until its last key is up */
}

UI_SMALL static int hold_merge(track_t *t, step_t *s)
{
    uint32_t i, k, add = 0;
    for (i = 0; i < t->rh_n; i++) {
        for (k = 0; k < s->n && s->note[k] != t->rh_note[i]; k++)
            ;
        add += k == s->n;
    }
    if (t->p[P_VOICE] != V_POLY || s->n > 4u || s->n + add > 4u || (s->flags & SF_SLIDE) || s->rat)
        return 0;                                   /* (ratchets, a slide: the step plays as written, the hold ends) */
    for (i = 0; i < t->rh_n; i++) {
        for (k = 0; k < s->n && s->note[k] != t->rh_note[i]; k++)
            ;
        if (k == s->n)
            s->note[s->n++] = t->rh_note[i];
        s->flags |= (uint8_t)SF_CONT(k);            /* (the same pitch there: it goes on, not played again) */
    }
    return 1;
}
/* (2.8.3) a step the hold goes on into, after notes that are not this hold's (a recorded melody's): a NOTE of the held
 * notes only, all going on, so the melody's notes end there and only the hold goes on */
UI_SMALL static int hold_only(track_t *t, step_t *s, uint32_t idx)
{
    uint8_t c[4];
    uint32_t n = chain_notes(t, idx, c), i, other = 0;
    if (s->time == ST_TIE)
        return 0;                                   /* (a TIE: the melody's note goes on with the hold, as recorded) */
    for (i = 0; i < n; i++)
        other |= !rh_held(t, c[i]);
    if (!other || t->p[P_VOICE] != V_POLY || !t->rh_n)
        return 0;
    sloop_zero(s, 0, sizeof *s);
    for (i = 0; i < t->rh_n && i < 4u; i++) {
        s->note[i] = t->rh_note[i];
        s->flags |= (uint8_t)SF_CONT(i);
    }
    s->n = (uint8_t)i;
    s->time = ST_NOTE;
    return 1;
}
UI_SMALL static void rec_hold(track_t *t, uint32_t idx, uint32_t len, uint32_t abs)
{
    step_t *s;
    if (!t->rh_n)
        return;
    if (!t->record || t->rh_ties + 1u >= len) {
        t->rh_n = 0;                                /* disarmed, or the whole pattern is this note */
        return;
    }
    if (idx == t->rh_start)
        return;                                     /* (recorded ahead into the step now starting) */
    s = &t->data->pattern[t->active].steps[idx];
    if (t->rh_end && (s->time == ST_TIE || s->time == ST_REST || !s->n || step_pure_cont(s))) {
        hold_restart(t, idx, len, abs);             /* (2.7.1) one let go: from here the others only */
        return;
    }
    if (step_pure_cont(s)) {                        /* (2.7) the end of a note over held ones: it goes on, the end moves */
        uint8_t keep[4];
        uint32_t nk = cont_notes(s, 0x100u, keep);
        t->rh_bak = *s;
        t->rh_last = (uint8_t)idx;
        t->rh_last_abs = abs;
        t->rh_ties++;
        sloop_zero(s, 0, sizeof *s);
        s->time = ST_TIE;
        if ((idx + 1u) % len != t->rh_start)
            chain_end(t, (idx + 1u) % len, keep, nk);
        return;
    }
    if (s->time == ST_NOTE && s->n) {
        step_t bak = *s;
        if (hold_merge(t, s)) {                     /* (2.8.3) POLY: it goes on through them */
            t->rh_bak = bak;
            t->rh_put = *s;
            t->rh_last = (uint8_t)idx;
            t->rh_last_abs = abs;
            t->rh_ties++;
            return;
        }
        t->rh_n = 0;                                /* a step with notes, no room: the hold ends before it */
        return;
    }
    t->rh_bak = *s;
    t->rh_last = (uint8_t)idx;
    t->rh_last_abs = abs;
    t->rh_ties++;
    if (!hold_only(t, s, idx)) {                    /* (2.8.3: after a melody's notes, only the hold goes on) */
        sloop_zero(s, 0, sizeof *s);
        s->time = ST_TIE;
    }
    t->rh_put = *s;
}

/* a key of a recorded note is up: the hold ends with the last one */
UI_SMALL static void rec_release(track_t *t, uint32_t note)
{
    uint32_t i, k = 0, into, slen, half, lat, early, len = trk_len(t);
    for (i = 0; i < t->rh_n; i++)
        if (t->rh_note[i] != note)
            t->rh_note[k++] = t->rh_note[i];
    if (k == t->rh_n)
        return;                                     /* not one of them */
    early = trk_grid(t, &into, &slen) == t->rh_last_abs;
    half = slen / 2u;
    lat = REC_LAT * (uint32_t)seq_bpm(t);
    early = early && into <= half + (lat < half ? lat : half);   /* (let go early in the hold's last step) */
    if (k) {                                        /* (2.7.1) others still held: this one ends, they go on */
        t->rh_n = (uint8_t)k;
        if (t->p[P_VOICE] != V_POLY)
            return;
        if (t->rh_offn < 4u)
            t->rh_off[t->rh_offn++] = (uint8_t)note;
        if (t->rh_ties && early && t->data->pattern[t->active].steps[t->rh_last].time == ST_TIE)
            hold_restart(t, t->rh_last, len, t->rh_last_abs);   /* (not held into this step: it ends before it) */
        else
            t->rh_end = 1;                          /* (held into this step: it ends with it) */
        return;
    }
    t->rh_n = 0;
    hold_marker_clear(t, ((t->rh_ties || t->rh_rs ? t->rh_last : t->rh_start) + 1u) % len, note);   /* (2.7.1) an end left
                                                     * ahead of notes all let go */
    if (t->rh_rs && !t->rh_ties && early && step_pure_cont(&t->data->pattern[t->active].steps[t->rh_last])) {
        sloop_zero(&t->data->pattern[t->active].steps[t->rh_last], 0, sizeof t->data->pattern[t->active].steps[t->rh_last]);   /* (2.7.1) let go early in a step the others went on */
        t->data->pattern[t->active].steps[t->rh_last].time = ST_REST;                            /* into: not held into it */
    }
    t->rh_end = t->rh_rs = t->rh_offn = 0;
    if (t->rh_ties && early && (t->data->pattern[t->active].steps[t->rh_last].time == ST_TIE || !memcmp(&t->data->pattern[t->active].steps[t->rh_last], &t->rh_put, sizeof t->rh_put)))
        t->data->pattern[t->active].steps[t->rh_last] = t->rh_bak;            /* released early in it: not held into this step */
    {   /* (2.8.3) the hold ended inside a recorded melody's note (TIEs carrying it and the held note on): from the step
         * it ended in, only the melody's notes go on */
        uint32_t j = t->rh_ties && early ? t->rh_last : (uint32_t)(t->rh_ties || t->rh_rs ? t->rh_last : t->rh_start) + 1u;
        uint8_t c[4], keep[4];
        uint32_t n, i, nk = 0, has = 0;
        j %= len;
        if (t->data->pattern[t->active].steps[j].time != ST_TIE || j == t->rh_start)
            return;
        n = chain_notes(t, j, c);
        for (i = 0; i < n; i++) {
            if (c[i] == note)
                has = 1;
            else
                keep[nk++] = c[i];
        }
        if (has && nk)
            chain_end(t, j, keep, nk);
    }
}

static uint32_t step_vel(const step_t *s, uint32_t i)
{
    uint32_t base = (s->flags & SF_ACCENT) ? 127u : (s->vel ? s->vel : 96u);
    return lvl_vel((s->lvl >> (2u * i)) & 3u, base);
}

/* play one synth step: TIE extends, REST releases, NOTE (re)triggers; a SLIDE on the previous
 * step makes this one legato with a glide (acid style). skip: bit k = note k already sounds
 * from live recording (not triggered, not released here). len: the step's length (units). */
static void seq_step(track_t *t, const step_t *s, uint32_t slen, uint32_t skip)
{
    uint32_t i, j, gate = slen * (uint32_t)t->data->gate / 128u;
    uint32_t slide_in = t->seq_hold && t->seq_n;
    const step_t *nx = &t->data->pattern[t->active].steps[(t->seq_idx + 1u) % trk_len(t)];
    uint32_t next_tie = nx->time == ST_TIE || (nx->time == ST_NOTE && (nx->flags & (SF_CONT_ALL | SF_LEG)));   /* (2.7: notes
                                                     * going on into the next step: held to it, it says which end;
                                                     * 2.7.2: a legato note next: held to it) */
    if (s->time == ST_TIE) {
        if (t->seq_n) {
            t->seq_off = gate + slen / 2u;
            t->seq_hold = (s->flags & SF_SLIDE) != 0 || next_tie;   /* chains hold at any GATE / swing */
        }
        return;
    }
    if (s->time == ST_REST || !s->n) {
        seq_release(t);
        return;
    }
    if (s->flags & SF_CONT_ALL) {                   /* (2.7) notes going on: kept; the others end, the new ones start */
        uint8_t old[4];
        uint32_t no = t->seq_n > 4u ? 4u : t->seq_n, kept = 0;
        memcpy(old, t->seq_notes, no);
        for (j = 0; j < no; j++) {
            for (i = 0; i < s->n && !((s->flags & SF_CONT(i)) && s->note[i] == old[j] && !((kept >> i) & 1u)); i++)
                ;
            if (i < s->n) {
                kept |= 1u << i;
            } else {
                if (!live_has(t, old[j]))
                    trk_note_off(t, old[j]);
                seq_out_off(t, old[j]);
            }
        }
        t->slide_glide = 0;
        for (i = 0; i < s->n; i++)                  /* (2.8.3) a note going on that a player holds: the key's, it sounds */
            if ((s->flags & SF_CONT(i)) && !((kept >> i) & 1u) && live_has(t, s->note[i]))
                skip |= 1u << i;
        for (i = 0; i < s->n; i++)
            if (!((kept >> i) & 1u) && !((skip >> i) & 1u) && !roll_has(t, s->note[i])) {
                trk_note_on(t, s->note[i], step_vel(s, i));   /* (a note going on that was not playing: from here) */
                seq_out_on(t, s->note[i], step_vel(s, i));
            }
        t->seq_n = 0;
        for (i = 0; i < s->n; i++)
            if (!((skip >> i) & 1u))
                t->seq_notes[t->seq_n++] = s->note[i];
        t->seq_off = step_pure_cont(s) ? gate + slen / 2u : gate;   /* (2.8.3: notes that only go on end as a TIE's do) */
        t->seq_hold = (s->flags & SF_SLIDE) != 0 || next_tie;
        return;
    }
    if (s->rat) {                                   /* ratchets: each hit its share of the step */
        uint32_t hits = 1u + ((s->rat >> 0) & 3u);
        for (i = 1; i < s->n; i++)
            if (1u + ((s->rat >> (2u * i)) & 3u) > hits)
                hits = 1u + ((s->rat >> (2u * i)) & 3u);
        gate /= hits;
    }
    t->slide_glide = (uint8_t)(slide_in && (!(s->flags & SF_LEG) ||   /* (2.7.2: legato alone: no glide of its own) */
                                            (t->data->pattern[t->active].steps[(t->seq_idx + trk_len(t) - 1u) % trk_len(t)].flags & SF_SLIDE)));
    if (!slide_in)
        seq_release(t);
    for (i = 0; i < s->n; i++)
        if (roll_has(t, s->note[i]))
            skip |= 1u << i;                        /* (a roll plays it) */
    for (i = 0; i < s->n; i++)
        if (!((skip >> i) & 1u)) {
            if (slide_in)
                trk_note_on(t, s->note[i], step_vel(s, i));
            else                                    /* (STRUM: a chord's notes one after the other) */
                trk_note_chord(t, s->note, s->n, i, step_vel(s, i));
            if (!slide_in || 1)
                seq_out_on(t, s->note[i], step_vel(s, i));   /* (a slide into the same note: one MIDI note) */
        }
    if (slide_in)                                   /* release what is not held over */
        for (i = 0; i < t->seq_n; i++) {
            for (j = 0; j < s->n && s->note[j] != t->seq_notes[i]; j++)
                ;
            if (j == s->n) {
                if (!live_has(t, t->seq_notes[i]))
                    trk_note_off(t, t->seq_notes[i]);
                seq_out_off(t, t->seq_notes[i]);
            }
        }
    t->seq_n = 0;
    for (i = 0; i < s->n; i++)
        if (!((skip >> i) & 1u))
            t->seq_notes[t->seq_n++] = s->note[i];
    t->seq_off = gate;
    t->seq_hold = !s->rat && ((s->flags & SF_SLIDE) != 0 || next_tie);   /* next step a TIE: keep the notes to it */
}

static void seq_ratchets(track_t *t, uint32_t into, uint32_t slen)
{
    uint32_t i;
    if (t->seq_skip)
        return;                                     /* (its condition failed: no hit at all) */
    {
        const step_t *s = &t->data->pattern[t->active].steps[t->seq_idx % NSTEP];
        if (s->time != ST_NOTE || !s->rat)
            return;
        for (i = 0; i < s->n; i++) {
            uint32_t hits = 1u + ((s->rat >> (2u * i)) & 3u), h;
            if (hits == 1u || roll_has(t, s->note[i]))
                continue;
            h = into * hits / slen;
            if (h > t->rat_done[i] && h < hits) {
                uint32_t j;
                t->rat_done[i] = (uint8_t)h;
                trk_note_off(t, s->note[i]);
                trk_note_on(t, s->note[i], step_vel(s, i));
                seq_out_on(t, s->note[i], step_vel(s, i));
                t->seq_off = slen / hits * (uint32_t)t->data->gate / 128u;
                for (j = 0; j < t->seq_n && t->seq_notes[j] != s->note[i]; j++)
                    ;
                if (j == t->seq_n && t->seq_n < 4u)
                    t->seq_notes[t->seq_n++] = s->note[i];   /* (its gate ends it) */
            }
        }
    }
}



/* Original SLOOP parameter-lock lifecycle, mapped onto Pacific voice parameters. */
#define NLOCK 24u
#define LOCK_FREE 255u
#define P_COUNT 192u
typedef PFSeqLock plock_t;
typedef struct {int min,max;} param_desc_t;
static int p_lockable(uint32_t id){return id<20||(id>=24&&id<28)||(id>=32&&id<88)||(id>=96&&id<128)||(mode==PF_CLOCK&&id>=128&&id<192);}
static int seq_lock_value(const track_t *t,uint32_t id){if(mode==PF_CLOCK&&id>=128&&id<192)return temple_params[id-128];if(id<28)return par[id];if(id>=32&&id<88)return current->tort[id-32];if(id>=96&&id<128)return current->lfos[(id-96)/8].cfg[(id-96)%8];return 0;}
static const param_desc_t *lock_desc(const track_t *t,uint32_t id){static param_desc_t d;d.min=0;d.max=100;if(mode==PF_CLOCK&&id>=128&&id<192)d.max=temple_max(id-128);else if(id>=32&&id<88)d.max=tort_max(id-32);else if(id>=96){const int hi[8]={100,100,5,pf_lfo_count(mode)-1,1,1,359,100};d.max=hi[(id-96)%8];}else{if(id==17){d.min=-2;d.max=2;}if(id==18){d.min=-100;d.max=100;}if(id==19){d.min=-50;d.max=50;}if(id==25){d.min=30;d.max=1000;}if(mode==1&&id==8){d.min=2;d.max=180;}if(mode==1&&id==11)d.max=2;if(mode==1&&id==12){d.min=30;d.max=240;}if(mode==1&&id==13){d.min=1;d.max=27;}if(mode==1&&id==14)d.max=3;if(mode==0&&id==12){d.min=60;d.max=2000;}if(mode==2&&id==6)d.max=6;if(mode==2&&id==8){d.min=1;d.max=240;}if(mode==2&&id==11){d.min=80;d.max=4000;}if(mode==2&&(id==12||id==14))d.min=1;if(mode==2&&id==15)d.max=1;}return &d;}
static void lock_write(track_t *t,uint32_t id,int32_t value){const param_desc_t *d=lock_desc(t,id);value=clamp(value,d->min,d->max);if(mode==PF_CLOCK&&id>=128&&id<192)temple_params[id-128]=value;else if(id<28)par[id]=value;else if(id>=32&&id<88)current->tort[id-32]=value;else if(id>=96&&id<128)current->lfos[(id-96)/8].cfg[(id-96)%8]=value;}
static void locks_restore(track_t *t)        /* every lock in force let go (STOP, a load, a cleared pattern) */
{
    uint32_t i;
    for (i = 0; i < t->lockState->n && i < NLOCK; i++)
        if (seq_lock_value(t,t->lockState->param[i]%P_COUNT) == t->lockState->set[i])
            lock_write(t, t->lockState->param[i], t->lockState->base[i]);
    t->lockState->n = 0;
}
static void locks_clear(track_t *t)          /* no lock, no nudge (an empty pattern) */
{
    uint32_t i;
    locks_restore(t);
    for(int j=0;j<64;j++)t->data->pattern[t->active].steps[j].micro=0;
    for (i = 0; i < NLOCK; i++) {
        t->data->pattern[t->active].locks[i].step = LOCK_FREE;
        t->data->pattern[t->active].locks[i].param = 0;
        t->data->pattern[t->active].locks[i].val = 0;
    }
}
/* the sequencer enters step idx: its locks take hold, the last step's that it does not share let go */
static void lock_step(track_t *t, uint32_t idx)
{
    uint32_t i, k, n = 0;
    for (i = 0; i < t->lockState->n && i < NLOCK; i++) {      /* in force, no lock here: back to the base (or the knob) */
        uint32_t p = t->lockState->param[i] % P_COUNT, has = 0;
        for (k = 0; k < NLOCK; k++)
            if (t->data->pattern[t->active].locks[k].step == idx && t->data->pattern[t->active].locks[k].param == p)
                has = 1;
        if (has) {
            t->lockState->param[n] = (uint8_t)p;
            t->lockState->base[n] = t->lockState->base[i];
            t->lockState->set[n] = t->lockState->set[i];
            n++;
        } else if (seq_lock_value(t,p) == t->lockState->set[i]) {
            lock_write(t, p, t->lockState->base[i]);
        }
    }
    t->lockState->n = (uint8_t)n;
    for (k = 0; k < NLOCK; k++) {                     /* this step's locks */
        const plock_t *l = &t->data->pattern[t->active].locks[k];
        uint32_t p = l->param;
        if (l->step != idx || p >= P_COUNT || !p_lockable(p))
            continue;
        for (i = 0; i < t->lockState->n && t->lockState->param[i] != p; i++)
            ;
        if (i == t->lockState->n) {
            if (i >= NLOCK)
                continue;
            t->lockState->param[i] = (uint8_t)p;
            t->lockState->base[i] = seq_lock_value(t,p);
            t->lockState->n++;
        } else if (seq_lock_value(t,p) != t->lockState->set[i]) {
            t->lockState->base[i] = seq_lock_value(t,p);                  /* turned meanwhile: that is the new base */
        }
        lock_write(t, p, l->val);
        t->lockState->set[i] = seq_lock_value(t,p);
    }
}
/* a lock of (step, param): its slot, or a free one for it (-1: none left) */
static int lock_find(const track_t *t, uint32_t step, uint32_t param, int make)
{
    uint32_t k;
    int fr = -1;
    for (k = 0; k < NLOCK; k++) {
        if (t->data->pattern[t->active].locks[k].step == step && t->data->pattern[t->active].locks[k].param == param)
            return (int)k;
        if (fr < 0 && t->data->pattern[t->active].locks[k].step == LOCK_FREE)
            fr = (int)k;
    }
    return make ? fr : -1;
}
/* set (or make) the lock of (step, param) at v, clamped; 0 = no slot left or not lockable. Callers hold the IRQ off */
static int lock_set(track_t *t, uint32_t step, uint32_t param, int32_t value)
{
    int k;
    const param_desc_t *d;
    if (step >= NSTEP || param >= P_COUNT || !p_lockable(param) || (k = lock_find(t, step, param, 1)) < 0)
        return 0;
    d = lock_desc(t, param);
    t->data->pattern[t->active].locks[k].step = (uint8_t)step;
    t->data->pattern[t->active].locks[k].param = (uint8_t)param;
    t->data->pattern[t->active].locks[k].val = (int16_t)clamp(value, d->min, d->max);
    return 1;
}
static void lock_del(track_t *t, uint32_t step, uint32_t param)   /* param P_COUNT: every lock of the step */
{
    uint32_t k;
    for (k = 0; k < NLOCK; k++)
        if (t->data->pattern[t->active].locks[k].step == step && (param >= P_COUNT || t->data->pattern[t->active].locks[k].param == param))
            t->data->pattern[t->active].locks[k].step = LOCK_FREE;
}
static int step_locked(const track_t *t, uint32_t step)   /* the step carries a lock or a nudge (the UI's mark) */
{
    uint32_t k;
    if (step < NSTEP && t->data->pattern[t->active].steps[step].micro)
        return 1;
    for (k = 0; k < NLOCK; k++)
        if (t->data->pattern[t->active].locks[k].step == step)
            return 1;
    return 0;
}

#define FS 44100u
static struct { uint32_t ph, inc; int32_t env, gain; } click;   /* env: Q30, 0 = silent */
static uint32_t click_n;                         /* clicks so far, and the last one's accent (the host tests count them) */
static uint8_t click_acc;
static void click_on(int accent)
{
    click.ph = 0;
    click.inc = accent ? (uint32_t)(((uint64_t)1568u << 32) / FS) : (uint32_t)(((uint64_t)1047u << 32) / FS);
    click.gain = accent ? 20000 : 12000;
    click.env = 1 << 30;
    click_acc = (uint8_t)(accent != 0);
    click_n++;
}
static void click_render(int32_t *ml, int32_t *mr, uint32_t n)
{
    uint32_t i;
    int32_t g;
    if (!click.env)
        return;
    g = (int32_t)((int64_t)click.gain * 100 / 100);
    for (i = 0; i < n; i++) {
        int32_t tick = (int32_t)(((int64_t)(int32_t)(sn(click.ph*(1.f/4294967296.f))*32767.f) * (click.env >> 15) >> 15) * g >> 15);
        ml[i] += tick;
        mr[i] += tick;
        click.ph += click.inc;
        click.env -= click.env >> 9;                 /* about 12 ms to 1/e */
    }
    if (click.env < (1 << 18))
        click.env = 0;                                /* (-72 dB: done, about 100 ms) */
}

/* Original SLOOP free take: event capture, tempo fit and quantized polyphonic lengths. */
#define FS 44100u
#define CTL 64u
#define FT_MAX 192u
#define FT_BLOCKS (24u*FS/CTL)
#define FT_OPEN 0xffffu
typedef struct {uint16_t t,d;uint8_t note,vel;} ft_ev_t;
static ft_ev_t ft_ev[FT_MAX];static uint32_t ft_n,ft_t,ft_frames,ft_close_ms;static uint8_t ft_on,ft_trk,ft_closed,ft_bars;
static uint8_t seqRecTempo=0,seqRecCount=0;
static uint32_t seq_track_index(const track_t *t){for(uint32_t i=0;i<PF_LAYERS;i++)if(t==&layers[i].seq)return i;return 0;}
static int sloop_project_empty(void){for(int m=0;m<PF_LAYERS;m++)for(int i=0;i<64;i++){step_t *st=&seqPrograms[m].pattern[layers[m].seq.active].steps[i];if(st->n&&st->time==ST_NOTE)return 0;}return 1;}
static void steps_clear(track_t *t){sloop_zero(t->data->pattern[t->active].steps,0,sizeof t->data->pattern[t->active].steps);locks_clear(t);sloop_zero(t->data->pattern[t->active].fill,0,16);}
static void sloop_seq_start_all(void){for(int m=0;m<PF_LAYERS;m++){track_t *t=&layers[m].seq;t->run=1;t->units=0;t->seq_abs=SEQ_NONE;t->step=-1;layers[m].running=1;t->data->enabled=1;}}
/* tempo x 10 of a loop of T blocks holding n bars of 4/4 */
static uint32_t ft_bpm10(uint32_t T, uint32_t n)
{
    uint32_t den = T * CTL;                       /* (n * 2400 * FS < 2^32 up to n = 4) */
    return den ? (n * 2400u * FS + den / 2u) / den : 0u;
}

/* the bars a loop of T blocks holds (1, 2 or 4: the tempo the nearest the current one, in
 * 40..240), 0 none; *bpm its tempo */
static uint32_t ft_fit(uint32_t T, uint32_t *bpm)
{
    static const uint8_t BARS[3] = {1, 2, 4};
    uint32_t i, best = 0, cur = (uint32_t)seqProjectBpm * 10u, err = 0xFFFFFFFFu;
    for (i = 0; i < 3u; i++) {
        uint32_t b = ft_bpm10(T, BARS[i]), e;
        if (b < 400u || b > 2400u)
            continue;
        e = b > cur ? b * 1000u / cur : cur * 1000u / b;   /* the ratio, x 1000 */
        if (e < err) {
            err = e;
            best = BARS[i];
            *bpm = (b + 5u) / 10u;
            if (e <= 1030u)
                *bpm = cur / 10u;                           /* played to the tempo set: keep it */
        }
    }
    return best;
}

static void ft_start(track_t *t)
{
    ft_on = 1;
    ft_trk = (uint8_t)seq_track_index(t);
    ft_t = 0;ft_frames=0;
    ft_n = 0;
    t->arm=0;
}

static void ft_note_on(uint32_t note, uint32_t vel)
{
    if (ft_n < FT_MAX && ft_t < FT_BLOCKS) {
        ft_ev[ft_n].t = (uint16_t)ft_t;
        ft_ev[ft_n].d = FT_OPEN;
        ft_ev[ft_n].note = (uint8_t)note;
        ft_ev[ft_n].vel = (uint8_t)vel;
        ft_n++;
    }
}

static void ft_note_off(uint32_t note)
{
    uint32_t i = ft_n;
    while (i--)
        if (ft_ev[i].note == note && ft_ev[i].d == FT_OPEN) {
            ft_ev[i].d = (uint16_t)(ft_t - ft_ev[i].t);
            return;
        }
}

/* REC on the downbeat: the loop is the time from the first note to now */
static void ft_close(void)
{
    track_t *t=&layers[ft_trk%3].seq;
    uint32_t T = ft_t, bars, bpm = 0, len, i, k;
    ft_on = 0;
    ft_close_ms = t->frames/44u;
    ft_closed = 1;
    bars = ft_n && T >= FS / CTL / 2u ? ft_fit(T, &bpm) : 0u;
    if (!bars) {
        ft_bars = 0xFF;                               /* nothing played, or no tempo fits */
        return;
    }
    len = 16u * bars;
    undo_mark(t,0);             /* (undo: back to the empty project) */
    steps_clear(t);                                   /* (no tie left over from an old pattern) */
    for (i = 0; i < 3; i++) {                      /* the project is empty: one loop length */
        layers[i].seq.data->pattern[layers[i].seq.active].length=(uint8_t)len;
        layers[i].seq.data->division=2;                         /* 1/16 */
    }
    for (i = 0; i < ft_n; i++) {                      /* the notes, to the nearest step */
        uint32_t idx = (ft_ev[i].t * len * 2u + T) / (2u * T) % len;
        int was_empty=!(t->data->pattern[t->active].steps[idx].time==ST_NOTE&&t->data->pattern[t->active].steps[idx].n);
        step_add(t,idx,ft_ev[i].note,ft_ev[i].vel,vel_lvl(ft_ev[i].vel),0);
        if (rec_quant_off && was_empty) {             /* (2.7) QUANT OFF: its time off the grid, as the nudge */
            uint32_t u = (ft_ev[i].t * len * 128u + T) / (2u * T);   /* its place in 1/64 steps (24 s x 64 steps:
                                                                      * < 2^29) */
            int32_t m = (int32_t)u - (int32_t)((ft_ev[i].t * len * 2u + T) / (2u * T)) * 64;
            t->data->pattern[t->active].steps[idx].micro = (int8_t)(m < MICRO_MIN ? MICRO_MIN : m > MICRO_MAX ? MICRO_MAX : m);
        }
    }
    if (!is_drum(t))
        for (i = 0; i < ft_n; i++) {                  /* their lengths: TIE steps, up to the next note */
            uint32_t d = ft_ev[i].d == FT_OPEN || ft_ev[i].t + ft_ev[i].d > T ? T - ft_ev[i].t : ft_ev[i].d;
            uint32_t idx = (ft_ev[i].t * len * 2u + T) / (2u * T) % len;
            uint32_t steps = (d * len * 2u + T) / (2u * T);
            if (t->p[P_VOICE] == V_POLY) {            /* (2.8.3) POLY: on under the notes after it, as held (it used to
                                                       * stop at the next step with notes: a held C1 cut by the scale
                                                       * played over it, Sam on the FM-1). Inside the loop */
                uint8_t nn = ft_ev[i].note;
                if (steps > 1u)
                    span_set(t, idx, &nn, 1u, steps < len - idx ? steps : len - idx);
                continue;
            }
            for (k = 1; k < steps && k < len; k++) {
                step_t *s = &t->data->pattern[t->active].steps[(idx + k) % len];
                if (s->time == ST_NOTE && s->n)
                    break;
                sloop_zero(s, 0, sizeof *s);
                s->time = ST_TIE;
            }
        }
    t->seq_active = 1;
    seqProjectBpm = (int16_t)bpm;
    ft_bars = (uint8_t)bars;
#if FELUCCA_ARRANGER
    arrangement_enabled = 0;
#endif
    sloop_seq_start_all();                                      /* this is the downbeat: the loop plays */
}

static uint32_t step_fill(const track_t *t, uint32_t idx)
{
    idx %= NSTEP;
    return (uint32_t)(t->data->pattern[t->active].fill[idx / 4u] >> (2u * (idx % 4u))) & 3u;
}
static void step_fill_set(track_t *t, uint32_t idx, uint32_t value)
{
    uint32_t sh;
    idx %= NSTEP;
    sh = 2u * (idx % 4u);
    t->data->pattern[t->active].fill[idx / 4u] = (uint8_t)((t->data->pattern[t->active].fill[idx / 4u] & ~(3u << sh)) | (value & 3u) << sh);
}

static int step_plays(const track_t *t,uint32_t idx){uint32_t condition=step_fill(t,idx);int now=t->fillHeld||t->fillBar;return condition==1?now:condition==2?!now:1;}

#define LV_NORM 0
#define LV_GHOST 1
#define LV_SOFT 2
#define LV_HARD 3
static const uint8_t F_LVL[4]={LV_GHOST,LV_SOFT,LV_NORM,LV_HARD};
UI_SMALL static int step_on(const step_t *st) { return st->time == ST_NOTE && st->n; }
/* LEN (SLOOP 2.6, after Felucca 1.5 by Leo Kuroshita, Discussions #178, #173): a NOTE step's length is the step and
 * the TIE steps after it (inside LEN, no wrap); SEQ > STEP's KNOB 3 on a note sets it (ui_input.c step_edit). Longer:
 * the steps after it become clean TIEs (a REST or an empty step; it stops at the next step holding notes, which stays,
 * and at LEN); shorter: its last TIEs become RESTs (one holding notes keeps them). The steps' locks and nudges stay;
 * the turns on one step are one undo (ui_input.c). Returns the length it got */
UI_SMALL static uint32_t note_len(const track_t *t, uint32_t i)
{
    uint32_t len = (uint32_t)clamp(trk_len(t), 1, NSTEP), n = 1;
    while (i + n < len && t->data->pattern[t->active].steps[i + n].time == ST_TIE)
        n++;
    return n;
}
UI_SMALL static uint32_t note_set_len(track_t *t, uint32_t i, uint32_t want)
{
    uint32_t len = (uint32_t)clamp(trk_len(t), 1, NSTEP), n = note_len(t, i);
    for (; n > want && n > 1u; n--) {
        if (!t->data->pattern[t->active].steps[i + n - 1u].n)                    /* (a TIE holding notes, from TIME or an older SLOOP, */
            sloop_zero(&t->data->pattern[t->active].steps[i + n - 1u], 0, sizeof(step_t));   /* keeps them, as TIME would) */
        t->data->pattern[t->active].steps[i + n - 1u].time = ST_REST;
    }
    for (; n < want && i + n < len && !t->data->pattern[t->active].steps[i + n].n; n++) {
        sloop_zero(&t->data->pattern[t->active].steps[i + n], 0, sizeof(step_t));
        t->data->pattern[t->active].steps[i + n].time = ST_TIE;
    }
    return n;
}
/* ---- (2.8.3) LEN under later notes ----
 * POLY: a note's LEN runs on under the notes after it: it joins their steps as a note going on (SF_CONT, as a
 * recording over held notes writes it, seq.c rec_hold), 4 notes a step at most; after them, a NOTE of its notes only,
 * all going on, carries it (the others end there). A long bass under a melody, programmed. MONO / LEGATO parts play one
 * note at a time: it stops there and says so. The step format is 2.7's: a project of 2.8.3 opens in 2.7 and later.
 * The work: seq.c span_len / span_set (a free take uses them too); span_why: why it stopped short */
UI_SMALL static uint32_t note_span(const track_t *t, uint32_t i)   /* LEN: the steps step i's notes sound */
{
    uint8_t s[4];
    uint32_t ns;
    if (!step_on(&t->data->pattern[t->active].steps[i]) || !(ns = span_notes(&t->data->pattern[t->active].steps[i], s)))
        return note_len(t, i);
    return span_len(t, i, s, ns);
}
UI_SMALL static uint32_t note_span_set(track_t *t, uint32_t i, uint32_t want)
{
    uint8_t s[4];
    uint32_t ns;
    span_why = 3;
    if (!step_on(&t->data->pattern[t->active].steps[i]) || !(ns = span_notes(&t->data->pattern[t->active].steps[i], s)))
        return note_set_len(t, i, want);
    return span_set(t, i, s, ns, want);
}

UI_SMALL static void step_clear(step_t *st)
{
    sloop_zero(st, 0, sizeof *st);
    st->time = ST_REST;
}

UI_SMALL static uint32_t note_force(const step_t *st, uint32_t k)   /* 0 GHOST .. 3 HARD, 4 ACC (the step's accent) */
{
    uint32_t l = (st->lvl >> (2u * k)) & 3u;
    if (st->flags & SF_ACCENT)
        return 4u;
    return l == LV_GHOST ? 0u : l == LV_SOFT ? 1u : l == LV_HARD ? 3u : 2u;
}
UI_SMALL static void note_force_set(step_t *st, uint32_t k, uint32_t f)
{
    uint32_t sh = 2u * k;
    st->lvl = (uint8_t)((st->lvl & ~(3u << sh)) | (uint32_t)F_LVL[f > 3u ? 3u : f] << sh);
    st->flags = (uint8_t)((st->flags & ~SF_ACCENT) | (f == 4u ? SF_ACCENT : 0u));
}
static uint8_t drop2(uint32_t value, uint32_t k)            /* a 2-bit field per note: note k's taken out */
{
    return (uint8_t)((value & ((1u << (2u * k)) - 1u)) | ((value >> (2u * k + 2u)) << (2u * k)));
}
UI_SMALL static void note_del_one(step_t *st, uint32_t k)   /* note k out of a chord's step */
{
    uint32_t j, c;
    for (j = k; j + 1u < st->n; j++)
        st->note[j] = st->note[j + 1u];
    st->lvl = drop2(st->lvl, k);
    st->rat = drop2(st->rat, k);
    c = (st->flags & SF_CONT_ALL) / SF_CONT0;
    c = (c & ((1u << k) - 1u)) | ((c >> (k + 1u)) << k);
    st->flags = (uint8_t)((st->flags & ~SF_CONT_ALL) | c * SF_CONT0);
    st->n--;
}
UI_SMALL static void note_del(track_t *t, uint32_t i, uint32_t k)   /* one note of a chord; the last one: the step */
{
    step_t *st = &t->data->pattern[t->active].steps[i];
    uint32_t j, c;
    if (!step_on(st))
        return;
    if (st->n <= 1u) {
        note_span_set(t, i, 1);                         /* (its TIEs: RESTs; 2.8.3: where it went on under others, out) */
        step_clear(st);
        return;
    }
    {   /* (2.8.3) one note of a chord: the chord back to one step, then the others as long again (its going on: gone) */
        uint32_t w = note_span(t, i);
        if (w > 1u && w != note_len(t, i)) {
            note_span_set(t, i, 1);
            note_del_one(st, k);
            note_span_set(t, i, w);
            return;
        }
    }
    for (j = k; j + 1u < st->n; j++)
        st->note[j] = st->note[j + 1u];
    st->lvl = drop2(st->lvl, k);
    st->rat = drop2(st->rat, k);
    c = (st->flags & SF_CONT_ALL) / SF_CONT0;
    c = (c & ((1u << k) - 1u)) | ((c >> (k + 1u)) << k);
    st->flags = (uint8_t)((st->flags & ~SF_CONT_ALL) | c * SF_CONT0);
    st->n--;
}
UI_SMALL static int step_free(const track_t *t, uint32_t i)   /* nothing there: no note, no TIE */
{
    return !step_on(&t->data->pattern[t->active].steps[i]) && t->data->pattern[t->active].steps[i].time != ST_TIE;
}
/* a note (its step, TIEs, nudge, fill, locks) one step on or back (copy: to just after it, the original stays);
 * the steps it goes to must be free, inside the pattern. Returns where it is now, or -1 */
UI_SMALL static int32_t note_shift(track_t *t, uint32_t i, int32_t dir, int copy)
{
    uint32_t len = trk_len(t), n = note_len(t, i), j, to;int8_t originalMicro=t->data->pattern[t->active].steps[i].micro;
    if (!step_on(&t->data->pattern[t->active].steps[i]) || note_span(t, i) != n)
        return -1;                                      /* (2.8.3: one going on under later notes: LEN 1 first) */
    to = copy ? i + n : dir > 0 ? i + 1u : i - 1u;
    if ((!copy && dir < 0 && i == 0u) || to + n > len)
        return -1;
    for (j = 0; j < n; j++)
        if ((to + j < i || to + j >= i + n) && !step_free(t, to + j))
            return -1;

    if (copy) {
        for (j = 0; j < n; j++)
            t->data->pattern[t->active].steps[to + j] = t->data->pattern[t->active].steps[i + j];
    } else if (dir > 0) {
        for (j = n; j > 0; j--)
            t->data->pattern[t->active].steps[i + j] = t->data->pattern[t->active].steps[i + j - 1u];
        step_clear(&t->data->pattern[t->active].steps[i]);
    } else {
        for (j = 0; j < n; j++)
            t->data->pattern[t->active].steps[i - 1u + j] = t->data->pattern[t->active].steps[i + j];
        step_clear(&t->data->pattern[t->active].steps[i + n - 1u]);
    }
    t->data->pattern[t->active].steps[to].micro = originalMicro;
    step_fill_set(t, to, step_fill(t, i));
    for (j = 0; j < NLOCK; j++)
        if (t->data->pattern[t->active].locks[j].step == i) {
            if (!copy)
                t->data->pattern[t->active].locks[j].step = (uint8_t)to;
            else {
                int k = lock_find(t, to, t->data->pattern[t->active].locks[j].param, 1);
                if (k >= 0) {
                    t->data->pattern[t->active].locks[k].step = (uint8_t)to;
                    t->data->pattern[t->active].locks[k].param = t->data->pattern[t->active].locks[j].param;
                    t->data->pattern[t->active].locks[k].val = t->data->pattern[t->active].locks[j].val;
                }
            }
        }
    if (!copy) {
        t->data->pattern[t->active].steps[i].micro = 0;
        step_fill_set(t, i, 0);
    }

    return (int32_t)to;
}
