// Public v16 patch offsets, checked against offsetof(pf_patch, ...) in the C header.
// Golden-audio tests explicitly restore their historical performance mix, so a
// startup preference change cannot hide a synthesis/effect regression.
import{modeDelta}from'./test-panel-order.mjs';
const bases=[20,76,132,11688],mutes=[694,696,698,11914],solos=[700,702,704,11916],arps=[706,722,738,11918],latched=[676,680,684,11908],lfos=[756,820,884,11934];
export function startupExpected(bytes){const out=bytes.slice(),d=new DataView(out.buffer,out.byteOffset,out.byteLength),put=(at,v)=>{if(at+2<=out.length)d.setInt16(at,v,true);};put(10,7);put(16,0);put(18,0);for(let m=0;m<4;m++){for(const p of[7,23,24,27])put(bases[m]+p*2,p===7?72:0);put(mutes[m],0);put(solos[m],0);put(arps[m],0);put(latched[m],0);put(latched[m]+2,0);}for(const at of lfos)for(let slot=0;slot<4;slot++){put(at+slot*16+2,0);put(at+slot*16+6,0);}for(const[at,v]of[[15547,2],[15552,90],[15553,0],[15554,0],[15555,0],[15556,(out[15556]&112)|1]])if(at<out.length)out[at]=v;put(11694,0);put(11718,0);const native=[1, 64, 110, 0, 1, 64, 100, 24, 0, 0, 64, 70, 80, 20, 80, 64, 5, 0, 40, 60, 20, 70, 40, 60, 10, 70, 100, 60, 0, 70, 0, 1, 0, 0, 0, 0, 2, 2, 0, 4, 30, 0, 30, 60, 2, 127, 0, 0, 3, 1, 64, 0, 0, 0, 0, 0];if(new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength).getUint32(4,true)<17){for(let i=0;i<56;i++)if(948+i<out.length)out[948+i]=native[i];}else for(const i of[32,33,34,35,46])if(948+i<out.length)out[948+i]=0;if(out.length>=15600)out.fill(0,15584,15600);if(d.getUint32(4,true)<20){let old=out.length>=1016&&d.getUint16(1014,true)&32768?(d.getUint16(1014,true)>>8)&127:0;let mode=d.getInt16(8,true);for(const at of[11664,11672,11680,15536])put(at,0);put([11664,11672,11680,15536][mode]??11664,Math.min(old,100));if(out.length>=1016)d.setUint16(1014,d.getUint16(1014,true)&255,true);}if(d.getUint32(4,true)<21){for(const at of[4548,8084,11620,15532])if(at<out.length)out[at]=1;}if(d.getUint32(4,true)<22){
 for(const at of [11664,11672,11680,15536]){if(at+4<=out.length){put(at+2,d.getInt16(at,true));put(at,0);}}
 if(out.length>=1016){const flags=d.getUint16(1014,true);d.setUint16(1014,(flags&~0x7000)|((flags&4)?0x0005:0x3001),true);}
 }return out;}
export function referencePerformance(bytes){const d=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),get=at=>d.getInt16(at,true);return{levels:bases.map(at=>get(at+14)),delay:bases.map(at=>get(at+48)),reverb:bases.map(at=>get(at+54)),latch:bases.map(at=>get(at+46)),mute:mutes.map(get),solo:solos.map(get),arp:arps.map(get),lfo:lfos.map(at=>[0,1,2,3].map(slot=>({depth:get(at+slot*16+2),dest:get(at+slot*16+6)}))),glide:get(11694),tortRoutes:[22,27,28,29,30,31].map(i=>bytes[948+i]),page:get(10),leadMini:Array.from(bytes.slice(15544,15576))};}
const historic={levels:[72,74,76,72],delay:[20,28,15,20],reverb:[35,40,50,35],latch:[0,0,0,0],mute:[0,0,0,0],solo:[0,0,0,0],arp:[0,0,0,0],page:7,leadMini:[3,3,3,2,2,0,64,64,90,70,0,0,111,0,64]};
export function restoreReferencePerformance(e,p=historic){const selected=e.web_mode(),turn=(r,n)=>{e.web_enc(r,n);e.web_buttons(0);},tap=b=>{e.web_buttons(1<<b);e.web_buttons(0);},combo=b=>{e.web_buttons(1<<5);e.web_buttons((1<<5)|(1<<b));e.web_buttons(0);};
 // Apply before the first audio sample: no clock/phase/RNG advancement.
 for(let m=0;m<4;m++){e.web_open_page(0);turn(2,modeDelta(e,m));if(e.web_param(23)!==p.latch[m])tap(1);if(e.web_layer_mute(m)!==p.mute[m])combo(8);if(e.web_layer_solo(m)!==p.solo[m])combo(9);e.web_open_page(8);turn(3,p.arp[m]-e.web_arp_setting(m,0));e.web_open_page(6);turn(e.web_fx_row?4:3,p.delay[m]-e.web_param(24));turn(e.web_fx_row?3:6,p.reverb[m]-e.web_param(27));}
 if(p.lfo)for(let m=0;m<4;m++){e.web_open_page(0);turn(2,modeDelta(e,m));for(let slot=0;slot<4;slot++){e.web_open_page(10+slot*2);turn(4,p.lfo[m][slot].depth-e.web_lfo_setting(m,slot,1));turn(5,p.lfo[m][slot].dest-e.web_lfo_setting(m,slot,3));}}
 if(p.leadMini)restoreLeadSources(e,p.leadMini);
 if(p.glide!==undefined){e.web_open_page(0);turn(2,modeDelta(e,3));turn(6,p.glide-e.web_param(3));}
 if(p.tortRoutes){e.web_open_page(0);turn(2,modeDelta(e,1));for(const[j,[page,knob,index]]of[[28,3,22],[28,5,27],[28,6,28],[29,3,29],[29,4,30],[29,5,31]].entries()){e.web_open_page(page);turn(knob,p.tortRoutes[j]-e.web_tort_param(index));}}
 e.web_open_page(7);for(const[k,m]of[0,2,1,3].entries())turn(3+k,p.levels[m]-e.web_layer_level(m));e.web_open_page(0);turn(2,modeDelta(e,selected));e.web_open_page(p.page);
}
// Explicitly restore preceding source levels for immutable historical audio comparisons.
export function restoreLeadSources(e,mini=[3,3,3,2,2,0,64,64,90,70,0,0,111,0,64]){const m=e.web_mode(),page=e.web_page(),turn=(r,n)=>{e.web_enc(r,n);e.web_buttons(0);};e.web_open_page(0);turn(2,modeDelta(e,3));for(let row=0;row<3;row++){e.web_open_page(42+row);turn(3,mini[3+row]-e.web_lead_param(3+row));if(!mini[8+row]&&(mini[12]&(1<<row)))turn(5,1-e.web_lead_param(8+row));turn(5,mini[8+row]-e.web_lead_param(8+row));}e.web_open_page(46);if(!mini[11]&&(mini[12]&8))turn(3,1-e.web_lead_param(11));turn(3,mini[11]-e.web_lead_param(11));e.web_open_page(0);turn(2,modeDelta(e,m));e.web_open_page(page);}


// Replay the pre-tuning-change factory timbres for immutable PCM checkpoints.
export function restoreHistoricalPitchDefaults(e){
 const mode=e.web_mode(),page=e.web_page();
 const turn=(r,d)=>{if(d){e.web_enc(r,d);e.web_buttons(0);}};
 const select=m=>{e.web_open_page(7);turn(2,modeDelta(e,m));};
 select(0);e.web_open_page(3);turn(3,45-e.web_param(0));
 select(2);e.web_open_page(0);turn(6,40-e.web_param(2));turn(5,15-e.web_param(13));
 e.web_open_page(58);turn(5,18-e.web_param(3));
 if(e.web_tort_param){
  select(1);e.web_open_page(19);turn(6,70-e.web_tort_param(11));
  e.web_open_page(21);turn(5,30-e.web_tort_param(42));
 }
 select(mode);e.web_open_page(page);
}
