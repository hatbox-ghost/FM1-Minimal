// SPDX-License-Identifier: GPL-3.0-only
// Display-only Worker, read-only state mirror. Transfer buffers are recycled, not allocated per frame.
let ex,latest,busy=false;const pixels=[];
const returnSnapshot=bytes=>postMessage({type:'visual-buffer',buffer:bytes.buffer},[bytes.buffer]);
onmessage=async({data:m})=>{
 try{
  if(m.type==='load'){
   const {instance}=await WebAssembly.instantiate(m.wasm,{wasi_snapshot_preview1:new Proxy({},{get:()=>()=>0}),env:new Proxy({},{get:()=>()=>0})});
   ex=instance.exports;ex._initialize?.();ex.web_boot();pixels.push(new ArrayBuffer(240*240*2),new ArrayBuffer(240*240*2));postMessage({type:'display-ready'});return;
  }
  if(m.type==='pixel-buffer'){if(m.buffer?.byteLength===240*240*2&&pixels.length<2)pixels.push(m.buffer);return;}
  if(m.type!=='draw')return;
  // Audio can start before this instance finishes compiling. Never strand its
  // finite snapshot pool during startup: return early frames for reuse.
  if(!ex){returnSnapshot(m.visual);return;}
  if(latest)returnSnapshot(latest);latest=m.visual;if(busy)return;busy=true;
  setTimeout(()=>{const bytes=latest;latest=null;try{
    if(bytes.byteLength!==ex.web_visual_size())throw Error('Display snapshot version mismatch');
    const buffer=pixels.pop();if(!buffer){returnSnapshot(bytes);return;}
    new Uint8Array(ex.memory.buffer,ex.web_visual_buffer(),bytes.byteLength).set(bytes);const serial=ex.web_visual_draw(bytes.byteLength);
    const fb=new Uint16Array(buffer);fb.set(new Uint16Array(ex.memory.buffer,ex.web_fb(),240*240));postMessage({type:'display-frame',serial,fb,snapshotBuffer:bytes.buffer},[buffer,bytes.buffer]);
   }catch(error){returnSnapshot(bytes);postMessage({type:'display-error',message:String(error)});}finally{busy=false;}},0);
 }catch(error){postMessage({type:'display-error',message:String(error)});}
};
