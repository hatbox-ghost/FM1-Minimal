// SPDX-License-Identifier: GPL-3.0-only
// Pacific audio/input instance. Display rasterization runs only in display-worker.js.
const RD_HELLO = [0x7d, 0x53, 0x52, 1, 1], RD_BYE = [0x7d, 0x53, 0x52, 2], RD_WHERE = [0x7d, 0x53, 0x52, 3];

const clock = globalThis.performance ? () => globalThis.performance.now() : () => Date.now();

class Amb extends AudioWorkletProcessor {
  constructor() {
    super();
    this.ex = null;
    this.input = null;
    this.sentBlits = -1;
    this.sentWrites = -1;
    this.lastFrame = 0;
    this.busy = 0;
    this.frames = 0;
    this.reader = false;
    this.lastHello = 0;
    this.visualBuffers = [];
    this.port.onmessage = (e) => this.onMessage(e.data);
  }

  async onMessage(m) {
    if (m.type === "load") {
      const now = () => BigInt(Math.round(currentTime * 1e9));
      const wasi = {
        clock_time_get: (id, prec, out) => {
          new DataView(this.mem.buffer).setBigUint64(out, now(), true);
          return 0;
        },
        fd_write: (fd, iov, n, out) => { new DataView(this.mem.buffer).setUint32(out, 0, true); return 0; },
        proc_exit: () => {},
      };
      const stub = new Proxy(wasi, { get: (t, k) => (k in t ? t[k] : () => 0) });
      const env = new Proxy({}, { get: () => () => 0 });
      const { instance } = await WebAssembly.instantiate(m.wasm, { wasi_snapshot_preview1: stub, env });
      this.ex = instance.exports;
      this.mem = this.ex.memory;
      if (this.ex._initialize) this.ex._initialize();
      const max = this.ex.web_store_max();
      for (const [obj, bytes] of Object.entries(m.store || {})) {
        const b = new Uint8Array(bytes).subarray(0, max);
        new Uint8Array(this.mem.buffer, this.ex.web_store(+obj), b.length).set(b);
        this.ex.web_store_set_len(+obj, b.length);
      }
      this.sentWrites = this.ex.web_store_writes();
      this.ex.web_master(m.master ?? 2800);
      this.ex.web_audio_boot();
      this.visualBuffers = Array.from({length:3},()=>new ArrayBuffer(this.ex.web_visual_size()));
      this.port.postMessage({ type: "ready" });
    } else if (!this.ex) {
      return;
    } else if (m.type === "save-project") {
      this.projectSave = m.id;
    } else if (m.type === "load-project") {
      const bytes = new Uint8Array(m.bytes);
      const valid = bytes.length >= 8 && bytes.length <= this.ex.web_store_max() &&
        new DataView(bytes.buffer).getUint32(0, true) === 0x50464332;
      if (valid) {
        this.ex.web_buttons(0);
        this.ex.web_keys(0);
        new Uint8Array(this.mem.buffer, this.ex.web_store(0), bytes.length).set(bytes);
        this.ex.web_store_set_len(0, bytes.length);
        this.ex.web_audio_boot();
      }
      this.port.postMessage({type: "project-loaded", id: m.id, ok: valid});
    } else if (m.type === "visual-buffer") {
      if(m.buffer?.byteLength===this.ex.web_visual_size()&&this.visualBuffers.length<3)this.visualBuffers.push(m.buffer);
    } else if (m.type === "delay-sync") {
      this.ex.web_delay_sync(!!m.on);
    } else if (m.type === "midi") {
      this.ex.web_midi(m.packet >>> 0);
    } else if (m.type === "buttons") {
      this.ex.web_buttons(m.mask >>> 0);
    } else if (m.type === "page") {
      this.ex.web_open_page(m.page|0);
    } else if (m.type === "keys") {
      this.ex.web_keys(m.mask >>> 0);
    } else if (m.type === "enc") {
      this.ex.web_enc(m.role, m.n | 0);
    } else if (m.type === "master") {
      this.ex.web_master(m.value | 0);
    } else if (m.type === "reader") {               // the screen reader on (HELLO now, then every 2 s) or off (BYE)
      this.reader = !!m.on;
      this.sysex(this.reader ? RD_HELLO : RD_BYE);
      this.lastHello = currentTime;
    } else if (m.type === "where") {                // say the whole screen
      if (this.reader) this.sysex(RD_WHERE);
    }
  }

  sysex(bytes) {                                    // a frame to the firmware: the bytes between F0 and F7
    const ex = this.ex;
    new Uint8Array(this.mem.buffer, ex.web_sysex_buf(), bytes.length).set(bytes);
    ex.web_sysex(bytes.length);
  }

  publish() {
    const ex = this.ex;
    const stringAt=p=>{const b=new Uint8Array(this.mem.buffer);let s="";while(b[p])s+=String.fromCharCode(b[p++]);return s;};
    const msg = { state:{fxRow:ex.web_fx_row(),arpSync:ex.web_arp_sync(ex.web_mode()),seqSync:ex.web_seq_sync(ex.web_mode()),lfoSetupRow:ex.web_lfo_setup_row(),delaySync:ex.web_delay_sync_enabled(),cloudsMode:ex.web_fx_setting(9),transpose:ex.web_transpose(),metronome:ex.web_metronome(),position:ex.web_page_position(),pageCount:ex.web_page_count(),transport:ex.web_transport(),seqRecording:ex.web_seq_state(ex.web_mode(),8),seqArmed:ex.web_seq_state(ex.web_mode(),9),seqCount:ex.web_seq_state(ex.web_mode(),15),muted:[0,1,2,3].map(i=>ex.web_layer_mute(i)),solo:[0,1,2,3].map(i=>ex.web_layer_solo(i)),levels:[0,1,2,3].map(i=>ex.web_layer_level(i)),layers:[0,1,2,3].map(i=>ex.web_layer_running(i)),mode:ex.web_mode(),page:ex.web_page(),selected:ex.web_selected(),running:ex.web_running(),latch:ex.web_param(23),values:[0,1,2,3].map(i=>stringAt(ex.web_label(ex.web_page()*4+i))+": "+stringAt(ex.web_value(i)))}, type: "frame", buttons: ex.web_lit_buttons() >>> 0, keys: ex.web_lit_keys() >>> 0 };
    if (this.frames >= 44100) {                       // the share of real time spent running the device
      msg.load = Math.round(100 * this.busy / (this.frames / 44.1));
      this.busy = this.frames = 0;
    }
    const transfer = [];
    // Small read-only state snapshot; no LCD pixels, geometry or redraw on this thread.
    const buffer=this.visualBuffers.pop();
    if(buffer){msg.visual=new Uint8Array(buffer);msg.visual.set(new Uint8Array(this.mem.buffer,ex.web_visual_snapshot(),ex.web_visual_size()));transfer.push(buffer);}
    const said = ex.web_said_len();
    if (said) {
      msg.said = new Uint8Array(this.mem.buffer, ex.web_said_buf(), said).slice();
      ex.web_said_clear();
    }
    const writes = ex.web_store_writes();
    if (writes !== this.sentWrites) {
      this.sentWrites = writes;
      msg.store = {};
      for (let o = 0; o < ex.web_nobj(); o++) {
        const n = ex.web_store_len(o);
        if (n >= 0) msg.store[o] = new Uint8Array(this.mem.buffer, ex.web_store(o), n).slice();
      }
    }
    this.port.postMessage(msg, transfer);
  }

  process(inputs, outputs) {
    if (!this.ex) return true;
    const out = outputs[0];
    const n = out[0].length;
    const t0 = clock();
    this.ex.web_audio_render(n);
    if (this.projectSave !== undefined) {
      const id = this.projectSave;
      this.projectSave = undefined;
      if (this.ex.web_save_project() === 0) {
        this.sentWrites = this.ex.web_store_writes();
        const bytes = new Uint8Array(this.mem.buffer, this.ex.web_store(0), this.ex.web_store_len(0)).slice();
        this.port.postMessage({type: "project-saved", id, bytes}, [bytes.buffer]);
      } else this.port.postMessage({type: "project-saved", id});
    }
    this.busy += clock() - t0;
    this.frames += n;
    out[0].set(new Float32Array(this.mem.buffer, this.ex.web_out_l(), n));
    if (out[1]) out[1].set(new Float32Array(this.mem.buffer, this.ex.web_out_r(), n));
    if (this.reader && currentTime - this.lastHello >= 2) {
      this.lastHello = currentTime;
      this.sysex(RD_HELLO);
    }
    if (currentTime - this.lastFrame >= 1 / 20) {
      this.lastFrame = currentTime;
      this.publish();
    }
    return true;
  }
}

registerProcessor("amb", Amb);
