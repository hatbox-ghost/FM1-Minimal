#!/bin/sh
# SPDX-License-Identifier: GPL-3.0-only
# The Pacific gate rejects every failure or timeout; no expected-red exemption list.
set -eu
exec python3 "$(dirname "$0")/../pacific/check-fx.py" "$@"
