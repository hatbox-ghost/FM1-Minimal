# Pacific Field licensing

The complete workstation is GPL-3.0-only. The full license is in [../LICENSE](../LICENSE). Source and license inventory: [../NOTICE.md](../NOTICE.md).

The inherited NACHTFAHRT/AMB-1 material retains its original notices. Its detailed attribution is preserved in [LEGACY-LICENSING.md](LEGACY-LICENSING.md); that document describes legacy components, not the current Pacific Field DSP build.
