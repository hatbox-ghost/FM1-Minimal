# Pacific Field — FM-1

Four playable instruments: **BRANCH, TEMPLE, TORT (OberVave), and FMini LEAD**, with shared original Clouds and Oliverb effects. TEMPLE retains at least six-note polyphony. The existing navigation, graphics, mappings and sound engines are preserved in this audit pass. Current project format: v21, 15,664 bytes.

[HOLD / SHIFT button map](docs/hold-shift/REPORT.md) · [Audit remediation report](docs/audit-remediation/REPORT.md) · [Build and validation](fm1/BUILDING.md) · [Licenses and upstream inventory](NOTICE.md)

## Build and check

Use Python 3.12+, Emscripten **6.0.13**, Node **24.19.0** and a host C compiler. No browser automation package is required. With the compiler tools on PATH:

```sh
EMCC=emcc NODE=node python3 fm1/pacific/check-fx.py --profile full
```

The gate compiles the emulator, tests 50 independent JavaScript suites and the actual C storage backend (51 independent suites total), and reports explicit per-suite timeouts. Full mode renders 1,800 seconds of LFO audio and 600 seconds of sequencer stress audio. `--profile ci` explicitly reduces each to 120 seconds. Aliases and imported helper modules are listed but not counted again. Generated results are in `fm1/build/validation/`.

```sh
python3 tools/stage-browser.py build/browser
python3 -m http.server --directory build/browser 8784
```

Open the served page and switch on the instrument. Hosting deployments are separate from this repository audit; a public URL is not evidence that the latest source is deployed.

## Reproducible source and audio references

```sh
python3 tools/make-source-archive.py build/pacific-field-source.tar.gz
EMCC=emcc NODE=node python3 tools/rebuild-reference.py historical-ui
EMCC=emcc NODE=node python3 tools/rebuild-reference.py current-ui
```

Exports include pinned reference WASM files **and their complete corresponding source**, checksums and all test inputs. They can be unpacked and tested without Git history or external reference folders. The source exporter requires a clean checkout by default; `--working-tree` explicitly includes reviewed local edits. See `references/README.md` for the two different sound epochs and the unchanged historical fixture.

The target is JieLi AC79 **PI32v2**, not ARM. Native build/link evidence and limitations are recorded separately from emulator results. No physical FM-1 CPU, dropout, latency or stack high-water validation is claimed.

Historical design reports under `docs/` describe their own checkpoints. They are retained for provenance, not presented as the current controls or current memory measurements. Audio examples and images are retained as historical design evidence; empty logs and the obsolete generated distribution have been removed.
