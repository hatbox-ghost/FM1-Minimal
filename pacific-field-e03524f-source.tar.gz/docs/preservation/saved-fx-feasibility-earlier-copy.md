# Pacific Field FX feasibility — Phase 0 only

Audit checkpoint: 2026-10-31 (America/Los_Angeles). **No effects port, firmware installation, graphics removal, patch-format change or website deployment was performed.** Standalone upstream compilation and a reference smoke test are audit probes, not workstation integration.

## Decision

| Candidate | Source reuse | Current FM-1 integration decision |
|---|---|---|
| Actual Parasites Oliverb | GO: original C++ DSP and MIT dependencies are available; standalone reference compiled and processed an impulse | **CONDITIONAL GO** after shared-bus/buffer design, target C++ build and physical timing. Not an add-on to the current allocation. |
| Actual original Clouds | GO: granular/looping DSP, support code and MIT resources are available; all 10 selected implementation units compile in the portable build | **CONDITIONAL GO** after reclaiming the existing per-layer FX buffers, rate conversion, bounded block scheduling, target linking and physical timing. Prefer the actual granular/looping subset over three module firmwares. |
| Whole original Beads Processor, stock buffers | GO for source inspection, not for this memory map | **NO-GO unchanged**: 851,968 bytes of recording/reverb buffers plus 24,588 bytes of processor state already exceed the entire nominal 512 KiB address window, before the workstation. |
| Selected original Beads DSP, smaller memory geometry | Relevant original code is available and 8 selected implementation units compile | **CONDITIONAL GO for a later separate experiment**, not approved for integration. Lowering max_delay alone does NOT shrink its fixed three-bank allocation. |

**Porting gate remains closed.** Available hooks and the configured memory map are established from source. Actual native .bss/.pool/stack/image usage and worst-case device CPU headroom are not verified: the correct SDK/toolchain is absent and no physical FM-1 was profiled. Do not replace this missing evidence with desktop/WASM speed. Stop here for review, as requested.

## 1. Workstation baseline and repository hygiene

- Exact current published source: branch `main`, commit `2a91dfa8bb97f54c7e02b8be335abef81827f3b5`, clean before this audit, at `/private/tmp/pacific-edit-pages`.
- Saved user project: `/Users/collindavis/Documents/Pacific Field/pacific-field`. Its primary `fm1/pacific/engine.c`, `app.c` and `dist/amb.wasm` match that checkpoint byte-for-byte.
- The saved folder's Git metadata is older (`9ce219ec233d5680979aaa7b6e150767ee433168`, branch main) with 495 changed/untracked entries, including pre-existing numbered duplicate files. These were not cleaned, staged, overwritten wholesale or treated as a clean firmware baseline. Use the verified current source checkout for future experiments; reconcile the saved folder's Git history separately.
- Current instruments are Branch, TORT (Melodee Prophet adaptation) and Clock. Shared tuning, per-layer latch, four LFOs per instrument, per-layer arps/Slip, note mix and layer mixer exist. The SEQ button is currently note mix/solo, not a completed block sequencer. No future sequencer CPU budget has been demonstrated.
- Current native build is the source-owned Nachtfahrt/Felucca-derived adapter selected by `PACIFIC_FIELD=1`, not the manufacturer's binary-engine workstation. Do not exchange these architectures accidentally.

### Separate upstream references

All upstream repositories are outside the workstation source directory, under `/Users/collindavis/Documents/Pacific Field/References/`:

| Directory | Origin | Pinned checkout |
|---|---|---|
| eurorack | https://github.com/pichenettes/eurorack | f4cfa7697095a28d292bff758beb51deb49b5a86 |
| eurorack/stmlib | https://github.com/pichenettes/stmlib | e3bd7c9cc00e4364166f9905c0509b6ffd0535ec |
| parasites | https://github.com/mqtthiqs/parasites | 32fa66f5acce1bff2f0a7bdd041e29bad3222557 |
| parasites/stmlib | https://github.com/mqtthiqs/stmlib | 8ab2aaee77cbacb47b646d46d22ee5d358effe2d |
| fm1_open | https://github.com/m-vave/fm1_open | 4c7496daac04a95ff10d1afdcc8f9ead2dbabc41 |

Only the DSP-required stmlib submodules were initialized at their pinned revisions. No module bootloader, MCU peripheral driver, hardware design or firmware image was copied into Pacific Field. Beads is genuinely present in the current original repository; old statements that its source is unavailable no longer apply. The upstream README itself says the Beads release builds on a desktop but was not verified to build/run on a module.

## 2. Actual audio path and editable insertion points

### Current Pacific Field path

1. `fm1/firmware/src/app/main_fm1.c`: `fm1_alnk0_irq()` identifies the free DMA half and calls `render_block()`.
2. `render_block()` calls `en_render(..., REND_FRAMES, master_q12)` and then `uac_tap()` when USB capture is enabled.
3. `fm1/pacific/hardware.h`: `en_render()` calls `pf_render()` in chunks of at most 256 stereo float frames, then converts to signed Q23 integer samples (`*8388607`). It applies the existing gain convention.
4. `fm1/pacific/engine.c`: `pf_render()` iterates three Contexts. `single_render()` produces per-layer stereo PCM, currently including that layer's echo and small room. `pf_render()` applies smoothed mute/solo, post-effect layer pan and the .65 mix scale, sums layers, and limits the master to ±.95.
5. The filled I2S half goes through the source-owned HAL in `fm1/firmware/hal/fm1_audio.h` to the codec. Existing master recording taps follow the same output.

**The required raw layer bus is available in source, but a shared send bus does not exist yet.** Existing `par[24]` (echo send) and `par[27]` (room amount) are editable per layer; each layer owns its own buffers. `single_render()` already has a dry per-layer `L/R` sum immediately before its delay/room section. That is the candidate source of a future dry output plus separate send accumulators. Merely inserting an effect after `pf_render()` would provide master processing, not independent sends.

Recommended future topology: instrument dry stereo -> layer gain/pan/mute/solo semantics -> dry master plus independent reverb and delay/granular sends -> one instance of each wet engine -> returns -> final protection/master/Q23 conversion/USB tap. Decide and test pre/post-fader and mute-tail behavior explicitly; preserve the current post-effects fader behavior or document any intentionally authorized change. Never route the entire mix into the new effects and call it per-instrument sends.

`fm1/firmware/src/main.c` selects `pacific/hardware.h` and `hardware-ui.h`; `firmware/src/dsp/amb.c` includes `pacific/engine.c` under the flag. The current DSP is editable C; no proprietary synth/effects library is linked by this build. `pf_post()` is the existing bounded parameter command queue; use it or an equivalent audited snapshot handoff for controls, not locks or allocations in the ISR.

### Manufacturer FM1 Open is different

At the pinned reference, `sdk/include/fm1_block.h` fixes 44,100 Hz and **128 frames**, not this project's 256. `app/board/audio.c::fm1_audio_irq()` calls proprietary `fm1_engine_render()` then source-owned `fm1_output_mix()` before DMA commit. The latter handles external USB/Bluetooth audio, master gain and USB recording. Post-master processing is feasible there, but the exposed render API returns only the combined instrument output. Public send-control functions are not evidence of accessible raw per-track PCM buses. No public raw per-track audio export/effects replacement hook was found in that API.

If the project were ever moved to that SDK, master-only external processing is the verified fallback; independent new sends would need a vendor extension or a source-owned renderer. Do not silently replace Pacific Field or reverse-engineer a proprietary library to solve this. The SDK has separate FM1-only binary permission, GPLv3-with-linking-exception APP sources and component-specific licenses (`THIRD_PARTY.md`). Those terms are distinct from the current GPL-3.0-only project.

## 3. FM-1 timing, RAM, flash and build constraints

### Source-established configuration

- Current native audio: **44,100 Hz, 256 stereo frames per DMA half/call**, about **5,805 microseconds** per half. `HALF_FRAMES`, `REND_FRAMES`, `FS` in `app/main_fm1.c` establish this. `pf_render()` internally limits chunks to 256. Browser AudioWorklet uses its host quantum, commonly 128; that is not the hardware block size.
- `en_dbg.last_us`, `max_us`, `halves`, `late`, `audio_cpu_pct`, `audio_cpu_peak`, `audio_xruns` provide existing device profiling points. `en_load` is updated, but the Pacific kernel does not implement the old engine's claimed load shedding merely because a platform comment mentions it.
- TIMER4 runs from a **24 MHz reference**, used for wall-time profiling. This is **not a verified CPU clock frequency**. Current core MHz, second-core availability and spare processing power have not been established by this audit. The current adapter renders serially on the audio ISR; no second audio worker is provided.
- Native target: JieLi PI32v2 `r3`, single-precision FPU (`-mcpu=r3 -mfprev1 -ffp-contract=off`). Do not use Cortex ARM assembly or assume desktop `double` math is cheap.
- `fm1/firmware/app.ld`: .data/.bss RAM **98,304 B**; .pool **344,064 B**; RAMTEXT **24,576 B** reserved for RAM-run code; XIP region **581,564 B**. The shown address window is roughly 512 KiB, not 512 KiB of free audio RAM. Stacks, guards, boot mailbox and reserved regions are distinct.
- User/system stack address ranges are approximately 24,320 B and 7,936 B respectively, with 256-byte guards. Actual maximum stack depth during interrupts still needs measurement. Existing nested audio scratch already consumes kilobytes.
- Flash code checks for the expected 1 MiB part; flash capacity is not writable realtime delay RAM. No external SDRAM is mapped/initialized by the current project; the manufacturer's reference also sets SDRAM_SIZE=0. This does not prove no board variant can have other memory; it establishes no usable external buffer here.
- Current patch v7 is **1,004 B** inside a **3,840 B** object capacity. A later FX patch extension needs explicit migration and bounded storage; audio recording buffers must not be serialized as normal patch data.

### Audited 32-bit memory ledger

Measurements use separate WASM32 `sizeof` probes against the actual source. They are bounded layout estimates, not a target linker map. The renderer's historical `pf_pool_bytes()` includes an extra 104-byte ordinary-BSS object, so the ledger below separates actual pool-tagged data rather than repeating that conservative aggregate.

| Allocation | Bytes |
|---|---:|
| Three `Context` objects (`layers`, .pool) | 252,348 |
| TORT voice states (.pool) | 4,640 |
| Shared 240 × 144 × RGB565 drawing canvas (.pool) | 69,120 |
| Accounted current pool total | **326,108** |
| Nominal pool space left | **17,956** |
| Required spare-pool guard in build checker | 8,192 |
| Accounted add-on space after that guard | **9,764** |
| TORT block object (ordinary .bss, not .pool) | 104 |
| Existing three stereo echo banks | 196,608 |
| Existing three room buffer pairs | 29,664 |
| Existing FX buffers potentially replaced by shared engines | **226,272** |

Pool-tagged source search found the Pacific arrays and the canvas; old Nachtfahrt DSP arrays are behind the opposite preprocessor branch. Actual target alignment/link sections, remaining .bss, stack, IRQ/DMA buffers and future C++ data still require the native map. The free pool figures are not a general heap allocation promise.

**Illustration question:** removing `pf_scene()` artwork calls alone releases essentially none of that canvas: text and mixer controls still use it. The illustrations are procedural code, not separate large bitmap buffers. They cost flash and background redraw work, whose actual timing is unmeasured. UI work is outside the audio ISR, although bus/cache/DMA contention can matter on the device.

Current Pacific pages already draw 120-row bands. Reducing the inherited maximum from 144 to 120 could save **11,520 B** while retaining artwork, subject to auditing splash/crash/common draw paths. A 24-row tiled renderer would save **57,600 B** relative to 144 rows, but needs a real redraw/DMA redesign and timing checks. Neither change was made. Full Beads does not become viable unchanged even by removing the entire canvas.

### Candidate shared allocation, not a fitted firmware

Replace (do not duplicate) the 226,272 B of old FX buffers. Remaining accounted pool becomes **99,836 B**, including artwork and instruments. Full original Clouds buffers+object (192,876 B) plus standalone Oliverb buffer+object (33,056 B) would bring that estimate to **325,768 B**, leaving **18,296 B before scratch and the 8 KiB reserve** (10,104 B after reserve). This is promising but tight: shared buses, SRC rings, C++ support state, alignment and realtime scratch have not been budgeted into an actual native link. Removing unused Clouds post-reverb/spectral workspace through a traceable granular subset is preferable to duplicating a second reverb bank. No such adaptation was implemented.

## 4. Exact upstream DSP, dependencies and licenses

Full file-by-file manifests, SHA-256 hashes and license-header checks are in `docs/fx-audit/{clouds,beads,oliverb}/dependencies.json`. They are compiler-derived closures, including headers and resource sources, not repository-wide license assumptions. All selected files in these closures carry MIT permission notices: **43 Clouds files, 46 Beads files, 11 Oliverb files**. Keep each original notice, author/year and attribution if reused. STM32 code is MIT; AVR code is separately GPL and hardware designs CC BY-SA 3.0. No AVR or hardware files are needed for these algorithms. The workstation remains GPL-3.0-only as a combined derived work with MIT notices retained.

### Oliverb / Parasites

Exact entry: `parasites/clouds/dsp/fx/oliverb.h`, class `clouds::Oliverb`, `Init(uint16_t*)`, in-place `Process(FloatFrame*, size_t)`. Dependencies:

- `clouds/dsp/fx/fx_engine.h` (the Parasites version, including Hermite interpolation)
- `clouds/dsp/random_oscillator.h`
- `clouds/dsp/frame.h`, `clouds/resources.h`, `clouds/resources.cc`
- `stmlib/stmlib.h`, `stmlib/dsp/dsp.h`, `stmlib/dsp/cosine_oscillator.h`, `stmlib/utils/random.h` and `.cc`

Important resource symbols include `lut_window` and `lut_raised_cos`; include their actual original data, not a replacement envelope approximation. The Oliverb file retains Emilie Gillet's 2014 MIT notice; the random oscillator retains Matthias Puech's 2015 MIT notice. Preserve both, and credit Parasites/Matthias Puech for the fork.

Memory: `FxEngine<16384, FORMAT_16_BIT>` requires **32,768 B** of caller-owned delay memory; object **288 B**, plus caller frame buffers/stack. `FloatFrame` is two float32 values (8 B). Original audio context is 32 kHz. Running its sample-count delays and per-sample modulation at 44.1 kHz unchanged changes timing; use bounded SRC around the 32 kHz wet engine first, or document and validate an explicit retiming adaptation. Neither has been done.

Reuse the original allpass/delay/modulation/filter/soft-limit topology. Configure `pitch_shift_amount=0` and `ratio=1` for v1; do not add a shimmer/octave page. Original freeze routing is in `parasites/clouds/dsp/granular_processor.cc` (input gain zero, decay unity, damping opened); this needs smoothing, headroom and long-run testing. `Init()` assumes some state is zero from static storage, so use explicit zeroed persistent state or a documented reset fix rather than an uninitialized local C++ object.

This is one Griesinger/Dattorro-style topology, not three separately implemented room/plate/hall algorithms. Short/medium/long parameter families may be useful, but conventional room/plate behavior needs listening/decay tests. Any later early-reflection addition must be separately identified and benchmarked, not passed off as original Oliverb.

### Original Clouds

Entry: `eurorack/clouds/dsp/granular_processor.{h,cc}`; `Init(large_buffer,large_bytes,small_buffer,small_bytes)`, `Prepare()`, `Process(ShortFrame*,ShortFrame*,size_t)`. Main implementation units compiled:

`granular_processor.cc`, `correlator.cc`, `mu_law.cc`, `pvoc/frame_transformation.cc`, `pvoc/phase_vocoder.cc`, `pvoc/stft.cc`, `clouds/resources.cc`, `stmlib/dsp/atan.cc`, `stmlib/dsp/units.cc`, `stmlib/utils/random.cc`.

The actual granular subset is `granular_sample_player.h`, `grain.h`, `audio_buffer.h`, `parameters.h`, `frame.h`, `window.h`, `mu_law.{h,cc}` and the resource/stmlib closure. `looping_sample_player.h` implements the original looping-delay mode; WSOLA uses `wsola_sample_player.h` and `correlator`, and spectral mode adds the phase-vocoder/STFT/FFT closure. The current header uses stmlib ShyFFT unless ARM FFT is explicitly enabled; do not pull STM32 CMSIS peripheral libraries into this workstation merely because the original module makefile lists them.

Memory at the original module allocation: **118,784 + 65,408 = 184,192 B** buffers, plus **8,684 B** processor object. `GranularSamplePlayer` alone is **3,740 B**, but that excludes recording buffers, AudioBuffer state, tails, filtering, feedback, SRC and scheduling. Stereo 16-bit uses 65,408 B per channel for approximately 1.022 s at 32 kHz; mono 16-bit uses 118,784 B for approximately 1.856 s. Quality modes use actual µ-law/downsampling rules, not free extra RAM.

The workspace allocator allocates 2,048 floats (8,192 B) for diffusion, 16,384 uint16 (32,768 B) for its internal reverb and a correlator block aliased for pitch shifting. These are within the original buffers, not extra additions to the 184,192 figure. `BufferAllocator` returns NULL when exhausted; blindly shrinking buffers can produce invalid downstream initialization. `Prepare()` can reset/clear substantial memory: it must not become unbounded work inside the audio ISR.

`kMaxBlockSize=32` in `clouds/dsp/frame.h` is a real fixed-array constraint. Never hand it a 128- or 256-frame block directly. Bridge the host into <=32-frame native wet blocks with a bounded rate-conversion schedule. Clouds uses 16-bit interleaved ShortFrame at its outer API and float stereo internally; preserve conversion gains, freeze, feedback and limiter behavior. The original high-quality processing rate is 32 kHz (16 kHz in low fidelity).

The ordinary feedback delay and granular view should share one planned recording arena. The original looping mode is not automatically proof of the requested neutral, tempo-synced conventional delay: that behavior still needs a testable control/read-head design. Reusing the original granular DSP does not require copying the whole module firmware or all spectral modes.

### Original Beads

Entry: `eurorack/beads/dsp/processor.{h,cc}`; `Processor::Init(uint8_t* buffers[],uint16_t* reverb_buffer)`, `Configure()`, and `Process(...)` with seed/freeze/parameter buffers. Selected implementation units compiled:

`processor.cc`, `delay_clock.cc`, `delay_controller.cc`, `trigger_generator.cc`, `mu_law.cc`, `beads/resources.cc`, `stmlib/dsp/units.cc`, `stmlib/utils/random.cc`.

Actual reuse candidates (not substitutes): `grain.h`, `delay_grain.h`, `grain_envelope.h`, `granular_player.h`, `delay_granular_player.h` (32 grains), `delay_line.h`, `multitap_delay.h`, `delay_controller.{h,cc}`, `delay_clock.{h,cc}`, `trigger_generator.{h,cc}`, modulation/randomized-parameter and limiter code. `sample_rate_conversion_filters.h` and stmlib SRC are needed for its quality modes. `synth.cc`, wavetable voices/players and wavetables are outside the requested delay/granular scope; do not import them gratuitously.

Original `beads/beads.cc` allocates **512 KiB + 256 KiB** recording RAM and **64 KiB** reverb RAM: **851,968 B** total. `Processor` adds **24,588 B** on WASM32, before other firmware state/stack. Its logical delay capacity is 768,000 bytes, distinct from the 786,432 physical bank bytes. The original STM32H7 linker script maps internal SRAM D1/D2/D3 banks; this is not evidence that Beads requires an external SDRAM chip. It has much more mapped working RAM than this project can spare.

**Critical bank constraint:** `DelayLine<resolution,max_delay,num_channels,bank_size=262144,num_banks=3>` places the freeze tail at the end of bank 3, and `Reset(true)` clears all banks. `GranularProcessor` instantiates these default bank dimensions internally for both mono and stereo views. Merely reducing max_delay while supplying a short buffer is unsafe. A real adaptation must forward bounded bank-size/count template parameters through the processor or use original DelayLine/Grain classes behind a documented memory adapter. For a 32,768-frame 16-bit stereo recording, PCM alone is 131,072 B; interpolation and the 256-FloatFrame freeze tail need at least another 2,064 B, plus alignment/state. A possible 135,168 B single bank is only a design candidate, NOT a tested adapted processor. The contiguous Init overload has a conservative additional-tail capacity assertion; audit that contract rather than disabling asserts.

A small-max-delay GranularProcessor object probes at 5,460 B, but still uses the stock three-bank scheme until adapted: this sizeof does not prove a small total RAM footprint. Its templates permit sample-rate-aware operation, but the top-level Processor hardcodes 48/32/24 kHz modes. Original codec blocks are at most 24 frames. Variable-length arrays appear in Processor and GranularProcessor: use bounded small subblocks/static scratch and account for nested scratch, rather than dropping a 256-frame host quantum onto the device stack. Do not switch codec rates globally and detune all instruments to accommodate Beads.

Beads and Clouds recording layouts are different (including head direction, tails and packed formats). They cannot be made to share a live buffer simply by casting a pointer. Initially choose Clouds. Later Beads kernels may use the same allocated arena in an exclusive mode with an explicit content/reset policy, or selectively reuse original envelope/clock/grain mechanics after validation. No third parallel long recording buffer is justified yet.

### Cross-cutting C++ and dependency adaptations

- Build original DSP as isolated freestanding C++ translation units behind a small `extern "C"` interface. Current build compiles C only and links no normal C++ runtime/libm. The required target C++ support, math functions, guards/destructors and linkage must be established; use no exceptions, RTTI, heap allocation or audio-thread I/O. Keep original numerical operations and tables where possible.
- Original stmlib uses ARM `ssat`, `usat` and `vsqrt.f32`. Unmodified non-TEST compilation on the non-ARM audit target fails with invalid constraints. Portable TEST branches compile; replace/guard architecture intrinsics explicitly for PI32v2, verify numeric behavior, and audit math/double helpers. Do not blindly enable a broad TEST flag in device firmware.
- Eurorack and Parasites pin **different stmlib revisions** and both use `namespace clouds`, similarly named LUTs and identical header guards with different FxEngine implementations. Naively linking both resource bundles or unity-including both causes duplicate symbols/ODR/header-guard hazards. Namespace the isolated, traced subsets (or prove exact dependency compatibility). Do not silently swap the original Clouds FxEngine for the Parasites version.
- Keep original lookup-table data and source notices. Namespace/platform/buffer/scheduler adaptations are legitimate ports; replacing the algorithms with simplified delay/reverb approximations is not what this audit recommends.

## 5. Tests, diagnostics and reproducibility

All evidence is local under `docs/fx-audit/`; no binaries were flashed or added to the production build. References remain separate. Tool paths used:

- C/C++: `/private/tmp/pacific-emsdk/upstream/emscripten/emcc` and `em++`
- Node: `/private/tmp/pacific-emsdk/node/24.19.0_64bit/bin/node`
- Scratch probes: `/private/tmp/pacific-fx-audit`

Commands actually run (the scripts capture complete unit paths and flags):

```sh
python3 /private/tmp/pacific-fx-audit/compile-audit.py
python3 /private/tmp/pacific-fx-audit/dependencies.py
/private/tmp/pacific-emsdk/node/24.19.0_64bit/bin/node /private/tmp/pacific-fx-audit/sizes.mjs
/private/tmp/pacific-emsdk/node/24.19.0_64bit/bin/node /private/tmp/pacific-fx-audit/current-memory.mjs
/private/tmp/pacific-emsdk/node/24.19.0_64bit/bin/node /private/tmp/pacific-fx-audit/oliverb-smoke.mjs
PACIFIC_FIELD=1 python3 fm1/tools/build.py
```

Compile-audit uses `em++ -DTEST -std=c++11 -O2 -fno-exceptions -fno-rtti -ffp-contract=off -Wno-vla-cxx-extension -I<upstream> -MMD -MF <deps> -c <unit> -o <object>`. Clouds 10/10, Beads 8/8, Oliverb support 2/2 units pass. sizeof probes compiled with WASM32, C++11, TEST. Beads' initial header probe reports **7 C++ VLA-extension warnings**; these are acknowledged portability/stack issues, not silently claimed as ISO C++ compliance.

An isolated reference-only Oliverb call wrapper links unchanged upstream Oliverb/resources/random with the same portable flags and explicit normal-reverb settings. It processes 128,000 frames (4 s at assumed 32 kHz) of impulse/tail: finite output, energy 48.3573135, peak .21743545. This is a basic reference smoke test, not listening validation, a freeze/feedback stress test, CPU headroom or a workstation port. No impulse/timing result is claimed for full Clouds/Beads.

Non-TEST diagnostic: `em++ -std=c++11 -fsyntax-only -I<parasites> oliverb-call.cc` fails on stmlib ARM constraints (`I`, `=w`); see `non-arm-diagnostic.txt`. Native baseline command exits **1** before compilation: missing `cpu/wl82/tools/uboot.boot`, requiring AC79_SDK. JIELI_TOOLCHAIN/AC79_SDK were unset, default toolchain/SDK paths absent, and Docker was not found on PATH. No native ELF/map was produced; target C++ compatibility, actual CPU MHz, xrun rate and remaining .bss/stack/flash space remain unverified. No new toolchain was installed or device connected/flashed to bypass this stop.

The current-memory probe includes the actual engine in a separate translation unit; to rerun the saved relative-include version use `emcc -O2 --no-entry -sSTANDALONE_WASM -sFILESYSTEM=0 -I<workstation-root> current-memory.c -o current-memory.wasm`. Existing instrument/UI source and published assets were unchanged. Prior browser regression/stress results are useful baseline history, not new physical measurements for these effects.

## 6. Staged plan and explicit completion gates

1. **Finish prerequisites before any port.** Reconcile a clean checkpoint/worktree; provide the matching PI32v2 toolchain and SDK resources; build PACIFIC_FIELD baseline; retain full ELF/map, section/stack/image and single-precision checks. Profile existing worst-case audio on the physical device using existing counters. No flashing without separate explicit authorization. If hardware testing cannot be performed, keep the gate closed.
2. **Phase 1, separately reviewed:** source-owned raw dry/send bus interface and no-op processing experiment on a guarded branch. Exact wet-disabled/dry regression, gain/mute/solo/tail policy, migrated independent sends, bounded scratch and no allocation. Compile and measure native memory/timing before enabling a new algorithm. Consolidate/replace old FX allocations rather than running all banks in parallel. Preserve all instruments, tuning, LFOs, arp/Slip and existing note-mix/SEQ behavior.
3. **Phase 2:** actual Oliverb isolated from its module firmware, traced namespace/math/platform changes, no added shimmer mode. Wet buffer and rate adapter budget, sane short/normal/long controls, smoothing and freeze. Compare original reference impulse/decay against port; listen for useful conventional spaces. Do not label parameter presets as three independent algorithms.
4. **Phase 3:** one bounded recording arena for neutral tempo delay and actual Clouds granular kernel, selected subset/modes documented. Prove conversion/scheduler bounds and tempo mapping; compare against original granular reference. Only then evaluate a Beads-specific grain/envelope/clock contribution under the verified remaining budget; no whole-stock Beads memory allocation.
5. **Phase 4:** two FX pages (Reverb and Delay/Granular), per-layer sends, explicit freeze, persistent settings/migration. Audit the real button map; physical encoders have no assumed click gesture. Any graphics/canvas optimization is a separate measured change; removal of the artwork is not currently recommended.
6. **Phase 5 / definition of done:** full target builds with >=8 KiB pool reserve; .bss/stack/XIP checks; no new soft-double helpers or audio-thread allocation/locks/I/O; golden dry regressions; all instruments/layering/LFOs/tuning/latch/arp/Slip and save/reload regressions; impulse/sweep/feedback/freeze transitions and at least 30–60 min nonfinite/output-bound tests; measured worst-case device block times with keys/LFOs/processes/both effects/UI/USB active, no xruns, agreed scheduling reserve. A proposed 20% scheduling margin is a future acceptance target, not measured headroom. Add future sequencer stress when that sequencer exists. Keep a restorable source/firmware checkpoint and explicitly separate host tests, device listening, compilation and actual physical performance.

Changed files in Phase 0: this report and audit evidence/scripts/manifests only. The website, firmware DSP/UI/patch structures and cute graphics are unchanged. Recommended next action is baseline native toolchain/build/timing verification, then review the shared buffer budget; **do not begin integrating DSP yet**.
