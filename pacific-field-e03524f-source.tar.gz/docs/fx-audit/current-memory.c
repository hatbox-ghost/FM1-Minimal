#define EN_HOST
#include "fm1/pacific/engine.c"
#define EX __attribute__((used,visibility("default")))
EX unsigned audit_layers_bytes(){return sizeof layers;}
EX unsigned audit_tort_voice_bytes(){return sizeof tort_voices;}
EX unsigned audit_tort_block_bytes(){return sizeof tort_block;}
EX unsigned audit_context_bytes(){return sizeof(Context);}
EX unsigned audit_patch_bytes(){return sizeof(pf_patch);}
