#include "clouds/dsp/granular_processor.h"
#define EX extern "C" __attribute__((used,visibility("default")))
EX unsigned processor_size(){return sizeof(clouds::GranularProcessor);}
EX unsigned player_size(){return sizeof(clouds::GranularSamplePlayer);}
EX unsigned frame_size(){return sizeof(clouds::FloatFrame);}
