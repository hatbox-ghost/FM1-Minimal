#include "clouds/dsp/frame.h"
#include "clouds/resources.h"
#include "clouds/dsp/fx/oliverb.h"
#define EX extern "C" __attribute__((used,visibility("default")))
EX unsigned processor_size(){return sizeof(clouds::Oliverb);}
EX unsigned frame_size(){return sizeof(clouds::FloatFrame);}
