#include "beads/dsp/processor.h"
#define EX extern "C" __attribute__((used,visibility("default")))
EX unsigned processor_size(){return sizeof(beads::Processor);}
EX unsigned frame_size(){return sizeof(beads::FloatFrame);}
EX unsigned core_size(){return sizeof(beads::GranularProcessor<beads::RESOLUTION_16_BIT,32768,1>);}
