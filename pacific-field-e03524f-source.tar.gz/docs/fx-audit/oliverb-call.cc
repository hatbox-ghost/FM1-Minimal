#include "clouds/dsp/frame.h"
#include "clouds/resources.h"
#include "clouds/dsp/fx/oliverb.h"
static clouds::Oliverb effect;
static uint16_t buffer[16384];
static clouds::FloatFrame block[32];
#define EX extern "C" __attribute__((used,visibility("default")))
EX void audit_init(){effect.Init(buffer);effect.set_ratio(1);effect.set_pitch_shift_amount(0);effect.set_input_gain(.5f);effect.set_decay(.7f);effect.set_mod_rate(.2f);effect.set_mod_amount(10);}
EX clouds::FloatFrame *audit_block(){return block;}
EX void audit_process(){effect.Process(block,32);}
