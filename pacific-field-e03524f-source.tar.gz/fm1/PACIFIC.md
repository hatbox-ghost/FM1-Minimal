# Pacific Field / FM-1

A playable, GPL-3.0 derivative of https://github.com/FartyPants/fm1-nachtfahrt.
The original panel, keyboard input handling, hardware platform and bitmap screen renderer are retained. The original musical engine and control pages are replaced when PACIFIC_FIELD=1.

## Sound adaptations

- Branch: eight fixed-cost coupled spring states, wind and rain excitation, noise-mallet bursts, sine/triangle pairs, resonant state-variable filtering and an envelope-controlled low-pass. This reduces the original full branch/node simulation and Web Audio graph to a bounded DSP model. It is an adaptation, not sample-identical to Branch Resonator.
- Albion: a 27-note polyphonic bank, exact ratio tuning, note-level/pan/fine mixer, sine/triangle/saw/pulse morph, LP/notch/HP filter, drift, slow stereo wander and an arpeggiator over held/latched notes. The original large Web Audio oscillator spectra and 2600 filter are approximated by bounded harmonic synthesis and a simpler filter.
- Clock: the Pad/Glass/Bell carrier/modulator ratios and gains are taken from the supplied clock study. Three independent pairs per voice feed a blend of carrier and upper octave. Slow cycle/orbit movement, a persistent root, interval steps, optional third and optional root travel preserve the musical clock idea. Wall-clock synchronization and the full mechanical escapement simulation are not included.

## Playing

All 27 physical keys play in every mode and on every page. Default is momentary; SEL toggles latch and releases the old held notes. PLAY starts/stops all three layers. A key can also start just its selected layer. A keyboard note can start audio. REC freezes process progression while keys remain live. PRESETS selects the layer for the keyboard and editing; other layers retain their notes, effects and process state. Hold HOME and turn knobs 1, 2 and 3 to mix Branch, Albion and Clock. Zero level mutes the layer without deleting held notes. ALGORITHM changes Branch LPG, Albion wave, or Clock FM configuration. SELECT selects the note edited on SEQ. OCT buttons shift newly played notes.

HOME = four voice macros. ENV = envelopes, shape/algorithm, master instrument level. LFO = motion. ARP = process parameters; press ARP again in Albion to toggle its arpeggiator. SEQ = selected note level, keyboard octave, selected note pan, selected note fine cents. GLO = tuning, root transposition, reference anchor, latch. FX = echo send, delay time, feedback, room. EDIT strikes Branch; holding regenerates it. In Albion/Clock EDIT advances the process. SAVE persists parameters and per-note mixer; reboot never resumes sounding notes.

Tuning maps: 12 TET, the supplied Albion 5-limit map, the research-corrected E-flat WTP 7 mapping, the C-sharp Riley 5-limit reference, Pythagorean. The root parameter transposes the reference frequency in equal semitones independently of map shape. Frequency anchor belongs to C, E-flat or C-sharp as appropriate. The WTP map preserves keyboard-order inversions. Tuning, root and anchor are global. Changing them retunes notes already held on all three layers. Per-note Fine intentionally retunes that held voice. Pitch-tuning ratios and FM operator ratios are separate parameters.

## Browser build

Install official Emscripten and Pillow, activate emsdk, then run `sh pacific/build-web.sh`. Serve `build/emu/amb.wasm` alongside the distributed `index.html` and `worklet.js`. `node pacific/test-web.mjs build/emu/amb.wasm` tests the shared audio/input/UI code. The webpage uses the original Nachtfahrt emulator control layer with new tips, guide and state readout. These are web assets, not hardware code.

## Hardware status

The hardware path is wired into `firmware/src/main.c` and `firmware/src/dsp/amb.c` under PACIFIC_FIELD. Run `PACIFIC_FIELD=1 python3 tools/build.py` with Nachtfahrt's documented JieLi AC79 toolchain/SDK and existing build prerequisites (see BUILDING.md). The platform, calibration, USB, storage and update loader are retained. `pacific/hardware.h` bridges the audio and `hardware-ui.h` bridges boot/UI/storage. No new installable hardware binary has been produced or flashed. The hardware build, memory map, CPU budget, tuning accuracy and physical controls require validation on the actual device; browser CPU timing cannot establish device viability.

Voice DSP is float-only; effect tails are stored as 16-bit PCM to fit three independent contexts. It uses fixed voice storage and a lock-free single-producer command ring. Delay is capped at 360 ms; feedback at 78%. Delay/room buffers plus the original strip canvas occupy about 311 KiB of the pool including the strip canvas, before hardware extras. Actual linking and device CPU remain unverified. No browser AudioContext nodes are used to generate the instrument itself. The browser audio worklet loads the shared C module compiled to WebAssembly.

## Attribution

Original Nachtfahrt: Cranky Man / FartyPants, derived from DUB-1, AMB-1 and Felucca. Preserve original file copyright notices and LICENSING.md. New Pacific Field DSP and mapping adapt the user's supplied Branch Resonator, Albion and FM Drone Clock concepts. Research tuning presets are references, not authorized score realizations. All distributed derivative source is provided under GPL-3.0-only; font licenses remain with their assets.

## Layered revision

Each layer retains its own voices, tuning, note levels/pan/fine, envelope, effect tails, process clock and latch/freeze state. Physical key releases return to the layer where the press began. The selected layer lights all sounding keys, including latched notes and release tails. Saving preserves live latch lights; reboot restores settings silently. Version-2 browser saves migrate into the new layered patch format. Mixer levels appear as B/A/C at the top of the screen, with an asterisk on running layers.

## Controls revision

HOME now alternates Voice and a persistent Mixer page. Its four knobs are Branch Level, Albion Level, Clock Level and Keyboard To. The original hold-HOME mixer shortcut remains. Four live labels below the browser panel knobs and the Current Controls guide describe each parameter. Clock ENV knob 3 or ALGORITHM selects all seven source configurations: Pad, Glass, Bell, Harmonium Wheel, Parallel, Dual Stack and Stack. These retain the source carrier/modulator ratios, gains and detune values; they are the clock study configurations, not complete emulations of the named DX7 algorithms.

Clock ARP knob 3 selects Climb OFF/GENTLE/FULL. OFF holds the current interval; EDIT and the Interval knob still work manually. GENTLE uses ratios 1, 9/8, 5/4, 3/2, 5/3, 2, 3/2 against the fixed root and caps glide at about 300 ms. FULL retains the scale climb and longer glide. REC remains an independent process freeze. Fresh patches use Gentle; saved settings are preserved. Optional Third follows the same gentle interval palette. Root Run remains separately switchable.

## Original screen artwork

`pacific/scenes.h` draws original pixel scenes through the existing FM-1 strip renderer. Branch: redwood grove, wind, rain and note lights. Albion: tortoise, moon, mist and shell lights for sounding notes. Clock: a still, four-armed Saraswati holding a veena, book and prayer beads, with lotus and swan; strings and surrounding lights respond to notes, while river lines move. The FX page uses coastal fog, waves, headlands and three level bars. The upper half carries the scene; the lower half retains four parameter labels/values and latch/status text. No raster assets or framebuffer allocations were added. UI refresh remains approximately 10 fps; real-device CPU validation remains outstanding.

## Playability and mixer revision (patch version 4)

GLO opens a full-screen three-channel mixer inspired by JIANT’s channel-strip organization, with original drawing code. SELECT/PRESETS select a strip; knobs are LEVEL, PAN, ECHO and ROOM for that layer. ARP toggles mute, SEQ toggles solo. The meters show post-fader, post-pan, post-mute/solo audio peaks rather than note activity. Meter decay, gain ramps, and true post-effects layer faders make the state audible and visible. GLO again opens GLOBAL TUNE; HOME opens Voice. The browser also has a Mixer shortcut. Mixer settings persist.

A keyboard press now starts only its played note, not the Branch or Clock generators. PLAY explicitly starts/stops the processes. Latch captures only chosen/held keyboard notes; enabling latch does not stop the layer, and disabling it releases the latched notes without resetting other layers. Very short taps receive an 80 ms minimum gate; the default envelope curve has faster low/mid attack and release, and voice gain is increased so keyboard notes are audible. Previously idle oscillators start at their target pitch.

The tuning map, root and anchor are shared globally, including held voices. Version-3 patches migrate to version 4, using the formerly selected layer’s tuning as the shared tuning. Per-note fine, note level, voice waveform, envelopes and effects remain layer-specific. The complete browser input/audio tests are in `pacific/test-instrument.mjs`; the older test entrypoints forward to it. Actual FM-1 compilation and physical CPU validation remain outstanding.

## Slip arpeggiators (patch version 5)

All three layers share an arp implementation, using each layer’s own timbre and held/latched pitch bank. ARP cycles Process → ARP Slip → ARP Shape. On Mixer, ARP retains its mute function. ARP Slip controls: On, BPM (30–240), Division (bar/half/quarter/eighth/sixteenth/thirty-second), Slip (0–100%). ARP Shape controls: Length, Order (up/down/up-down/random), Gate and Level. Albion’s original Process tempo/length/order/gate controls remain aliases of these settings.

Albion’s supplied Slip behavior is translated into the common C scheduler: <=1.5% uses one head. Above that, the two heads retain identical periods while the right head starts later by `min(interval * .42, .006 + interval * slip * .32)` seconds. Separation is `.28 + slip * .72`, reaching hard left/right at 100%. Panning uses equal-power coefficients; split-head levels are compensated to avoid a sudden gain increase. Two dedicated voice slots are allocated per layer, never a new voice per control edit. The left clock does not restart while Slip changes; pending changes affect subsequent right-head offsets. Steps are scheduled in audio-sample time. The source’s separate delay wow/flutter implementation is not part of this arp change.

Tempo, division, Slip, shape and enable state are per layer and saved. Existing version-4 patches migrate without losing global tuning or mixer settings; arp settings for Albion inherit the former pattern settings. Reboot restores parameters silently. Freeze pauses the selected arp clock, while all note-bank and keyboard state remain available. Turning arp off restores the held drone notes. Tests: `node pacific/test-slip.mjs build/emu/amb.wasm`, alongside `test-instrument.mjs`. Actual FM-1 build and CPU validation remain outstanding.

## EDIT page navigation

EDIT now advances through all ten existing pages in this order: Voice, Envelope, Motion, Process, ARP Slip, ARP Shape, Note Mix, Space, Global Tune, Mixer. It wraps from Mixer to Voice and follows the current page when a direct page button was used. The current position is shown as n/10 on the native screen and browser readout. Tapping or holding EDIT no longer strikes notes, regenerates branches, advances the clock interval, or starts transport. Keyboard/latch/arp state and parameters are unchanged by navigation. Clock intervals remain editable with the Interval knob. Direct page shortcuts remain available. `test-edit-pages.mjs` covers navigation and absence of musical side effects on all three layers.


## Four LFOs and page navigation
Four independent global-per-layer LFOs, RATE / DEPTH / SHAPE / DESTINATION; LFO cycles slots 1–4. EDIT opens each configuration (SYNC / KEY SYNC / PHASE / SLEW) and cycles all 18 settings pages. HOME exits. Existing motion controls remain on EDIT’s Mechanics / Legacy Motion page. GLO opens GLOBAL; tuning / root / anchor affect all layers. Repeat GLO for Mixer, or HOME again / browser Mixer button. LFO settings save in v6; old patches migrate at depth zero. See pacific/LFO-IMPLEMENTATION.md for detailed semantics and hardware verification limits.


## TORT replaces Albion
TORT uses the Melodee Prophet oscillator, four-pole filter, dual ADSR and Poly-Mod architecture. See pacific/TORT.md for provenance, exact port scope, 27-page edit map and v7 patch migration. All other layers and performance systems remain.

TORT filter-first navigation: HOME and the first EDIT page open FILTER (Cutoff / Resonance / Env Amount / Model). Next EDIT opens Filter ADSR, then Amp ADSR, then oscillator pages. ENV toggles Filter ADSR / Amp ADSR. Key Track remains on Env Mod. Patch/audio format unchanged.


## Clock v8: no note shifting
Clock Climb, Step, Interval and Root Run are removed. Its process holds a fixed root/fifth, and keyboard pitch centers stay fixed. Mechanics exposes original wheel rate, Evolve, Remontoire amount and recharge period; Quartz offers bounded small drift, its rate/slew and Motion on/off. See pacific/CLOCK.md for exact source adaptations, the new quartz extension, migration and tests.


## Current EDIT behavior: voice design only
EDIT cycles four voice pages on Branch/Clock and twelve native tone pages on TORT. It skips mixer, global tuning, note mix, FX, arpeggiators and the universal LFO bank. Dedicated buttons still open those sections. EDIT inside a universal LFO toggles only that slot’s main/config pages; LFO selects slots 1–4. See docs/VOICE-EDIT.md.
