/* SPDX-License-Identifier: GPL-3.0-only */
#include <stdint.h>
#include <string.h>
#ifndef EN_HOST
#define EN_HOST
#endif
#include "pacific.h"
static uint16_t fb[240*240];static uint32_t blits,now,buttons,keys,master=2200,litb,litk,writes;
static int32_t enc[NE];static uint8_t store[3840];static int storelen=-1;
static void lcd_sync(void){}
static void lcd_blit(uint32_t x,uint32_t y,uint32_t w,uint32_t h,const uint16_t *px){for(uint32_t j=0;j<h;j++)for(uint32_t i=0;i<w;i++)if(x+i<240&&y+j<240)fb[(y+j)*240+x+i]=px[j*w+i];blits++;}
static void lcd_fill(uint32_t x,uint32_t y,uint32_t w,uint32_t h,uint16_t c){for(uint32_t j=y;j<y+h&&j<240;j++)for(uint32_t i=x;i<x+w&&i<240;i++)fb[j*240+i]=c;blits++;}
#include "../firmware/src/gfx.c"
uint32_t plat_ms(void){return now;}uint32_t plat_buttons(void){return buttons;}uint32_t plat_keys(void){return keys;}int32_t plat_enc(int r){int d=enc[r];enc[r]=0;return d;}uint32_t plat_master(void){return master;}void plat_leds(uint32_t b,uint32_t k){litb=b;litk=k;}void plat_glow(int on){(void)on;}void plat_play_red(int on){(void)on;}
int plat_store_load(uint32_t obj,void *dst,uint32_t max){if(obj||storelen<0||(uint32_t)storelen>max)return -1;memcpy(dst,store,storelen);return storelen;}
int plat_store_save(uint32_t obj,const void *src,uint32_t len){if(obj||len>3840)return -1;memcpy(store,src,len);storelen=len;writes++;return 0;}
static uint32_t midiQueue[64],mw,mr;
int plat_midi_in(uint32_t *p){if(mr==mw)return 0;*p=midiQueue[mr++%64];return 1;}void plat_midi_out(uint32_t p){(void)p;}
uint32_t plat_cpu_pct(void){return 0;}uint32_t plat_xruns(void){return 0;}uint32_t plat_cpu_peak(void){return 0;}int32_t plat_battery(void){return -1;}int plat_usb_power(void){return 1;}
#include "app.c"
#define EXPORT __attribute__((used,visibility("default")))
static float outl[1024],outr[1024],msfrac;
EXPORT float *web_out_l(void){return outl;}EXPORT float *web_out_r(void){return outr;}
EXPORT void web_boot(void){pf_init();pf_load();pf_apply();pf_app_init();pf_app_frame();}
EXPORT void web_render(uint32_t n){if(n>1024)n=1024;pf_app_input();pf_render(outl,outr,n,(float)master/4096.f*1.8f);msfrac+=n*1000.f/PF_SR;uint32_t dt=(uint32_t)msfrac;msfrac-=dt;now+=dt;if(now%32<dt)pf_app_frame();}
EXPORT void web_buttons(uint32_t m){buttons=m;pf_app_input();}EXPORT void web_keys(uint32_t m){keys=m;pf_app_input();}EXPORT void web_enc(int role,int32_t n){if(role>=0&&role<NE)enc[role]+=n;}EXPORT void web_master(uint32_t v){master=v>4096?4096:v;}
EXPORT uint32_t web_lit_buttons(void){return litb;}EXPORT uint32_t web_lit_keys(void){return litk;}EXPORT uint16_t *web_fb(void){return fb;}EXPORT uint32_t web_blits(void){return blits;}EXPORT uint32_t web_now(void){return now;}EXPORT uint32_t web_cpu(void){return 0;}
EXPORT uint8_t *web_store(uint32_t obj){return store;}EXPORT int web_store_len(uint32_t obj){return obj?-1:storelen;}EXPORT void web_store_set_len(uint32_t obj,int n){if(!obj)storelen=n<0?-1:n>3840?3840:n;}EXPORT uint32_t web_store_writes(void){return writes;}EXPORT uint32_t web_nobj(void){return 1;}EXPORT uint32_t web_store_max(void){return 3840;}
static uint8_t sx[64];EXPORT uint8_t *web_said_buf(void){return sx;}EXPORT uint32_t web_said_len(void){return 0;}EXPORT void web_said_clear(void){}EXPORT uint8_t *web_sysex_buf(void){return sx;}EXPORT void web_sysex(uint32_t n){(void)n;}
EXPORT void web_midi(uint32_t packet){if(mw-mr<64)midiQueue[mw++%64]=packet;}
EXPORT int web_mode(void){return pf_ui.mode;}EXPORT int web_page(void){return pf_ui.page;}EXPORT int web_selected(void){return pf_ui.selected;}EXPORT int web_param(int i){return i>=0&&i<PF_NPAR?pf_ui.par[pf_ui.mode][i]:0;}EXPORT uint32_t web_active(void){return pf_active;}EXPORT float web_peak(void){return pf_peak;}EXPORT uint32_t web_running(void){return pf_running;}EXPORT uint32_t web_dropped(void){return pf_dropped;}
EXPORT const char *web_label(int i){int knob=i-pf_ui.page*4;return knob>=0&&knob<4?pf_control_label(knob):"";}
EXPORT const char *web_value(int knob){static char values[4][32];if(knob<0||knob>3)return "";pf_control_value(knob,values[knob]);return values[knob];}
EXPORT float web_note_hz(int key){return pf_hz(key,pf_ui.par[pf_ui.mode],pf_ui.octave,0);}
EXPORT uint32_t web_layer_active(int m){return pf_layer_active(m);}
EXPORT uint32_t web_layer_running(int m){return pf_layer_running(m);}
EXPORT int web_layer_level(int m){return m>=0&&m<3?pf_ui.par[m][7]:0;}
EXPORT uint32_t web_pool_bytes(void){return pf_pool_bytes();}
EXPORT uint32_t web_clock_step(void){return pf_clock_step;}

EXPORT int web_layer_mute(int m){return m>=0&&m<3?pf_ui.mute[m]:0;}
EXPORT int web_layer_solo(int m){return m>=0&&m<3?pf_ui.solo[m]:0;}
EXPORT int web_layer_pan(int m){return m>=0&&m<3?pf_ui.mixpan[m]:0;}
EXPORT float web_layer_meter(int m){return pf_layer_meter(m);}
EXPORT float web_voice_frequency(int m,int key){return pf_voice_frequency(m,key);}
EXPORT uint32_t web_transport(void){return pf_transport;}

EXPORT int web_arp_setting(int m,int i){return m>=0&&m<3&&i>=0&&i<8?pf_ui.arpSettings[m][i]:0;}
EXPORT uint32_t web_arp_events(int m,int h){return pf_arp_events(m,h);}
EXPORT uint32_t web_arp_last(int m,int h){return pf_arp_last(m,h);}

EXPORT int web_page_position(void){return pf_page_position();}
EXPORT int web_page_count(void){return pf_page_count();}

EXPORT int web_lfo_setting(int m,int slot,int field){return m>=0&&m<3&&slot>=0&&slot<4&&field>=0&&field<8?pf_ui.lfo[m][slot][field]:0;}
EXPORT float web_lfo_phase(int m,int slot){return pf_lfo_phase(m,slot);}
EXPORT float web_lfo_output(int m,int slot){return pf_lfo_output(m,slot);}
EXPORT int web_patch_bytes(void){return sizeof(pf_patch);}
EXPORT void web_open_page(int page){if(page>=0&&page<PF_PAGES){pf_ui.page=page;pf_dirty=1;}}

EXPORT float web_lfo_sample(int shape,float phase,float held){return pf_lfo_sample(shape,phase,held);}
EXPORT float web_lfo_effective(int m,int parameter){return pf_lfo_effective(m,parameter);}
EXPORT uint32_t web_lfo_cycles(int m,int slot){return pf_lfo_cycles(m,slot);}

EXPORT int web_tort_param(int i){return i>=0&&i<56?pf_ui.tort[i]:0;}

EXPORT int web_lfo_config(int m,int slot,int field){return pf_lfo_config(m,slot,field);}

EXPORT float web_clock_macro(void){return pf_clock_macro();}
EXPORT float web_clock_quartz(void){return pf_clock_quartz();}

EXPORT float web_clock_frequency(int voice){return pf_clock_frequency(voice);}

EXPORT int web_voice_spread(int m){return m>=0&&m<3?pf_ui.spread[m]:0;}
