#!/bin/sh
# SPDX-License-Identifier: GPL-3.0-only
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/gen build/emu
python3 tools/gen_font_noraqm.py tools/gen_font.py build/gen/felucca_font.h
emcc -O2 -ffp-contract=off -DEN_HOST -Ibuild/gen --no-entry -sSTANDALONE_WASM -sSTACK_SIZE=131072 -sINITIAL_MEMORY=4194304 -sFILESYSTEM=0 -o build/emu/amb.wasm pacific/web.c pacific/engine.c

cp web/emu/index.html web/emu/worklet.js build/emu/
