/* SPDX-License-Identifier: GPL-3.0-only */
#pragma once
#include <stdint.h>
#include <string.h>
#include "tort-patch.h"
#include "../firmware/src/app/plat.h"
#define PF_SR 44100.f
#define PF_NV 40
#define PF_PAGES 31
#define PF_LFO_COUNT 4
#define PF_NPAR 28
/* Four values per page: HOME, ENV, LFO, ARP, note mixer, GLO, FX. */
enum { PF_BRANCH,PF_TORT,PF_CLOCK };
enum { PF_MODE,PF_PARAM,PF_KEY,PF_PLAY,PF_FREEZE,PF_ACTION,PF_NOTE,PF_ARP,PF_PANIC,PF_MIX,PF_LFO,PF_TORT_PARAM };
typedef struct {uint32_t magic,version; int16_t mode,page,selected,octave,arp,latch; int16_t par[3][PF_NPAR]; int16_t level[3][27],pan[3][27],fine[3][27]; uint32_t latched[3]; int16_t mixpan[3],mute[3],solo[3]; int16_t arpSettings[3][8]; int16_t lfo[3][4][8] __attribute__((aligned(4)));uint8_t tort[56];int16_t spread[3];} pf_patch;
extern pf_patch pf_ui;
extern volatile uint32_t pf_active, pf_steps, pf_clock_step, pf_running, pf_frozen;
extern volatile float pf_energy[8],pf_clock_phase,pf_peak;
extern volatile uint32_t pf_dropped;
extern volatile uint8_t en_load;
void pf_init(void);
int pf_post(int op,int a,int b);
void pf_render(float *l,float *r,uint32_t n,float gain);
float pf_hz(int key,const int16_t *p,int octave,int fine);
void pf_defaults(pf_patch *p);
void pf_app_init(void);
void pf_app_input(void);
void pf_app_frame(void);
int pf_save(void);
int pf_load(void);
void pf_apply(void);
extern const char *const pf_modes[3];
extern const char *const pf_labels[3][PF_NPAR];
extern const char *const pf_tunings[5];
extern const char *const pf_pages[PF_PAGES];
void pf_value(char *dst,int size,int mode,int index,int value);

uint32_t pf_layer_active(int m);
uint32_t pf_layer_running(int m);
uint32_t pf_layer_lit(int m);
uint32_t pf_pool_bytes(void);

float pf_layer_meter(int m);
float pf_voice_frequency(int m,int key);

uint32_t pf_arp_events(int layer,int head);
uint32_t pf_arp_last(int layer,int head);

const char *pf_lfo_destination(int m,int d);
float pf_lfo_rate(int rate,int sync,int bpm);
float pf_lfo_phase(int m,int slot);
float pf_lfo_output(int m,int slot);

float pf_lfo_sample(int shape,float phase,float held);
float pf_lfo_effective(int m,int parameter);
uint32_t pf_lfo_cycles(int m,int slot);

_Static_assert(sizeof(pf_patch)<=PLAT_STORE_MAX,"Pacific patch exceeds flash object capacity");

int pf_lfo_config(int m,int slot,int field);

float pf_clock_macro(void);
float pf_clock_quartz(void);

float pf_clock_frequency(int voice);
