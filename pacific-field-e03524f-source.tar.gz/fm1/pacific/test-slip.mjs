import fs from 'node:fs';import assert from 'node:assert/strict';
const {instance:{exports:e}}=await WebAssembly.instantiate(fs.readFileSync(process.argv[2]),{wasi_snapshot_preview1:new Proxy({},{get:()=>()=>0}),env:new Proxy({},{get:()=>()=>0})});e._initialize?.();e.web_boot();
function run(sec=.04,events){for(let i=0;i<Math.ceil(sec*44100/128);i++){e.web_render(128);for(const ptr of [e.web_out_l(),e.web_out_r()])for(const x of new Float32Array(e.memory.buffer,ptr,128))assert(Number.isFinite(x)&&Math.abs(x)<=.951);if(events)for(let h=0;h<2;h++){const count=e.web_arp_events(e.web_mode(),h);if(count!==events.count[h]){events.count[h]=count;events.times[h].push(e.web_arp_last(e.web_mode(),h));}}}}
const tap=b=>{e.web_buttons(1<<b);e.web_buttons(0);run();};const turn=(r,n)=>{e.web_enc(r,n);run();};const select=m=>turn(2,(m-e.web_mode()+3)%3);const log=()=>({count:[e.web_arp_events(e.web_mode(),0),e.web_arp_events(e.web_mode(),1)],times:[[],[]]});
run();
for(let m=0;m<3;m++){
 select(m);tap(6);tap(1);e.web_keys((1<<7)|(1<<11)|(1<<14));e.web_keys(0);run();assert.equal(e.web_layer_active(m),(1<<7)|(1<<11)|(1<<14));tap(8);assert.equal(e.web_page(),3);tap(8);assert.equal(e.web_page(),8);turn(4,120-e.web_arp_setting(m,1));turn(5,2-e.web_arp_setting(m,2));turn(3,1);assert.equal(e.web_arp_setting(m,0),1);
 const mono=log();run(1.6,mono);assert(mono.times[0].length>=3);assert.equal(e.web_arp_events(m,1),0);for(let i=1;i<mono.times[0].length;i++)assert(Math.abs(mono.times[0][i]-mono.times[0][i-1]-22050)<=1);
 turn(6,50);const split=log();run(2.6,split);assert(split.times[1].length>=4);for(let i=1;i<split.times[1].length;i++)assert(Math.abs(split.times[1][i]-split.times[1][i-1]-22050)<=1);const offset=(e.web_arp_last(m,1)-e.web_arp_last(m,0)+22050)%22050;assert.equal(offset,3793,'right head offset differs from Albion formula');
 turn(6,50);run(1.2);assert.equal((e.web_arp_last(m,1)-e.web_arp_last(m,0)+22050)%22050,7321);assert.equal(e.web_arp_setting(m,1),120);
 // Repeated Slip edits never reset the left clock or create extra simultaneous heads.
 const n=e.web_arp_events(m,0);for(let j=0;j<20;j++)turn(6,j%2?-20:20);assert(e.web_arp_events(m,0)-n<=3);assert.equal(e.web_dropped(),0);
 turn(6,-1000);const right=e.web_arp_events(m,1);run(1.1);assert.equal(e.web_arp_events(m,1),right);
 turn(6,60);tap(11);const frozen=[e.web_arp_events(m,0),e.web_arp_events(m,1)];run(.7);assert.equal(e.web_arp_events(m,0),frozen[0]);assert.equal(e.web_arp_events(m,1),frozen[1]);tap(11);
}
const counts=[0,1,2].map(m=>e.web_arp_events(m,0));run(2);for(let m=0;m<3;m++)assert(e.web_arp_events(m,0)>counts[m]);
tap(7);e.web_boot();run();for(let m=0;m<3;m++){assert.equal(e.web_arp_setting(m,0),1);assert.equal(e.web_arp_setting(m,3),60);assert.equal(e.web_layer_running(m),0);}assert.equal(e.web_dropped(),0);assert(e.web_pool_bytes()+240*144*2<0x54000);
console.log('PASS: all three arps, mono at zero, two stereo heads at Slip > 1.5%, exact 3793/7321-frame offsets at 120 BPM, equal head periods, live edits without bursts, independent freeze, simultaneous layers, persistence, silent reboot and memory bounds.');
