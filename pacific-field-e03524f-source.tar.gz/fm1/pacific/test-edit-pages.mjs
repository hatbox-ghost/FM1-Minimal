import fs from 'node:fs';import assert from 'node:assert/strict';
const {instance:{exports:e}}=await WebAssembly.instantiate(fs.readFileSync(process.argv[2]),{wasi_snapshot_preview1:new Proxy({},{get:()=>()=>0}),env:new Proxy({},{get:()=>()=>0})});e._initialize?.();e.web_boot();
const run=(s=.03)=>{for(let i=0;i<s*44100/128;i++)e.web_render(128);};const tap=b=>{e.web_buttons(1<<b);e.web_buttons(0);run();};run();
for(let m=0;m<3;m++){
 e.web_enc(2,(m-e.web_mode()+3)%3);run();const pages=m===1?[22,23,24,18,19,20,21,25,26,27,28,29,30]:[0,1,2,3,30];
 e.web_open_page(7);for(let n=0;n<pages.length*2;n++){tap(4);assert.equal(e.web_page(),pages[n%pages.length]);assert.equal(e.web_page_count(),pages.length);assert.equal(e.web_page_position(),n%pages.length+1);assert.equal(e.web_layer_running(m),0,'EDIT started audio');}
 tap(1);e.web_keys(1<<7);e.web_keys(0);run(.2);const parameters=Array.from({length:28},(_,i)=>e.web_param(i));const arp=Array.from({length:8},(_,i)=>e.web_arp_setting(m,i));
 for(let n=0;n<pages.length*2;n++){tap(4);assert.equal(e.web_layer_active(m),1<<7);assert.deepEqual(Array.from({length:28},(_,i)=>e.web_param(i)),parameters);assert.deepEqual(Array.from({length:8},(_,i)=>e.web_arp_setting(m,i)),arp);}
 // Non-voice sections remain directly accessible; EDIT returns to voice design.
 for(const page of [4,5,6,7,8,9]){e.web_open_page(page);tap(4);assert.equal(e.web_page(),pages[0]);}
 // Universal LFOs retain main/config access without joining the instrument's page cycle.
 e.web_open_page(pages[0]);for(let slot=0;slot<4;slot++){tap(3);const main=10+slot*2;assert.equal(e.web_page(),main);assert.equal(e.web_page_count(),2);tap(4);assert.equal(e.web_page(),main+1);assert.equal(e.web_page_position(),2);tap(4);assert.equal(e.web_page(),main);assert.equal(e.web_page_position(),1);assert.equal(e.web_layer_active(m),1<<7);}
 tap(5);assert.equal(e.web_page(),5);tap(5);assert.equal(e.web_page(),7);tap(0);assert.equal(e.web_page(),6);tap(6);tap(9);assert.equal(e.web_page(),4);tap(8);assert.equal(e.web_page(),3);tap(8);assert.equal(e.web_page(),8);tap(8);assert.equal(e.web_page(),9);
}
e.web_open_page(0);e.web_buttons(1<<4);run(1.5);e.web_buttons(0);run();assert.equal(e.web_page(),1,'holding EDIT repeated');assert.equal(e.web_transport(),0);assert.equal(e.web_dropped(),0);console.log('PASS: voice-only EDIT cycles (5 Branch / 13 TORT / 5 Clock), wrap, no performance/global detours, LFO-local main/config toggle, dedicated shortcuts, held notes and parameter preservation, no sound/transport side effects.');
