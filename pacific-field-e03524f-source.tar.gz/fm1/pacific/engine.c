/* SPDX-License-Identifier: GPL-3.0-only
 * Pacific Field: bounded, single-precision C DSP shared by browser and FM-1 adapter.
 * Original adaptations of the user's Branch, TORT and FM Drone Clock machines.
 */
#include "pacific.h"
#include "../firmware/src/dsp/fastmath.h"
#include <string.h>
#define CL(x,a,b) fm_clampf((x),(a),(b))
#define DEL 16384
#define TAB 2048
#define BARRIER() __asm__ volatile("" ::: "memory")
static float sine[TAB+1];
volatile uint32_t pf_active,pf_steps,pf_clock_step,pf_running,pf_frozen,pf_dropped;
volatile float pf_energy[8],pf_clock_phase,pf_peak;
volatile uint8_t en_load;
static const float ratios[5][12]={
 {1,1.059463094f,1.122462048f,1.189207115f,1.25992105f,1.334839854f,1.414213562f,1.498307077f,1.587401052f,1.681792831f,1.781797436f,1.887748625f},
 {1,16.f/15,9.f/8,6.f/5,5.f/4,4.f/3,45.f/32,3.f/2,8.f/5,5.f/3,9.f/5,15.f/8},
 {1,567.f/512,9.f/8,147.f/128,21.f/16,1323.f/1024,189.f/128,3.f/2,49.f/32,7.f/4,441.f/256,63.f/32},
 {1,16.f/15,9.f/8,6.f/5,5.f/4,4.f/3,64.f/45,3.f/2,8.f/5,5.f/3,16.f/9,15.f/8},
 {1,256.f/243,9.f/8,32.f/27,81.f/64,4.f/3,729.f/512,3.f/2,128.f/81,27.f/16,16.f/9,243.f/128}};
const char *const pf_modes[3]={"BRANCH","TORT","CLOCK"};
const char *const pf_pages[PF_PAGES]={"VOICE","ENVELOPE","MOTION","PROCESS","NOTE MIX","GLOBAL","SPACE","MIXER","ARP SLIP","ARP SHAPE","LFO 1","LFO 1 CONFIG","LFO 2","LFO 2 CONFIG","LFO 3","LFO 3 CONFIG","LFO 4","LFO 4 CONFIG","OSC A","OSC B","B WAVES","OSC MIXER","FILTER","FILTER ENV","AMP ENV","ENV MOD","POLY-MOD","NATIVE LFO","WHEEL SOURCE","MOD ROUTES","VOICE SPREAD"};
const char *const pf_tunings[5]={"12 TET","5 LIMIT","WTP 7","RILEY 5","PYTHAG"};
const char *const pf_labels[3][PF_NPAR]={
 {"TONE","RING","WIND","RAIN","ATTACK","RELEASE","LPG","LEVEL","STIFF","DAMP","COUPLE","AIR","RAIN MS","DENSITY","CENTER","SPREAD","NOTE LVL","OCTAVE","PAN","FINE","TUNING","ROOT","ANCHOR","LATCH","ECHO","TIME MS","FEEDBACK","ROOM"},
 {"WAVE","CUTOFF","RESON","DRIFT","ATTACK","RELEASE","SHAPE","LEVEL","LFO SEC","LFO DEP","WANDER","FILTER","TEMPO","LENGTH","ORDER","GATE","NOTE LVL","OCTAVE","PAN","FINE","TUNING","ROOT","ANCHOR","LATCH","ECHO","TIME MS","FEEDBACK","ROOM"},
 {"SHIMMER","OSC MIX","ORBIT","DRIFT","ATTACK","RELEASE","ALGO","LEVEL","MECH RATE","EVOLVE","REMONTOIRE","REWIND MS","QTZ RATE","QTZ DEPTH","QTZ SLEW","MOTION","NOTE LVL","OCTAVE","PAN","FINE","TUNING","ROOT","ANCHOR","LATCH","ECHO","TIME MS","FEEDBACK","ROOM"}};
/* LFO definitions follow the sine helpers; runtime storage is fixed. */
#include "tort.h"
typedef struct {float c[3],m[3],freq,target,env,gate,pan,level,fine,low,band,mal,excite,x,velocity,arpL,arpR,inc[3],mi[3]; int key,oct,minFrames;} Voice;
typedef struct {int op,a,b;} Cmd;
typedef struct {int16_t cfg[8];float phase,held,output;uint32_t random,cycles;} PFLfo;
#define PF_LFO_TYPE_DEFINED
typedef struct {
 uint8_t tort[56];PFLfo lfos[4];float lfoPitch,lfoPan,lfoAmp,baseSmooth[PF_NPAR];
 int16_t echoL[DEL],echoR[DEL],roomL[2203],roomR[2741];
 uint32_t ep,rpL,rpR,seed,controlCount,heldMask,midiMask;
 int arpConfig[8],arpCursor[2],arpSplit,arpWait,arpGate[2];float arpPeriod;uint32_t arpTicks,arpEvent[2],arpLast[2];
 float mechPhase,remCharge,remOutput,remSmooth,quartzTimer,quartzTarget,quartzSmooth,clockMacro,clockEvolve[3],clockDetune[3],clockIndex[3],clockBrightness;uint32_t quartzSeed;
 int spread;float spreadSmooth;int process,mixMute,mixSolo,mixPan;float mixGain,meter;
 int mode,par[PF_NPAR],arpOn,arpIndex,arpDir,selected,octave,smoothReady;
 float sampleClock,arpLeft,rainLeft;
 float smooth[PF_NPAR],masterRamp,dcL,dcR,lastL,lastR;
 Voice v[PF_NV]; Cmd queue[256]; volatile uint32_t qw,qr;
 volatile uint32_t active,steps,clock_step,running,frozen,dropped;
 volatile float energy[8],clock_phase,peak;
} Context;
static Context layers[3] EN_POOL;
static Context *current;
static int editLayer;
#define echoL (current->echoL)
#define echoR (current->echoR)
#define roomL (current->roomL)
#define roomR (current->roomR)
#define ep (current->ep)
#define rpL (current->rpL)
#define rpR (current->rpR)
#define seed (current->seed)
#define controlCount (current->controlCount)
#define heldMask (current->heldMask)
#define midiMask (current->midiMask)
#define mode (current->mode)
#define par (current->par)
#define arpOn (current->arpOn)
#define arpIndex (current->arpIndex)
#define arpDir (current->arpDir)
#define selected (current->selected)
#define octave (current->octave)
#define smoothReady (current->smoothReady)
#define sampleClock (current->sampleClock)
#define arpLeft (current->arpLeft)
#define rainLeft (current->rainLeft)
#define smooth (current->smooth)
#define masterRamp (current->masterRamp)
#define dcL (current->dcL)
#define dcR (current->dcR)
#define lastL (current->lastL)
#define lastR (current->lastR)
#define v (current->v)
#define queue (current->queue)
#define qw (current->qw)
#define qr (current->qr)
#define pf_active (current->active)
#define pf_steps (current->steps)
#define pf_clock_step (current->clock_step)
#define pf_running (current->running)
#define pf_frozen (current->frozen)
#define pf_dropped (current->dropped)
#define pf_energy (current->energy)
#define pf_clock_phase (current->clock_phase)
#define pf_peak (current->peak)
static int single_post(int op,int a,int b){uint32_t w=qw;if(w-qr>=256){pf_dropped++;return 0;}queue[w&255]=(Cmd){op,a,b};BARRIER();qw=w+1;return 1;}
static float rnd(void){seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;return (float)(seed&65535)/32768.f-1.f;}
static float sn(float phase){phase-=fm_floorf(phase);float x=phase*TAB;int i=(int)x;return sine[i]+(sine[i+1]-sine[i])*(x-i);}
static float cycle(float x){return x-fm_floorf(x);}
#include "lfo.h"
static void lfo_key_reset(void){for(int slot=0;slot<4;slot++)if(current->lfos[slot].cfg[5])lfo_reset(&current->lfos[slot]);}
float pf_hz(int key,const int16_t *p,int oct,int fine){int tuning=p[20];if(tuning<0||tuning>4)tuning=0;int ref=tuning==2?3:tuning==3?1:0;int degree=(key+5-ref)%12,baseOct=(key+5-ref)/12;return p[22]*.1f*ratios[tuning][degree]*fm_exp2f((float)(oct+baseOct)+(float)p[21]/12.f+(float)fine/1200.f);}
static float freq(int key,int oct,int fine){int16_t p[PF_NPAR];for(int i=20;i<24;i++)p[i]=par[i];return pf_hz(key,p,oct,fine);}
static void setvoice(int i,int key,int oct,float level,int retrigger){Voice *a=&v[i];a->key=key;a->oct=oct;a->target=freq(key,oct,(int)a->fine);if(a->freq<1||a->env<.001f)a->freq=a->target;if(mode==PF_TORT&&(!a->gate||retrigger))tort_note(i,current->tort,a->target);a->gate=1;a->level=level;if(retrigger){a->excite=.7f;a->mal=1;a->velocity+=.15f;}}
static void silence(int hard){heldMask=0;pf_active=0;for(int i=0;i<PF_NV;i++){v[i].gate=0;v[i].excite=0;if(hard){v[i].env=0;v[i].minFrames=0;v[i].mal=0;v[i].low=v[i].band=0;}}if(hard){memset(echoL,0,sizeof echoL);memset(echoR,0,sizeof echoR);memset(roomL,0,sizeof roomL);memset(roomR,0,sizeof roomR);masterRamp=0;if(mode==PF_TORT)memset(tort_voices,0,sizeof tort_voices);}}
static void branch_seed(void){static const int notes[8]={7,11,14,18,19,23,26,30};for(int i=0;i<8;i++){int k=notes[i]+(int)(rnd()*2);if(k>26)k-=12;Voice *a=&v[30+i];a->fine=0;a->x=rnd()*.03f;a->velocity=0;a->pan=0;a->freq=0;setvoice(30+i,k,-1,.48f,1);}}
/* Stable anchor and fifth: no scale wheel, climb, root travel or interval stepping. */
static void clock_notes(void){setvoice(27,7,-1,.75f,0);setvoice(28,14,-1,.55f,0);v[29].gate=0;pf_clock_step=0;}
static const float FMCONFIG[7][3][5];
static void clock_mechanics(float dt){
 if(pf_running&&!pf_frozen&&par[15]){
  current->quartzTimer+=dt*(.005f+smooth[12]*.00795f);
  if(current->quartzTimer>=1||!current->quartzSeed){uint32_t x=current->quartzSeed?current->quartzSeed:93817;x^=x<<13;x^=x>>17;x^=x<<5;current->quartzSeed=x;current->quartzTarget=(x&65535)/32768.f-1;current->quartzTimer=cycle(current->quartzTimer);}
  current->quartzSmooth+=(current->quartzTarget-current->quartzSmooth)*CL(dt/(.02f+smooth[14]*.04f),0,1);
  current->mechPhase=cycle(current->mechPhase+dt*smooth[8]*.0005f*(1+current->quartzSmooth*smooth[13]*.000001f));
  float raw=.5f-.5f*sn(current->mechPhase+.25f);
  current->remCharge-=dt/CL(smooth[11]*.001f,.08f,4);
  if(current->remCharge<=0){current->remCharge+=1;current->remOutput=.35f+.65f*raw;}
  current->remSmooth+=(current->remOutput-current->remSmooth)*CL(dt*5,0,1);
  current->clockMacro=CL(raw*(1-.65f*smooth[10]*.01f)+current->remSmooth*.65f*smooth[10]*.01f,0,1);
  float evolve=.002f+smooth[9]*.00118f;
  for(int j=0;j<3;j++)current->clockEvolve[j]=cycle(current->clockEvolve[j]+dt*evolve*(.62f+.2f*j)*(1+current->clockMacro*smooth[2]*.036f));
 }
 pf_clock_phase=current->mechPhase;
 float macro=par[15]?current->clockMacro:0;
 current->clockBrightness=CL(FM_TWO_PI*(2300+macro*smooth[2]*36)/PF_SR,.002f,.8f);
 int algorithm=par[6]%7;for(int j=0;j<3;j++){const float *cfg=FMCONFIG[algorithm][j];float orbit=smooth[2]*.01f,evolve=par[15]?sn(current->clockEvolve[j]):0;current->clockIndex[j]=smooth[0]*.055f*cfg[2]*(.78f+macro*orbit*.78f+evolve*(.11f+macro*.13f));float cents=cfg[4]*(smooth[3]*.22f+macro*orbit*7.5f)*(1+j*.12f)+(par[15]?current->quartzSmooth*smooth[13]*.02f:0);current->clockDetune[j]=fm_exp2f(cents/1200.f);}

}
static void start(void){current->process=1;pf_running=1;arpLeft=0;rainLeft=0;if(mode==PF_BRANCH)branch_seed();if(mode==PF_CLOCK)clock_notes();}
static void drain(void){while(qr!=qw){Cmd c=queue[qr&255];qr++;switch(c.op){case PF_MODE:mode=(c.a%3+3)%3;pf_running=0;pf_frozen=0;silence(1);arpIndex=0;pf_clock_step=0;pf_clock_phase=0;smoothReady=0;break;case PF_PARAM:if(c.a>=0&&c.a<PF_NPAR){par[c.a]=c.b;if(c.a>=20&&c.a<=22){for(int j=0;j<PF_NV;j++)if(v[j].target>1)v[j].target=freq(v[j].key,v[j].oct,(int)v[j].fine);}}break;case PF_TORT_PARAM:if(c.a>=0&&c.a<56)current->tort[c.a]=(uint8_t)CL(c.b,0,tort_max(c.a));break;case PF_LFO:if(c.a>=0&&c.a<32){int index=c.a%8;const int hi[8]={100,100,5,10,1,1,359,100};current->lfos[c.a/8].cfg[index]=(int16_t)CL(c.b,0,hi[index]);}break;case PF_MIX:if(c.a==3)current->spread=(int)CL(c.b,0,100);else if(c.a==0)current->mixPan=c.b;else if(c.a==1)current->mixMute=c.b;else if(c.a==2)current->mixSolo=c.b;break;case PF_PLAY:if(c.a==2){if(!pf_running){arpLeft=0;current->arpWait=-1;}pf_running=1;}else if(c.a)start();else{pf_running=0;silence(0);}break;case PF_PANIC:current->process=0;pf_running=0;silence(1);break;case PF_FREEZE:pf_frozen=c.a;break;case PF_ARP:if(c.a>=0&&c.a<8){current->arpConfig[c.a]=c.b;if(c.a==0){int previous=arpOn;arpOn=!!c.b;if(arpOn&&!previous){arpLeft=0;current->arpCursor[0]=current->arpCursor[1]=0;current->arpWait=-1;current->arpSplit=0;for(int k=0;k<27;k++){v[k].gate=0;v[k].minFrames=0;}}if(!arpOn){v[38].gate=v[39].gate=0;current->arpWait=-1;for(int k=0;k<27;k++)if(heldMask&(1u<<k))setvoice(k,k,octave,v[k].level,0);}}}break;case PF_KEY:{int k=c.a;if(k<0||k>26)break;if(c.b){if(!heldMask)lfo_key_reset();heldMask|=1u<<k;if(!arpOn){setvoice(k,k,octave,v[k].level,mode==PF_BRANCH);v[k].minFrames=3528;}}else{heldMask&=~(1u<<k);v[k].gate=0;}break;}case PF_NOTE:if(c.a==1){octave=c.b;}else if(c.a>=100&&c.a<127){int k=c.a-100;v[k].level=c.b*.01f;}else if(c.a>=200&&c.a<227){v[c.a-200].pan=c.b*.01f;}else if(c.a>=300&&c.a<327){int k=c.a-300;v[k].fine=c.b;v[k].target=freq(k,v[k].oct,c.b);}break;case PF_ACTION:if(mode==PF_BRANCH){if(c.a)branch_seed();else for(int i=30;i<38;i++){v[i].mal=1;v[i].excite=.6f;v[i].velocity+=.2f;}}else if(mode==PF_CLOCK){/* No automatic note-shifting action. */}else{arpIndex++;arpLeft=0;}break;}}}
static void single_init(void){memset(v,0,sizeof v);memset(par,0,sizeof par);for(int i=0;i<=TAB;i++)sine[i]=fm_sinf(FM_TWO_PI*i/TAB);silence(1);qw=qr=0;pf_running=pf_frozen=pf_dropped=0;sampleClock=0;mode=0;arpOn=0;octave=0;smoothReady=0;for(int i=0;i<27;i++){v[i].level=.65f;v[i].pan=0;}}
static void controls(uint32_t n){float dt=n/PF_SR;sampleClock+=dt;current->spreadSmooth+=(current->spread*.01f-current->spreadSmooth)*.075f;for(int i=0;i<PF_NPAR;i++){if(!smoothReady)current->baseSmooth[i]=par[i];else current->baseSmooth[i]+=(par[i]-current->baseSmooth[i])*.075f;smooth[i]=current->baseSmooth[i];}smoothReady=1;
 float sums[PF_NPAR]={0};float pitch=0,pan=0,amp=0;int anyAmp=0;
 for(int slot=0;slot<4;slot++){PFLfo *a=&current->lfos[slot];lfo_tick(a,dt,current->arpConfig[1]>=30?current->arpConfig[1]:96);int d=a->cfg[3];if(d<=0||d>=11||!a->cfg[1])continue;const PFDestination *dest=&destinations[mode][d];float amount=a->cfg[1]*.01f*a->output*dest->range;if(dest->parameter>=0)sums[dest->parameter]+=amount;else if(dest->parameter==-2)pitch+=amount;else if(dest->parameter==-3)pan+=amount;else if(dest->parameter==-4){amp+=amount;anyAmp=1;}}
 for(int slot=0;slot<4;slot++){PFLfo *a=&current->lfos[slot];int d=a->cfg[3];if(d>0&&d<11&&a->cfg[1]){const PFDestination *dest=&destinations[mode][d];if(dest->parameter>=0)smooth[dest->parameter]=CL(current->baseSmooth[dest->parameter]+sums[dest->parameter],dest->low,dest->high);}}
 current->lfoPitch=fm_exp2f(CL(pitch,-100,100)/1200.f);current->lfoPan=CL(pan,-1,1);current->lfoAmp=anyAmp?CL(1+amp,0,1):1;
 if(pf_running&&!pf_frozen){if(mode==PF_BRANCH&&current->process){rainLeft-=dt;float spring=.3f+smooth[8]*.08f,damp=.4f+smooth[9]*.045f;for(int i=30;i<38;i++){Voice *a=&v[i];float wind=sn(sampleClock*(.025f+i*.0007f)+i*.13f)*smooth[2]*.003f;float coupled=i>30?v[i-1].x*smooth[10]*.003f:0;a->velocity+=(-a->x*spring-a->velocity*damp+wind+coupled)*dt;a->x+=a->velocity*dt;a->excite*=fm_expf(-dt/(.4f+smooth[1]*.09f));pf_energy[i-30]=CL(a->excite+fm_fabsf(a->velocity)*5,0,1);}if(rainLeft<=0&&smooth[3]>0){int center=par[14]*7/100;int width=par[15]*7/100;int index=center+(int)(rnd()*(width+.5f));if(index<0)index=0;if(index>7)index=7;v[30+index].excite=smooth[3]*.01f;v[30+index].mal=smooth[3]*.01f;v[30+index].velocity+=.06f;rainLeft=(smooth[12]*.001f)*(1+rnd()*.35f)*(1.3f-smooth[13]*.009f);}}

 }
 if(mode==PF_CLOCK)clock_mechanics(dt);
 if(arpOn){for(int k=0;k<27;k++){v[k].gate=0;v[k].minFrames=0;}}
 else if(pf_running)for(int k=0;k<27;k++)v[k].gate=(heldMask>>k)&1;

 pf_active=heldMask;
 for(int i=0;i<PF_NV;i++){Voice *a=&v[i];if(a->target<1)continue;float glide=.07f;a->freq+=(a->target-a->freq)*CL(dt/glide,0,1);float drift=mode==PF_TORT?smooth[3]*.00006f*sn(sampleClock*.03f+i*.21f):0;float f=a->freq*(1+drift)*current->lfoPitch;for(int j=0;j<3;j++){a->inc[j]=f/PF_SR;a->mi[j]=f/PF_SR;}}}
static float arp_interval(void){static const float division[6]={4,2,1,.5f,.25f,.125f};int d=current->arpConfig[2];if(d<0||d>5)d=2;return fm_maxf(.024f,60.f/CL(current->arpConfig[1],30,240)*division[d]);}
static void arp_fire(int head){int bank[27],count=0;for(int k=0;k<27;k++)if(heldMask&(1u<<k))bank[count++]=k;int length=current->arpConfig[4];if(length<count)count=length;if(count<=0)return;int index=current->arpCursor[head]++,order=current->arpConfig[5];int slot=index%count;if(order==1)slot=count-1-slot;if(order==2){int span=count>1?count*2-2:1;slot=index%span;if(slot>=count)slot=span-slot;}if(order==3)slot=(int)((rnd()+1)*.499f*count);if(slot>=count)slot=count-1;int key=bank[slot],voice=38+head;float slip=current->arpConfig[3]*.01f;setvoice(voice,key,octave,v[key].level*current->arpConfig[7]*.01f*(slip>.015f?.70710678f:1),1);v[voice].fine=v[key].fine;v[voice].target=freq(key,octave,(int)v[key].fine);v[voice].freq=v[voice].target;for(int j=0;j<3;j++)v[voice].inc[j]=v[voice].mi[j]=v[voice].freq/PF_SR;v[voice].pan=slip>.015f?(head?1:-1)*(.28f+slip*.72f):v[key].pan;v[voice].arpL=fm_sqrtf((1-v[voice].pan)*.5f)*.70710678f;v[voice].arpR=fm_sqrtf((1+v[voice].pan)*.5f)*.70710678f;current->arpGate[head]=(int)(current->arpPeriod*CL(current->arpConfig[6]*.01f,.02f,.95f));pf_steps=key;current->arpEvent[head]++;current->arpLast[head]=current->arpTicks;}
static void arp_sample(void){if(!arpOn||!pf_running||pf_frozen)return;current->arpTicks++;float period=arp_interval()*PF_SR;if(current->arpPeriod>0&&fm_fabsf(period-current->arpPeriod)>.01f){arpLeft*=period/current->arpPeriod;if(current->arpWait>0)current->arpWait=(int)(current->arpWait*period/current->arpPeriod);}current->arpPeriod=period;int split=current->arpConfig[3]>1;if(split!=current->arpSplit){current->arpSplit=split;current->arpWait=-1;if(split)current->arpCursor[1]=current->arpCursor[0];else v[39].gate=0;}
 if(arpLeft<=0){arp_fire(0);if(split){float slip=current->arpConfig[3]*.01f;current->arpWait=(int)(fm_minf(period*.42f,PF_SR*.006f+period*slip*.32f)+.5f);}arpLeft+=period;}if(split&&current->arpWait==0){arp_fire(1);current->arpWait=-1;}if(current->arpWait>0)current->arpWait--;arpLeft-=1;for(int h=0;h<2;h++){if(current->arpGate[h]>0){if(--current->arpGate[h]==0)v[38+h].gate=0;}}}
static float morph(Voice *a,float wave,float shape){float p=a->c[0],s=sn(p),tri=sn(p)-sn(p*3)/9.f+sn(p*5)/25.f;float saw=s-sn(p*2)*.5f+sn(p*3)/3.f-sn(p*4)*.25f+sn(p*5)*.2f;float pulse=s+sn(p*3)/3.f+sn(p*5)/5.f;float x=wave*.03f;float out=x<1?s+(tri-s)*x:x<2?tri+(saw-tri)*(x-1):saw+(pulse-saw)*(x-2);a->c[0]=cycle(p+a->inc[0]);return out*(1-shape*.002f)+sn(p*2)*shape*.0015f;}
static const float FMCONFIG[7][3][5]={{{1.0f,1.0f,0.26f,0.31f,-1.0f},{1.0f,2.0f,0.24f,0.18f,0.0f},{0.5f,1.5f,0.18f,0.2f,1.0f}},{{1.0f,2.0f,0.34f,0.28f,-1.0f},{1.0f,3.0f,0.3f,0.19f,0.0f},{0.5f,2.5f,0.2f,0.17f,1.0f}},{{1.0f,1.414f,0.38f,0.24f,-1.0f},{1.0f,2.71f,0.34f,0.17f,0.0f},{0.5f,3.5f,0.24f,0.14f,1.0f}},{{1.0f,2.0f,0.115f,0.33f,-1.7f},{1.5f,3.0f,0.09f,0.25f,0.8f},{2.0f,4.0f,0.065f,0.18f,2.2f}},{{1.0f,1.0f,0.18f,0.3f,-1.0f},{2.0f,2.0f,0.1f,0.16f,0.0f},{0.5f,0.5f,0.12f,0.2f,1.0f}},{{1.0f,1.0f,0.34f,0.3f,-1.0f},{1.0f,4.0f,0.28f,0.18f,0.0f},{2.0f,3.0f,0.18f,0.12f,1.0f}},{{1.0f,1.0f,0.44f,0.3f,-1.0f},{1.0f,3.0f,0.34f,0.16f,0.0f},{0.5f,5.0f,0.22f,0.12f,1.0f}}};
static void single_render(float *l,float *r,uint32_t n,float gain){drain();controls(n);if(mode==PF_TORT)tort_prepare(current->tort,smooth,par);float aa=smooth[4]*.01f;float attack=1.f/(PF_SR*(.005f+7.f*aa*aa*aa)),release=1.f/(PF_SR*(.02f+9.f*(smooth[5]*.01f)*(smooth[5]*.01f)*(smooth[5]*.01f)));float morphWave=smooth[0],cut=mode==PF_TORT?smooth[1]:mode==PF_BRANCH?smooth[0]:70;float cutoff=100+cut*cut*.65f;float filterCoeff=CL(FM_TWO_PI*cutoff/PF_SR,0,.65f);int len=(int)(smooth[25]*PF_SR*.001f);if(len<1)len=1;if(len>=DEL)len=DEL-1;float fb=CL(smooth[26]*.01f,0,.78f),send=smooth[24]*.01f,room=smooth[27]*.01f,level=smooth[7]*.01f;float peak=0;
 for(uint32_t k=0;k<n;k++){arp_sample();if(mode==PF_TORT)tort_wheel_sample();float L=0,R=0;masterRamp+=(pf_running?1.f:0.f)-masterRamp>0?(.0004f*(1-masterRamp)):(-.0004f*masterRamp);for(int i=0;i<PF_NV;i++){Voice *a=&v[i];float target=(a->gate||a->minFrames>0)?1:0;if(a->minFrames>0)a->minFrames--;float atk=i>=38?1.f/(PF_SR*.003f):attack,rel=i>=38?1.f/(PF_SR*.08f):release;a->env+=(target-a->env)*(target>a->env?atk:rel);if(a->env<.000001f&&(mode!=PF_TORT||tort_voices[i].amp.stage==0)){a->env=0;continue;}float x=0;float position=i<27?((i%7)-3)/3.f:i<30?(i==27?-.75f:.75f):(i-33.5f)/3.5f;float pan=CL(a->pan+position*current->spreadSmooth+current->lfoPan,-1,1);
 if(mode==PF_CLOCK){int algo=par[6]%7;if(algo<0)algo=0;for(int j=0;j<3;j++){const float *cfg=FMCONFIG[algo][j];float mod=sn(a->m[j]);float index=current->clockIndex[j];float cphase=a->c[j]+mod*index;float mix=smooth[1]*.01f;x+=(sn(cphase)*(1-mix)+sn(cphase*2)*mix)*cfg[3];a->c[j]=cycle(a->c[j]+a->inc[j]*cfg[0]*current->clockDetune[j]);a->m[j]=cycle(a->m[j]+a->mi[j]*cfg[1]);}x*=1.6f;a->low+=(x-a->low)*current->clockBrightness;x=a->low;}
 else if(mode==PF_TORT){x=tort_sample(i,a->freq*current->lfoPitch,target>0);}
 else{float sin=sn(a->c[0]),tri=sn(a->c[1])-sn(a->c[1]*3)/9.f;a->c[0]=cycle(a->c[0]+a->inc[0]);a->c[1]=cycle(a->c[1]+a->inc[0]*1.003f);float wind=fm_fabsf(a->velocity)*7;float mal=a->mal*rnd()*.5f;a->mal*=.995f;float excitation=sin*.32f+tri*.18f+mal+(.03f+smooth[2]*.0008f)*rnd();float f=CL(FM_TWO_PI*a->freq/PF_SR,.001f,.3f);float q=CL(1.4f-smooth[1]*.012f,.15f,1.4f);float high=excitation-a->low-q*a->band;a->band+=f*high;a->low+=f*a->band;float ring=a->band*.6f;float bright=CL(.03f+filterCoeff+(a->excite+wind)*smooth[6]*.003f,.002f,.65f);a->c[2]+=(ring-a->c[2])*bright;x=a->c[2]*(.25f+a->excite+wind);}
 float amp=(mode==PF_TORT?1:a->env)*a->level*.36f*current->lfoAmp;L+=x*amp*(i>=38?a->arpL*(1-fm_maxf(current->lfoPan,0)):(.5f-pan*.45f));R+=x*amp*(i>=38?a->arpR*(1+fm_minf(current->lfoPan,0)):(.5f+pan*.45f));}
 uint32_t read=(ep+DEL-len)%DEL;float eL=echoL[read]/32768.f,eR=echoR[read]/32768.f;echoL[ep]=(int16_t)(CL(L*send+eR*fb,-.8f,.8f)*32767.f);echoR[ep]=(int16_t)(CL(R*send+eL*fb,-.8f,.8f)*32767.f);ep=(ep+1)%DEL;float rl=roomL[rpL]/32768.f,rr=roomR[rpR]/32768.f;roomL[rpL]=(int16_t)(CL(L*.35f+rr*.66f,-.95f,.95f)*32767.f);roomR[rpR]=(int16_t)(CL(R*.35f+rl*.63f,-.95f,.95f)*32767.f);rpL=(rpL+1)%2203;rpR=(rpR+1)%2741;L+=eL*.7f+rl*room;R+=eR*.7f+rr*room;float outL=L-lastL+.995f*dcL,outR=R-lastR+.995f*dcR;lastL=L;lastR=R;dcL=outL;dcR=outR;float g=gain*masterRamp*level;outL=CL(outL*g,-.92f,.92f);outR=CL(outR*g,-.92f,.92f);l[k]=outL;r[k]=outR;float pk=fm_maxf(fm_fabsf(outL),fm_fabsf(outR));if(pk>peak)peak=pk;}
 pf_peak=peak;}

#undef echoL
#undef echoR
#undef roomL
#undef roomR
#undef ep
#undef rpL
#undef rpR
#undef seed
#undef controlCount
#undef heldMask
#undef midiMask
#undef mode
#undef par
#undef arpOn
#undef arpIndex
#undef arpDir
#undef selected
#undef octave
#undef smoothReady
#undef sampleClock
#undef arpLeft
#undef rainLeft
#undef smooth
#undef masterRamp
#undef dcL
#undef dcR
#undef lastL
#undef lastR
#undef v
#undef queue
#undef qw
#undef qr
#undef pf_active
#undef pf_steps
#undef pf_clock_step
#undef pf_running
#undef pf_frozen
#undef pf_dropped
#undef pf_energy
#undef pf_clock_phase
#undef pf_peak

static void snapshot(void){Context *a=&layers[editLayer];pf_active=a->active;pf_steps=a->steps;pf_clock_step=a->clock_step;pf_running=a->running;pf_frozen=a->frozen;pf_clock_phase=a->clock_phase;pf_dropped=layers[0].dropped+layers[1].dropped+layers[2].dropped;for(int k=0;k<8;k++)pf_energy[k]=layers[0].energy[k];}
void pf_init(void){memset(tort_voices,0,sizeof tort_voices);memset(&tort_block,0,sizeof tort_block);memset(layers,0,sizeof layers);for(int m=0;m<3;m++){current=&layers[m];single_init();layers[m].mode=m;layers[m].seed=311+m*179;for(int j=0;j<4;j++){layers[m].lfos[j].random=1777+m*73+j*139;layers[m].lfos[j].held=lfo_random(&layers[m].lfos[j]);}}editLayer=0;current=&layers[0];snapshot();}
int pf_post(int op,int x,int y){if(op==PF_MODE){editLayer=(x%3+3)%3;snapshot();return 1;}Context *a=&layers[editLayer];uint32_t w=a->qw;if(w-a->qr>=256){a->dropped++;return 0;}a->queue[w&255]=(Cmd){op,x,y};BARRIER();a->qw=w+1;return 1;}
void pf_render(float *l,float *r,uint32_t n,float gain){float tl[256],tr[256];pf_peak=0;for(int m=0;m<3;m++){current=&layers[m];drain();}int anySolo=layers[0].mixSolo||layers[1].mixSolo||layers[2].mixSolo;for(uint32_t offset=0;offset<n;offset+=256){uint32_t count=n-offset>256?256:n-offset;for(uint32_t i=0;i<count;i++)l[offset+i]=r[offset+i]=0;for(int m=0;m<3;m++){current=&layers[m];single_render(tl,tr,count,gain);float audible=!layers[m].mixMute&&(!anySolo||layers[m].mixSolo);float pan=layers[m].mixPan*.01f,peak=0;for(uint32_t i=0;i<count;i++){layers[m].mixGain+=(audible-layers[m].mixGain)*.004f;if(fm_fabsf(layers[m].mixGain-audible)<.000001f)layers[m].mixGain=audible;float L=tl[i]*layers[m].mixGain*(pan>0?1-pan:1)*.65f,R=tr[i]*layers[m].mixGain*(pan<0?1+pan:1)*.65f;l[offset+i]+=L;r[offset+i]+=R;peak=fm_maxf(peak,fm_maxf(fm_fabsf(L),fm_fabsf(R)));}layers[m].meter=fm_maxf(peak,layers[m].meter*.975f);}for(uint32_t i=0;i<count;i++){l[offset+i]=CL(l[offset+i],-.95f,.95f);r[offset+i]=CL(r[offset+i],-.95f,.95f);float peak=fm_maxf(fm_fabsf(l[offset+i]),fm_fabsf(r[offset+i]));if(peak>pf_peak)pf_peak=peak;}}snapshot();}
float pf_layer_meter(int m){return m>=0&&m<3?layers[m].meter:0;}
float pf_voice_frequency(int m,int key){return m>=0&&m<3&&key>=0&&key<27?layers[m].v[key].target:0;}

uint32_t pf_layer_active(int m){return m>=0&&m<3?layers[m].active:0;}
uint32_t pf_layer_running(int m){return m>=0&&m<3?layers[m].running:0;}
uint32_t pf_layer_lit(int m){if(m<0||m>2||!layers[m].running)return 0;uint32_t mask=0;for(int i=0;i<PF_NV;i++){Voice *a=&layers[m].v[i];if(a->key>=0&&a->key<27&&a->env>.001f&&a->level>.001f)mask|=1u<<a->key;}return mask;}
uint32_t pf_pool_bytes(void){return sizeof layers+sizeof tort_voices+sizeof tort_block;}

uint32_t pf_arp_events(int m,int h){return m>=0&&m<3&&h>=0&&h<2?layers[m].arpEvent[h]:0;}
uint32_t pf_arp_last(int m,int h){return m>=0&&m<3&&h>=0&&h<2?layers[m].arpLast[h]:0;}

float pf_lfo_phase(int m,int slot){return m>=0&&m<3&&slot>=0&&slot<4?layers[m].lfos[slot].phase:0;}
float pf_lfo_output(int m,int slot){return m>=0&&m<3&&slot>=0&&slot<4?layers[m].lfos[slot].output:0;}

float pf_lfo_sample(int shape,float phase,float held){return lfo_wave(shape,cycle(phase),held);}
float pf_lfo_effective(int m,int parameter){return m>=0&&m<3&&parameter>=0&&parameter<PF_NPAR?layers[m].smooth[parameter]:0;}
uint32_t pf_lfo_cycles(int m,int slot){return m>=0&&m<3&&slot>=0&&slot<4?layers[m].lfos[slot].cycles:0;}

int pf_lfo_config(int m,int slot,int field){return m>=0&&m<3&&slot>=0&&slot<4&&field>=0&&field<8?layers[m].lfos[slot].cfg[field]:0;}

float pf_clock_macro(void){return layers[PF_CLOCK].clockMacro;}
float pf_clock_quartz(void){return layers[PF_CLOCK].quartzSmooth;}

float pf_clock_frequency(int voice){return voice>=0&&voice<2?layers[PF_CLOCK].v[27+voice].target:0;}
