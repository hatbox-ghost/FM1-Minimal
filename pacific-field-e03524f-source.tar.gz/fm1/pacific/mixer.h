/* SPDX-License-Identifier: GPL-3.0-only
 * Original three-channel mixer, informed by JIANT's channel-strip organization.
 * Uses the existing 120-row strip canvas; no new framebuffer allocation.
 */
static int mx_offset;
static void mx_rect(int x,int y,int w,int h,uint16_t c){cv_rect(x,y-mx_offset,w,h,c);}
static void mx_line(int x,int y,int xx,int yy,uint16_t c){cv_line(x,y-mx_offset,xx,yy-mx_offset,c);}
static void mx_text(int x,int y,const char *s,uint16_t c){cv_text(x,y-mx_offset,&FONT_XS,s,c);}
static uint16_t mx_color(int m){return (const uint16_t[]){RGB(158,196,139),RGB(232,191,118),RGB(159,198,219)}[m];}
static void mx_content(void){uint16_t bg=RGB(13,22,22),dim=RGB(111,130,126),line=RGB(48,65,61);char b[20];
 mx_text(8,4,"MIXER",RGB(228,222,199));pf_num(b,pf_page_count());pf_cat(b,"/");char total[8];pf_num(total,pf_page_count());pf_cat(b,total);mx_text(50,4,b,dim);mx_text(90,4,"GLOBAL TUNE",dim);mx_text(172,4,pf_tunings[pf_ui.par[0][20]],mx_color(pf_ui.mode));
 for(int m=0;m<3;m++){int x=5+m*78,sel=m==pf_ui.mode,level=pf_ui.par[m][7];uint16_t c=mx_color(m),border=sel?c:line;mx_rect(x,23,74,157,RGB(21,33,31));mx_line(x,23,x+73,23,border);mx_line(x,179,x+73,179,border);mx_line(x,23,x,179,border);mx_line(x+73,23,x+73,179,border);
 mx_rect(x+4,28,sel?66:2,15,sel?c:line);mx_text(x+7,29,pf_modes[m],sel?bg:c);
 float meter=pf_layer_meter(m);int lit=(int)((60.f+6.0206f*fm_log2f(fm_maxf(meter,.000001f)))*20.f/60.f);lit=pf_clip(lit,0,20);int fader=level*20/100;
 for(int k=0;k<20;k++){uint16_t cold=k<12?RGB(55,119+k*3,91):k<17?RGB(191,163,87):RGB(213,116,96);int y=126-k*4;mx_rect(x+9,y,34,3,k<fader?(pf_ui.mute[m]?line:RGB(60+k*3,81+k*3,65)):RGB(31,48,42));mx_rect(x+48,y,9,3,k<lit?cold:RGB(30,43,39));}
 mx_line(x+6,128-fader*4,x+44,128-fader*4,c);pf_num(b,level);mx_text(x+12,136,b,c);mx_text(x+39,136,"LVL",dim);
 mx_rect(x+8,152,57,2,line);mx_rect(x+36,149,1,7,dim);int pan=pf_ui.mixpan[m]*26/100;mx_rect(x+35+pan,149,3,7,c);
 mx_rect(x+8,159,57,2,line);mx_rect(x+8,159,pf_ui.par[m][27]*57/100,2,c);
 const char *state=pf_ui.mute[m]?"MUTE":pf_ui.solo[m]?"SOLO":pf_layer_active(m)?"HELD":meter>.0001f?"LIVE":"IDLE";mx_text(x+16,166,state,pf_ui.mute[m]?RGB(224,132,114):c);}
 mx_text(6,185,"SELECT: LAYER  ARP:MUTE SEQ:SOLO",dim);
 int values[4]={pf_ui.par[pf_ui.mode][7],pf_ui.mixpan[pf_ui.mode],pf_ui.par[pf_ui.mode][24],pf_ui.par[pf_ui.mode][27]};
 for(int k=0;k<4;k++){int x=4+k*59;mx_rect(x,202,56,36,RGB(28,42,36));mx_text(x+4,204,(const char*[]){"LEVEL","PAN","ECHO","ROOM"}[k],dim);pf_num(b,values[k]);mx_text(x+4,220,b,mx_color(pf_ui.mode));}
}
static void pf_draw_mixer(void){for(int band=0;band<2;band++){mx_offset=band*120;cv_begin(240,120,RGB(13,22,22));mx_content();cv_blit(0,band*120);}}
