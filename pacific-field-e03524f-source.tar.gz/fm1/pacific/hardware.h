/* SPDX-License-Identifier: GPL-3.0-only */
#include "pacific.h"
#ifndef EN_VERSION
#define EN_VERSION "PACIFIC DEV"
#endif
#define UI_SPLASH_N 2
void en_init(void){pf_init();}
void en_play(int on){pf_post(PF_PLAY,on,0);}
void en_panic(void){pf_post(PF_PANIC,0,0);}
void en_render(int32_t *out,uint32_t n,uint32_t gain_q12){float l[256],r[256];while(n){uint32_t k=n>256?256:n;pf_render(l,r,k,(float)gain_q12/4096.f*1.8f);for(uint32_t i=0;i<k;i++){out[2*i]=(int32_t)(l[i]*8388607.f);out[2*i+1]=(int32_t)(r[i]*8388607.f);}out+=2*k;n-=k;}}
