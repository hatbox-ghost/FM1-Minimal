/* SPDX-License-Identifier: GPL-3.0-only
 * Shared global-per-instrument modulation. No heap or wall clock dependencies.
 * Config: rate, depth, shape, destination, sync, key sync, phase degrees, slew.
 */
#ifndef PF_LFO_TYPE_DEFINED
typedef struct {int16_t cfg[8];float phase,held,output;uint32_t random,cycles;} PFLfo;
#endif
typedef struct {const char *name;int parameter;float range,low,high;} PFDestination;
/* Special IDs: -1 off, -2 cents, -3 stereo pan, -4 amplitude. */
static const PFDestination destinations[3][11]={
 {{"OFF",-1,0,0,0},{"TONE",0,45,0,100},{"RING",1,30,0,90},{"LPG",6,45,0,100},{"DAMP",9,40,0,100},{"STIFF",8,40,0,100},{"SPREAD",15,40,0,100},{"WIND",2,40,0,100},{"RAIN",3,40,0,100},{"PAN",-3,1,-1,1},{"AMPLITUDE",-4,1,0,1}},
 {{"OFF",-1,0,0,0},{"CUTOFF",1,45,0,100},{"OSC A LEVEL",0,50,0,100},{"PULSE WIDTH A",6,45,0,100},{"RESON",2,30,0,85},{"PITCH FINE",-2,50,-100,100},{"AMPLITUDE",-4,1,0,1},{"PAN",-3,1,-1,1},{"PULSE WIDTH B",10,45,0,100},{"NOISE",8,40,0,100},{"OSC B LEVEL",9,50,0,100}},
 {{"OFF",-1,0,0,0},{"FM INDEX",0,40,0,100},{"BRIGHTNESS",1,45,0,100},{"ORBIT",2,40,0,100},{"DRIFT",3,30,0,100},{"PITCH FINE",-2,35,-100,100},{"AMPLITUDE",-4,1,0,1},{"PAN",-3,1,-1,1},{"ECHO",24,35,0,100},{"ROOM",27,35,0,100},{"GLIDE",9,35,0,100}}};
const char *pf_lfo_destination(int m,int d){return destinations[m>=0&&m<3?m:0][d>=0&&d<11?d:0].name;}
static float lfo_random(PFLfo *a){uint32_t x=a->random?a->random:1;x^=x<<13;x^=x>>17;x^=x<<5;a->random=x;return (float)(x&65535)/32768.f-1;}
static const float lfo_beats[9]={32,16,8,4,2,1,.5f,.25f,.125f};
float pf_lfo_rate(int rate,int sync,int bpm){rate=rate<0?0:rate>100?100:rate;if(sync)return (bpm/60.f)/lfo_beats[(rate*8+50)/100];return rate==0?0:.02f*fm_exp2f(rate*.01f*9.22881869f);}
static float lfo_wave(int shape,float phase,float held){switch(shape){case 0:return sn(phase);case 1:return 1-4*fm_fabsf(phase-.5f);case 2:return 2*phase-1;case 3:return 1-2*phase;case 4:return phase<.5f?1:-1;default:return held;}}
static void lfo_reset(PFLfo *a){a->phase=0;if(a->cfg[2]==5)a->held=lfo_random(a);}
static void lfo_tick(PFLfo *a,float dt,int bpm){float next=a->phase+dt*pf_lfo_rate(a->cfg[0],a->cfg[4],bpm);if(next>=1){a->cycles+=(uint32_t)next;/* At <=12 Hz and bounded control blocks, at most one wrap. */a->held=lfo_random(a);}a->phase=next-fm_floorf(next);float phase=cycle(a->phase+a->cfg[6]/360.f);float target=lfo_wave(a->cfg[2],phase,a->held);float seconds=.003f+a->cfg[7]*.005f;a->output+=(target-a->output)*CL(dt/seconds,0,1);}
