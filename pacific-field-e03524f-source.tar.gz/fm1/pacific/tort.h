/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Kerem Kilic (Ellic Studio).
 * Prophet DSP primitives ported from keremimo/melodee. Pacific Field adapter follows.
 */
#include "tort-tables.h"
typedef struct { float value; uint8_t stage; } p5_env_t;
typedef struct {
    uint32_t phase[2];
    float z[4], triangle, sync_tail;
    int32_t noise;
    int32_t drift, filter_drift, amp_drift, env_drift;
    float filter_prev, amp_prev;
    int32_t glide_pitch, last_pcm;
    float coeff_cut, coeff_k, coeff_g[4], coeff_inv;
    uint32_t coeff_valid;
    p5_env_t filter, amp;
} p5_voice_t;

static inline  float p5_fast_blep(uint32_t ph, uint32_t inc)
{
    if (!inc) return 0.0f;
    if (ph < inc) {
        float x = (float)ph / (float)inc;
        return x + x - x * x - 1.0f;
    }
    if (ph > 0xFFFFFFFFu - inc) {
        float x = -(float)(0xFFFFFFFFu - ph) / (float)inc;
        return x * x + x + x + 1.0f;
    }
    return 0.0f;
}
static inline  float p5_fast_osc_saw(uint32_t ph, uint32_t inc)
{
    return (float)ph * (1.0f / 2147483648.0f) - 1.0f - p5_fast_blep(ph, inc);
}
static inline  float p5_fast_softclip(float x)
{
    float a=fm_fabsf(x)*128.0f;
    if(a>=1024.0f)return x<0.0f?-1.0f:1.0f;
    uint32_t i=(uint32_t)a;
    float y=P5_TANH[i]+(P5_TANH[i+1u]-P5_TANH[i])*(a-(float)i);
    return x<0.0f?-y:y;
}
#define P5_ENV_END (1.f/1024.f)
static float p5_env_tick(p5_env_t *e, int gate, const uint8_t *p,
                        uint32_t a, uint32_t d, uint32_t s, uint32_t r, int32_t variation, const uint8_t *value, int ssm, uint32_t release)
{
    if (!gate && e->stage != 0u) e->stage = 3;
    float target = (float)value[s] * (1.0f / 127.0f);
    float scale = 1.0f + (float)variation * (1.0f / 32768.0f);
    uint32_t rel = release ? release : p[P5_RELEASE_ON] ? value[r] : 16u;
    if (e->stage == 1u) {
        e->value += P5_ENV_ATK[value[a]] * scale;
        if (e->value >= 1.0f) { e->value = 1.0f; e->stage = 2; }
    } else if (ssm && e->stage >= 2u) {
        float step = P5_ENV_SSM[e->stage == 2u ? value[d] : rel] * scale;
        if (e->stage == 3u) target = 0.0f;
        e->value += fm_clampf(target - e->value, -step, step);
    } else if (e->stage == 2u) {
        e->value += (target - e->value) * fm_minf(P5_ENV_EXP[value[d]] * scale, 1.0f);
    } else if (e->stage == 3u) {
        e->value -= e->value * fm_minf(P5_ENV_EXP[rel] * scale, 1.0f);
    }
    if (e->stage == 3u && e->value < P5_ENV_END) { e->value = 0.0f; e->stage = 0; }
    return e->value;
}
static inline  float p5_lfo_wave(uint32_t phase,const uint8_t *p)
{
    float pos=(float)phase*(1.0f/4294967296.0f), y=0.0f;uint32_t n=0;
    if(p[P5_LFO_SAW]){y+=pos;n++;}
    if(p[P5_LFO_TRI]){y+=phase<0x80000000u?pos*2.0f-0.5f:1.5f-pos*2.0f;n++;}
    if(p[P5_LFO_PULSE]){y+=phase<0x80000000u?1.0f:0.0f;n++;}
    /* Division by one/two is exact in binary; only the three-wave blend
     * needs division. This runs for every wheel sample, not every voice. */
    return n==1u?y:n==2u?y*0.5f:n==3u?y/3.0f:0.0f;
}
static inline  float p5_pitch_ratio(float x)
{
    int32_t octave=(int32_t)x;if((float)octave>x)octave--;
    float pos=(x-(float)octave)*512.0f;uint32_t i=(uint32_t)pos;
    float ratio=P5_EXP2[i]+(P5_EXP2[i+1u]-P5_EXP2[i])*(pos-(float)i);
    fm_bits_t scale;scale.u=(uint32_t)(octave+127)<<23;
    return ratio*scale.f;
}
static inline  float p5_filter_core(p5_voice_t *s, float input, float cutoff, float k, float gain, int curtis)
{
    cutoff=fm_clampf(cutoff,0.0f,127.0f);
    float g,g2,g3,g4,reciprocal;
    if(s->coeff_valid && cutoff==s->coeff_cut && k==s->coeff_k){
        g=s->coeff_g[0];g2=s->coeff_g[1];g3=s->coeff_g[2];g4=s->coeff_g[3];reciprocal=s->coeff_inv;
    }else{
        uint32_t i=(uint32_t)cutoff;g=P5_TPT_G[i];
        if(i<127u)g+=(P5_TPT_G[i+1u]-g)*(cutoff-(float)i);
        g2=g*g;g3=g2*g;g4=g3*g;
        reciprocal=1.0f/(1.0f+k*g4);
        s->coeff_g[0]=g;s->coeff_g[1]=g2;s->coeff_g[2]=g3;s->coeff_g[3]=g4;
        s->coeff_cut=cutoff;s->coeff_k=k;s->coeff_inv=reciprocal;s->coeff_valid=1;
    }
    float sigma=(1.0f-g)*(g3*s->z[0]+g2*s->z[1]+g*s->z[2]+s->z[3]);
    float u=p5_fast_softclip((input*gain-k*sigma)*reciprocal);
#define P5_STAGE(j, clip) do { \
    float delta=g*(u-s->z[j]); \
    float y=s->z[j]+delta; \
    s->z[j]=fm_clampf(y+delta,-1.83105469f,1.83105469f); \
    if(fm_fabsf(s->z[j])<1e-20f)s->z[j]=0.0f; \
    u=clip(y); \
} while(0)
#define P5_LINEAR(y) (y)
    if(curtis){P5_STAGE(0,P5_LINEAR);P5_STAGE(1,P5_LINEAR);P5_STAGE(2,P5_LINEAR);P5_STAGE(3,P5_LINEAR);}
    else {P5_STAGE(0,p5_fast_softclip);P5_STAGE(1,p5_fast_softclip);P5_STAGE(2,p5_fast_softclip);P5_STAGE(3,p5_fast_softclip);}
#undef P5_LINEAR
#undef P5_STAGE
    return p5_fast_softclip(u);
}
static inline  float p5_wave(uint32_t phase, uint32_t inc, uint32_t pw, int saw, int pulse, int tri, float *triangle)
{
    if(!saw && !pulse && !tri)return 0.0f;
    float y=0.0f,a=p5_fast_osc_saw(phase,inc),square=0.0f;
    if(saw)y+=a*0.5f;
    if(pulse){square=(a-p5_fast_osc_saw(phase+pw,inc))*0.5f;y+=square;}
    if(tri){
        if(!pulse || pw!=0x80000000u)square=(a-p5_fast_osc_saw(phase+0x80000000u,inc))*0.5f;
        *triangle=fm_clampf(*triangle*(32767.0f/32768.0f)+square*(float)inc*(8.0f/4294967296.0f),-1.220703125f,1.220703125f);
        y+=*triangle*0.5f;
    }
    return y;
}
static inline  float p5_sync_fraction(uint32_t distance,uint32_t inc)
{
    return inc ? fm_minf((float)distance/(float)inc,1.0f) : 0.0f;
}
static inline  uint32_t p5_pw(float value)
{
    return (uint32_t)(fm_clampf(value,0.03125f,31743.0f/32768.0f)*4294967296.0f);
}
static inline  uint32_t p5_inc(uint32_t base,float x)
{
    if(!x)return base;
    float y=(float)base*p5_pitch_ratio(fm_clampf(x,-8.0f,6.0f));
    return (uint32_t)fm_clampf(y,1.0f,1932735232.0f);
}

static p5_voice_t tort_voices[PF_NV] EN_POOL;
static uint8_t tort_effective[56];
static struct {float ar,br,baseCut,k,gain,pwa,pwb,la,lb,ln,pae,pab,pfe,pfb,pwe,pwbm,envAmount,glide,wheelRate,wheelAmount,wheelMix,lastHz;uint32_t lfo;float wheel,pitch;uint32_t noise;} tort_block;
static void tort_note(int index,const uint8_t *p,float hz){int vintage=p[P5_VINTAGE];p5_voice_t *s=&tort_voices[index];if(s->amp.stage==0){memset(s,0,sizeof *s);s->triangle=1;s->noise=71771+index*179;s->filter_prev=tort_block.lastHz>1?tort_block.lastHz:hz;if(p[P5_RESONANCE]>=110&&!p[P5_LEVEL_A]&&!p[P5_LEVEL_B]&&!p[P5_NOISE]){s->z[0]=.5f;s->z[2]=-.5f;}}tort_block.lastHz=hz;s->amp.stage=s->filter.stage=1;s->drift=((index*71%255)-128)*vintage/1024;s->env_drift=((index*113%255)-128)*vintage/128;s->filter_drift=((index*37%255)-128)*vintage/32;s->amp_drift=((index*97%255)-128)*vintage/16;}
static float tort_noise(uint32_t *seed){uint32_t x=*seed?*seed:1;x^=x<<13;x^=x>>17;x^=x<<5;*seed=x;return (x>>8)*(1.f/16777216.f)-.5f;}
static void tort_prepare(const uint8_t *p,const float *effective,const int *base){memcpy(tort_effective,p,56);int curtis=!!p[P5_FILTER_REV];
 float cut=CL(p[P5_CUTOFF]+(effective[1]-base[1])*1.27f,0,127),res=CL(p[P5_RESONANCE]+(effective[2]-base[2])*1.27f,0,127);
 tort_block.ar=fm_exp2f(((int)p[P5_FREQ_A]/2-12)/12.f);tort_block.br=fm_exp2f(((int)p[P5_FREQ_B]/2-12)/12.f+p[P5_FINE_B]/1536.f);
 tort_block.baseCut=(1618+cut*236+(curtis?0:fm_minf(127-cut,66)*38))/256.f;tort_block.k=res*(curtis?19200.f:18800.f)/(127.f*4096.f);tort_block.gain=1-res*(curtis?100:45)/32768.f;
 tort_block.pwa=CL((p[P5_PW_A]+(effective[6]-base[6])*1.27f)/127.f,.032f,.968f);tort_block.pwb=CL((p[P5_PW_B]+(effective[10]-base[10])*1.27f)/127.f,.032f,.968f);
 tort_block.la=CL((p[P5_LEVEL_A]+(effective[0]-base[0])*1.27f)/127.f,0,1);tort_block.lb=CL((p[P5_LEVEL_B]+(effective[9]-base[9])*1.27f)/127.f,0,1);tort_block.ln=CL((p[P5_NOISE]+(effective[8]-base[8])*1.27f)/127.f,0,1);
 tort_block.pae=p[P5_POLY_ENV]*85/4096.f;tort_block.pab=p[P5_POLY_B]*35/4096.f;tort_block.pfe=p[P5_POLY_ENV]*226/256.f;tort_block.pfb=p[P5_POLY_B]*226/256.f;tort_block.pwe=p[P5_POLY_ENV]*64/32768.f;tort_block.pwbm=p[P5_POLY_B]*258/32768.f;tort_block.envAmount=p[P5_ENV_FILTER]*165/256.f;
 tort_block.glide=p[P5_GLIDE]?1.f/(PF_SR*(.003f+4*fm_exp2f(p[P5_GLIDE]/16.f)/256.f)):1;
 float v=p[P5_LFO_RATE],ex=-3.1005f+.05387f*v;if(v>100)ex+=(6.2146081f-(-3.1005f+.05387f*127))*((v-100)/27)*((v-100)/27);if(v<20)ex-=(-3.1005f+3.8167128f)*((20-v)/20)*((20-v)/20);tort_block.wheelRate=fm_expf(ex)/PF_SR;
 tort_block.wheelAmount=p[P5_LFO_INITIAL]?fm_exp2f(fm_log2f(p[P5_LFO_INITIAL]/127.f)*1.737f):0;tort_block.wheelMix=p[P5_WHEEL_MIX]/127.f;
}
static void tort_wheel_sample(void){tort_block.lfo+=(uint32_t)(tort_block.wheelRate*4294967296.f);float noise=tort_noise(&tort_block.noise);tort_block.wheel=(p5_lfo_wave(tort_block.lfo,tort_effective)*(1-tort_block.wheelMix)+noise*tort_block.wheelMix)*tort_block.wheelAmount;tort_block.pitch=p5_pitch_ratio(tort_block.wheel*470.f/1200.f);}
static float tort_sample(int index,float hz,int gate){p5_voice_t *s=&tort_voices[index];const uint8_t *p=tort_effective;int curtis=!!p[P5_FILTER_REV];
 float fe=p5_env_tick(&s->filter,gate,p,P5_ATTACK_FILTER,P5_DECAY_FILTER,P5_SUSTAIN_FILTER,P5_RELEASE_FILTER,s->env_drift,p,!curtis,0);float amp=p5_env_tick(&s->amp,gate,p,P5_ATTACK_AMP,P5_DECAY_AMP,P5_SUSTAIN_AMP,P5_RELEASE_AMP,s->env_drift,p,0,0);
 if(s->filter.stage==0&&p[P5_RESONANCE]>=110&&!p[P5_LEVEL_A]&&!p[P5_LEVEL_B]&&!p[P5_NOISE]){s->z[0]=.5f;s->z[2]=-.5f;}
 if(s->filter_prev<1)s->filter_prev=hz;s->filter_prev+=(hz-s->filter_prev)*tort_block.glide;hz=s->filter_prev;
 float mismatch=fm_exp2f(s->drift/1200.f);float fa=hz*tort_block.ar*mismatch,fb=(p[P5_KEY_B]?hz*tort_block.br:32.7032f*fm_exp2f(p[P5_FREQ_B]*108.f/(127*12)+p[P5_FINE_B]/1536.f))/mismatch;if(p[P5_LOW_B])fb*=1.f/128;
 uint32_t ia=(uint32_t)CL(fa/PF_SR*4294967296.f,1,1932735232.f),ib=(uint32_t)CL(fb/PF_SR*4294967296.f,1,1932735232.f);float w=tort_block.wheel;
 if(p[P5_WHEEL_FREQ_B])ib=(uint32_t)fm_minf(ib*tort_block.pitch,1932735232.f);
 float b=p5_wave(s->phase[1],ib,p5_pw(tort_block.pwb+(p[P5_WHEEL_PW_B]?w:0)),p[P5_SAW_B],p[P5_PULSE_B],p[P5_TRI_B],&s->triangle),bn=b*2;
 if(p[P5_POLY_FREQ])ia=p5_inc(ia,fe*tort_block.pae+bn*tort_block.pab);if(p[P5_WHEEL_FREQ_A])ia=(uint32_t)fm_minf(ia*tort_block.pitch,1932735232.f);
 uint32_t pw=p5_pw(tort_block.pwa+(p[P5_POLY_PW]?fe*tort_block.pwe+b*tort_block.pwbm:0)+(p[P5_WHEEL_PW_A]?w:0));float unused=0;
 float a=p5_wave(s->phase[0],ia,pw,p[P5_SAW_A],p[P5_PULSE_A],0,&unused)+s->sync_tail;s->sync_tail=0;uint32_t na=s->phase[0]+ia,nb=s->phase[1]+ib;
 if(p[P5_SYNC]&&nb<s->phase[1]&&ib){float frac=p5_sync_fraction(0u-s->phase[1],ib),remain=1-frac;uint32_t at=s->phase[0]+(uint32_t)(ia*frac);float before=p5_wave(at,ia,pw,p[P5_SAW_A],p[P5_PULSE_A],0,&unused),after=p5_wave(0,ia,pw,p[P5_SAW_A],p[P5_PULSE_A],0,&unused);float jump=(after-before)*.5f;a+=jump*remain*remain;s->sync_tail=-jump*frac*frac;na=(uint32_t)(ia*remain);}s->phase[0]=na;s->phase[1]=nb;
 float input=p5_fast_softclip(a*tort_block.la+b*tort_block.lb+tort_noise((uint32_t*)&s->noise)*tort_block.ln);
 float keytrack=(fm_log2f(fm_maxf(hz,1)/65.4064f))*p[P5_KEY_FILTER]*7.01f;float cutoff=tort_block.baseCut+keytrack+fe*tort_block.envAmount+s->filter_drift/256.f;if(p[P5_POLY_FILTER])cutoff+=fe*tort_block.pfe+bn*tort_block.pfb;if(p[P5_WHEEL_FILTER])cutoff+=w*112;
 s->amp_prev=amp;return p5_filter_core(s,input,cutoff,tort_block.k,tort_block.gain,curtis)*amp*(1+s->amp_drift/32768.f)*2;
}
